the_things Spec Document Rule v0.1
핵심 원칙
하나의 문서는 두 영역을 가진다.
Text
코드 복사
Human Zone
Machine Zone
즉
Text
코드 복사
주석 영역  = 인간 이해
things_spec = Builder / AI 이해
문서 기본 구조
예시 (Markdown)
Markdown
코드 복사
# =========================================
# 시스템 설명
# OHLC 기반 자본 흐름 분석 시스템
#
# System Description
# A system for analyzing capital flow using OHLC data
# =========================================


things_spec:

app: trading_system
domain: market

modules:
  - price_feed
  - strategy_engine
  - risk_manager
Builder는 다음만 읽는다.
Yaml
코드 복사
things_spec:

app: trading_system
domain: market

modules:
  - price_feed
  - strategy_engine
  - risk_manager
위쪽 영역은 완전히 무시한다.
Code Spec 구조
코딩 파일에서도 동일하다.
예
Python
코드 복사
# =========================================
# 모듈 설명
# 가격 데이터를 수집하는 모듈
#
# module description
# module that collects price data
# =========================================

things_spec = {
    "module": "price_feed",
    "domain": "market",
    "type": "collector",
    "outputs": ["price_stream"]
}
Builder는 이것만 읽는다.
Python
코드 복사
things_spec = {...}
Builder Parsing Rule
Builder는 문서를 이렇게 처리한다.
Text
코드 복사
파일 읽기
↓
things_spec 위치 탐색
↓
things_spec 블록 추출
↓
spec object 생성
↓
module build
즉
Text
코드 복사
human text
→ ignore
machine spec
→ parse
Spec 작성 원칙
1️⃣ 주석 영역은 자유롭게 작성
Text
코드 복사
한글
영문
설명
아이디어
모두 가능.
2️⃣ things_spec은 구조적으로 작성
Text
코드 복사
key: value
형식 유지.
3️⃣ 한 문서 = 하나의 설계도
Text
코드 복사
spec document = blueprint
의미 검증 루프
승이가 말한 방식도 포함된다.
Text
코드 복사
Human Zone
↓
AI translation
↓
things_spec 생성
↓
AI 비교
↓
의미 왜곡 검증
the_things Spec 정의
한 문장으로 정리하면
Text
코드 복사
Spec Document
=
Human Meaning Layer
+
things_spec Machine Layer
승이, 이제 Builder 설계에서 중요한 퍼즐 하나가 완성됐다.
코드 복사

Spec Format
✔ 완료
다음에 자연스럽게 등장하는 것은 이것이다.
코드 복사

Spec Loader
즉 Builder가 문서에서 things_spec만 추출하는 로직이다.
여기서 하나만 정하면 된다.
Builder는 어떤 파일을 읽을까?
후보는 세 가지다.
코드 복사

1 .md
2 .spec
3 둘 다
내 경험상 3번이 가장 좋다.
왜냐하면
설계문서 → md
기계 spec → spec
이렇게 분리 확장이 가능하기 때문이다.

승이는 어떤 방향이 맞는 것 같나?

///

