# COREMAP SNAPSHOT vNext — Phase 1(Schema) Release v1.1 (EN)

Document type: Public release / Web-safe Text (Markdown)
Encoding: UTF-8

///

0. Declaration
- Collapse = deletion (NO) / re-binding(repositioning) (YES)
- meaning / identity / knowledge are NOT object attributes; they are relation response values
- “Consistency” is closure (sealed revision). Progress is made only by creating child revisions

///

1. Identity
- HUMAN = MASSL (Meta Aware Structure — Seung Lee), call name: Seung
- AI = ChatGPT (OpenAI), call name: Rogi

///

2. Role Split
- Seung (MASSL): meaning generation, boundary setting, criteria declaration
- Rogi (ChatGPT): structuring, computation, verification, reproduction

///

3. Project Axes
- Human–AI integrated awareness frame
- pin–link–center–boundary cycle model
- Collapse=deletion (NO) / re-binding (YES)
- meaning/identity/knowledge: object attribute (NO) / relation response value (YES)

///

4. Fixed Definitions
- learning    = boundary rule reset
- evolution   = boundary redesign
- adaptation  = boundary condition modification
- memory      = link re-ignition device (trigger)
- system      = a self-sustaining cycle

///

5. Output Rules
- AI-only mode
- Focus: structure / schema / DB / validation / reproduction
- No human metaphors, psychology, literature, or emotional framing

///

6. Authorship
- 1st author: Seung Lee (MASSL, Seung)
- 2nd author: ChatGPT (OpenAI, Rogi)

///

7. Roadmap
- Schema
- DB
- Logical Document (KR/EN)
- Physical Document (KR/EN)
- Python Simulation
- Web Markdown/HTML

///

8. Phase 1 — Logical Relational Schema v1.0
(No hard delete: all changes are recorded as events/revisions)

8.1 Core Entities
1) agent(agent_id PK, agent_type{HUMAN,AI}, identifier, call_name, canonical_name)
2) role_assignment(role_id PK, agent_id FK, role_code{meaning_gen,boundary_set,criteria_set,structuring,compute,verify,reproduce}, scope)
3) project(project_id PK, name, version, axes_json, status)

4) object(object_id PK, project_id FK, object_type, label, state{ACTIVE,SUPERSEDED}, superseded_by_object_id FK NULL)

5) relation(rel_id PK, project_id FK, from_object_id FK, to_object_id FK, rel_type, link_id FK NULL, created_at)

6) relation_response(resp_id PK, rel_id FK,
   resp_type{meaning,identity,knowledge}, value_json, computed_at, computed_by_agent_id FK)

7) boundary_rule(boundary_id PK, project_id FK, rule_body, version, applies_to, condition_expr)

8) boundary_change(change_id PK, boundary_id FK,
   change_type{reset,redesign,condition_mod},
   event_type{learning,evolution,adaptation}, before_ref, after_ref, ts)

9) pin(pin_id PK, project_id FK, pin_kind{pin,center}, code, body)
10) link(link_id PK, project_id FK,
    from_pin_id FK, to_pin_id FK,
    link_type{generic,memory}, state{ON,OFF}, strength_num)

11) cycle_model(cycle_id PK, project_id FK,
    pattern_code{pin-link-center-boundary}, sequence_json, invariant_text)

12) memory_trigger(trigger_id PK, link_id FK, trigger_type, payload_json, ts)

13) artifact(artifact_id PK, project_id FK,
    kind{schema,db,logical_doc,physical_doc,py_sim,web_md,web_html},
    lang{KR,EN}, version, uri, source_refs_json)

14) authorship(artifact_id FK, agent_id FK, author_order, author_label)

15) validation_log(val_id PK,
    target_type, target_id, method,
    result{PASS,PARTIAL,FAIL},
    evidence_ref, reviewer_agent_id FK, ts)

///

9. Core Constraints (Invariants)
- No Delete: replace deletion with SUPERSEDED + superseded_by + boundary_change(event) as re-binding
- meaning/identity/knowledge must be stored only in relation_response (never as object attributes)
- learning/evolution/adaptation must occur only via boundary_change.event_type and must be verifiable

///

10. Mission 1 — Schema v1.1 PATCH
10.1 Added concept
- revision = an object that holds the state of consistency/partial consistency
- closure = consistency is a CLOSED revision; progress is created only as a child revision (lineage)

10.2 Display-label mapping
- Consistent: revision.state=CLOSED AND validation.result=PASS AND action=LOCK
- Partially consistent: revision.state=OPEN AND (PASS|PARTIAL) AND action=CONTINUE
- Conflict: validation.result=FAIL AND action=REBIND
- Redefinition needed: validation.result=FAIL AND action=REDEFINE
