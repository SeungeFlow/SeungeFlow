# COREMAP IO Language v1.0 (EN)
Document type: Human ↔ AI shared input language (chat input + file upload) / Web-safe Markdown
Encoding: UTF-8
Goal: Human-readable, while staying deterministic for AI parsing/validation/artifact generation.

///

0. Core principles
- Separate intent (what) from method (how).
- Treat chat and documents with the same packet format. (chat = single packet, upload = packet + file list)
- Changes are recorded as PATCH (add/replace), not deletion.
- Every output must include a STATUS (validation-driven).

///

1. Packet format (COREMAP-PACKET)
- One line = one field
- Field format = KEY: VALUE
- Section delimiter = '///'
- Comment = text after '#'
- Multi-line content goes into the BODY under the proper section.

///

2. Header (required 6 fields)
PROTOCOL: COREMAP-IO
LANG: EN
VERSION: 1.0
MODE: CHAT | FILE
INTENT: ASK | DEFINE | PATCH | VALIDATE | RUN | PUBLISH
PROJECT: <project_id or name>

(Optional but recommended)
REV: <rev_id>
TARGET: <target_kind/target_id>
TS: <ISO-8601 timestamp>

///

3. Body sections (fixed order)
CONTEXT:
- background assumptions (short)

INPUT:
- the core content from the human (question/definition/requirements)

FILES: (MODE=FILE only)
- declare uploaded files in a human-readable “manifest”

RULES:
- invariants/constraints (e.g., No Delete, relation_response-only)

REQUEST:
- tasks the AI must perform (artifacts, validation, transformation)

OUTPUT:
- desired output format(s) (Markdown, SQL, JSON, ZIP)
- desired filenames/folder layout (if any)

///

4. FILES manifest (recommended)
- FILE: <name> | TYPE: <md/sql/pdf/zip/...> | ROLE: <phase1/phase2/layer7/...> | NOTE: <short>

///

5. AI response minimum contract
- AI should always include these blocks:
[INPUT] faithful reproduction of the user INPUT
[MY JUDGMENT] structuring/validation/conflict detection/plan
[STATUS] ✅CONSISTENT / ⚠️PARTIAL / ❌CONFLICT / 🔄REDEFINE

(If artifacts exist)
ARTIFACTS:
- FILE: <path or name> | DESC: <short>

///

6. Example A: chat question
```text
PROTOCOL: COREMAP-IO
LANG: EN
VERSION: 1.0
MODE: CHAT
INTENT: ASK
PROJECT: COREMAP vNext
///
CONTEXT:
Before Phase 2, confirm the status-label logic is consistent.
///
INPUT:
Does the revision + validation_log status_label computation violate “Consistency = Closure”?
///
RULES:
No Delete
Consistency = Closure
///
REQUEST:
Validate logical conflicts; if conflict, propose a PATCH.
///
OUTPUT:
Markdown
```

///

7. Example B: file upload validation
```text
PROTOCOL: COREMAP-IO
LANG: EN
VERSION: 1.0
MODE: FILE
INTENT: VALIDATE
PROJECT: COREMAP vNext
REV: rev-Phase2-001
///
CONTEXT:
Check whether Phase2 SQL and docs inside a ZIP are inconsistent.
///
FILES:
FILE: coremap_phase2_migration.sql | TYPE: sql | ROLE: phase2 | NOTE: physical schema
FILE: coremap_phase2_seed.sql | TYPE: sql | ROLE: phase2 | NOTE: sample seed
FILE: Phase2_Release_EN.md | TYPE: md | ROLE: docs | NOTE: EN doc
///
RULES:
No Delete
Relation Response Only
Boundary-Event Only
///
REQUEST:
1) DDL executability  2) doc-code mismatch detection  3) PASS/PARTIAL/FAIL decision
///
OUTPUT:
Markdown + (if needed) patched SQL file
```

///

8. Minimal checklist (for humans)
- Did you provide MODE/INTENT/PROJECT?
- Did you declare invariants in RULES?
- Did you state deliverables in REQUEST?
- Did you specify OUTPUT format/filenames (if needed)?
