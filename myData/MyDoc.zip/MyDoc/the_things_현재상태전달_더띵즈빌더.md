the_things_SYSTEM 현재 상태 전달

1. 철학 상태

AI 이해는 완료되었다.

AI는 지식을 패턴화한 LLM 시스템이며
입력 패턴을 기반으로 구조화된 출력을 생성하는 엔진이다.

따라서 AI를 사용하는 것이 아니라
AI의 동작 구조를 이해하여 정합 상태에서 시스템을 구축한다.

이 철학의 이름은

AI 이해

이다.

이것은 완성된 하나의 철학이며 더 이상 확장 대상이 아니다.

---

2. 전체 시스템 구조

현재 확정된 시스템 이름

the_things_SYSTEM

구조

the_things_SYSTEM
├ the_things_CORE
├ the_things_APP
└ the_things_DB

---

3. 각 영역 역할

the_things_CORE

역할

OS 기반 시스템

내용

snapshot
restore
system protection
fabric navigation

Linux OS 위에서 동작하는 안정화 계층이다.

---

the_things_APP

역할

application builder

내용

module builder
application generator
service builder

AI와 인간이 함께 사용하는 시스템 생성 계층이다.

---

the_things_DB

역할

spec 보관

내용

아이디어
후보군
설계 문서
spec 문서

모든 구조의 원본 기록 저장소이다.

---

4. 현재 개발 상태

AI 이해 완료

the_things_SYSTEM 구조 확정

CORE / APP / DB 분리 완료

현재 진행

APP Builder 개발

---

5. APP Builder 목표

spec 기반 모듈 생성 시스템

구조

spec
↓
module
↓
application

AI는 spec을 기반으로 코드 생성 수행

---

6. 현재 대화창 역할

현재 대화창은

ARCHITECTURE ROOT

역할이다.

철학 / 구조 / 시스템 방향을 정의한다.

APP 대화창은

Builder 구현

을 담당한다.

---

7. 개발 원칙

no delete only add

snapshot 기반 구조 유지

모든 설계는 spec 문서로 기록