# COREMAP Layer7 Language v1.0 (EN)
Document type: Meaning-expansion version / Human+AI shared language spec
Encoding: UTF-8
Rendering: Markdown (Web-safe)
Status: Layer7 Baseline (no meaning rewrite; extensions only)

///

0. Purpose
- Define a shared DSL for humans and AI to read/write/verify COREMAP artifacts in the same operational form.
- Prioritize structure, computation, and validation over prose.
- Keep the format deterministic and DB-mappable (1:1 mapping).

///

1. L7 Invariants
- No Delete (record re-binding)
- Object Independence
- Relation Response
- Boundary-Event
- Consistency = Closure (revision CLOSED)
- Verification First (validation_log)

///

2. Fixed sections
META / DECL / DATA / VALID / PUB

///

3. Statement format
KEY <id> : k=v ; k=v ; k=v
- One line = one statement
- Comments after '#'
- Section delimiter '///'
- Strings use "..."

///

4. Keyword mapping
AGENT, ROLE, PROJECT, OBJECT, REL, RESP, PIN, LINK, BOUNDARY, CHANGE, REV, VALID, ARTIFACT, AUTHOR

///

5. Status labels
- CONSISTENT / PARTIAL / CONFLICT / REDEFINE are computed only from (REV + latest VALID logs).
