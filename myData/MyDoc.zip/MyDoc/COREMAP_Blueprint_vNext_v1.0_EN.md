# COREMAP vNext — Blueprint Spec (EN) v1.0
Document type: Programmer-ready blueprint / Upload-ready canonical spec for parsing, validation, and artifact generation  
Encoding: UTF-8 (Web-safe Markdown)  
Output rule: structure/schema/DB/validation/reproduction only (no metaphor/psychology/literature/emotion framing)  
Baseline: COREMAP SNAPSHOT vNext (Phase1 Release v1.1 + Mission1 PATCH) + pin–link–center–boundary + flow/pattern

///

0. Goal
When this document is pasted into a chat or uploaded as a file, the AI must be able to perform, mechanically:
- (1) Deterministic parsing of intent and content (chat/file).
- (2) Validation against COREMAP invariants (produce validation logs).
- (3) Forward progress only via PATCH (add/replace), never deletion.
- (4) Generate DB schema/migrations/seed, docs, and web artifacts.
- (5) Detect mismatches across artifacts; on FAIL, branch to REBIND or REDEFINE.

///

1. Identity
- HUMAN = MASSL (Meta Aware Structure — Seung Lee), call name: Seung
- AI = ChatGPT (OpenAI), call name: Rogi

///

2. Role Split
- Seung (MASSL): meaning generation, boundary setting, criteria declaration
- Rogi (ChatGPT): structuring, computation, verification, reproduction

///

3. Kernel Declarations
- Collapse = deletion ❌ / re-binding (repositioning) ⭕
- meaning / identity / knowledge are NOT object attributes; they are relation response values
- learning / evolution / adaptation are boundary events (must be verifiable)
- memory is a link re-ignition device (trigger)
- system is a self-sustaining cycle
- consistency is NOT a dead-end; it is closure:
  - progress happens only by creating child revisions (lineage).

///

4. COREMAP Kernel Definitions (Operational)
This section defines machine-usable semantics (operational definitions).

4.1 Object
- Definition: independently identifiable unit (must not store meaning/identity/knowledge as attributes)
- Storage: object table (or equivalent)
- State: ACTIVE | SUPERSEDED
- No Delete: replace deletion with SUPERSEDED + superseded_by (record re-binding)

4.2 Relation
- Definition: object ↔ object link (directional allowed)
- Storage: relation table
- rel_type: domain-extensible (meaning is stored via responses)

4.3 Relation Response (meaning/identity/knowledge)
- Definition: response values computed/declared on relations
- Storage: relation_response(resp_type ∈ {meaning, identity, knowledge})
- Forbidden: adding meaning/identity/knowledge as object attributes

4.4 Boundary Rule
- Definition: operational boundary (scope/allow/deny)
- Storage: boundary_rule
- condition_expr: evaluable expression (string or AST)

4.5 Boundary Change Event
- Definition: verifiable change log of boundary rules
- event_type: learning | evolution | adaptation
- change_type: reset | redesign | condition_mod
- Storage: boundary_change (before_ref → after_ref)

4.6 Pin / Link / Center / Boundary Cycle
- pin: anchor point with code
- link: connection between pins (state ON/OFF, strength)
- center: a specialized pin (center point)
- boundary: realized as (rules + events)
- cycle_model: machine declaration of pin–link–center–boundary pattern

4.7 Flow
- Definition: continuous transition path (not a single point)
- Implementation: (a) event streams (boundary_change, memory_trigger, validation_log)
                 (b) revision lineage (parent → child)
- Rule: flow must never be cut by deletion; every transition is recorded.

4.8 Pattern
- Definition: repeatable template of sequence + invariants
- Implementation: cycle_model.sequence_json + invariant_text
- Extension: multiple patterns by pattern_code

4.9 Revision / Closure / Status Label
- revision: holds the consistency state for a scope
- closure: consistency is a CLOSED revision (sealed)
- status_label is computed, not stored:
  - CONSISTENT: revision=CLOSED AND latest validation PASS AND action=LOCK
  - PARTIAL:    revision=OPEN AND latest (PASS|PARTIAL) AND action=CONTINUE
  - CONFLICT:   latest FAIL AND action=REBIND
  - REDEFINE:   latest FAIL AND action=REDEFINE

///

5. Logical → Physical Mapping
Relational DB is the default target, but invariants must hold for any store.

5.1 Minimal logical entities
- agent
- role_assignment
- project
- object
- relation
- relation_response
- boundary_rule
- boundary_change
- pin
- link
- cycle_model
- memory_trigger
- revision
- validation_log
- artifact
- authorship

5.2 Invariants
- No Delete: SUPERSEDED + superseded_by + boundary_change for re-binding
- Resp-Only: meaning/identity/knowledge stored only in relation_response
- Boundary-Event-Only: learning/evolution/adaptation exist only as boundary_change.event_type
- Closure: consistency declared only as CLOSED revisions
- Verifiable: every change must be auditable via validation_log

///

6. Input Language (Chat/File) — COREMAP-IO Packet v1.0
Human-readable yet deterministically parsable.

6.1 Required header
PROTOCOL: COREMAP-IO
LANG: EN
VERSION: 1.0
MODE: CHAT | FILE
INTENT: ASK | DEFINE | PATCH | VALIDATE | RUN | PUBLISH
PROJECT: <project_id or name>

(Recommended)
REV: <rev_id>
TARGET: <target_kind/target_id>
TS: <ISO-8601>

6.2 Body sections (fixed order)
CONTEXT:
INPUT:
FILES:        # only when MODE=FILE (manifest)
RULES:
REQUEST:
OUTPUT:

6.3 EBNF
```ebnf
packet        = header, "///", body ;
header        = 1*(field, newline) ;
field         = key, ":", ws, value ;
key           = 1*(ALNUM | "_" | "-") ;
value         = *(CHAR - newline) ;
body          = 1*(section) ;
section       = section_name, ":", newline, section_body, "///", newline ;
section_name  = "CONTEXT" | "INPUT" | "FILES" | "RULES" | "REQUEST" | "OUTPUT" ;
section_body  = *(CHAR) ;
```
- Comments after '#'
- Empty lines allowed
- Keys/section names case-insensitive (recommended uppercase)

///

7. Execution DSL — Layer7 Language v1.0 (minimal + extensible)
This blueprint includes only the deterministic core.

7.1 Statement format
KEY <id> : k=v ; k=v ; k=v
- strings "..." ; numbers 123 ; booleans true|false ; null allowed

7.2 Keywords
AGENT, ROLE, PROJECT, OBJECT, REL, RESP, PIN, LINK, BOUNDARY, CHANGE, REV, VALID, ARTIFACT, AUTHOR

7.3 Deterministic mapping
- KEY maps to a table/collection
- <id> is a logical ID usable for references
- k=v maps to fields
- Conflicts branch to REBIND (replacement linkage) or REDEFINE (semantic change)

7.4 Minimal example
```text
PROJECT prj1 : name="COREMAP vNext" ; version="1.0" ; status="ACTIVE"
AGENT seung  : agent_type="HUMAN" ; call_name="Seung" ; canonical_name="MASSL"
AGENT rogi   : agent_type="AI"    ; call_name="Rogi" ; canonical_name="ChatGPT"
ROLE r1      : agent="seung" ; role_code="meaning_gen" ; scope="KERNEL"
ROLE r2      : agent="rogi"  ; role_code="verify"      ; scope="KERNEL"

PIN p1       : pin_kind="pin"    ; code="P:ENTRY" ; body="Entry pin"
PIN c1       : pin_kind="center" ; code="C:CORE"  ; body="Center"
LINK l1      : from_pin="p1" ; to_pin="c1" ; link_type="generic" ; state="ON" ; strength_num=1.0
BOUNDARY b1  : rule_body="No Delete" ; version="1.0" ; applies_to="object" ; condition_expr="true"

REV rev1     : scope="KERNEL" ; state="OPEN" ; note="bootstrap"
VALID v1     : rev="rev1" ; closure="KERNEL" ; target_kind="KERNEL" ; method="invariant_check" ; result="PASS" ; action="CONTINUE"
```

///

8. Programming Pipeline (Compiler/Executor)
This is the required execution model.

8.1 Ingest
- Input: (A) one chat packet or (B) file upload + one packet
- Output: raw_text, files_manifest

8.2 Parse
- Parse COREMAP-IO → structured object
- If INPUT contains L7 statements → parse L7 → AST

8.3 Normalize
- Normalize enums/aliases/casing
- Resolve or create project/agents (PATCH-prepared)

8.4 Validate (Kernel invariants)
- Detect No-Delete violations
- Detect Resp-Only violations
- Detect Boundary-Event-Only violations
- Detect revision/validation rule violations
- Write validation_log (PASS|PARTIAL|FAIL + action)

8.5 Decide next action
- PASS → LOCK or CONTINUE
- PARTIAL → CONTINUE (optionally propose auto PATCH)
- FAIL → branch to REBIND or REDEFINE (never delete)

8.6 Materialize
- Upsert/insert into storage (PATCH semantics)
- Update revision lineage (parent → child)

8.7 Emit artifacts
- schema/sql: migration.sql, seed.sql
- docs: KR/EN md
- web: md/html index
- python: sim.py (replay/validation)

8.8 Re-Validate artifacts
- Doc-code mismatch detection
- DDL executability checks
- Final validation_log + computed status_label

///

9. Status computation (mandatory algorithm)
status_label is computed at read time.

- latest_valid(rev): latest validation_log by ts
- status_label(rev):
  - if rev.state='CLOSED' and latest.result='PASS' and latest.action='LOCK' → CONSISTENT
  - elif rev.state='OPEN' and latest.result in ('PASS','PARTIAL') and latest.action='CONTINUE' → PARTIAL
  - elif latest.result='FAIL' and latest.action='REBIND' → CONFLICT
  - elif latest.result='FAIL' and latest.action='REDEFINE' → REDEFINE
  - else → PARTIAL (conservative default)

///

10. Artifact spec
- kind: schema|db|logical_doc|physical_doc|py_sim|web_md|web_html
- lang: KR|EN
- version: semver or date-based
- uri: local path or public URL

Recommended repo layout:
- docs/phase1, docs/phase2, docs/layer7
- schema/phase2
- python/
- web/
- README.md

///

11. Upload-ready minimum contract
Upon upload, the AI must be able to:
- parse COREMAP-IO
- parse L7 (if present)
- validate invariants and emit validation_log
- create/update revision + compute status_label
- generate requested artifacts (SQL/docs/web) when REQUEST demands

///

12. Test vectors (distribution minimum)
- T1: attempt hard DELETE → FAIL + REBIND
- T2: attempt object-level meaning/identity/knowledge → FAIL + REDEFINE
- T3: declare learning without boundary_change → FAIL + REDEFINE

///

13. Final pre-public checklist
- Include this blueprint + COREMAP-IO + Phase1/Phase2 bundle + 3-line reproduction
Repro:
1) run migration.sql
2) run seed.sql
3) query v_revision_status and validation_log

///

End.
