Node:
  id: ROOT-001
  title: Structure-First Principle
  layer: 0
  type: concept
  created_at: 2026-02-15

  description: >
    이 시스템의 출발점은 지식이 아니라 구조이다.
    내용은 변하지만 구조는 유지된다.
    모든 기록, 개념, 관계는 구조 위에만 적재된다.

  links:
    parents: []
    children: []
    related: []

  tags:
    - foundation
    - ontology
    - system-core

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: First principle extracted from dialogue foundation

Node:
  id: ROOT-002
  title: Relation-Driven Reality
  layer: 0
  type: concept
  created_at: 2026-02-15

  description: >
    이 시스템에서 실체는 노드가 아니라 관계다.
    의미는 개념 자체가 아니라 연결에서 발생한다.
    변화는 노드가 아니라 링크에서 일어난다.

  links:
    parents: [ROOT-001]
    children: []
    related: []

  tags:
    - ontology
    - relation
    - graph-core

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: Extracted as structural stabilizer of ROOT layer

Node:
  id: ROOT-003
  title: Time-as-Change-Index
  layer: 0
  type: concept
  created_at: 2026-02-15

  description: >
    시간은 독립적인 실체가 아니라 변화의 인덱스다.
    이 시스템에서 시간은 사건의 순서와 구조 변화를 기록하는 좌표이며,
    노드 자체가 아니라 관계 변화의 축으로 존재한다.

  links:
    parents: [ROOT-001, ROOT-002]
    children: []
    related: []

  tags:
    - ontology
    - time
    - dynamics
    - ordering

  confidence: 0.96

  history:
    - timestamp: 2026-02-15
      action: created
      note: Extracted as temporal axis for structure evolution

Node:
  id: PHYS-001
  title: Interaction-First Physics
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리 세계의 기본 단위는 입자나 물질이 아니라 상호작용이다.
    장, 힘, 교환, 결합은 모두 관계의 물리적 표현이며,
    물체는 상호작용 패턴의 안정 상태로 이해된다.

  links:
    parents: [ROOT-001, ROOT-002, ROOT-003]
    children: []
    related: []

  tags:
    - physics
    - interaction
    - fields
    - ontology

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: First physical ontology node — world defined by interaction, not object

Node:
  id: PHYS-002
  title: Field-Primary Ontology
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 실재의 1차 단위는 입자가 아니라 장이다.
    입자는 장의 국소적 안정 패턴이며,
    상호작용은 장의 구조 변화로 표현된다.

  links:
    parents: [PHYS-001]
    children: []
    related: []

  tags:
    - physics
    - field
    - particle
    - quantum

  confidence: 0.95

  history:
    - timestamp: 2026-02-15
      action: created
      note: Establish field ontology before particle ontology

Node:
  id: PHYS-003
  title: Gradient Generates Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    모든 물리적 변화는 구배(gradient)에서 시작된다.
    균일한 장에서는 변화가 없다.
    차이가 생기는 순간,
    에너지 흐름과 운동이 발생한다.

  links:
    parents: [PHYS-002]
    children: []
    related: [PHYS-001]

  tags:
    - physics
    - gradient
    - motion
    - energy

  confidence: 0.96

  history:
    - timestamp: 2026-02-15
      action: created
      note: Motion defined as gradient-driven change in field structure

Node:
  id: PHYS-004
  title: Systems Move Toward Energy Minimum
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 시스템은 가능한 한 낮은 에너지 상태로 이동한다.
    이는 안정성의 조건이며,
    구배가 존재할 때 흐름이 발생하는 이유다.
    운동은 에너지 최소화를 향한 과정이다.

  links:
    parents: [PHYS-003]
    children: []
    related: [PHYS-002, PHYS-001]

  tags:
    - physics
    - stability
    - energy
    - equilibrium

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: Stability defined as energy-minimized configuration

Node:
  id: PHYS-005
  title: Equilibrium Is Dynamic, Not Static
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    평형은 정지 상태가 아니다.
    힘과 에너지의 흐름이 서로 상쇄되어
    거시적으로 변화가 없어 보이는 상태일 뿐이다.
    미시적으로는 상호작용과 교환이 계속 일어난다.
    따라서 안정은 멈춤이 아니라
    균형 잡힌 지속이다.

  links:
    parents: [PHYS-004]
    children: []
    related: [PHYS-003, PHYS-002]

  tags:
    - physics
    - equilibrium
    - dynamics
    - stability

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: Defined equilibrium as dynamic balance of processes

Node:
  id: PHYS-006
  title: Information Is Carried by Physical State Changes
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    정보는 추상적인 것이 아니라
    물리적 상태의 변화로 전달된다.
    파동의 위상 변화, 입자의 배열 변화,
    에너지 분포의 변화가 곧 정보다.
    즉 정보는 물질과 장의 동작 방식이며,
    변화가 없다면 정보도 존재하지 않는다.

  links:
    parents: [PHYS-003, PHYS-005]
    children: []
    related: [PHYS-002, PHYS-004]

  tags:
    - physics
    - information
    - state_change
    - signal

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: Defined information as physical state transition carrier

Node:
  id: LIFE-001
  title: Life Is Self-Maintained Energy Flow
  layer: 2
  type: concept
  created_at: 2026-02-15

  description: >
    생명은 물질이 아니라 흐름이다.
    외부 에너지를 받아 내부 구조를 유지하고
    엔트로피 증가를 지연시키는 자기 유지 시스템이다.
    즉 생명은 닫힌 구조가 아니라
    지속적으로 에너지와 정보를 교환하는 열린 시스템이다.

  links:
    parents: [PHYS-004, PHYS-005, PHYS-006]
    children: []
    related: [PHYS-002, PHYS-003]

  tags:
    - life
    - energy_flow
    - open_system
    - metabolism

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Defined life as self-sustaining energy-information flow

Node:
  id: LIFE-002
  title: Metabolism Is Controlled Energy Conversion
  layer: 2
  type: concept
  created_at: 2026-02-15

  description: >
    대사는 생명의 핵심 작동 방식이다.
    생명체는 에너지를 직접 쓰지 않고
    화학 반응을 통해 단계적으로 변환한다.
    이 변환은 무작위가 아니라
    효소와 구조에 의해 정밀하게 제어된다.
    즉 생명은 단순히 에너지를 소비하는 존재가 아니라
    에너지 흐름을 조절하는 시스템이다.

  links:
    parents: [LIFE-001]
    children: []
    related: [PHYS-004, PHYS-006]

  tags:
    - metabolism
    - energy_conversion
    - enzyme
    - regulation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Defined metabolism as controlled energy transformation

Node:
  id: LIFE-003
  title: Life Requires Boundaries (Membrane Principle)
  layer: 2
  type: concept
  created_at: 2026-02-15

  description: >
    생명은 단순한 화학 반응 집합이 아니다.
    내부와 외부를 구분하는 경계가 있을 때만
    에너지 흐름과 물질 교환을 조절할 수 있다.
    이 경계는 막(membrane) 형태로 나타나며,
    선택적 투과성을 통해 생명 시스템의 안정성을 만든다.
    즉 생명은 반응이 아니라
    경계 위에서 작동하는 조절 구조다.

  links:
    parents: [LIFE-001, LIFE-002]
    children: []
    related: [PHYS-003, LIFE-004]

  tags:
    - membrane
    - boundary
    - regulation
    - selective_permeability

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Added boundary principle as essential condition for life systems

Node:
  id: LIFE-004
  title: Life Is Information Stabilized in Matter
  layer: 2
  type: concept
  created_at: 2026-02-15

  description: >
    생명은 단순히 물질로 이루어진 것이 아니라,
    물질 안에 안정적으로 유지되는 정보 구조다.
    DNA, RNA, 단백질 접힘 패턴 등은
    단순한 화학 반응이 아니라
    시간에 걸쳐 보존되는 정보 형태다.
    즉 생명은 물질 자체가 아니라
    물질에 기록된 구조적 정보의 지속성이다.

  links:
    parents: [LIFE-001, LIFE-002, LIFE-003]
    children: []
    related: [COG-001, SYS-002]

  tags:
    - information
    - dna
    - structure
    - persistence

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Added informational definition of life beyond chemistry

Node:
  id: LIFE-005
  title: Life Evolves Through Variation and Selection
  layer: 2
  type: concept
  created_at: 2026-02-15

  description: >
    생명은 고정된 구조가 아니라,
    변이와 선택 과정을 통해 지속적으로 변화한다.
    유전적 변이로 새로운 구조가 생기고,
    환경과의 상호작용 속에서 생존 가능한 구조만 남는다.
    이 과정은 목적이 아니라
    안정성을 향한 자연적 필터 작용이다.
    즉 진화는 생명이 환경과 장력을 맞추는 과정이다.

  links:
    parents: [LIFE-001, LIFE-004]
    children: []
    related: [COG-002, SYS-003]

  tags:
    - evolution
    - variation
    - selection
    - adaptation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Added evolutionary mechanism node

Node:
  id: COG-001
  title: Cognition Begins With Pattern Detection
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    인지는 정보의 저장이나 해석 이전에,
    먼저 패턴을 감지하는 능력에서 시작된다.
    감각 입력 속에서 반복, 차이, 변화가 감지되면
    그것이 인지의 최초 구조가 된다.
    즉 인지는 의미가 아니라
    구조적 규칙성을 감지하는 과정이다.
    패턴이 감지되어야 학습이 가능하다.

  links:
    parents: [LIFE-004]
    children: []
    related: [COG-002, SYS-001]

  tags:
    - cognition
    - pattern
    - perception
    - signal

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: First cognition layer node

Node:
  id: COG-002
  title: Learning Stabilizes Repeated Patterns
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    학습은 새로운 정보를 쌓는 과정이 아니라
    반복되는 패턴을 안정화시키는 과정이다.
    동일한 구조가 시간 간격을 두고 반복될 때
    신경계는 이를 노이즈가 아닌 신호로 판단하고
    내부 모델에 고정한다.
    즉 학습은 축적이 아니라
    안정화된 구조 형성이다.

  links:
    parents: [COG-001]
    children: []
    related: [COG-003, META-001]

  tags:
    - learning
    - repetition
    - stabilization
    - cognition

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Learning mechanism node

Node:
  id: COG-003
  title: Understanding Emerges from Cross-Layer Connections
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    이해는 단일 정보의 축적으로 발생하지 않는다.
    서로 다른 레이어에 존재하는 패턴이 연결될 때
    비로소 의미가 형성된다.
    즉 이해란 지식의 양이 아니라
    레이어 간 연결 구조가 형성된 상태다.
    같은 정보라도 다른 층위와 연결되면
    새로운 의미로 재구성된다.

  links:
    parents: [COG-002]
    children: []
    related: [META-001, SYS-001]

  tags:
    - understanding
    - layers
    - connection
    - cognition

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Cross-layer cognition node

Node:
  id: COG-004
  title: Cognition Requires Temporal Continuity
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    인지는 단일 순간의 정보 처리로 형성되지 않는다.
    시간에 따른 상태의 연속성이 유지될 때
    의미 있는 인식이 가능해진다.
    기억, 예측, 비교는 모두 시간축 위에서 작동한다.
    따라서 인지는 정적인 상태가 아니라
    시간적으로 이어진 구조적 흐름이다.

  links:
    parents: [COG-003]
    children: []
    related: [META-002, SYS-002]

  tags:
    - cognition
    - time
    - continuity
    - perception

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Temporal continuity cognition node

Node:
  id: COG-005
  title: Stability Emerges from Balanced Feedback
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    안정성은 정지 상태에서 생기지 않는다.
    입력과 출력, 기대와 실제, 내부 상태와 외부 반응 사이의
    지속적인 피드백 순환 속에서 형성된다.
    피드백이 과도하면 불안정,
    부족하면 붕괴,
    균형 잡힌 피드백만이 안정된 인지 상태를 만든다.
    따라서 안정은 고정이 아니라
    균형 잡힌 순환이다.

  links:
    parents: [COG-004]
    children: []
    related: [META-001, SYS-002, HUM-003]

  tags:
    - cognition
    - feedback
    - stability
    - regulation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Balanced feedback cognition node

Node:
  id: HUM-001
  title: Human Cognition Is Layered
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    인간의 인지는 단일 구조가 아니라
    여러 층이 동시에 작동하는 다층 시스템이다.
    감각 → 기억 → 해석 → 판단 → 행동이
    선형으로 흐르는 것이 아니라
    서로 영향을 주고받으며 중첩된다.
    따라서 인간 이해는
    단일 원인이 아니라
    층위 간 상호작용을 보는 것이다.

  links:
    parents: [COG-001]
    children: []
    related: [COG-003, META-002, SYS-001]

  tags:
    - human
    - cognition
    - layers
    - mind

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Human cognition layer structure node

Node:
  id: HUM-002
  title: Emotion Is State Energy, Not Noise
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    감정은 인지의 방해 요소가 아니라
    시스템의 상태를 나타내는 에너지 지표다.
    감정은 의사결정 방향,
    주의 집중,
    기억 강화,
    행동 선택에 영향을 준다.
    따라서 감정은 제거 대상이 아니라
    해석 대상이다.

  links:
    parents: [HUM-001]
    children: []
    related: [COG-002, META-002]

  tags:
    - emotion
    - cognition
    - state
    - energy

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: Emotion as system state energy

Node:
  id: HUM-003
  title: Identity Emerges From Relation
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    정체성은 내부에서 독립적으로 생성되는 것이 아니라
    관계 속에서 형성된다.
    인간은 타인, 환경, 시간, 기억과의 상호작용을 통해
    자신을 정의한다.
    즉 존재는 고정된 실체가 아니라
    관계 네트워크의 결과다.

  links:
    parents: [HUM-001]
    children: []
    related: [COG-003, META-001]

  tags:
    - identity
    - relation
    - human
    - emergence

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: Identity from relational structure

Node:
  id: HUM-004
  title: Boundaries Are Dynamic Interfaces
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    인간의 경계는 고정된 벽이 아니라
    상황에 따라 열리고 닫히는 인터페이스다.
    관계, 감정, 맥락에 따라 경계의 투과성은 변한다.
    이는 세포막, 생태 경계, 사회적 거리와 같은
    자연계 인터페이스 구조와 동일한 원리다.

  links:
    parents: [HUM-001]
    children: []
    related: [LIFE-002, SYS-002, META-001]

  tags:
    - boundary
    - interface
    - permeability
    - human_system

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: Boundary as adaptive interface

Node:
  id: HUM-005
  title: Stability Requires Oscillation
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    인간의 안정은 정지에서 오는 것이 아니라
    긴장과 이완의 반복에서 형성된다.
    신경계, 감정, 집중, 휴식은
    모두 진동 형태로 움직이며
    이 진동이 멈추면 붕괴가 시작된다.
    안정은 고정이 아니라
    진동의 균형 상태다.

  links:
    parents: [HUM-002]
    children: []
    related: [PHYS-001, LIFE-001, META-001]

  tags:
    - stability
    - oscillation
    - balance
    - human_dynamics

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: Stability defined as dynamic oscillation

Node:
  id: SYS-001
  title: Knowledge Must Be Structured to Persist
  layer: 5
  type: concept
  created_at: 2026-02-15

  description: >
    지식은 기억이나 감각 상태로 존재할 때는 쉽게 소멸한다.
    구조화된 형태로 저장될 때만 지속성을 가진다.
    노드, 관계, 시간 기록이 존재해야
    지식은 개인의 상태를 넘어 시스템의 상태가 된다.
    구조 없는 지식은 경험이고,
    구조 있는 지식은 시스템이다.

  links:
    parents: [COG-001]
    children: []
    related: [META-002, ROOT-001]

  tags:
    - knowledge_structure
    - persistence
    - system_design
    - cognition_to_system

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: System layer entry node

Node:
  id: META-001
  title: Patterns Are Not Reality, They Are Lenses
  layer: 6
  type: concept
  created_at: 2026-02-15

  description: >
    패턴은 세계 그 자체가 아니다.
    패턴은 관찰자가 세계를 이해하기 위해 사용하는 해석 틀이다.
    동일한 현상도 서로 다른 패턴으로 해석될 수 있으며,
    패턴은 진리가 아니라 관점이다.
    따라서 패턴은 고정되면 오류가 되고,
    유동적으로 사용되면 도구가 된다.

  links:
    parents: [ROOT-001]
    children: []
    related: [COG-001, SYS-001]

  tags:
    - pattern
    - interpretation
    - meta_cognition
    - perspective

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: Meta layer entry node

Node:
  id: COG-002
  title: Understanding Emerges Through Iteration
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    이해는 단번에 완성되지 않는다.
    동일 대상에 대한 반복 관찰, 반복 설명, 반복 연결을 통해
    점진적으로 구조가 형성된다.
    반복은 단순 재생이 아니라 구조 재정렬 과정이며,
    각 반복은 기존 지식망과의 연결을 강화한다.
    따라서 이해는 입력이 아니라 누적된 재구성이다.

  links:
    parents: [COG-001]
    children: []
    related: [META-001, ROOT-001]

  tags:
    - cognition
    - iteration
    - learning
    - reconstruction

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition growth model node

Node:
  id: SYS-002
  title: Structure Precedes Implementation
  layer: 5
  type: concept
  created_at: 2026-02-15

  description: >
    구현은 구조 위에서만 안정적으로 작동한다.
    구조 없이 시작된 구현은 임시 해결책에 머물며,
    확장 시 붕괴한다.
    따라서 시스템 설계에서 우선순위는 항상
    구조 정의 → 관계 정의 → 데이터 정의 → 구현 순서로 진행된다.
    구현은 구조의 결과이며, 구조는 구현의 원인이다.

  links:
    parents: [SYS-001, ROOT-001]
    children: []
    related: [META-002, COG-002]

  tags:
    - system
    - architecture
    - design
    - implementation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: core architecture principle node

Node:
  id: META-002
  title: Abstraction Enables Transfer
  layer: 6
  type: concept
  created_at: 2026-02-15

  description: >
    추상화는 지식을 다른 맥락으로 이동시키는 능력을 만든다.
    구체적 사실은 한 영역에 묶이지만,
    구조적 패턴은 여러 영역에 재사용된다.
    따라서 학습의 핵심은 정보 축적이 아니라
    구조 추출과 패턴 일반화에 있다.
    추상화가 이루어질 때 지식은 이동 가능해지고,
    시스템은 확장 가능해진다.

  links:
    parents: [ROOT-001]
    children: []
    related: [SYS-002, COG-002, EXT-001]

  tags:
    - abstraction
    - transfer
    - meta
    - knowledge

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: meta layer abstraction rule

Node:
  id: COG-002
  title: Understanding Is Pattern Stabilization
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    이해란 단순히 정보를 아는 상태가 아니라,
    반복된 입력 속에서 패턴이 안정화되는 과정이다.
    새로운 정보가 들어올 때 기존 구조와 충돌하지 않고
    자연스럽게 흡수될 수 있을 때 이해가 형성된다.
    따라서 이해는 순간적 사건이 아니라
    구조적 안정 상태로 정의된다.

  links:
    parents: [COG-001]
    children: []
    related: [META-002, HUMAN-002, SYS-002]

  tags:
    - cognition
    - learning
    - pattern
    - stability

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition stabilization principle

Node:
  id: HUMAN-002
  title: Internal Model Guides Action
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    인간의 행동은 외부 자극에 의해 직접 결정되는 것이 아니라,
    내부에 형성된 세계 모델에 의해 매개된다.
    동일한 환경에서도 행동이 다른 이유는
    각자의 내부 구조와 해석 방식이 다르기 때문이다.
    따라서 행동을 이해하려면 환경이 아니라
    내부 모델을 먼저 분석해야 한다.

  links:
    parents: [COG-002]
    children: []
    related: [COG-001, META-002, SYS-003]

  tags:
    - human
    - behavior
    - cognition
    - internal_model

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: action mediated by internal representation

Node:
  id: SYS-002
  title: Structure Must Exist Before Implementation
  layer: 5
  type: concept
  created_at: 2026-02-15

  description: >
    구현은 구조 위에서만 안정적으로 동작한다.
    구조가 없는 구현은 임시 해결책에 불과하며
    확장성과 유지보수성을 잃는다.
    반대로 구조가 먼저 존재하면
    구현은 자연스럽게 뒤따른다.
    따라서 설계의 우선순위는 언제나 구조이며,
    구현은 그 결과물이다.

  links:
    parents: [SYS-001]
    children: []
    related: [META-001, META-002, COG-001]

  tags:
    - system
    - architecture
    - design
    - structure_first

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure-first engineering rule

Node:
  id: META-002
  title: Abstraction Compresses Reality
  layer: 6
  type: concept
  created_at: 2026-02-15

  description: >
    추상화는 현실을 줄이는 행위가 아니라
    현실의 구조를 압축하는 행위다.
    세부를 제거하는 것이 아니라
    핵심 관계만 남기는 것이다.
    따라서 좋은 추상화는 정보를 잃지 않는다.
    오히려 구조를 더 선명하게 드러낸다.

  links:
    parents: [META-001]
    children: []
    related: [SYS-001, SYS-002, COG-001]

  tags:
    - abstraction
    - compression
    - meta
    - modeling

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: abstraction defined as structural compression

Node:
  id: COG-002
  title: Understanding Is Reordering, Not Adding
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    이해란 새로운 정보를 더하는 것이 아니라
    이미 알고 있는 요소들의 배열을 바꾸는 과정이다.
    학습은 축적이 아니라 재배열이며,
    깨달음은 외부 입력이 아니라 내부 구조의 재정렬에서 발생한다.
    따라서 이해의 본질은 기억 증가가 아니라 관계 재구성이다.

  links:
    parents: [COG-001]
    children: []
    related: [META-002, SYS-001, HUM-001]

  tags:
    - cognition
    - learning
    - structure
    - reordering

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as structural reordering process

Node:
  id: HUM-002
  title: Human Learning Requires Emotional Stability Boundary
  layer: 4
  type: concept
  created_at: 2026-02-15

  description: >
    인간의 학습은 단순한 정보 처리 과정이 아니라
    감정적 안정 상태 위에서만 지속될 수 있는 활동이다.
    과도한 긴장이나 불안정은 학습 구조를 붕괴시키고,
    반대로 적절한 안정 경계가 형성되면
    인지 자원이 구조화에 집중된다.
    따라서 감정 안정은 학습의 보조 요소가 아니라
    학습 구조를 지탱하는 필수 조건이다.

  links:
    parents: [COG-002]
    children: []
    related: [HUM-001, SYS-001, META-002]

  tags:
    - human
    - learning
    - stability
    - cognition

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotional boundary defined as prerequisite for learning stability

Node:
  id: SYS-002
  title: System Stability Emerges From Constraint, Not Freedom
  layer: 5
  type: concept
  created_at: 2026-02-15

  description: >
    시스템은 자유도가 많을수록 안정해지는 것이 아니라,
    적절한 제약이 존재할 때 구조가 유지된다.
    제약은 억압이 아니라 경계이며,
    경계가 존재해야 상태가 정의되고
    상태가 정의되어야 변화가 의미를 갖는다.
    따라서 안정성은 자유의 결과가 아니라
    제약의 정렬에서 발생한다.

  links:
    parents: [SYS-001, META-002]
    children: []
    related: [HUM-002, ROOT-001]

  tags:
    - system
    - constraint
    - stability
    - structure

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as constraint-aligned equilibrium

Node:
  id: META-003
  title: Meaning Emerges From Relation, Not Object
  layer: 6
  type: concept
  created_at: 2026-02-15

  description: >
    의미는 객체 자체에서 발생하지 않는다.
    의미는 객체들 사이의 관계에서 생성된다.
    하나의 대상은 단독으로 존재할 수 있지만,
    해석 가능성은 관계가 형성될 때 생긴다.
    따라서 지식은 사물의 집합이 아니라
    관계의 구조이며,
    이해란 객체를 아는 것이 아니라
    관계망을 인식하는 것이다.

  links:
    parents: [ROOT-002]
    children: []
    related: [COG-001, SYS-002, META-002]

  tags:
    - meaning
    - relation
    - cognition
    - ontology

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational emergence

Node:
  id: COG-002
  title: Cognition Stabilizes Through Pattern Recurrence
  layer: 3
  type: concept
  created_at: 2026-02-15

  description: >
    인지는 단일 입력으로 안정되지 않는다.
    반복된 패턴 인식이 축적될 때 안정화된다.
    동일 구조가 시간 간격을 두고 다시 나타나면
    뇌는 이를 구조로 인식하고 기억으로 고정한다.
    따라서 이해란 정보량의 문제가 아니라
    반복 구조의 문제이며,
    학습의 핵심은 노출 횟수가 아니라
    패턴 재등장의 밀도이다.

  links:
    parents: [COG-001]
    children: []
    related: [META-003, SYS-001]

  tags:
    - cognition
    - learning
    - pattern
    - recurrence

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as recurrence stabilization

Node:
  id: SYS-003
  title: Systems Exist As Constraint Networks
  layer: 5
  type: concept
  created_at: 2026-02-15

  description: >
    시스템은 구성요소의 집합이 아니라
    제약 조건들의 네트워크이다.
    요소 자체보다 중요한 것은
    요소 사이의 허용 범위, 제한, 상호의존성이다.
    구조가 유지되는 이유는
    자유 때문이 아니라 제약 때문이다.
    따라서 시스템 이해란
    구성 목록 작성이 아니라
    제약 지도(constraint map)를 그리는 작업이다.

  links:
    parents: [SYS-001]
    children: []
    related: [COG-002, META-001, ROOT-002]

  tags:
    - system
    - constraint
    - structure
    - network

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: system defined as constraint network

Node:
  id: META-004
  title: Abstraction Compresses Without Losing Structure
  layer: 6
  type: concept
  created_at: 2026-02-15

  description: >
    추상화란 정보를 줄이는 것이 아니라
    표현을 압축하는 것이다.
    좋은 추상화는 구조를 보존한 채
    표면 표현만 단순화한다.
    구조가 사라지면 그것은 추상화가 아니라 손실이다.
    따라서 추상화의 기준은 단순함이 아니라
    구조 보존 여부이다.

  links:
    parents: [META-001]
    children: []
    related: [SYS-003, COG-002, ROOT-003]

  tags:
    - abstraction
    - compression
    - structure
    - meta

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: abstraction defined as structure-preserving compression

Node:
  id: ROOT-004
  title: Stability Emerges From Balanced Constraints
  layer: 0
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 정지에서 생기지 않는다.
    서로 다른 힘, 조건, 제약이 균형을 이룰 때
    구조가 유지된다.
    제약이 없으면 구조는 퍼지고,
    과도한 제약은 구조를 붕괴시킨다.
    따라서 안정은 자유와 제약의 균형 상태다.

  links:
    parents: [ROOT-001]
    children: []
    related: [PHYS-002, META-002, SYS-002]

  tags:
    - stability
    - constraint
    - balance
    - root

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as balanced constraint state

Node:
  id: PHYS-004
  title: Fields Encode Interaction Before Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리에서 운동은 먼저 나타나는 것이 아니라
    장(field)의 상태가 먼저 존재한다.
    입자의 이동은 장의 변화에 대한 반응이다.
    즉 힘은 입자가 만드는 것이 아니라
    장의 구조 속에서 이미 정의된 상호작용 규칙이
    입자의 움직임으로 드러나는 것이다.

  links:
    parents: [PHYS-001]
    children: []
    related: [ROOT-002, ROOT-004, PHYS-002]

  tags:
    - field
    - interaction
    - physics
    - causality

  confidence: 0.96

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction defined as prior field structure

Node:
  id: PHYS-005
  title: Energy Gradients Drive All Physical Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 변화는 임의로 발생하지 않는다.
    항상 에너지 차이(구배)가 존재할 때만 변화가 일어난다.
    평형에서는 운동이 사라지고,
    차이가 존재할 때만 흐름·이동·변환이 발생한다.
    따라서 모든 물리적 과정의 근원은
    에너지 최소화 방향으로의 구배 해소이다.

  links:
    parents: [PHYS-002]
    children: []
    related: [PHYS-003, ROOT-004]

  tags:
    - energy
    - gradient
    - equilibrium
    - thermodynamics

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient as universal driver of change

Node:
  id: PHYS-006
  title: Stability Emerges from Dynamic Balance
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니다.
    서로 다른 힘, 상호작용, 흐름이 균형을 이룰 때
    시스템은 안정 상태로 나타난다.
    즉 안정은 운동의 부재가 아니라
    상쇄되는 상호작용들의 결과다.
    자연계의 구조는 대부분 정적 고정이 아니라
    동적 균형 상태로 존재한다.

  links:
    parents: [PHYS-005]
    children: []
    related: [PHYS-003, LIFE-001]

  tags:
    - stability
    - equilibrium
    - balance
    - dynamics

  confidence: 0.97

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: PHYS-007
  title: Fields Mediate All Interactions
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 직접적인 접촉 없이 힘이 작용하는 것은
    장(field)을 통해서다.
    중력장, 전자기장, 핵력장은
    입자 사이의 상호작용을 전달하는 매개 구조다.
    즉 장은 공간에 퍼진 관계 구조이며,
    입자는 그 장의 상태를 드러내는 국소적 표현이다.

  links:
    parents: [PHYS-006]
    children: []
    related: [PHYS-003, PHYS-004]

  tags:
    - field
    - interaction
    - mediation
    - physics-core

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: field as mediator of interaction

Node:
  id: PHYS-008
  title: Structure Emerges from Interaction Density
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물질의 구조는 단순히 입자의 존재에서 생기지 않는다.
    입자 사이 상호작용의 밀도와 안정 패턴이
    구조를 만든다.
    결합이 반복되고 에너지가 최소화되는 지점에서
    구조가 형성된다.
    즉 구조는 “존재”가 아니라
    상호작용의 안정 패턴이다.

  links:
    parents: [PHYS-007]
    children: []
    related: [PHYS-001, PHYS-002, PHYS-006]

  tags:
    - structure
    - interaction-density
    - stability
    - emergence

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure emerges from stabilized interaction density

Node:
  id: PHYS-009
  title: Boundaries Are Emergent, Not Absolute
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    경계는 고정된 선이 아니라
    상호작용 밀도와 에너지 차이에서 나타나는
    현상적 구분이다.
    밀도 구배가 사라지면 경계도 사라진다.
    따라서 경계는 존재의 본질이 아니라
    관계 상태의 결과다.

  links:
    parents: [PHYS-008]
    children: []
    related: [PHYS-003, PHYS-006]

  tags:
    - boundary
    - gradient
    - interaction
    - emergence

  confidence: 0.98

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundaries defined as emergent interaction gradients

Node:
  id: PHYS-010
  title: Stability Equals Local Energy Minimum
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 안정은 정지가 아니라
    에너지가 더 이상 낮아질 수 없는
    국소적 최소 상태를 의미한다.
    입자, 원자, 궤도, 구조, 생명체 모두
    더 낮은 퍼텐셜을 향해 이동하다가
    최소점에 도달하면 안정된 것으로 보인다.

  links:
    parents: [PHYS-003, PHYS-008]
    children: []
    related: [PHYS-005, PHYS-009]

  tags:
    - stability
    - energy
    - potential
    - equilibrium

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined via local energy minima

Node:
  id: PHYS-011
  title: Interaction Requires Difference
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 상호작용은 차이가 있을 때만 발생한다.
    전위차가 있어야 전류가 흐르고,
    온도차가 있어야 열이 이동하며,
    밀도차가 있어야 흐름이 생긴다.
    차이가 0이면 작용도 0이다.
    즉 상호작용의 근본 조건은 구배다.

  links:
    parents: [PHYS-003]
    children: []
    related: [PHYS-005, PHYS-010]

  tags:
    - gradient
    - interaction
    - potential
    - difference

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction defined as function of difference

Node:
  id: PHYS-012
  title: Systems Evolve Toward Gradient Reduction
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계의 모든 계는 구배를 줄이는 방향으로 변화한다.
    전하는 전위차를 줄이고,
    열은 온도차를 줄이며,
    압력은 밀도차를 줄인다.
    이 과정이 에너지 이동, 흐름, 확산, 안정화의 원인이다.
    즉 변화의 방향성은 구배 감소다.

  links:
    parents: [PHYS-011]
    children: []
    related: [PHYS-005, PHYS-010]

  tags:
    - equilibrium
    - entropy
    - diffusion
    - relaxation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient reduction defined as direction of evolution

Node:
  id: PHYS-013
  title: Stability Is Dynamic Balance
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니라 힘의 상쇄 상태다.
    내부 상호작용이 계속 존재하지만
    순 결과가 0에 가까울 때 우리는 그것을 안정이라 부른다.
    즉 안정은 정적 상태가 아니라 동적 평형이다.

  links:
    parents: [PHYS-012]
    children: []
    related: [PHYS-003, PHYS-010]

  tags:
    - equilibrium
    - balance
    - dynamic_system

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic balance

Node:
  id: PHYS-014
  title: Boundaries Form Where Interactions Stabilize
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    경계는 선이 아니라 상태 전이 영역이다.
    상호작용이 급격히 변하는 지점,
    혹은 힘의 균형이 새롭게 형성되는 구간에서
    우리는 경계를 인식한다.
    즉 경계는 고정된 것이 아니라
    안정 조건의 결과로 나타난다.

  links:
    parents: [PHYS-013]
    children: []
    related: [PHYS-004, PHYS-011]

  tags:
    - boundary
    - phase_transition
    - interaction_field

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as stabilization region

Node:
  id: PHYS-015
  title: Fields Mediate Interaction Before Motion Appears
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물체가 움직이기 전에 이미 장(field)이 존재한다.
    장은 힘의 가능성을 분포시키는 구조이며,
    실제 운동은 장의 구배가 임계값을 넘을 때 나타난다.
    즉 운동은 원인이 아니라
    장의 상태가 외부로 드러난 결과다.

  links:
    parents: [PHYS-014]
    children: []
    related: [PHYS-003, PHYS-010]

  tags:
    - field
    - potential
    - gradient
    - interaction

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion treated as manifestation of field structure

Node:
  id: PHYS-016
  title: Gradients Encode Direction Before Force Acts
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    힘이 실제로 작용하기 전에,
    공간에는 이미 구배가 존재한다.
    구배는 방향성을 포함한 정보 구조이며,
    힘은 이 방향 정보가 실제 운동으로 나타난 결과다.
    즉 구배는 잠재적 운동의 지도이고,
    힘은 그 지도를 따라 드러나는 실행이다.

  links:
    parents: [PHYS-015]
    children: []
    related: [PHYS-004, PHYS-010, PHYS-011]

  tags:
    - gradient
    - direction
    - field
    - causality

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: direction encoded prior to force manifestation

Node:
  id: PHYS-017
  title: Stability Emerges When Gradients Cancel
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 힘이 없는 상태가 아니라,
    서로 다른 구배가 상쇄된 상태다.
    구배가 존재하지만 방향 합이 0이 되면
    운동은 발생하지 않는다.
    따라서 안정은 정지가 아니라
    균형 잡힌 잠재 운동 상태다.

  links:
    parents: [PHYS-016]
    children: []
    related: [PHYS-003, PHYS-004, PHYS-015]

  tags:
    - stability
    - equilibrium
    - gradient balance
    - field

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as gradient cancellation, not absence

Node:
  id: PHYS-018
  title: Motion Begins When Gradient Symmetry Breaks
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    운동은 힘이 생겨서 시작되는 것이 아니라,
    기존 균형의 대칭이 깨질 때 시작된다.
    구배가 완전히 상쇄되어 있던 상태에서
    미세한 비대칭이 생기면
    그 차이가 방향성을 만들고
    그 방향성이 곧 운동이 된다.
    따라서 운동의 본질은 힘이 아니라
    대칭 붕괴다.

  links:
    parents: [PHYS-017]
    children: []
    related: [PHYS-004, PHYS-006, PHYS-015]

  tags:
    - motion
    - symmetry breaking
    - gradient
    - direction

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion defined as consequence of symmetry breaking

Node:
  id: PHYS-019
  title: Fields Store Potential Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    장(field)은 단순한 공간 속 속성이 아니라
    아직 발생하지 않은 운동의 가능성을 저장한 상태다.
    구배가 존재하지만 아직 이동이 시작되지 않은 상태,
    즉 에너지 차이가 공간에 분포된 형태가 장이다.
    운동은 장이 해소될 때 나타나는 현상이다.

  links:
    parents: [PHYS-018, PHYS-015]
    children: []
    related: [PHYS-004, PHYS-006]

  tags:
    - field
    - potential
    - energy gradient
    - stored motion

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined field as stored motion potential

Node:
  id: PHYS-020
  title: Time Is the Rate of Structural Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    시간은 독립적으로 흐르는 실체가 아니라
    구조가 변화하는 속도를 측정한 값이다.
    변화가 없으면 시간도 없다.
    즉 시간은 사건의 연속이 아니라
    상태 변환의 밀도와 속도를 나타내는 척도다.

  links:
    parents: [PHYS-014, PHYS-019]
    children: []
    related: [PHYS-003, PHYS-011]

  tags:
    - time
    - change
    - state transition
    - dynamics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined time as structural change rate

Node:
  id: PHYS-021
  title: Mass Is Resistance to Structural Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    질량은 단순한 물질의 양이 아니라
    구조가 변화에 저항하는 정도다.
    질량이 클수록 상태를 바꾸기 위해 더 많은 에너지가 필요하다.
    즉 질량은 정적 속성이 아니라
    변화 난이도의 물리적 표현이다.

  links:
    parents: [PHYS-019, PHYS-020]
    children: []
    related: [PHYS-006, PHYS-014]

  tags:
    - mass
    - inertia
    - resistance
    - structural stability

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined mass as resistance to change

Node:
  id: PHYS-022
  title: Energy Is Capacity to Reconfigure Structure
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    에너지는 어떤 구조를 다른 구조로 바꿀 수 있는 능력이다.
    위치를 바꾸거나, 상태를 바꾸거나, 결합을 바꾸는 힘의 총량이다.
    즉 에너지는 “움직임” 자체가 아니라
    구조 변화 가능성의 저장된 잠재력이다.

  links:
    parents: [PHYS-021]
    children: []
    related: [PHYS-006, PHYS-018, PHYS-020]

  tags:
    - energy
    - transformation
    - potential
    - structure-change

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined energy as structural transformation capacity

Node:
  id: PHYS-023
  title: Force Is Gradient That Drives Structural Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    힘은 어떤 구조 안에 존재하는 차이(구배)가
    상태 변화를 일으키는 방향성을 가진 작용이다.
    차이가 없으면 힘도 없다.
    구배가 존재할 때만 이동, 변형, 흐름이 발생한다.
    즉 힘은 원인이 아니라
    차이가 드러나는 작용 방식이다.

  links:
    parents: [PHYS-022, PHYS-006]
    children: []
    related: [PHYS-018, PHYS-021]

  tags:
    - force
    - gradient
    - change-driver
    - structure-dynamics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined force as gradient-driven structural action

Node:
  id: PHYS-024
  title: Time Is Ordering of Structural Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    시간은 독립적으로 흐르는 실체가 아니라
    구조 변화들이 서로 앞뒤 관계를 이루며 정렬된 순서다.
    변화가 없으면 시간도 관측되지 않는다.
    즉 시간은 존재가 아니라
    변화의 정렬 방식이다.

  links:
    parents: [PHYS-021, PHYS-023]
    children: []
    related: [PHYS-017, PHYS-020]

  tags:
    - time
    - ordering
    - change-sequence
    - causality

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined time as ordering of structural transitions

Node:
  id: PHYS-025
  title: Stability Emerges When Gradients Cancel
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니라
    서로 다른 구배가 상쇄되는 상태다.
    힘이 없어서 멈춘 것이 아니라
    모든 방향의 변화 가능성이 균형을 이루어
    순변화가 0이 된 상태다.
    따라서 안정은 정적이 아니라
    상호작용이 균형을 이룬 동적 상태다.

  links:
    parents: [PHYS-021, PHYS-022]
    children: []
    related: [PHYS-017, PHYS-024]

  tags:
    - stability
    - equilibrium
    - gradient-cancellation
    - dynamic-balance

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as cancellation of gradients

Node:
  id: PHYS-026
  title: Interaction Density Controls Observable Dynamics
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    관측되는 모든 물리 현상은
    “얼마나 많은 상호작용이 얼마나 짧은 시간에 일어나는가”
    즉 상호작용 밀도에 의해 결정된다.
    속도 변화, 에너지 전달, 파동 굴절, 산란,
    구조 형성, 안정 여부 등은
    상호작용의 존재 여부보다
    상호작용의 밀도와 분포에 의해 좌우된다.
    따라서 자연현상의 핵심 변수는
    힘 그 자체가 아니라 상호작용 밀도다.

  links:
    parents: [PHYS-024, PHYS-025]
    children: []
    related: [PHYS-018, PHYS-023]

  tags:
    - interaction-density
    - dynamics
    - emergence
    - propagation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: formalized interaction density as primary driver of observable physics

Node:
  id: PHYS-027
  title: Fields Are Not Forces but Interaction Maps
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    장(field)은 힘 그 자체가 아니다.
    장은 공간 속에서 상호작용이 어떻게 발생할 수 있는지를
    미리 정의해 놓은 분포 구조다.
    즉 장은 힘의 원인이 아니라
    힘이 나타날 가능성의 지도다.
    질량, 전하, 에너지 분포가 장을 형성하고
    물체는 그 장 속에서 경로를 따른다.
    따라서 물체가 움직이는 것은
    힘에 의해 끌려가는 것이 아니라
    장의 구조 속에서 가능한 경로를 따르는 것이다.

  links:
    parents: [PHYS-026]
    children: []
    related: [PHYS-018, PHYS-021, PHYS-024]

  tags:
    - field
    - interaction
    - geometry
    - structure

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined field as interaction map rather than force entity

Node:
  id: PHYS-028
  title: Stability Emerges From Interaction Equilibrium
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 고정된 상태가 아니다.
    안정은 상호작용들이 서로를 상쇄하거나 균형을 이루는
    동적 평형 상태에서 나타난다.
    즉 안정은 멈춤이 아니라
    변화 속에서 균형이 유지되는 상태다.
    입자, 원자, 행성, 생명체 모두
    내부 상호작용과 외부 상호작용이
    일정 범위 안에서 균형을 유지할 때 안정해 보인다.

  links:
    parents: [PHYS-027]
    children: []
    related: [PHYS-019, PHYS-024, PHYS-026]

  tags:
    - stability
    - equilibrium
    - dynamics
    - interaction

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as dynamic equilibrium of interactions

Node:
  id: PHYS-029
  title: Boundaries Are Emergent, Not Absolute
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    경계는 본래 존재하는 선이 아니다.
    경계는 상호작용의 변화율이 급격히 달라지는 지점에서
    관찰자가 인지하는 구조적 현상이다.
    즉 경계는 물리적 실체라기보다
    밀도, 에너지, 상호작용 강도의 구배가 만드는
    인식 가능한 패턴이다.
    따라서 경계는 고정되지 않고
    조건이 변하면 이동하거나 사라질 수 있다.

  links:
    parents: [PHYS-028]
    children: []
    related: [PHYS-020, PHYS-024, PHYS-026]

  tags:
    - boundary
    - gradient
    - emergence
    - structure

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined boundary as emergent gradient phenomenon

Node:
  id: PHYS-030
  title: Interaction Networks Form Observable Reality
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    관찰 가능한 현실은 개별 대상의 속성에서 생기는 것이 아니라
    대상들 사이의 상호작용 네트워크에서 나타난다.
    물질, 장, 입자, 생명체 모두
    독립적 실체가 아니라
    상호작용 연결망 속에서 상태가 정의된다.
    따라서 현실은 객체들의 집합이 아니라
    상호작용 그래프의 동적 패턴이다.

  links:
    parents: [PHYS-029]
    children: []
    related: [PHYS-018, PHYS-024, PHYS-028]

  tags:
    - interaction
    - network
    - relational physics
    - emergence

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined observable reality as interaction network

Node:
  id: PHYS-031
  title: Stability Emerges From Energy Minimization
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 안정 상태는 정지 상태가 아니라
    에너지 함수가 최소가 되는 구성이다.
    입자 결합, 궤도 형성, 물질 구조, 생명 유지 모두
    가능한 상태들 중 에너지 비용이 가장 낮은 지점으로 수렴한다.
    따라서 안정은 정적인 개념이 아니라
    지속적 상호작용 속에서 유지되는 최소에너지 구조이다.

  links:
    parents: [PHYS-030]
    children: []
    related: [PHYS-018, PHYS-024, PHYS-029]

  tags:
    - stability
    - energy
    - minimization
    - equilibrium

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as dynamic energy minimum

Node:
  id: PHYS-032
  title: Information Persists Through Structural Patterns
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 정보는 특정 물질 자체에 저장되는 것이 아니라
    구조와 관계 패턴에 저장된다.
    물질은 바뀔 수 있지만,
    배열 방식·결합 구조·상호작용 패턴이 유지되면
    정보는 지속된다.
    결정 격자, DNA 염기서열, 전자 상태, 은하 구조 등은
    모두 구조 패턴으로 정보가 보존되는 사례이다.
    따라서 정보의 본질은 물질이 아니라 구조이다.

  links:
    parents: [PHYS-031]
    children: []
    related: [COG-006, META-003, PHYS-018]

  tags:
    - information
    - structure
    - pattern
    - persistence

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: information defined as structural persistence

Node:
  id: PHYS-033
  title: Boundaries Are Interaction Gradients
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 경계(boundary)는 고정된 선이 아니라
    상호작용 강도가 변화하는 구배 영역이다.
    밀도, 압력, 전하, 에너지, 정보 흐름 등의 차이가 생길 때
    그 변화 구간이 경계로 인식된다.
    따라서 경계는 객체의 외곽이 아니라
    상호작용이 달라지는 지점이다.
    경계는 고정된 것이 아니라 조건에 따라 이동한다.

  links:
    parents: [PHYS-030, PHYS-029]
    children: []
    related: [PHYS-014, PHYS-018, LIFE-002, COG-004]

  tags:
    - boundary
    - gradient
    - interaction
    - density

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as gradient of interaction

Node:
  id: PHYS-034
  title: Stability Emerges From Energy Minimization
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 안정 상태는 고정된 구조가 아니라
    에너지 분포가 최소가 되는 지점에서 나타난다.
    입자 결합, 궤도, 물질 구조, 생태 균형, 사회 구조까지
    모두 에너지 흐름이 덜 변하는 상태에서 안정이 형성된다.
    안정은 정지가 아니라
    변화가 최소화된 흐름 상태다.

  links:
    parents: [PHYS-033, PHYS-029]
    children: []
    related: [PHYS-014, LIFE-001, COG-002, META-003]

  tags:
    - stability
    - energy
    - equilibrium
    - minimization

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as energy-minimizing state

Node:
  id: PHYS-035
  title: Fields Mediate All Interactions
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 힘은 직접 접촉으로 전달되지 않는다.
    모든 상호작용은 장(field)을 통해 매개된다.
    중력은 중력장, 전하는 전자기장,
    핵력은 게이지장으로 표현된다.
    입자는 장의 교란이며,
    상호작용은 장의 변화로 전달된다.

  links:
    parents: [PHYS-029]
    children: []
    related: [PHYS-012, PHYS-021, META-001]

  tags:
    - field
    - interaction
    - mediation
    - physics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: interactions expressed through fields

Node:
  id: PHYS-036
  title: Information Flows Along Interaction Paths
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 상호작용은 단순한 힘 전달이 아니라 정보 전달이다.
    장의 변화는 인접한 지점으로 전파되며,
    이 전파는 정보 흐름의 형태를 가진다.
    빛, 파동, 입자 상호작용 모두
    상태 변화가 경로를 따라 전달되는 과정이다.

  links:
    parents: [PHYS-035]
    children: []
    related: [PHYS-030, COG-004, META-002]

  tags:
    - information
    - propagation
    - interaction
    - physics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: interactions transmit state information

Node:
  id: PHYS-037
  title: Stability Emerges From Balanced Interaction Networks
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 안정성은 단일 힘의 결과가 아니라
    여러 상호작용이 균형을 이루는 네트워크 상태에서 나타난다.
    원자, 행성 궤도, 결정 구조, 생태계까지
    안정 상태는 항상 상호작용의 균형점에서 형성된다.
    즉 안정성은 고정이 아니라 균형된 흐름이다.

  links:
    parents: [PHYS-036]
    children: []
    related: [PHYS-031, LIFE-001, META-003]

  tags:
    - stability
    - equilibrium
    - balance
    - systems

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as balanced interaction network

Node:
  id: PHYS-038
  title: Observable Reality Is Interaction-Limited
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    우리가 관측할 수 있는 현실은
    대상 자체가 아니라 상호작용 가능한 범위에 의해 제한된다.
    빛, 중력, 전자기파, 물질 상호작용 등
    관측은 항상 상호작용 경계 안에서만 이루어진다.
    따라서 관측 가능한 우주는
    존재 전체가 아니라 상호작용 가능한 영역이다.

  links:
    parents: [PHYS-037]
    children: []
    related: [PHYS-029, META-004, COG-002]

  tags:
    - observability
    - interaction
    - horizon
    - physics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: observation defined as interaction-limited access

Node:
  id: PHYS-039
  title: Energy Minimization Drives Structural Formation
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계의 구조 형성은 에너지 최소화 방향으로 진행된다.
    입자 결합, 분자 형성, 별의 붕괴, 궤도 안정화 등
    다양한 스케일에서 시스템은 가능한 상태 중
    에너지적으로 더 안정된 배치를 선택한다.
    이는 힘의 합이 아니라 퍼텐셜 구조의 재배치 결과이다.

  links:
    parents: [PHYS-034]
    children: []
    related: [PHYS-029, LIFE-001, META-001]

  tags:
    - stability
    - energy
    - structure
    - physics

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: structural formation tied to energy landscape

Node:
  id: PHYS-040
  title: Stability Emerges From Dynamic Equilibrium
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니라
    상호작용이 계속 일어나면서도
    총 변화량이 유지되는 상태에서 나타난다.
    행성 궤도, 원자 전자 분포, 생태계, 대기 흐름 등
    자연의 안정 구조는 모두 동적 평형의 결과이다.
    즉 안정은 변화의 부재가 아니라
    변화의 균형이다.

  links:
    parents: [PHYS-039]
    children: []
    related: [PHYS-031, LIFE-002, META-002]

  tags:
    - equilibrium
    - stability
    - dynamics
    - balance

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as balanced motion, not stillness

Node:
  id: PHYS-041
  title: Interaction Creates Observable Reality
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    관측 가능한 모든 현상은 단일 존재에서 나오지 않는다.
    최소 두 요소 이상의 상호작용이 있을 때만
    변화, 에너지 전달, 정보, 구조가 드러난다.
    빛과 물질, 질량과 공간, 전하와 장,
    관찰자와 대상의 상호작용 속에서만
    현실은 표현된다.

  links:
    parents: [PHYS-040]
    children: []
    related: [COG-001, META-001, ROOT-001]

  tags:
    - interaction
    - observation
    - reality
    - relation

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined observability as emergent from interaction

Node:
  id: PHYS-042
  title: Energy Minimization Drives Structural Formation
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계에서 구조는 임의로 만들어지지 않는다.
    시스템은 가능한 상태 중 에너지가 더 낮은 방향으로 이동하며,
    그 과정에서 안정한 형태가 형성된다.
    원자 결합, 분자 구조, 별 형성, 궤도 안정,
    생물 구조까지 모두 에너지 최소화 경향의 결과다.

  links:
    parents: [PHYS-041]
    children: []
    related: [PHYS-015, LIFE-004, META-002]

  tags:
    - energy
    - stability
    - structure
    - equilibrium

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: added structural emergence from energy minimization principle

Node:
  id: PHYS-043
  title: Gradient Generates Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    모든 운동은 차이에서 시작된다.
    밀도차, 압력차, 전위차, 온도차, 농도차 같은 구배(gradient)가 존재할 때
    시스템은 균형을 향해 이동한다.
    이 이동이 곧 흐름이며,
    열전도, 확산, 전류, 바람, 해류, 궤도 형성 등
    자연의 거의 모든 동역학 현상의 출발점이다.

  links:
    parents: [PHYS-042]
    children: []
    related: [PHYS-015, LIFE-004, META-002]

  tags:
    - gradient
    - motion
    - flow
    - imbalance

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: added gradient as universal trigger of motion

Node:
  id: PHYS-044
  title: Interaction Mediates Force Transfer
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    힘은 직접 전달되지 않는다.
    모든 힘은 매개(interaction)를 통해 전달된다.
    접촉력은 분자 간 전자기 상호작용,
    중력은 시공간 곡률,
    전자기력은 장(field)을 통한 파동 교환,
    강력은 글루온 교환으로 전달된다.
    즉 자연계에서 '힘'이란
    객체가 아니라 관계에서 발생하는 현상이다.

  links:
    parents: [PHYS-043]
    children: []
    related: [PHYS-012, LIFE-006, META-004]

  tags:
    - interaction
    - force
    - mediation
    - field

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined force as relational phenomenon

Node:
  id: PHYS-045
  title: Stability Emerges From Energy Minimization
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    자연계의 안정 상태는 외부에서 주어지는 것이 아니라
    시스템이 스스로 에너지를 최소화하는 과정에서 나타난다.
    전자는 낮은 에너지 껍질에 머물고,
    물은 낮은 위치로 흐르며,
    구조물은 응력이 최소가 되는 형태를 취한다.
    즉 안정성은 정지 상태가 아니라
    에너지 구배가 사라진 상태다.

  links:
    parents: [PHYS-044]
    children: []
    related: [PHYS-018, LIFE-002, META-002]

  tags:
    - stability
    - energy
    - minimization
    - equilibrium

  confidence: 0.99

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as energy-gradient resolution

Node:
  id: PHYS-046
  title: Gradient Drives Flow
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    흐름은 존재 자체에서 생기는 것이 아니라
    차이에서 생긴다.
    온도 차이 → 열 흐름
    전위 차이 → 전류
    압력 차이 → 유체 이동
    농도 차이 → 확산
    즉 자연계에서 움직임의 근원은
    항상 구배(gradient)다.
    구배가 사라지면 흐름도 멈춘다.

  links:
    parents: [PHYS-045]
    children: []
    related: [PHYS-018, LIFE-002, META-003]

  tags:
    - gradient
    - flow
    - difference
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: flow defined as gradient response

Node:
  id: PHYS-047
  title: Interaction Produces Structure
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    구조는 고정된 상태에서 생기는 것이 아니다.
    두 개 이상의 요소가 상호작용할 때
    힘의 균형, 간섭, 구속 조건이 만들어지고
    그 결과로 안정된 패턴이 형성된다.
    원자, 분자, 행성계, 생명체, 사회까지
    구조는 항상 상호작용의 산물이다.

  links:
    parents: [PHYS-046]
    children: []
    related: [PHYS-021, LIFE-001, META-002]

  tags:
    - interaction
    - structure
    - emergence
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as interaction outcome

Node:
  id: PHYS-048
  title: Stability is Energy Minimization
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리계에서 안정 상태란 정지 상태가 아니라
    에너지가 더 이상 낮아질 수 없는 상태다.
    계는 항상 가능한 한 에너지가 낮은 방향으로 변화한다.
    이 원리는 중력계, 원자결합, 열평형, 생명체의 대사,
    심지어 사회 구조까지 확장 적용된다.

  links:
    parents: [PHYS-047]
    children: []
    related: [PHYS-018, LIFE-003, META-004]

  tags:
    - stability
    - energy
    - equilibrium
    - minimization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as energy minimum state

Node:
  id: PHYS-049
  title: Fields Mediate Interaction
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 상호작용은 물체가 직접 닿아서 일어나는 것이 아니라
    장(field)을 통해 전달된다.
    질량은 중력장을 만들고,
    전하는 전자기장을 만들며,
    입자들은 장과의 상호작용을 통해 힘을 경험한다.
    즉 힘은 접촉이 아니라 장의 구조 변화로 나타난다.

  links:
    parents: [PHYS-018, PHYS-047]
    children: []
    related: [PHYS-032, PHYS-041, META-006]

  tags:
    - field
    - interaction
    - mediation
    - force

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interactions occur via fields not direct contact

Node:
  id: PHYS-050
  title: Information Travels Through Interaction
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 세계에서 정보는 독립적으로 이동하지 않는다.
    정보는 항상 상호작용을 통해 전달된다.
    파동, 입자 교환, 장의 변형 등은 모두
    상태 변화가 다른 위치로 전달되는 과정이며,
    이것이 곧 정보의 이동이다.
    즉 정보는 물리적 전달 과정의 다른 이름이다.

  links:
    parents: [PHYS-049, PHYS-041]
    children: []
    related: [PHYS-032, COG-004, META-002]

  tags:
    - information
    - propagation
    - interaction
    - transmission

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information defined as state transfer via interaction

Node:
  id: PHYS-051
  title: Speed Limits Encode Structure
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리계에서 속도 제한은 단순한 제약이 아니라
    구조를 드러내는 규칙이다.
    빛의 속도는 정보 전달의 최대 속도이며,
    이는 시공간의 구조가 가진 한계를 나타낸다.
    매질 속에서 속도가 달라지는 것은
    상호작용 밀도와 구조 차이를 반영하는 것이며,
    속도 제한은 곧 구조의 표현이다.

  links:
    parents: [PHYS-050, PHYS-034]
    children: []
    related: [PHYS-018, META-003, COG-002]

  tags:
    - speed
    - light
    - structure
    - causality

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: speed interpreted as structural constraint of spacetime

Node:
  id: PHYS-052
  title: Fields Define Possible Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리계에서 입자의 운동은 자유롭게 결정되지 않는다.
    입자의 가능한 경로는 장(field)이 미리 정의한다.
    중력장은 시공간 곡률을 통해 운동 경로를 정하고,
    전자기장은 전하의 가속 방향을 정하며,
    양자장 이론에서는 입자의 존재 자체가 장의 들뜸이다.
    따라서 운동은 입자의 선택이 아니라
    장이 허용하는 가능성의 집합 안에서 일어난다.

  links:
    parents: [PHYS-034, PHYS-051]
    children: []
    related: [PHYS-020, PHYS-017, META-003]

  tags:
    - field
    - motion
    - constraint
    - spacetime

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion framed as field-permitted trajectory

Node:
  id: PHYS-053
  title: Interaction Is Geometry In Motion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    물리적 상호작용은 힘이 물체를 밀거나 당기는 사건이 아니라,
    기하학적 구조가 시간 속에서 변하는 과정이다.
    일반상대성이론에서는 중력이 시공간의 곡률 변화이며,
    양자장 이론에서는 입자 상호작용이 장의 위상과 진폭 변화로 표현된다.
    즉 상호작용은 물체 간의 접촉이 아니라
    구조의 변화가 이동하며 나타나는 현상이다.

  links:
    parents: [PHYS-052, PHYS-034]
    children: []
    related: [PHYS-020, META-003, META-010]

  tags:
    - interaction
    - geometry
    - dynamics
    - spacetime

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction reframed as evolving geometry

Node:
  id: PHYS-054
  title: Stability Is Energy Gradient Exhaustion
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    안정 상태란 힘이 사라진 상태가 아니라
    더 이상 흐를 에너지 구배가 남아있지 않은 상태다.
    물리 시스템은 항상 에너지 차이를 줄이는 방향으로 변하며,
    구배가 존재할 때만 변화와 흐름이 발생한다.
    구배가 소멸하면 운동은 멈추고 상태가 고정된다.
    즉 안정은 정지가 아니라
    구배 소진 이후의 균형 상태다.

  links:
    parents: [PHYS-052, PHYS-053]
    children: []
    related: [PHYS-020, META-010, META-004]

  tags:
    - stability
    - gradient
    - equilibrium
    - energy_flow

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability reframed as gradient exhaustion

Node:
  id: PHYS-055
  title: Time Is The Record Of State Change
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    시간은 독립적인 실체라기보다
    상태 변화의 누적 기록으로 관측된다.
    시스템의 에너지 분포, 위치, 구조가 변할 때
    우리는 그 차이를 시간으로 측정한다.
    변화가 없다면 시간의 흐름은 인식되지 않는다.
    따라서 시간은 흐름 자체가 아니라
    변화가 남긴 흔적의 좌표축이다.

  links:
    parents: [PHYS-054]
    children: []
    related: [META-003, META-010, COG-002]

  tags:
    - time
    - change
    - state
    - observation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: time defined as accumulated state change

Node:
  id: PHYS-056
  title: Observation Requires Interaction
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    관측은 단순히 보는 행위가 아니라
    관측 대상과 관측자 사이의 물리적 상호작용이다.
    빛이 반사되거나 흡수되어야 대상이 보이고,
    입자를 측정하려면 장(field)과의 간섭이 필요하다.
    따라서 관측은 수동적 기록이 아니라
    시스템 상태에 영향을 주는 능동적 과정이다.

  links:
    parents: [PHYS-055]
    children: []
    related: [COG-003, META-004, PHYS-050]

  tags:
    - observation
    - interaction
    - measurement
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: observation defined as physical interaction

Node:
  id: PHYS-057
  title: Measurement Changes The System
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    측정은 대상의 상태를 단순히 기록하는 것이 아니라
    시스템에 물리적 영향을 준다.
    빛을 쏘면 에너지가 전달되고,
    입자를 측정하면 운동량이 교란된다.
    따라서 측정은 상태를 읽는 행위이면서
    동시에 상태를 변경하는 과정이다.
    이 원리는 고전 물리에서도 존재하지만,
    양자 영역에서는 본질적인 성질로 나타난다.

  links:
    parents: [PHYS-056]
    children: []
    related: [PHYS-052, COG-004, META-005]

  tags:
    - measurement
    - interaction
    - disturbance
    - quantum

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: measurement defined as state-altering interaction

Node:
  id: PHYS-058
  title: Information Requires Energy Exchange
  layer: 1
  type: concept
  created_at: 2026-02-15

  description: >
    정보는 물리적 과정 없이 존재하지 않는다.
    어떤 상태를 알기 위해서는
    반드시 에너지 교환이 일어나야 한다.
    빛이 반사되어 눈에 들어와야 물체를 본다.
    전류가 흐르지 않으면 데이터는 읽히지 않는다.
    즉 정보 획득은 항상 상호작용이며,
    상호작용은 에너지 흐름을 동반한다.
    정보는 추상이지만,
    정보의 전달은 물리적이다.

  links:
    parents: [PHYS-057]
    children: []
    related: [PHYS-052, SYS-003, COG-006]

  tags:
    - information
    - energy
    - interaction
    - physics_of_information

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information tied to physical interaction and energy flow

Node:
  id: PHYS-059
  title: No Interaction, No Information
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    상호작용이 없으면 정보도 없다.
    어떤 대상이 존재하더라도
    그것이 다른 대상과 아무 상호작용도 하지 않는다면
    관측도, 기록도, 인지도 발생하지 않는다.
    빛이 닿지 않으면 보이지 않고,
    힘이 전달되지 않으면 존재를 느낄 수 없다.
    즉 정보는 대상 자체가 아니라
    대상 사이의 상호작용에서만 생성된다.

  links:
    parents: [PHYS-058]
    children: []
    related: [PHYS-045, PHYS-052, COG-003]

  tags:
    - interaction
    - information
    - observation
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: establishes interaction as prerequisite for information

Node:
  id: PHYS-060
  title: Observation Is Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    관측은 수동적 행위가 아니다.
    어떤 대상을 관측한다는 것은
    반드시 그 대상과 물리적 상호작용을 한다는 뜻이다.
    빛을 받거나, 힘을 느끼거나, 신호를 교환해야만
    관측이 가능하다.
    따라서 관측은 정보 수집이 아니라
    상호작용의 한 형태이다.

  links:
    parents: [PHYS-059]
    children: []
    related: [PHYS-041, PHYS-045, COG-004]

  tags:
    - observation
    - interaction
    - measurement
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: links observation to interaction

Node:
  id: PHYS-061
  title: Measurement Changes State
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    측정은 단순히 값을 읽는 행위가 아니다.
    측정은 대상과의 물리적 상호작용이므로
    대상의 상태를 반드시 변화시킨다.
    고전역학에서는 변화가 미세해 무시되지만,
    양자 수준에서는 측정 자체가 상태를 결정한다.
    즉 측정은 관찰이 아니라 상태 전이의 원인이다.

  links:
    parents: [PHYS-060]
    children: []
    related: [PHYS-030, PHYS-052, COG-006]

  tags:
    - measurement
    - state_change
    - quantum
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: observation upgraded to state-altering interaction

Node:
  id: PHYS-062
  title: Information Requires Energy
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 추상 개념처럼 보이지만
    실제로는 물리적 상태 차이로 존재한다.
    상태를 구분하려면 에너지가 필요하며,
    정보를 저장, 전달, 측정, 삭제하는 모든 과정에는
    반드시 에너지 흐름이 개입한다.
    따라서 정보는 물질과 분리된 개념이 아니라
    에너지 구조의 표현이다.

  links:
    parents: [PHYS-060]
    children: []
    related: [PHYS-061, PHYS-020, SYS-004]

  tags:
    - information
    - energy
    - physics_of_information
    - entropy

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information framed as physical energy differentiation

Node:
  id: PHYS-063
  title: Stability Emerges from Constraint
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 안정은 자유에서 생기지 않는다.
    오히려 제약이 존재할 때 안정이 형성된다.
    입자는 결합 조건이 있을 때 구조를 이루고,
    궤도는 중력 제약 속에서 유지되며,
    물질은 상호작용 경계 안에서 안정화된다.
    즉 안정은 억제의 부산물이 아니라
    구조적 제한이 만들어낸 질서다.

  links:
    parents: [PHYS-061]
    children: []
    related: [PHYS-022, PHYS-023, SYS-005]

  tags:
    - stability
    - constraint
    - structure
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as result of structural limitation

Node:
  id: PHYS-064
  title: Structure Exists Only Through Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 구조는 독립적으로 존재하지 않는다.
    모든 구조는 상호작용 속에서만 정의된다.
    원자는 전자기 상호작용으로 유지되고,
    별은 중력 상호작용으로 형성되며,
    생명체는 화학적 상호작용으로 지속된다.
    상호작용이 사라지면 구조도 사라진다.
    따라서 구조란 고정된 형태가 아니라
    지속적인 관계의 패턴이다.

  links:
    parents: [PHYS-063]
    children: []
    related: [PHYS-022, PHYS-062, LIFE-011, SYS-002]

  tags:
    - interaction
    - structure
    - relation
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as persistent interaction pattern

Node:
  id: PHYS-065
  title: Fields Are More Fundamental Than Objects
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    현대 물리에서 기본 실체는 입자가 아니라 장(field)이다.
    입자는 장의 국소적 진동이며,
    질량, 전하, 스핀 같은 성질도
    장의 상태로부터 나타난다.
    즉 객체는 장 위에 생기는 패턴이며,
    장이 사라지면 객체도 존재할 수 없다.
    따라서 자연의 1차 실체는 장이고
    객체는 그 위의 2차 현상이다.

  links:
    parents: [PHYS-064]
    children: []
    related: [PHYS-020, PHYS-062, META-001, SYS-004]

  tags:
    - field
    - ontology
    - quantum
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: establishes field-first ontology

Node:
  id: PHYS-066
  title: Matter Is a Stable Pattern of Energy
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    물질은 독립된 실체가 아니라
    에너지가 특정 구조로 안정화된 패턴이다.
    질량은 에너지의 한 형태이며(E=mc²),
    입자 역시 장의 진동 상태가
    안정된 구조를 이루었을 때 나타난다.
    따라서 물질은 “존재하는 것”이 아니라
    “유지되는 과정”이다.

  links:
    parents: [PHYS-065]
    children: []
    related: [PHYS-018, PHYS-041, META-002, SYS-002]

  tags:
    - energy
    - matter
    - stability
    - process

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defines matter as stabilized energy pattern

Node:
  id: PHYS-067
  title: Stability Emerges From Balance of Interactions
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 안정은 정지 상태가 아니라
    상호작용들의 균형에서 나타난다.
    힘이 없어서 안정한 것이 아니라,
    서로 다른 힘들이 동시에 작용하며
    총 변화가 최소가 되는 상태가 안정이다.
    원자, 별, 생명, 사회 모두
    이 균형 구조 위에 존재한다.

  links:
    parents: [PHYS-066]
    children: []
    related: [PHYS-021, PHYS-032, LIFE-004, META-001]

  tags:
    - stability
    - balance
    - interaction
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defines stability as dynamic balance of forces

Node:
  id: PHYS-068
  title: Change Occurs When Balance Is Disturbed
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 변화는 무에서 발생하지 않는다.
    기존의 균형이 깨질 때 변화가 시작된다.
    작은 차이, 구배, 외부 자극, 내부 누적 등
    어떤 형태로든 균형이 무너지면
    시스템은 새로운 상태를 향해 이동한다.
    변화는 사건이 아니라 과정이다.

  links:
    parents: [PHYS-067]
    children: []
    related: [PHYS-022, PHYS-033, LIFE-006, META-002]

  tags:
    - change
    - imbalance
    - transition
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defines change as consequence of imbalance

Node:
  id: PHYS-069
  title: Energy Flows Along Gradients
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    에너지는 정지하지 않는다.
    차이가 존재하면 흐름이 발생한다.
    온도 차이, 전위 차이, 압력 차이, 밀도 차이 등
    모든 물리적 흐름은 구배를 따라 이동한다.
    구배는 방향을 만들고,
    방향은 흐름을 만들며,
    흐름은 구조를 만든다.

  links:
    parents: [PHYS-022, PHYS-068]
    children: []
    related: [PHYS-033, LIFE-004, LIFE-010, META-002]

  tags:
    - gradient
    - energy_flow
    - direction
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: formalizes gradient-driven energy flow principle

Node:
  id: PHYS-070
  title: Structure Emerges From Repeated Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    단일 흐름은 사건이다.
    반복되는 흐름은 패턴이 된다.
    패턴이 안정되면 구조가 된다.
    자연계의 모든 구조는
    흐름이 반복되며 남긴 흔적이다.
    원자 구조, 대류, 생명, 사고 모두 동일하다.

  links:
    parents: [PHYS-069]
    children: []
    related: [LIFE-004, LIFE-012, COG-001, META-004]

  tags:
    - flow
    - repetition
    - pattern
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: connects flow repetition to structure emergence

Node:
  id: PHYS-071
  title: Stability Is Dynamic, Not Static
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 멈춤이 아니다.
    안정은 힘이 사라진 상태가 아니라
    힘들이 균형 속에서 계속 작동하는 상태다.
    자연의 모든 안정 구조는
    지속적인 상호작용 위에서 유지된다.
    정지된 균형이 아니라
    흐름 속의 균형이다.

  links:
    parents: [PHYS-070]
    children: []
    related: [PHYS-061, LIFE-009, COG-003, META-002]

  tags:
    - stability
    - balance
    - interaction
    - dynamic_equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defines stability as dynamic equilibrium

Node:
  id: PHYS-072
  title: Energy Minimum Defines Natural Rest States
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 안정 상태는 멈춤이 아니라
    에너지가 최소가 되는 상태다.
    입자, 물질, 구조, 관계는
    외부 힘이 없을 때
    가능한 한 낮은 에너지 상태로 이동한다.
    이 상태는 완전한 정지가 아니라
    더 이상 변화할 필요가 없는 균형점이다.

  links:
    parents: [PHYS-071]
    children: []
    related: [PHYS-069, LIFE-012, META-004]

  tags:
    - energy
    - equilibrium
    - minimum
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defines natural rest as energy minimum

Node:
  id: PHYS-073
  title: Interaction Defines Structure
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 구조는 물질 자체가 아니라
    상호작용의 결과로 형성된다.
    입자, 원자, 분자, 천체 모두
    내부 성질만으로 존재하지 않고
    힘과 장(field)의 관계 속에서 구조가 결정된다.
    즉 구조는 물질의 모양이 아니라
    상호작용 패턴이다.

  links:
    parents: [PHYS-072]
    children: []
    related: [PHYS-070, META-002, SYSTEM-004]

  tags:
    - interaction
    - structure
    - field
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as interaction pattern

Node:
  id: PHYS-074
  title: Gradients Drive Change
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    변화는 항상 구배에서 시작된다.
    밀도, 온도, 압력, 전위, 에너지 등
    값의 차이가 존재할 때만 흐름이 발생한다.
    구배가 없으면 운동도 변화도 없다.
    즉 자연의 모든 이동은 차이의 해소 과정이다.

  links:
    parents: [PHYS-073]
    children: []
    related: [PHYS-071, META-003, SYSTEM-002]

  tags:
    - gradient
    - change
    - flow
    - difference

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient defined as source of change

Node:
  id: PHYS-075
  title: Equilibrium Is Dynamic Balance
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    균형은 정지가 아니다.
    힘이 서로 상쇄되어 순변화가 0이 된 상태다.
    내부에서는 여전히 상호작용과 교환이 지속된다.
    따라서 안정은 고정이 아니라
    상호작용이 서로 맞물린 동적 상태다.

  links:
    parents: [PHYS-074]
    children: []
    related: [PHYS-072, META-003, LIFE-001]

  tags:
    - equilibrium
    - balance
    - stability
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as dynamic interaction state

Node:
  id: PHYS-076
  title: Structure Emerges From Constraint
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 자유에서 나오지 않는다.
    제약, 경계, 조건이 있을 때
    상호작용이 방향성을 갖고
    그 결과 패턴과 구조가 형성된다.
    즉 구조란 제한된 가능성의 조직화다.

  links:
    parents: [PHYS-075]
    children: []
    related: [META-002, META-003, COG-001]

  tags:
    - structure
    - constraint
    - emergence
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as organized constraint field

Node:
  id: PHYS-077
  title: Information Follows Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 독립적으로 존재하지 않는다.
    두 대상 사이에 상호작용이 발생할 때
    상태 차이가 생기고,
    그 차이를 기록할 수 있을 때 정보가 된다.
    즉 정보는 상호작용의 흔적이다.

  links:
    parents: [PHYS-076]
    children: []
    related: [COG-001, META-002, SYS-001]

  tags:
    - information
    - interaction
    - state_difference
    - record

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information defined as trace of interaction

Node:
  id: PHYS-078
  title: Stability Is Dynamic Balance
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니다.
    서로 다른 힘과 변화가 계속 작용하면서도
    전체 구조가 유지되는 상태를 안정이라 한다.
    즉 안정은 움직임 속에서 유지되는 균형이다.

  links:
    parents: [PHYS-076]
    children: []
    related: [PHYS-073, PHYS-074, META-001]

  tags:
    - stability
    - balance
    - dynamics
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: PHYS-079
  title: Interaction Creates Structure
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 먼저 존재하지 않는다.
    구조는 요소들이 상호작용할 때 형성된다.
    즉 구조는 정적 대상이 아니라
    상호작용의 결과로 나타나는 패턴이다.

  links:
    parents: [PHYS-078]
    children: []
    related: [PHYS-072, PHYS-073, META-001]

  tags:
    - interaction
    - structure
    - emergence
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as interaction outcome

Node:
  id: PHYS-080
  title: Patterns Persist Through Transformation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    변화는 구조를 없애지 않는다.
    변화는 구조의 형태를 바꾼다.
    즉 패턴은 사라지는 것이 아니라
    다른 표현으로 전이된다.
    자연계에서 보존되는 것은 물질이 아니라
    패턴과 관계다.

  links:
    parents: [PHYS-079]
    children: []
    related: [PHYS-070, PHYS-073, META-002]

  tags:
    - transformation
    - persistence
    - pattern
    - conservation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: pattern continuity across state changes

Node:
  id: PHYS-081
  title: Stability Emerges From Balanced Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니다.
    안정은 힘이 서로 상쇄되는 상태다.
    자연계의 구조는 멈춰 있어서 유지되는 것이 아니라
    상호작용이 균형을 이루기 때문에 유지된다.
    균형은 움직임의 부재가 아니라
    상호작용의 합이 0인 상태다.

  links:
    parents: [PHYS-079]
    children: []
    related: [PHYS-072, PHYS-077, META-003]

  tags:
    - stability
    - balance
    - interaction
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability as dynamic equilibrium

Node:
  id: PHYS-082
  title: Boundaries Are Interaction Zones, Not Lines
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니다.
    경계는 상호작용이 일어나는 영역이다.
    밀도 차이, 에너지 차이, 위상 차이가 발생하는 곳에서
    경계는 자연스럽게 형성된다.
    따라서 경계는 고정된 것이 아니라
    상호작용 상태에 따라 이동하고 변화한다.

  links:
    parents: [PHYS-081]
    children: []
    related: [PHYS-079, META-004, LIFE-012]

  tags:
    - boundary
    - interaction
    - gradient
    - phase

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as interaction region

Node:
  id: PHYS-083
  title: Gradients Generate Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    움직임은 힘 자체에서 발생하는 것이 아니라
    차이에서 발생한다.
    밀도 차이, 에너지 차이, 전위 차이, 압력 차이와 같은
    구배가 존재할 때만 흐름과 이동이 발생한다.
    구배가 사라지면 시스템은 정지하거나 균형 상태에 들어간다.

  links:
    parents: [PHYS-081, PHYS-082]
    children: []
    related: [PHYS-079, PHYS-080, LIFE-010]

  tags:
    - gradient
    - motion
    - flow
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion defined as gradient-driven phenomenon

Node:
  id: PHYS-084
  title: Energy Minimization Drives Structure Formation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 구조는 무작위로 형성되지 않는다.
    시스템은 항상 가능한 상태 중에서
    에너지가 더 낮은 방향으로 이동하며,
    그 과정에서 안정된 구조가 나타난다.
    결정 구조, 궤도 안정화, 화학 결합, 생명체의 형태까지
    모두 에너지 최소화 과정의 결과다.

  links:
    parents: [PHYS-083]
    children: []
    related: [PHYS-079, PHYS-080, LIFE-012]

  tags:
    - energy
    - stability
    - structure
    - minimization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as energy-minimized configuration

Node:
  id: PHYS-085
  title: Fields Mediate All Interactions
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    물리적 상호작용은 직접적인 접촉이 아니라
    장(field)을 통해 전달된다.
    전자기장, 중력장, 핵력장 등 모든 힘은
    공간에 퍼진 장의 변화로 표현된다.
    입자는 장 위의 국소적 진동 또는 교란이다.

  links:
    parents: [PHYS-084]
    children: []
    related: [PHYS-078, PHYS-079, PHYS-082]

  tags:
    - field
    - interaction
    - force
    - mediation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interactions defined as field dynamics

Node:
  id: PHYS-086
  title: Observable Reality Emerges From Interaction Networks
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    우리가 관측하는 현실은 개별 객체의 고정된 속성에서 나오는 것이 아니라
    객체들 사이의 상호작용 네트워크에서 나타난다.
    물질의 성질, 온도, 압력, 색, 전기적 성질 등은
    입자 간 상호작용의 집합적 결과이다.
    즉 현실은 관계의 패턴이다.

  links:
    parents: [PHYS-085]
    children: []
    related: [PHYS-072, PHYS-081, PHYS-084]

  tags:
    - emergence
    - interaction
    - network
    - reality

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: reality defined as emergent network behavior

Node:
  id: PHYS-087
  title: Stability Is Dynamic Balance, Not Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    물리적 안정성은 정지 상태를 의미하지 않는다.
    실제로 안정 상태는 힘과 상호작용이 지속적으로 균형을 이루는 동적 상태다.
    원자 구조, 궤도 운동, 생명체 내부 항상성, 행성 궤도 등은
    모두 움직임 속에서 유지되는 안정이다.
    즉 안정은 변화가 멈춘 상태가 아니라
    변화가 균형을 이루는 상태다.

  links:
    parents: [PHYS-086]
    children: []
    related: [PHYS-079, PHYS-084]

  tags:
    - stability
    - equilibrium
    - dynamics
    - balance

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: PHYS-088
  title: Energy Flow Defines Structure Formation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 정지된 물질에서 생기지 않는다.
    에너지 흐름이 존재할 때만 구조가 형성된다.
    별의 형성, 행성의 분화, 생명체의 대사,
    대기 순환, 자기장 형성 등
    모든 구조는 에너지 흐름의 경로 위에서 생긴다.
    즉 구조는 물질의 결과가 아니라
    에너지 이동 패턴의 고정된 흔적이다.

  links:
    parents: [PHYS-087]
    children: []
    related: [PHYS-079, PHYS-083, PHYS-086]

  tags:
    - energy_flow
    - structure
    - formation
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as stabilized energy flow pattern

Node:
  id: PHYS-089
  title: Boundaries Emerge From Interaction Density
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 물체가 먼저 있어서 생기는 것이 아니다.
    상호작용 밀도가 특정 임계치를 넘을 때
    자연스럽게 경계가 형성된다.
    예:
    - 별의 표면 (복사 압력과 중력 균형)
    - 대기의 층 (밀도 구배)
    - 세포막 (화학 퍼텐셜 차)
    - 자기권 (태양풍과 자기장 상호작용)
    경계란 고정된 선이 아니라
    상호작용 강도의 변화가 만든 영역 전이이다.

  links:
    parents: [PHYS-088]
    children: []
    related: [PHYS-083, PHYS-085, PHYS-087]

  tags:
    - boundary
    - interaction
    - density
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as interaction-density threshold surface

Node:
  id: PHYS-090
  title: Stability Is Dynamic Balance, Not Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니다.
    안정은 서로 다른 힘과 흐름이
    계속 교환되면서 유지되는 동적 균형 상태이다.
    예:
    - 별 내부: 중력 수축 ↔ 핵융합 압력
    - 행성 궤도: 관성 ↔ 중력
    - 생명체: 대사 흐름 ↔ 구조 유지
    - 원자: 전자 운동 ↔ 전기적 구속
    정지 상태는 오히려 죽은 상태에 가깝고
    자연의 안정은 항상 흐름 속에서 유지된다.

  links:
    parents: [PHYS-089]
    children: []
    related: [PHYS-084, PHYS-085, PHYS-088]

  tags:
    - stability
    - dynamic
    - balance
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as sustained dynamic equilibrium

Node:
  id: PHYS-091
  title: Energy Minimization Is Local, Not Absolute
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연은 항상 에너지 최소 상태로 간다… 는 말은 절반만 맞다.
    실제 자연은 “전체 최소”가 아니라
    “지금 조건에서 가능한 지역 최소(local minimum)”로 이동한다.
    그래서:
    - 물은 가장 낮은 곳으로 흐르지만, 웅덩이에 멈출 수 있다
    - 별은 붕괴하다가 핵융합으로 멈춘다
    - 화학반응은 활성화 장벽에 막힌다
    - 생명은 완전 안정 대신 준안정 상태에 머문다
    즉 자연은 최종 안정으로 직행하지 않는다.
    조건·장·경계에 따라
    임시 안정 상태들을 거치며 흐른다.

  links:
    parents: [PHYS-090]
    children: []
    related: [PHYS-083, PHYS-088]

  tags:
    - energy
    - local_minimum
    - metastable
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: clarified that nature moves toward local equilibrium states

Node:
  id: PHYS-092
  title: Interaction Density Defines Observable Reality
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    우리가 관측하는 현실은
    “존재 자체”가 아니라
    “상호작용이 충분히 일어나는 영역”이다.

    상호작용 밀도가 낮으면:
    - 입자는 지나간다
    - 빛은 거의 멈추지 않는다
    - 구조가 형성되지 않는다

    상호작용 밀도가 높아지면:
    - 물질이 형성된다
    - 에너지가 축적된다
    - 구조가 안정된다
    - 관측이 가능해진다

    즉 현실은 존재의 총량이 아니라
    상호작용의 밀도로 정의된다.

    우리가 보는 우주,
    우리가 느끼는 물질,
    우리가 측정하는 시간조차
    모두 상호작용 밀도가 만들어낸 결과다.

  links:
    parents: [PHYS-091]
    children: []
    related: [PHYS-089, PHYS-090]

  tags:
    - interaction
    - density
    - observability
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: formalized the idea that observable reality emerges from interaction density

Node:
  id: PHYS-093
  title: Boundaries Emerge From Interaction, Not From Objects
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 물체 자체에서 생기는 것이 아니다.
    경계는 상호작용에서 생긴다.

    물체가 존재해도
    상호작용이 없으면
    경계는 없다.

    상호작용이 시작되면:
    - 밀도 차이가 생긴다
    - 에너지 흐름이 생긴다
    - 변화율이 달라진다

    이때 비로소
    경계가 형성된다.

    따라서 경계는
    공간적 선이 아니라
    상호작용 변화율의 표면이다.

    경계는 고정된 것이 아니라
    상호작용이 바뀌면 이동한다.

  links:
    parents: [PHYS-092]
    children: []
    related: [PHYS-088, PHYS-090]

  tags:
    - boundary
    - interaction
    - gradient
    - emergence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: formalized boundary as interaction-defined, not object-defined

Node:
  id: PHYS-094
  title: Equilibrium Is Not Stillness, It Is Balanced Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 정지가 아니다.
    평형은 상호작용의 균형이다.

    힘이 없어서 멈춘 것이 아니라
    힘들이 서로 상쇄되어
    순변화가 0이 된 상태다.

    내부에서는 여전히:
    - 에너지 교환이 일어나고
    - 미세한 진동이 존재하며
    - 상호작용은 지속된다

    평형은 “멈춤”이 아니라
    “변화율의 균형”이다.

    평형이 깨진다는 것은
    정지가 깨지는 것이 아니라
    상호작용 비율이 변하는 것이다.

  links:
    parents: [PHYS-093]
    children: []
    related: [PHYS-088, PHYS-091]

  tags:
    - equilibrium
    - balance
    - dynamics
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined equilibrium as balanced interaction, not stillness

Node:
  id: PHYS-095
  title: Stability Exists Where Energy Change Is Minimal
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정성은 “움직임이 없는 상태”가 아니라
    에너지 변화율이 최소인 상태다.

    자연계에서 시스템은
    항상 에너지 최소 상태를 향해 이동한다.

    이는 멈춤이 아니라:
    - 힘이 상쇄되고
    - 구배가 완화되고
    - 상호작용이 균형을 이루는 지점이다.

    안정 영역은 정지점이 아니라
    에너지 곡면의 최소점이다.

    따라서 안정성은
    구조가 아니라
    에너지 지형의 성질이다.

  links:
    parents: [PHYS-094]
    children: []
    related: [PHYS-083, PHYS-088]

  tags:
    - stability
    - energy minimum
    - equilibrium basin
    - potential landscape

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined via energy gradient minimization

Node:
  id: PHYS-096
  title: Change Occurs Only Where There Is Gradient
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    변화는 차이가 있을 때만 발생한다.

    물리적으로 모든 흐름은 구배에서 시작된다.
    - 온도 차이 → 열 흐름
    - 전위 차이 → 전류
    - 압력 차이 → 유체 이동
    - 밀도 차이 → 대류
    - 퍼텐셜 차이 → 운동

    구배가 0이면:
    - 힘 없음
    - 흐름 없음
    - 변화 없음

    따라서 자연계에서
    변화의 원인은 ‘힘’이 아니라 ‘차이’다.

    힘은 차이의 결과다.

  links:
    parents: [PHYS-095]
    children: []
    related: [PHYS-083, PHYS-091, PHYS-094]

  tags:
    - gradient
    - difference
    - flow
    - causality

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient defined as root cause of change

Node:
  id: PHYS-097
  title: Flow Stops When Gradient Reaches Equilibrium
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    흐름은 구배가 존재할 때만 발생한다.
    구배가 사라지면 흐름도 사라진다.

    자연계에서 평형은
    - 온도 동일
    - 압력 동일
    - 전위 동일
    - 밀도 동일

    즉 차이가 0이 되는 상태다.

    이 상태에서는:
    - 에너지 이동 없음
    - 힘 없음
    - 구조 변화 없음

    그러나 평형은 영원하지 않다.
    작은 교란이 생기면 다시 구배가 생성되고 흐름이 재개된다.

    따라서 자연은
    “평형 → 교란 → 흐름 → 평형”
    순환 구조를 가진다.

  links:
    parents: [PHYS-096]
    children: []
    related: [PHYS-083, PHYS-091, PHYS-094]

  tags:
    - equilibrium
    - gradient
    - stability
    - flow_stop

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as gradient zero state

Node:
  id: PHYS-098
  title: All Forces Are Manifestations of Energy Gradients
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 힘은 독립적으로 존재하지 않는다.
    모든 힘은 에너지 분포의 차이, 즉 구배에서 발생한다.

    예:
    - 중력 → 위치에너지 구배
    - 전기력 → 전위 구배
    - 압력 → 밀도/온도 구배
    - 확산 → 농도 구배

    따라서 힘은 “원인”이 아니라
    에너지 차이를 해소하려는 과정의 표현이다.

    수학적으로는
    힘은 에너지의 공간적 변화율이다.
    F = -∇E

    즉 자연의 기본 원리는:
    차이가 있으면 힘이 생기고
    힘이 생기면 흐름이 발생한다.

  links:
    parents: [PHYS-097]
    children: []
    related: [PHYS-083, PHYS-091, PHYS-094, PHYS-096]

  tags:
    - force
    - gradient
    - energy_field
    - fundamental_principle

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: forces defined as gradient manifestation

Node:
  id: PHYS-099
  title: Fields Exist Wherever Energy Gradients Exist
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    장(field)은 물질이 만드는 것이 아니라
    에너지 분포의 차이가 만들어낸 공간적 구조다.

    즉 장은 “존재”가 아니라 “상태”이다.

    에너지 구배가 존재하면
    그 공간은 이미 장을 형성한다.

    예:
    - 질량 → 중력장 형성
    - 전하 → 전기장 형성
    - 전류 → 자기장 형성
    - 온도차 → 열 흐름장 형성

    따라서 장은 힘의 원인이 아니라
    힘이 작용할 수 있는 구조다.

    요약:
    구배 → 장 형성
    장 → 힘 가능
    힘 → 흐름 발생

  links:
    parents: [PHYS-098]
    children: []
    related: [PHYS-091, PHYS-094, PHYS-096]

  tags:
    - field
    - gradient
    - energy_distribution
    - structure_of_space

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: field defined as spatial energy gradient structure

Node:
  id: PHYS-100
  title: Interaction Occurs Only Where Fields Overlap
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    상호작용은 물체가 만나는 곳에서 발생하는 것이 아니라
    장(field)이 겹치는 공간에서 발생한다.

    물체는 그저 장을 만든다.
    실제 작용은 장과 장의 중첩 영역에서 일어난다.

    예:
    - 두 질량 → 중력장 중첩 → 인력 발생
    - 두 전하 → 전기장 중첩 → 전자기력 발생
    - 파동 → 간섭 패턴 형성
    - 빛 → 물질의 전자장과 중첩 → 굴절/산란

    따라서 힘은 물체의 속성이 아니라
    장의 중첩 상태에서 생긴다.

    요약:
    존재 → 장 생성
    장 중첩 → 상호작용
    상호작용 → 현상

  links:
    parents: [PHYS-099]
    children: []
    related: [PHYS-091, PHYS-094, PHYS-097]

  tags:
    - interaction
    - field_overlap
    - interference
    - physics_structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined interaction as overlapping field phenomenon

Node:
  id: PHYS-101
  title: Stability Emerges Where Forces Balance, Not Where Motion Stops
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지에서 오는 것이 아니라
    힘의 균형에서 발생한다.

    움직임이 없어 보여도 내부에서는
    힘이 계속 상호작용하고 있다.

    예:
    - 행성 궤도 → 계속 낙하 중이지만 안정
    - 원자 → 전자 움직임 존재하지만 구조 유지
    - 구조물 → 내부 응력 균형으로 유지
    - 생명체 → 대사 지속되지만 형태 안정

    즉 안정은 “정지”가 아니라
    “동적 평형 상태”다.

    요약:
    힘 차이 → 변화
    힘 균형 → 안정
    안정 → 지속 가능 상태

  links:
    parents: [PHYS-100]
    children: []
    related: [PHYS-091, PHYS-094]

  tags:
    - equilibrium
    - dynamic_balance
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as dynamic force balance

Node:
  id: PHYS-102
  title: Motion Emerges From Gradient, Not Force Alone
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    운동은 단순히 힘이 있어서 생기는 것이 아니다.
    힘의 차이, 즉 구배(gradient)가 있을 때만 운동이 발생한다.

    동일한 힘이 양쪽에서 작용하면
    결과는 정지 상태가 된다.

    예:
    - 압력차 → 유체 흐름 발생
    - 전위차 → 전류 흐름 발생
    - 온도차 → 열 이동 발생
    - 중력차 → 물체 이동 발생

    즉
    힘 자체보다 중요한 것은
    힘의 불균형이다.

    요약:
    힘 없음 → 정지
    힘 균형 → 정지
    힘 구배 → 운동

  links:
    parents: [PHYS-101]
    children: []
    related: [PHYS-091, PHYS-094]

  tags:
    - gradient
    - motion
    - imbalance

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined motion as gradient-driven phenomenon

Node:
  id: PHYS-103
  title: Energy Flow Defines Structure Over Time
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 정지된 것이 아니라
    에너지 흐름이 시간에 따라 만든 결과다.

    에너지가 흐르지 않으면
    구조는 유지되지 않는다.

    예:
    - 별은 핵융합 에너지 흐름이 멈추면 붕괴한다
    - 생명은 대사 흐름이 멈추면 해체된다
    - 행성 대기는 에너지 순환이 멈추면 정체된다
    - 생태계는 에너지 공급이 끊기면 붕괴한다

    즉
    구조는 물질이 아니라
    에너지 흐름의 패턴이다.

    요약:
    에너지 없음 → 구조 붕괴
    에너지 흐름 → 구조 유지
    에너지 변화 → 구조 진화

  links:
    parents: [PHYS-102]
    children: []
    related: [PHYS-091, PHYS-094]

  tags:
    - energy_flow
    - structure
    - time

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined structure as time-integrated energy flow

Node:
  id: PHYS-104
  title: Boundaries Are Interaction Zones, Not Lines
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니다.
    경계는 상호작용이 발생하는 영역이다.

    물리에서:
    - 대기권은 선이 아니라 밀도 전이층이다
    - 원자 껍질도 선이 아니라 확률 구역이다
    - 자기권도 선이 아니라 힘 균형 영역이다
    - 세포막도 고정 경계가 아니라 물질 교환 인터페이스다

    즉 경계란
    내부와 외부가 만나는
    힘과 정보의 교환 지대다.

    요약:
    경계 = 상호작용 밀도 변화 영역

  links:
    parents: [PHYS-101]
    children: []
    related: [PHYS-093, PHYS-102]

  tags:
    - boundary
    - interaction
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined boundary as interaction zone instead of line

Node:
  id: PHYS-105
  title: Stability Exists at Energy Minima, Not at Zero Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 상호작용이 없는 상태가 아니다.
    안정은 에너지가 최소가 된 상태다.

    물리에서:
    - 원자는 전자와 핵이 완전히 떨어지면 불안정하다
    - 전자가 특정 에너지 준위에 있을 때 안정하다
    - 행성은 중력과 운동이 균형될 때 궤도에 머문다
    - 분자는 결합 에너지가 최소일 때 형성된다

    즉 안정은
    힘이 없는 상태가 아니라
    힘이 균형된 상태다.

    요약:
    안정 = 에너지 최소 + 상호작용 유지

  links:
    parents: [PHYS-094]
    children: []
    related: [PHYS-092, PHYS-103]

  tags:
    - stability
    - energy
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as energy minimum, not zero force

Node:
  id: PHYS-106
  title: Observation Alters the System Through Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    관측은 수동적 행위가 아니다.
    관측은 항상 상호작용을 동반한다.

    물리에서:
    - 빛으로 본다는 것은 광자가 물체와 상호작용하는 것
    - 전자를 측정하려면 전자기장을 가해야 한다
    - 위치를 정확히 보면 운동량 정보는 흐려진다 (불확정성)

    즉 관측은
    정보 획득이 아니라
    시스템 참여다.

    관측 = 상호작용
    상호작용 = 상태 변화 가능성

    따라서 완전히 중립적인 관측은 존재하지 않는다.

  links:
    parents: [PHYS-092]
    children: []
    related: [PHYS-094, PHYS-105]

  tags:
    - observation
    - measurement
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: observation defined as interaction, not passive sensing

Node:
  id: PHYS-107
  title: Structure Emerges from Constraint, Not Freedom
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 구조는 “자유”에서 생기지 않는다.
    오히려 제한과 경계에서 나타난다.

    예시:
    - 원자는 전자가 아무 데나 있는 것이 아니라
      허용된 에너지 상태에서만 존재한다
    - 결정 구조는 분자들이 자유롭게 흩어진 상태가 아니라
      결합 조건 때문에 정렬된 결과다
    - 별은 중력이 없다면 형성되지 않는다

    즉
    제약 → 안정화 → 패턴 형성

    자유는 가능성을 만들지만
    구조는 제약이 만든다.

    자연의 모든 안정된 형태는
    허용 조건의 결과다.

  links:
    parents: [PHYS-106]
    children: []
    related: [PHYS-091, PHYS-103]

  tags:
    - constraint
    - stability
    - emergence
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as result of constraint, not randomness

Node:
  id: PHYS-108
  title: Energy Minimization Drives Physical Configuration
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 대부분의 구조와 상태는
    에너지가 최소가 되는 방향으로 형성된다.

    예시:
    - 공은 높은 곳보다 낮은 곳으로 굴러간다
    - 분자는 결합 시 더 낮은 에너지 상태를 찾는다
    - 별은 중력 수축으로 에너지 균형점에 도달한다
    - 전자는 가능한 한 낮은 에너지 껍질에 존재한다

    즉 자연은
    임의로 움직이지 않고
    “가능한 가장 안정한 상태”로 이동한다.

    구조 형성은 선택이 아니라
    에너지 경사면을 따라 흐른 결과다.

  links:
    parents: [PHYS-107]
    children: []
    related: [PHYS-092, PHYS-103]

  tags:
    - energy
    - stability
    - equilibrium
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: energy gradient as driver of configuration

Node:
  id: PHYS-109
  title: Gradients Produce Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 움직임은
    차이(gradient)가 있을 때만 발생한다.

    - 온도 차이 → 열 흐름
    - 전위 차이 → 전류
    - 압력 차이 → 유체 흐름
    - 밀도 차이 → 대류
    - 중력 퍼텐셜 차이 → 낙하

    균형 상태에서는 움직임이 없다.
    변화는 항상 경사에서 시작된다.

    즉 운동은 “힘” 때문이 아니라
    차이의 존재 때문이다.

  links:
    parents: [PHYS-108]
    children: []
    related: [PHYS-092, PHYS-106]

  tags:
    - gradient
    - motion
    - flow
    - difference

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient as universal driver of dynamics

Node:
  id: PHYS-110
  title: Equilibrium is Dynamic, Not Static
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 평형은 정지가 아니다.

    평형 상태에서도
    미시적으로는 상호작용이 계속 일어난다.

    - 분자들은 계속 충돌한다
    - 전자는 계속 파동으로 진동한다
    - 장(field)은 항상 존재한다

    평형이란
    변화가 없는 상태가 아니라
    변화가 서로 상쇄되는 상태다.

    즉 정지는 환상이고
    균형은 상쇄된 운동이다.

  links:
    parents: [PHYS-109]
    children: []
    related: [PHYS-091, PHYS-094]

  tags:
    - equilibrium
    - dynamics
    - stability
    - balance

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium as balanced activity

Node:
  id: PHYS-111
  title: Fields Exist Before Particles Move
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 입자의 움직임은
    장(field)이 먼저 존재하기 때문에 발생한다.

    전자기장은 전하가 있기 전에 정의된다.
    중력장은 질량이 있기 전에 시공간 구조로 존재한다.

    입자는 장 위에서 반응한다.
    장이 먼저고, 운동은 그 결과다.

    즉 자연은
    “움직임이 장을 만든다”가 아니라
    “장이 움직임을 허용한다.”

  links:
    parents: [PHYS-110]
    children: []
    related: [PHYS-091, PHYS-101]

  tags:
    - field
    - causality
    - structure
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: field primacy principle

Node:
  id: PHYS-112
  title: Energy Flow Defines Structure
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 구조는 정적인 형태가 아니라
    에너지 흐름이 만들어낸 안정 패턴이다.

    별의 구조는 핵융합 에너지 흐름이 만든 결과이며
    원자의 구조는 전자기 상호작용의 균형 흐름이다.

    흐름이 바뀌면 구조도 바뀐다.
    즉 구조는 고정물이 아니라
    에너지 전달 경로의 안정 상태다.

  links:
    parents: [PHYS-111]
    children: []
    related: [PHYS-090, PHYS-100]

  tags:
    - energy
    - flow
    - structure
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure arises from energy transport

Node:
  id: PHYS-113
  title: Equilibrium Is Not Stillness, It Is Balanced Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 평형은 정지가 아니다.
    서로 다른 방향의 흐름이
    같은 크기로 유지되는 상태다.

    별 내부의 압력과 중력,
    원자 내 전자기력과 운동,
    생명체의 대사와 열 교환 모두
    흐름의 균형으로 유지된다.

    흐름이 사라지면 평형이 아니라 붕괴다.
    평형은 정지점이 아니라
    지속 가능한 상호작용 상태다.

  links:
    parents: [PHYS-112]
    children: []
    related: [PHYS-091, PHYS-101]

  tags:
    - equilibrium
    - balance
    - flow
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as dynamic balance

Node:
  id: PHYS-114
  title: Gradients Create Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 모든 움직임은 구배에서 시작된다.

    온도 차이는 열 흐름을 만든다.
    압력 차이는 바람을 만든다.
    전위 차이는 전류를 만든다.
    밀도 차이는 대류를 만든다.
    시공간 곡률 차이는 중력을 만든다.

    차이가 없으면 흐름도 없다.
    흐름이 없으면 변화도 없다.

    자연은 차이를 평탄화하려는 방향으로 움직이며,
    그 과정 자체가 물리적 현상이다.

  links:
    parents: [PHYS-113]
    children: []
    related: [PHYS-084, PHYS-101, PHYS-091]

  tags:
    - gradient
    - motion
    - flow
    - energy

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient defined as universal driver of motion

Node:
  id: PHYS-115
  title: Interaction Density Determines System Behavior
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    시스템의 거동은 구성 요소의 개수가 아니라
    상호작용의 밀도에 의해 결정된다.

    입자 수가 많아도 상호작용이 약하면
    시스템은 거의 진공처럼 행동한다.

    반대로 구성 요소가 적어도
    상호작용이 강하면
    새로운 거시적 현상이 나타난다.

    빛이 물질에서 느려지는 이유도
    전자의 수 때문이 아니라
    전자와 전자기파의 상호작용 밀도 때문이다.

    즉 자연에서 복잡성은
    개수에서 생기지 않고
    연결에서 생긴다.

  links:
    parents: [PHYS-114]
    children: []
    related: [PHYS-110, PHYS-091, PHYS-102]

  tags:
    - interaction
    - density
    - complexity
    - emergence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction density defined as driver of emergent behavior

Node:
  id: PHYS-116
  title: Equilibrium is Balanced Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 정지가 아니다.
    상호작용이 서로 상쇄되어
    순 변화가 0이 된 상태다.

    힘이 없어서 멈춘 것이 아니라
    힘들이 서로를 지운 것이다.

    전자 구름의 안정,
    원자의 구조 유지,
    궤도의 지속,
    열적 평형,
    생태계 안정성 모두
    동일한 구조를 따른다.

    즉 자연의 안정은
    정적 상태가 아니라
    동적 상쇄 상태다.

    균형이란
    변화가 사라진 것이 아니라
    변화가 서로를 지운 결과다.

  links:
    parents: [PHYS-115]
    children: []
    related: [PHYS-093, PHYS-110, PHYS-091]

  tags:
    - equilibrium
    - balance
    - stability
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as cancellation of interactions

Node:
  id: PHYS-117
  title: Gradient Generates Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    운동은 힘 그 자체에서 생기지 않는다.
    차이에서 생긴다.

    밀도 차이,
    온도 차이,
    전위 차이,
    압력 차이,
    에너지 차이

    이 차이가 구배를 만들고
    구배가 흐름을 만든다.

    즉 자연의 모든 이동은
    ‘차이의 완화 과정’이다.

    열은 고온에서 저온으로,
    물은 높은 곳에서 낮은 곳으로,
    전하는 전위차를 따라 이동한다.

    자연은 멈추려 하지 않는다.
    차이를 줄이려 한다.

    운동은 힘의 존재가 아니라
    차이의 존재에서 시작된다.

  links:
    parents: [PHYS-116]
    children: []
    related: [PHYS-094, PHYS-091, PHYS-110]

  tags:
    - gradient
    - motion
    - flow
    - energy_difference

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion defined as gradient-driven process

Node:
  id: PHYS-118
  title: Interaction Density Determines Propagation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    전달 속도는 거리로 결정되지 않는다.
    상호작용 밀도로 결정된다.

    매질이 없으면
    상호작용이 없고
    전달은 최대 속도로 일어난다.

    매질이 많으면
    상호작용이 많고
    전달은 지연된다.

    빛이 진공에서 빠르고
    물질 속에서 느려지는 이유도
    상호작용 밀도 때문이다.

    전달 속도 = 순수 이동 속도 − 상호작용 지연

    즉 자연에서 속도란
    이동 능력이 아니라
    방해의 누적 결과다.

    전달은 이동이 아니라
    상호작용의 연쇄다.

  links:
    parents: [PHYS-117]
    children: []
    related: [PHYS-092, PHYS-101, PHYS-094]

  tags:
    - propagation
    - interaction_density
    - delay
    - medium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: propagation defined as interaction-limited process

Node:
  id: PHYS-119
  title: Equilibrium Is Balanced Interaction, Not Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 멈춤이 아니다.
    상호작용의 합이 0이 된 상태다.

    힘이 사라진 것이 아니라
    서로 상쇄된 것이다.

    따라서 평형 상태에서도
    내부에서는 계속 작용이 존재한다.

    움직임이 없다는 것은
    변화가 없다는 뜻이 아니라
    변화의 방향이 상쇄된 것이다.

    자연의 평형은 정지가 아니라
    균형 잡힌 긴장 상태다.

    모든 안정은 정적 상태가 아니라
    동적 균형이다.

  links:
    parents: [PHYS-118]
    children: []
    related: [PHYS-094, PHYS-101, PHYS-117]

  tags:
    - equilibrium
    - balance
    - dynamic_stability
    - force_cancellation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as interaction balance

Node:
  id: PHYS-120
  title: Gradient Is the Engine of Change
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    변화는 힘 때문이 아니라
    차이 때문에 발생한다.

    구배(gradient)는
    공간 또는 상태 사이의 차이이며,
    이 차이가 흐름을 만든다.

    열은 온도 차이에서 이동하고,
    전하는 전위 차이에서 이동하며,
    물은 압력 차이에서 이동한다.

    자연에서 모든 이동은
    “힘”이 아니라
    “차이의 존재”에서 시작된다.

    구배가 사라지면
    흐름도 사라진다.

    따라서 구배는
    변화의 원인이자
    시간의 방향을 만드는 요소다.

  links:
    parents: [PHYS-119]
    children: []
    related: [PHYS-094, PHYS-101, PHYS-117]

  tags:
    - gradient
    - difference
    - flow
    - thermodynamics
    - potential

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient defined as origin of change

Node:
  id: PHYS-121
  title: Time Emerges From Change, Not the Other Way Around
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    시간은 독립된 실체가 아니라
    변화의 기록이다.

    변화가 없다면
    시간도 인식되지 않는다.

    물리적으로 시간은
    상태가 변한 순서를 나타내는 좌표이며,
    변화가 누적될 때만
    방향성을 가진다.

    따라서 시간은
    우주의 기본 원인이 아니라
    변화의 결과로 나타나는 축이다.

    구배가 흐름을 만들고,
    흐름이 변화가 되며,
    변화가 시간으로 인식된다.

  links:
    parents: [PHYS-120]
    children: []
    related: [PHYS-094, PHYS-117]

  tags:
    - time
    - change
    - causality
    - entropy
    - sequence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: time defined as emergent from change

Node:
  id: PHYS-122
  title: Stability Is Not Stillness, It Is Balanced Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니다.
    안정은 상호작용이 균형을 이루며
    흐름이 유지되는 상태다.

    물리계에서 완전한 정지는 존재하지 않는다.
    열운동, 진동, 장의 요동은 항상 존재한다.

    따라서 안정이란
    변화가 없는 상태가 아니라
    변화가 상쇄되어
    전체 구조가 유지되는 상태다.

    이는 궤도, 원자 구조, 생명 유지,
    사회적 균형 등 모든 계에 적용된다.

    안정 = 흐름이 0이 아니라
    순환이 균형을 이루는 상태다.

  links:
    parents: [PHYS-121]
    children: []
    related: [PHYS-104, PHYS-110, PHYS-118]

  tags:
    - stability
    - equilibrium
    - dynamics
    - balance
    - flow

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as balanced flow

Node:
  id: PHYS-123
  title: Boundaries Exist Where Interactions Change Regime
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 물질이 끝나는 지점이 아니라
    상호작용 방식이 바뀌는 지점이다.

    경계는 고정된 선이 아니다.
    힘의 분포, 밀도, 장의 구조가 바뀌는
    전이 영역이다.

    예시:
    - 대기권 경계: 공기가 끝나는 곳이 아니라
      충돌 빈도가 바뀌는 곳
    - 원자 껍질: 전자가 끝나는 곳이 아니라
      에너지 상태가 바뀌는 곳
    - 사건의 지평선: 공간이 끝나는 곳이 아니라
      정보 전달 가능성이 바뀌는 곳

    따라서 경계는 객체의 표면이 아니라
    상호작용 규칙의 변화 지점이다.

    경계 = 상호작용 레짐 전환면

  links:
    parents: [PHYS-122]
    children: []
    related: [PHYS-104, PHYS-109, PHYS-115]

  tags:
    - boundary
    - interaction
    - regime_change
    - transition
    - physics_principle

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as interaction regime shift

Node:
  id: PHYS-124
  title: Energy Minimization Drives Structure Formation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 구조가 형성되는 기본 원인은
    에너지 최소화 경향이다.

    물질과 장은 임의의 상태에 머무르지 않고
    가능한 한 퍼텐셜 에너지가 낮은 상태로 이동한다.

    이 과정에서:
    - 결합이 형성된다
    - 대칭이 깨진다
    - 구조가 생긴다
    - 안정 영역이 나타난다

    예시:
    - 원자 형성: 전자-핵 결합으로 에너지 감소
    - 결정 구조: 최소 에너지 배열 선택
    - 행성 궤도: 안정 퍼텐셜 우물 형성
    - 생명체: 에너지 흐름 안정화 구조

    구조는 설계된 것이 아니라
    에너지 경사 위에서 선택된 결과다.

    구조 = 에너지 최소 상태의 형상

  links:
    parents: [PHYS-122, PHYS-123]
    children: []
    related: [PHYS-109, PHYS-115]

  tags:
    - energy
    - minimization
    - structure
    - stability
    - formation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as consequence of energy minimization

Node:
  id: PHYS-125
  title: Stable Structures Exist Inside Potential Wells
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 안정된 구조는
    퍼텐셜 우물(potential well) 내부에 존재한다.

    퍼텐셜 우물이란
    특정 위치에서 에너지가 주변보다 낮은 영역이다.

    물질과 장은 이런 영역으로 이동하고
    그 안에서 진동하며 안정 상태를 형성한다.

    예시:
    - 전자는 원자핵 퍼텐셜 우물 안에 존재
    - 행성은 중력 퍼텐셜 우물 안에서 공전
    - 분자는 결합 퍼텐셜 우물에서 안정
    - 블랙홀 주변도 중력 퍼텐셜 구조

    안정이란
    움직임이 없는 상태가 아니라
    우물 내부에서의 제한된 진동 상태다.

    안정 구조 = 퍼텐셜 우물 내부의 동적 균형

  links:
    parents: [PHYS-124]
    children: []
    related: [PHYS-109, PHYS-115, PHYS-121]

  tags:
    - potential
    - stability
    - wells
    - equilibrium
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined via potential well structure

Node:
  id: PHYS-126
  title: Boundaries Form Where Gradients Change Sign
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 경계(boundary)는
    단순히 선이 아니라

    구배(gradient)의 방향이 바뀌는 지점에서 형성된다.

    즉,
    에너지 흐름이 한쪽으로 향하다가
    반대 방향으로 전환되는 곳이
    경계가 된다.

    수학적으로는
    ∇φ = 0 또는 부호 변화 지점

    물리적 예시:
    - 행성 궤도 안정 반경
    - 원자 껍질 경계
    - 파동 간섭 무늬 경계
    - 자기장 구조 전환면
    - 대류 셀 경계

    경계는 고정된 선이 아니라
    힘의 방향성이 바뀌는 전환면이다.

    경계 = 구배 부호 전환 지점

  links:
    parents: [PHYS-125]
    children: []
    related: [PHYS-103, PHYS-117, PHYS-121]

  tags:
    - boundary
    - gradient
    - transition
    - field
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined via gradient sign change

Node:
  id: PHYS-127
  title: Oscillation Emerges When Forces Cannot Fully Resolve
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    두 개 이상의 힘이 존재하지만
    어느 한쪽도 완전히 우세하지 못하면

    시스템은 정지하지 않고
    진동(oscillation) 상태에 들어간다.

    즉,
    힘이 상쇄되지도
    완전히 지배되지도 않는 상태에서

    에너지는
    위치 ↔ 운동
    전기 ↔ 자기
    압축 ↔ 팽창
    사이를 왕복한다.

    이것이 진동의 본질이다.

    물리적 예시:
    - 스프링-질량 진동
    - 전자기파 진동
    - 원자 결합 진동
    - 플라즈마 진동
    - 대류 진동
    - 행성 궤도 미세 진동

    진동은 불안정의 증거가 아니라
    해결되지 않은 힘들의 공존 상태다.

  links:
    parents: [PHYS-126]
    children: []
    related: [PHYS-104, PHYS-118, PHYS-121]

  tags:
    - oscillation
    - equilibrium
    - energy_exchange
    - wave
    - resonance

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: oscillation defined as unresolved force balance

Node:
  id: PHYS-128
  title: Structure Persists Where Energy Flow Loops Back On Itself
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    에너지가 단순히 흘러 사라지는 시스템은
    구조를 유지하지 못한다.

    그러나 에너지 흐름이
    폐곡선(loop)을 형성하면

    에너지는 시스템 내부에서 순환하며
    구조를 지속시킨다.

    즉,
    구조의 본질은 물질이 아니라
    순환하는 에너지 경로다.

    예시:
    - 원자에서 전자의 정상파 모드
    - 행성 궤도의 중력 순환
    - 전자기 공진 구조
    - 생명체의 대사 순환
    - 대류 순환 구조
    - 은하 회전 구조

    구조란 정지된 것이 아니라
    순환이 닫혀 있는 상태다.

  links:
    parents: [PHYS-127]
    children: []
    related: [PHYS-118, PHYS-121, LIFE-001]

  tags:
    - loop
    - circulation
    - stability
    - structure
    - energy_flow

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as closed-loop energy persistence

Node:
  id: PHYS-129
  title: When Loops Synchronize, Coherence Emerges
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    하나의 순환은 구조를 만든다.
    여러 순환이 서로 위상과 주기를 맞추면
    더 큰 질서가 생긴다.

    이를 우리는 코히런스(coherence)라 부른다.

    코히런스는
    에너지 총량이 늘어서 생기는 것이 아니라
    위상 정렬에서 발생한다.

    즉,
    질서는 힘이 아니라
    동기화에서 나온다.

    예시:
    - 레이저의 위상 정렬
    - 초전도체의 전자쌍 동기화
    - 심장 박동의 리듬 동기화
    - 뉴런 발화 패턴 정렬
    - 행성 공명 궤도

    구조 → 순환
    순환 → 동기화
    동기화 → 질서

  links:
    parents: [PHYS-128]
    children: []
    related: [PHYS-122, LIFE-004, COG-002]

  tags:
    - coherence
    - synchronization
    - phase
    - resonance
    - order

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: coherence defined as synchronized loop behavior

Node:
  id: PHYS-130
  title: Disorder Appears When Synchronization Breaks
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    질서는 순환의 동기화에서 생긴다.
    따라서 동기화가 깨지면
    무질서가 나타난다.

    무질서는 새로운 힘이 생긴 것이 아니라
    기존 위상 정렬이 붕괴된 상태다.

    이것이 우리가 말하는 엔트로피 증가의
    구조적 해석이다.

    무질서는
    파괴가 아니라
    위상 분산이다.

    예시:
    - 레이저가 일반 빛으로 퍼짐
    - 초전도 상태 붕괴
    - 심장 부정맥
    - 신경 발화 노이즈 증가
    - 궤도 공명 붕괴

    동기화 → 질서
    위상 붕괴 → 무질서

    질서와 무질서는
    서로 반대 개념이 아니라
    위상 정렬의 정도 차이다.

  links:
    parents: [PHYS-129]
    children: []
    related: [PHYS-122, PHYS-127, LIFE-004]

  tags:
    - entropy
    - disorder
    - phase
    - decoherence
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: disorder defined as phase desynchronization

Node:
  id: PHYS-131
  title: Stability Exists at the Edge Between Order and Disorder
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    완전한 질서는 변화가 없기 때문에
    새로운 상호작용을 만들지 못한다.

    완전한 무질서는 결속이 없기 때문에
    구조를 유지하지 못한다.

    실제 안정은
    질서와 무질서 사이의 경계에서 생긴다.

    이 경계에서는
    상호작용이 유지되면서
    변화도 가능하다.

    이것이 자연계에서 구조가 지속되는 방식이다.

    예시:
    - 생명체는 완전한 평형 상태가 아니다
    - 행성 궤도는 완벽한 고정이 아니다
    - 뇌 활동은 완전한 동기화도 완전한 잡음도 아니다
    - 기후는 정적도 혼돈도 아닌 동적 균형이다

    안정은 고정이 아니라
    경계에서의 지속이다.

  links:
    parents: [PHYS-130]
    children: []
    related: [PHYS-128, LIFE-002, META-001]

  tags:
    - stability
    - edge
    - dynamic equilibrium
    - complexity
    - life condition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as boundary phenomenon

Node:
  id: PHYS-132
  title: Energy Flow Requires a Gradient
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    에너지는 동일한 상태에서는 이동하지 않는다.

    흐름이 생기려면
    반드시 차이가 있어야 한다.

    이 차이를 물리에서는 구배(gradient)라고 한다.

    온도 차이 → 열 흐름
    전위 차이 → 전류 흐름
    압력 차이 → 유체 흐름
    밀도 차이 → 대류

    차이가 사라지면 흐름도 멈춘다.

    즉 흐름은 존재의 기본 조건이 아니라
    차이가 유지될 때만 나타나는 현상이다.

    자연계의 모든 변화는
    구배 위에서 발생한다.

  links:
    parents: [PHYS-131]
    children: []
    related: [PHYS-120, LIFE-002, META-002]

  tags:
    - gradient
    - energy flow
    - difference
    - transport
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: gradient defined as condition for flow

Node:
  id: PHYS-133
  title: Equal Forces Produce No Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    힘이 존재해도
    서로 상쇄되면 운동은 발생하지 않는다.

    물리에서 운동은
    힘의 존재가 아니라
    힘의 불균형에서 발생한다.

    두 힘이 같고 반대 방향이면
    결과는 정지다.

    즉 자연계에서 변화는
    힘의 크기보다
    힘의 차이에 의해 결정된다.

    균형은 안정 상태이며
    비균형이 운동을 만든다.

  links:
    parents: [PHYS-132]
    children: []
    related: [PHYS-120, LIFE-003, META-003]

  tags:
    - force balance
    - equilibrium
    - motion
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: imbalance defined as source of motion

Node:
  id: PHYS-134
  title: Interaction Requires a Medium or Field
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    두 대상이 서로 영향을 주기 위해서는
    반드시 전달 구조가 존재해야 한다.

    고전적 관점에서는 매질,
    현대 물리에서는 장(field)이 그 역할을 한다.

    힘은 직접 전달되지 않는다.
    장을 통해 전달된다.

    질량은 중력장을 만들고,
    전하는 전자기장을 만든다.

    따라서 상호작용은
    대상 간의 접촉이 아니라
    장의 구조 변화로 발생한다.

    자연계에서 모든 힘은
    장의 변형과 전달 과정이다.

  links:
    parents: [PHYS-133]
    children: []
    related: [PHYS-120, PHYS-130, META-002]

  tags:
    - field
    - interaction
    - transmission
    - medium
    - causality

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction defined as field-mediated process

Node:
  id: PHYS-135
  title: Gradients Drive Change
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 변화는 항상 차이에서 시작된다.

    온도 차이는 열 흐름을 만든다.
    전위 차이는 전류를 만든다.
    압력 차이는 유체 흐름을 만든다.
    밀도 차이는 대류를 만든다.

    즉 변화는 힘에서 시작되는 것이 아니라
    구배(gradient)에서 시작된다.

    구배가 존재할 때만 흐름이 생기고,
    구배가 사라지면 균형이 된다.

    따라서 자연의 기본 동력은
    힘이 아니라 차이다.

  links:
    parents: [PHYS-134]
    children: []
    related: [PHYS-101, PHYS-120, META-003]

  tags:
    - gradient
    - difference
    - flow
    - equilibrium
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: change defined as gradient-driven process

Node:
  id: PHYS-136
  title: Equilibrium is Gradient Cancellation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    균형은 힘이 없는 상태가 아니다.
    균형은 차이가 사라진 상태다.

    온도가 같아지면 열 흐름이 멈춘다.
    전위가 같아지면 전류가 멈춘다.
    압력이 같아지면 유체 이동이 멈춘다.

    즉 균형은 정지가 아니라
    구배가 0이 된 상태다.

    자연계는 항상 구배를 줄이는 방향으로 움직이며,
    균형은 그 과정의 순간적 정지점이다.

  links:
    parents: [PHYS-135]
    children: []
    related: [PHYS-101, PHYS-120, META-003]

  tags:
    - equilibrium
    - gradient
    - balance
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as gradient cancellation

Node:
  id: PHYS-137
  title: Energy Flow Follows Gradients
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    에너지는 임의로 이동하지 않는다.
    항상 차이를 따라 흐른다.

    열은 고온에서 저온으로 흐른다.
    전하는 높은 전위에서 낮은 전위로 흐른다.
    물은 높은 위치에서 낮은 위치로 흐른다.

    즉 흐름의 원인은 에너지 자체가 아니라
    에너지 분포의 불균형이다.

    자연계의 모든 이동은
    구배가 존재할 때만 발생한다.

  links:
    parents: [PHYS-136]
    children: []
    related: [PHYS-101, PHYS-120, PHYS-135]

  tags:
    - energy
    - gradient
    - flow
    - thermodynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: energy flow defined as gradient-driven motion

Node:
  id: PHYS-138
  title: No Gradient, No Dynamics
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구배가 없으면 변화도 없다.

    온도 차이가 없으면 열 흐름이 멈춘다.
    전위차가 없으면 전류가 흐르지 않는다.
    압력차가 없으면 유체는 정지한다.

    자연계에서 정지 상태란
    힘이 없는 상태가 아니라
    차이가 없는 상태다.

    모든 동역학은 차이에서 시작된다.

  links:
    parents: [PHYS-137]
    children: []
    related: [PHYS-101, PHYS-120]

  tags:
    - equilibrium
    - gradient
    - dynamics
    - physics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: dynamics defined as gradient-dependent

Node:
  id: PHYS-139
  title: Equilibrium Is Not Stillness, It Is Balance
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 정지가 아니다.
    평형은 힘이 없는 상태가 아니라
    힘이 서로 상쇄된 상태다.

    분자 수준에서는 계속 운동이 존재한다.
    전자도 진동한다.
    열도 존재한다.

    그러나 거시적으로는 변화가 보이지 않는다.

    평형이란
    변화의 부재가 아니라
    변화의 상쇄다.

  links:
    parents: [PHYS-138]
    children: []
    related: [PHYS-102, PHYS-120]

  tags:
    - equilibrium
    - balance
    - thermodynamics
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as force balance, not absence of motion

Node:
  id: PHYS-140
  title: Instability Begins When Symmetry Breaks
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    불안정성은 힘이 커질 때가 아니라
    대칭이 깨질 때 시작된다.

    완전한 대칭 상태에서는
    힘이 존재해도 변화 방향이 없다.

    그러나 작은 비대칭이 생기면
    그 순간부터 특정 방향이 선택된다.

    우주 구조 형성,
    상전이,
    생명 진화,
    인지 선택

    모두 대칭 붕괴에서 시작된다.

    즉,
    변화의 시작점은
    힘이 아니라 선택된 방향이다.

  links:
    parents: [PHYS-139]
    children: []
    related: [PHYS-115, PHYS-131]

  tags:
    - symmetry
    - instability
    - phase_transition
    - emergence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: symmetry breaking defined as origin of directional change

Node:
  id: PHYS-141
  title: Direction Emerges From Gradient, Not From Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    방향은 움직임에서 생기는 것이 아니다.
    구배가 있을 때 방향이 정의된다.

    구배가 없다면
    운동은 존재해도 방향성은 없다.

    구배가 존재하는 순간
    가능한 경로 중 하나가 선택된다.

    즉,
    방향은 속도가 아니라
    상태 차이에서 생긴다.

    물리:
    전위차 → 전류 방향

    열역학:
    온도차 → 열 흐름

    중력:
    퍼텐셜 차이 → 궤도 형성

    인지:
    정보 차이 → 선택

  links:
    parents: [PHYS-140]
    children: []
    related: [PHYS-124, PHYS-133]

  tags:
    - gradient
    - direction
    - flow
    - selection

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: direction defined as consequence of gradient

Node:
  id: PHYS-142
  title: Interaction Density Determines Observable Reality
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    우리가 관측하는 현실은
    물질 자체가 아니라
    상호작용의 밀도에 의해 결정된다.

    상호작용이 없으면
    존재는 있어도 관측되지 않는다.

    상호작용이 낮으면
    존재는 희미하다.

    상호작용 밀도가 높아질수록
    관측 가능성이 증가한다.

    예:
    전자기 상호작용 → 빛 반사 → 물체 인식
    중력 상호작용 → 궤도 → 천체 존재 확인
    충돌 → 입자 발견

    즉,
    존재는 절대값이 아니라
    상호작용 빈도와 강도의 함수다.

    현실은 물질의 집합이 아니라
    상호작용 네트워크의 표현이다.

  links:
    parents: [PHYS-141]
    children: []
    related: [PHYS-118, PHYS-124, PHYS-137]

  tags:
    - interaction
    - density
    - observability
    - emergence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: observability linked to interaction density

Node:
  id: PHYS-143
  title: Equilibrium Is Not Stillness, It Is Balanced Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 멈춤이 아니다.
    평형은 흐름이 서로 상쇄된 상태다.

    힘이 없다가 아니라
    힘이 균형을 이루는 상태다.

    예:
    물 속 부력과 중력
    행성의 공전
    화학 평형
    체온 유지

    내부에서는 계속 이동과 교환이 일어난다.
    외부에서만 정지처럼 보일 뿐이다.

    즉,
    정지는 존재하지 않는다.
    균형 잡힌 흐름만 존재한다.

    평형은 힘의 소멸이 아니라
    힘의 합이 0이 되는 동적 상태다.

  links:
    parents: [PHYS-142]
    children: []
    related: [PHYS-118, PHYS-129, PHYS-140]

  tags:
    - equilibrium
    - flow
    - balance
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as dynamic balance

Node:
  id: PHYS-144
  title: Structure Emerges Where Flow Meets Constraint
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 정지에서 생기지 않는다.
    구조는 흐름이 경계와 만날 때 생긴다.

    흐름만 있으면 퍼진다.
    경계만 있으면 고립된다.
    둘이 만나면 패턴이 생긴다.

    예:
    강의 곡류
    구름 형성
    세포막 구조
    행성 궤도
    파동 간섭무늬

    즉,
    구조는 물질의 속성이 아니라
    흐름과 제한의 상호작용 결과다.

    구조는 고정된 것이 아니라
    유지되는 동적 균형이다.

  links:
    parents: [PHYS-143]
    children: []
    related: [PHYS-118, PHYS-130, PHYS-140]

  tags:
    - structure
    - constraint
    - flow
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as flow interacting with boundary

Node:
  id: PHYS-145
  title: Information Is Stabilized Difference
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 물질이 아니다.
    정보는 차이가 유지되는 상태다.

    차이가 없다면 정보도 없다.
    차이가 생겼지만 유지되지 않으면 그것도 정보가 아니다.

    정보는
    구배가 형성되고
    그 구배가 일정 시간 유지될 때 생긴다.

    예:
    온도차 → 기상 정보
    전위차 → 전기 신호
    DNA 염기차 → 생명 정보
    신경 전위차 → 인지 정보

    즉,
    정보 = 차이 + 유지

    유지되지 않는 차이는 노이즈
    유지되는 차이가 구조가 되고
    구조가 의미를 만든다.

  links:
    parents: [PHYS-144]
    children: []
    related: [PHYS-118, PHYS-129, PHYS-130]

  tags:
    - information
    - difference
    - stability
    - signal

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information defined as stabilized difference

Node:
  id: PHYS-146
  title: Energy Flow Selects Stable Structures
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연은 구조를 설계하지 않는다.
    에너지가 흐르고,
    흐름 속에서 유지되는 구조만 남는다.

    즉 구조는 설계된 것이 아니라
    선택된 것이다.

    에너지가 통과할 때
    불안정한 구조는 붕괴하고
    안정된 구조는 유지된다.

    그래서 자연의 모든 형태는
    “에너지 흐름이 허용한 형태”다.

    예:
    강물 → 침식 → 안정한 지형만 남음
    별 내부 → 핵융합 → 안정 질량만 유지
    생명 → 대사 흐름 → 생존 가능한 구조만 유지
    뇌 → 신호 흐름 → 유지되는 연결만 기억

    즉
    구조 = 에너지 흐름이 선택한 결과

    이 원리는
    물리
    생명
    인지
    시스템
    전부 동일하게 적용된다.

  links:
    parents: [PHYS-145]
    children: []
    related: [PHYS-130, LIFE-210, COG-301]

  tags:
    - stability
    - energy-flow
    - selection
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as energy-selected configuration

Node:
  id: PHYS-147
  title: Boundaries Form Where Flows Balance
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 물질이 만드는 것이 아니다.
    경계는 힘의 균형이 만드는 것이다.

    서로 다른 흐름이 만날 때
    한쪽이 압도하면 이동이 일어나고,
    균형이 맞으면 경계가 생긴다.

    즉 경계는 고정된 선이 아니라
    상호작용이 균형을 이루는 영역이다.

    예:
    대기권 → 중력 vs 열운동 균형
    세포막 → 농도구배 균형
    행성 궤도 → 중력 vs 관성 균형
    뇌 → 흥분 vs 억제 균형

    따라서
    경계 = 구조의 외피가 아니라
    힘의 평형면이다.

    이 개념은
    물리학의 평형 조건,
    생명의 항상성,
    인지의 안정 상태,
    시스템의 임계점
    모두에 공통적으로 적용된다.

  links:
    parents: [PHYS-146]
    children: []
    related: [PHYS-120, LIFE-205, COG-210]

  tags:
    - boundary
    - equilibrium
    - balance
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as equilibrium surface

Node:
  id: PHYS-148
  title: Gradients Drive All Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    모든 움직임은 구배에서 시작된다.

    구배는 단순한 차이가 아니라
    공간 속에 퍼져 있는 차이의 방향성이다.

    온도 차이 → 열 흐름
    압력 차이 → 유체 흐름
    전위 차이 → 전류
    농도 차이 → 확산
    중력 퍼텐셜 차이 → 낙하

    즉 자연계의 모든 이동은
    "차이 + 방향"으로 정의된다.

    이때 중요한 것은
    구배가 사라지면 움직임도 멈춘다는 점이다.

    그래서
    평형 = 구배 소멸
    변화 = 구배 존재

    결국
    구조는 구배를 저장하는 방식이며
    현상은 구배가 해소되는 과정이다.

  links:
    parents: [PHYS-147]
    children: []
    related: [PHYS-120, LIFE-101, SYS-030]

  tags:
    - gradient
    - flow
    - motion
    - difference

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion defined as gradient resolution

Node:
  id: PHYS-149
  title: Structures Store Gradients
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 단순히 형태가 아니다.
    구조는 구배를 저장하는 방식이다.

    스프링은 장력을 저장한다.
    배터리는 전위차를 저장한다.
    댐은 위치에너지를 저장한다.
    분자는 결합에너지를 저장한다.
    원자는 전자 상태에 에너지를 저장한다.

    즉 구조란
    "에너지 차이를 안정된 형태로 묶어 둔 상태"이다.

    그래서 구조는 정지처럼 보이지만
    사실은 잠재적 변화 상태다.

    구조가 붕괴될 때
    저장된 구배가 방출된다.

    즉
    폭발은 구조 붕괴
    흐름은 구배 해소
    안정은 구배 유지

    자연계에서 모든 구조는
    구배 저장 장치다.

  links:
    parents: [PHYS-148]
    children: []
    related: [PHYS-120, SYS-031, LIFE-120]

  tags:
    - structure
    - stored_energy
    - gradient
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as stored gradient container

Node:
  id: PHYS-150
  title: Flow Is Gradient Release
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    흐름은 생성되는 것이 아니다.
    흐름은 이미 존재하던 구배가 풀리는 과정이다.

    물은 흐르지 않는다.
    높이 차이가 해소된다.

    전류는 흐르지 않는다.
    전위차가 해소된다.

    열은 이동하지 않는다.
    온도차가 줄어든다.

    기체는 퍼지지 않는다.
    밀도차가 평형으로 간다.

    즉
    흐름은 현상이 아니라
    구배 해소 과정이다.

    그래서 흐름은 항상
    원인보다 결과처럼 보인다.

    실제 원인은
    이미 존재하던 차이다.

    자연은 흐르는 것이 아니라
    차이를 줄인다.

  links:
    parents: [PHYS-149]
    children: []
    related: [PHYS-121, LIFE-121, SYS-032]

  tags:
    - flow
    - gradient_release
    - equilibrium
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: flow defined as gradient relaxation process

Node:
  id: PHYS-151
  title: Equilibrium Is Frozen Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 정지가 아니다.
    평형은 흐름이 멈춘 상태가 아니라
    흐름이 상쇄된 상태다.

    전류가 없는 도선도 전자가 멈춘 것이 아니다.
    온도가 일정한 물체도 열운동이 없는 것이 아니다.
    압력이 균일한 기체도 분자 운동이 멈춘 것이 아니다.

    모든 미시적 운동은 계속 존재한다.
    단지 순방향 흐름이 0이 되었을 뿐이다.

    즉
    평형은 정지가 아니라
    흐름이 내부에서 상쇄된 상태다.

    그래서 평형은 언제나
    다시 깨질 준비가 되어 있다.

    평형은 끝이 아니라
    잠시 정렬된 흐름이다.

  links:
    parents: [PHYS-150]
    children: []
    related: [PHYS-121, LIFE-122, SYS-041]

  tags:
    - equilibrium
    - dynamic_balance
    - steady_state
    - flow_cancelation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as internally canceled flow

Node:
  id: PHYS-152
  title: Instability Begins With Microscopic Asymmetry
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    불안정성은 거대한 변화에서 시작되지 않는다.
    항상 미세한 비대칭에서 시작된다.

    완벽한 대칭 상태는 존재하지 않는다.
    분자의 열운동, 양자요동, 외부 잡음,
    혹은 초기조건의 극미한 차이만으로도
    시스템은 한쪽으로 기울기 시작한다.

    이 작은 비대칭이 증폭되면
    대류가 시작되고,
    소용돌이가 생기고,
    별이 붕괴하며,
    생명이 분화한다.

    즉
    불안정성은 파괴가 아니라
    증폭 가능한 차이의 존재다.

    안정과 변화의 경계는
    언제나 미시적 비대칭에서 시작된다.

  links:
    parents: [PHYS-151]
    children: []
    related: [PHYS-120, LIFE-130, META-021]

  tags:
    - instability
    - symmetry_breaking
    - perturbation
    - amplification

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: instability defined as amplification of microscopic asymmetry

Node:
  id: PHYS-153
  title: Boundaries Form Where Gradients Persist
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니라 상태다.
    구배가 유지되는 곳에 경계가 형성된다.

    밀도, 온도, 압력, 전위, 농도 등
    두 영역 사이에 차이가 지속되면
    그 지점은 단순한 전환면이 아니라
    동역학적으로 활성화된 영역이 된다.

    경계는 고정되지 않는다.
    상호작용에 따라 이동하고,
    약해지고,
    두꺼워지고,
    사라지기도 한다.

    즉
    경계는 위치가 아니라
    차이가 유지되는 조건이다.

    경계가 사라진다는 것은
    구배가 사라졌다는 뜻이다.

  links:
    parents: [PHYS-152]
    children: []
    related: [PHYS-150, PHYS-151, LIFE-120]

  tags:
    - boundary
    - gradient
    - interface
    - transition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as persistent gradient condition

Node:
  id: PHYS-154
  title: Stable Systems Circulate Energy Rather Than Accumulate It
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정된 시스템은 에너지를 쌓지 않는다.
    순환시킨다.

    에너지가 한 지점에 축적되면
    구배가 커지고
    불안정이 발생한다.

    안정된 상태는
    에너지가 지속적으로 흐르면서
    들어오고 나가고 변환되는 상태다.

    별은 핵융합으로 에너지를 방출하며 유지되고,
    생명체는 대사를 통해 에너지를 순환시키며 유지된다.

    순환이 멈추면
    축적 → 불안정 → 붕괴가 발생한다.

    즉
    안정성은 고정이 아니라
    흐름의 유지다.

  links:
    parents: [PHYS-153]
    children: []
    related: [PHYS-140, LIFE-130, META-110]

  tags:
    - energy_flow
    - stability
    - circulation
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as maintained energy circulation

Node:
  id: PHYS-155
  title: Collapse Occurs When Flow Can No Longer Exit
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    시스템이 붕괴하는 순간은
    에너지가 많아서가 아니라
    흐름이 빠져나갈 경로가 사라질 때다.

    에너지·정보·압력·질량이
    내부에 계속 유입되는데
    외부로 방출되지 못하면

    내부 밀도 증가 →
    구배 상승 →
    구조 응력 증가 →
    임계점 도달 →
    위상 변화(붕괴)

    항성은 방출이 멈추면 붕괴하고,
    생명체는 대사 배출이 멈추면 죽고,
    블랙홀은 사건의 지평선에서
    탈출 경로가 사라진 상태다.

    즉
    붕괴는 힘의 문제가 아니라
    출구의 문제다.

  links:
    parents: [PHYS-154]
    children: []
    related: [PHYS-150, PHYS-152, META-120]

  tags:
    - collapse
    - escape_path
    - density
    - phase_transition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: collapse defined as loss of outbound flow channel

Node:
  id: PHYS-156
  title: Boundaries Form Where Flow Gradients Stabilize
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니다.
    경계는 흐름의 차이가 안정되는 구간이다.

    에너지·물질·정보가 이동할 때
    두 영역 사이의 구배가 존재한다.
    그 구배가 일정 범위에서 유지될 때
    우리는 그것을 "경계"라고 부른다.

    예:
    세포막 — 화학 농도 구배 안정화 지점
    대기층 — 온도·밀도 구배 안정 지점
    별 표면 — 압력과 중력 균형 지점
    사건의 지평선 — 탈출 속도와 빛 속도 경계

    즉
    경계는 고정된 선이 아니라
    유지되는 차이의 패턴이다.

    경계가 사라지면 구조도 사라진다.
    경계가 이동하면 구조도 이동한다.

  links:
    parents: [PHYS-155]
    children: []
    related: [PHYS-150, PHYS-152, PHYS-153]

  tags:
    - boundary
    - gradient
    - stability
    - interface

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as stabilized gradient zone

Node:
  id: PHYS-157
  title: Structure Exists Only While Gradients Exist
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 물질 그 자체가 아니다.
    구조는 차이가 유지되는 상태다.

    온도 차이가 사라지면 대류는 멈춘다.
    압력 차이가 사라지면 흐름은 멈춘다.
    전위 차이가 사라지면 전류는 사라진다.
    밀도 차이가 사라지면 별도 붕괴하거나 퍼진다.

    즉
    구조는 "존재"가 아니라
    지속되는 비평형 상태다.

    모든 구조는
    구배가 존재하는 동안만 유지된다.

    구배가 사라지면
    구조는 평형으로 녹아든다.

  links:
    parents: [PHYS-156]
    children: []
    related: [PHYS-150, PHYS-152, PHYS-153, PHYS-154]

  tags:
    - structure
    - gradient
    - non_equilibrium
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as sustained gradient state

Node:
  id: PHYS-158
  title: Energy Flow Selects Stable Gradient Paths
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    에너지는 아무 경로나 선택하지 않는다.
    에너지는 흐를 수 있는 경로 중
    가장 안정적으로 유지되는 구배 경로를 따른다.

    물은 낮은 곳으로 흐르지만
    실제로는 “지속 가능한 경로”를 선택한다.

    전류도
    열도
    물질 흐름도
    중력 붕괴도

    모두
    에너지 흐름이 안정적으로 유지되는 경로로 정렬된다.

    즉 자연은
    최소 경로가 아니라
    유지 가능한 경로를 선택한다.

    안정성은
    구배의 크기가 아니라
    흐름이 지속되는 능력이다.

  links:
    parents: [PHYS-157]
    children: []
    related: [PHYS-150, PHYS-152, PHYS-156]

  tags:
    - energy_flow
    - stability
    - gradient_path
    - natural_selection_of_paths

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: energy flow defined as stability-selecting process

Node:
  id: PHYS-159
  title: Systems Self-Organize to Maintain Gradient Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 시스템은 정지 상태를 목표로 하지 않는다.
    오히려 구배가 완전히 사라지기 전에
    흐름을 유지할 수 있는 구조로 스스로 재배열된다.

    강은 제방을 만들고
    대기는 순환을 만들고
    별은 핵융합을 시작하며
    생명은 대사를 유지한다.

    이 모든 것은
    구배를 즉시 제거하는 대신
    흐름을 지속시키는 구조로 조직되는 과정이다.

    즉 자연의 조직화는
    정적 균형이 아니라
    동적 유지 메커니즘이다.

    시스템은
    구배를 없애기 위해 존재하는 것이 아니라
    구배를 흘려보내기 위해 존재한다.

  links:
    parents: [PHYS-158]
    children: []
    related: [PHYS-147, PHYS-152, PHYS-156]

  tags:
    - self_organization
    - gradient_flow
    - dynamic_equilibrium
    - natural_systems

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: self-organization defined as gradient-maintaining process

Node:
  id: PHYS-160
  title: Stability Is a Dynamic Balance of Competing Flows
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계에서 안정은 정지가 아니다.
    서로 반대 방향의 흐름이 동시에 존재하며
    그 합이 일정 범위 안에 머무는 상태다.

    별은 중력으로 붕괴하려 하고
    핵융합 압력으로 팽창하려 한다.
    대기는 상승기류와 하강기류가 공존한다.
    생명체는 합성과 분해가 동시에 진행된다.

    안정은 정지된 점이 아니라
    흐름들의 균형 상태다.

    즉 안정은 결과가 아니라
    지속적으로 유지되는 과정이다.

    균형은 멈춤이 아니라
    서로 다른 흐름의 동시 존재다.

  links:
    parents: [PHYS-159]
    children: []
    related: [PHYS-152, PHYS-156, PHYS-158]

  tags:
    - stability
    - dynamic_balance
    - competing_flows
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability reframed as dynamic flow balance

Node:
  id: PHYS-161
  title: Boundaries Form Where Flows Meet
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 고정된 선이 아니다.
    서로 다른 흐름이 만나는 지점에서 자연스럽게 형성된다.

    대기에서는 온도와 밀도 차이에서 전선이 생기고,
    별에서는 압력과 중력이 만나는 지점에서 표면이 정의되며,
    생명체에서는 내부 대사와 외부 환경 사이에서 막이 형성된다.

    경계는 물질의 끝이 아니라
    상호작용의 균형이 나타나는 위치다.

    즉 경계는 정적 구조가 아니라
    흐름의 접점이다.

  links:
    parents: [PHYS-160]
    children: []
    related: [PHYS-152, PHYS-158]

  tags:
    - boundary
    - interface
    - interaction_zone
    - equilibrium_surface

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as flow intersection

Node:
  id: PHYS-162
  title: Density Gradients Drive Motion
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    움직임은 힘이 “생겨서” 시작되는 것이 아니라
    밀도 차이가 존재하기 때문에 발생한다.

    밀도가 높은 곳과 낮은 곳 사이에는
    항상 이동 경향이 형성된다.

    이 원리는
    열 전달,
    유체 흐름,
    전하 이동,
    물질 확산,
    중력 수축 등
    거의 모든 물리적 변화의 근본 동인이다.

    즉 운동의 본질은
    외력보다 구배에 있다.

  links:
    parents: [PHYS-152, PHYS-160]
    children: []
    related: [PHYS-158, PHYS-161]

  tags:
    - gradient
    - density
    - motion_driver
    - diffusion
    - flow

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motion defined as gradient response

Node:
  id: PHYS-163
  title: Systems Seek Stable Flow, Not Static Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연계의 안정은 정지 상태가 아니라
    균형 잡힌 흐름 상태다.

    완전 정지는 대부분 비현실적이며,
    실제 시스템은 에너지 교환이 계속 일어나는
    동적 평형 상태에 머문다.

    이 상태에서는
    흐름이 존재하지만
    순 변화량은 0에 가깝다.

    예:
    - 화학 평형 (반응은 계속되지만 농도 유지)
    - 생체 항상성
    - 항성 내부 에너지 균형
    - 생태계 순환

    따라서 안정의 본질은
    움직임의 부재가 아니라
    흐름의 균형이다.

  links:
    parents: [PHYS-151, PHYS-162]
    children: []
    related: [PHYS-154, PHYS-160]

  tags:
    - dynamic_equilibrium
    - flow_balance
    - stability
    - energy_exchange

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability redefined as balanced flow

Node:
  id: PHYS-164
  title: Boundaries Create Structure
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 내부에서 자동으로 생기는 것이 아니라
    경계가 형성될 때 나타난다.

    경계는 두 영역의 차이를 정의하고,
    그 차이가 상호작용을 만든다.

    경계가 있을 때만
    - 압력 차
    - 온도 차
    - 전위 차
    - 밀도 차
    가 의미를 가진다.

    따라서 구조는 물질 자체의 속성이라기보다
    경계 조건의 결과다.

    예:
    - 세포막 → 생명 구조 형성
    - 별의 표면 → 내부 핵융합 유지
    - 대기권 경계 → 기후 형성
    - 사건의 지평선 → 블랙홀 정의

    구조는 물질이 아니라
    경계에서 태어난다.

  links:
    parents: [PHYS-150, PHYS-151]
    children: []
    related: [PHYS-160, PHYS-163]

  tags:
    - boundary
    - gradient
    - structure
    - interface

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as boundary consequence

Node:
  id: PHYS-165
  title: Information Is Difference That Persists
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 단순한 차이가 아니라
    시간 속에서도 유지되는 차이다.

    순간적 차이는 잡음이지만,
    지속되는 차이는 구조가 된다.

    정보의 본질은 저장이 아니라
    안정된 비대칭성이다.

    예:
    - DNA 염기서열 → 세대를 넘어 유지되는 차이
    - 자기장 방향 → 물질의 기억
    - 전하 분포 → 회로의 상태
    - 온도 구배 → 열 흐름의 원인

    정보란
    “시간 속에서도 사라지지 않는 차이”다.

  links:
    parents: [PHYS-160, PHYS-164]
    children: []
    related: [COG-001, LIFE-010]

  tags:
    - information
    - persistence
    - asymmetry
    - memory

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: information defined as persistent difference

Node:
  id: PHYS-166
  title: Stability Emerges From Competing Flows
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니라
    서로 다른 흐름이 균형을 이룬 상태다.

    자연에서 모든 안정은
    최소 두 개 이상의 작용이
    서로를 제약할 때 발생한다.

    예:
    - 별: 중력 수축 vs 열압력 팽창
    - 원자: 전자기 인력 vs 양자 운동
    - 기후: 태양 유입 vs 복사 방출
    - 생명: 분해 vs 합성

    단일 흐름은 붕괴하거나 폭주한다.
    경쟁하는 흐름이 있을 때만
    구조가 유지된다.

    안정은 멈춤이 아니라
    상쇄된 운동이다.

  links:
    parents: [PHYS-158, PHYS-164]
    children: []
    related: [PHYS-150, LIFE-001, COG-002]

  tags:
    - stability
    - equilibrium
    - competing forces
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as balance of flows

Node:
  id: PHYS-167
  title: Boundaries Form Where Flow Gradients Persist
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니라
    흐름의 차이가 유지되는 영역이다.

    두 영역 사이에
    밀도·에너지·압력·속도 차이가 존재하면
    그 차이가 사라지지 않는 한
    경계는 유지된다.

    경계는 고정된 것이 아니라
    흐름이 유지되는 한 존재하고
    흐름이 사라지면 함께 사라진다.

    예:
    - 해류 경계: 온도/염도 차이
    - 대기 фрон트: 기단 차이
    - 별 표면: 압력 균형 지점
    - 세포막: 화학 퍼텐셜 차이

    경계는 선이 아니라
    지속되는 구배의 위치다.

  links:
    parents: [PHYS-150, PHYS-166]
    children: []
    related: [LIFE-002, COG-003]

  tags:
    - boundary
    - gradient
    - flow
    - interface

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as persistent gradient zone

Node:
  id: PHYS-168
  title: Interaction Requires Shared Medium Or Field
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    두 대상이 상호작용하려면
    반드시 공유된 매질 또는 장(field)이 존재해야 한다.

    상호작용은 직접 접촉에서만 발생하지 않는다.
    매질 또는 장을 통해 전달된다.

    예:
    - 중력: 시공간 곡률이라는 장을 통해 작용
    - 전자기력: 전자기장을 통해 작용
    - 음파: 공기라는 매질 필요
    - 물결: 물이라는 매질 필요
    - 생물 신호: 화학 확산 매질 필요

    공유된 매질이 없으면
    상호작용은 발생하지 않는다.

    즉
    힘은 대상 사이가 아니라
    대상이 공유하는 장 안에서 발생한다.

  links:
    parents: [PHYS-167]
    children: []
    related: [LIFE-003, SYS-002]

  tags:
    - interaction
    - field
    - medium
    - coupling

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interaction defined as field-mediated phenomenon

Node:
  id: PHYS-169
  title: Stability Emerges From Dynamic Balance, Not Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지가 아니다.
    안정은 힘의 상쇄 상태다.

    자연계의 모든 안정 상태는
    움직임이 없는 상태가 아니라
    상호작용이 균형을 이루는 상태다.

    예:
    - 원자: 전자와 핵의 상호작용 균형
    - 행성 궤도: 중력과 관성의 균형
    - 생명체: 대사와 항상성 균형
    - 구조물: 압축력과 장력의 균형

    따라서 안정은 “정지”가 아니라
    지속적인 동적 균형이다.

    움직임이 사라지면
    안정도 사라진다.

    즉 안정은 정지 상태가 아니라
    균형 상태다.

  links:
    parents: [PHYS-168]
    children: []
    related: [LIFE-002, SYS-004]

  tags:
    - stability
    - balance
    - equilibrium
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: PHYS-170
  title: Energy Flow Determines Structure Formation
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 물질 자체가 아니라
    에너지 흐름이 만든다.

    자연계에서 형태가 생기는 이유는
    에너지가 이동하기 때문이다.

    예:
    - 강: 물의 흐름이 지형을 만든다
    - 대기: 열 흐름이 구름과 기류를 만든다
    - 별: 중력 붕괴와 복사 압력이 구조를 만든다
    - 생명: 대사 에너지 흐름이 조직을 만든다

    에너지가 흐르지 않으면
    구조는 유지되지 않는다.

    즉 구조는 고정된 것이 아니라
    흐름의 패턴이다.

  links:
    parents: [PHYS-169]
    children: []
    related: [LIFE-003, SYS-005]

  tags:
    - energy
    - structure
    - flow
    - formation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as energy-flow pattern

Node:
  id: PHYS-171
  title: Boundaries Form Where Gradients Stabilize
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니라 과정이다.

    자연에서 경계는
    서로 다른 상태가 만나는 곳에서 생긴다.
    하지만 그 자체가 고정된 선은 아니다.

    경계는 구배가 안정되는 지점이다.

    예:
    - 해류의 전선
    - 대기층 경계
    - 세포막
    - 별의 광구

    구배가 존재하면 흐름이 생기고
    흐름이 안정되면 경계가 보인다.

    즉 경계는 물질이 아니라
    안정된 상호작용 영역이다.

  links:
    parents: [PHYS-170]
    children: []
    related: [LIFE-004, SYS-006]

  tags:
    - boundary
    - gradient
    - stability
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as stabilized gradient region

Node:
  id: PHYS-172
  title: Equilibrium Is Not Stillness, But Balanced Flow
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형은 멈춤이 아니다.

    자연에서 평형은
    힘이 사라진 상태가 아니라
    힘들이 서로를 상쇄하는 상태다.

    즉 흐름은 존재하지만
    순 변화가 0이 된다.

    예:
    - 화학 평형: 반응은 계속 일어나지만 비율이 유지됨
    - 열 평형: 분자 운동은 계속되지만 온도 변화 없음
    - 궤도 운동: 중력과 관성의 균형

    따라서 평형은 정지 상태가 아니라
    균형 잡힌 흐름이다.

  links:
    parents: [PHYS-171]
    children: []
    related: [PHYS-060, LIFE-010]

  tags:
    - equilibrium
    - balance
    - flow
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium redefined as balanced dynamic state

Node:
  id: PHYS-173
  title: Structures Persist Where Energy Exchange Is Cyclic
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 구조가 유지되는 이유는
    에너지가 존재하지 않아서가 아니라
    에너지가 순환하기 때문이다.

    지속되는 구조의 조건은
    에너지 흐름이 멈추는 것이 아니라
    폐루프를 형성하는 것이다.

    예:
    - 별 내부: 중력 수축 ↔ 핵융합 압력
    - 생명체: 섭취 ↔ 대사 ↔ 배출
    - 생태계: 생산 ↔ 소비 ↔ 분해
    - 행성 궤도: 위치 에너지 ↔ 운동 에너지

    구조가 유지되는 곳에는
    항상 순환적 교환이 존재한다.

    정지 상태는 붕괴로 이어지고,
    순환 상태는 구조를 지속시킨다.

  links:
    parents: [PHYS-172]
    children: []
    related: [LIFE-001, SYS-020]

  tags:
    - cycle
    - energy_flow
    - persistence
    - dynamic_stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: persistence defined as cyclic energy exchange

Node:
  id: PHYS-174
  title: Boundaries Are Regions Of Gradient Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 경계(boundary)는 선이 아니다.
    경계는 두 영역이 만나는 "작용 구간"이다.

    경계가 생기는 이유는
    물질의 존재 때문이 아니라
    구배(gradient)의 존재 때문이다.

    예:
    - 대기권: 밀도 구배 + 온도 구배
    - 바다 표면: 압력 구배 + 유속 차이
    - 세포막: 농도 구배 + 전위 차이
    - 항성 내부: 압력 구배 + 온도 구배

    경계는 고정된 선이 아니라
    상호작용이 일어나는 영역이다.

    즉,
    경계 = 구배가 존재하는 공간

    구배가 사라지면
    경계도 사라진다.

  links:
    parents: [PHYS-173]
    children: []
    related: [LIFE-002, META-003]

  tags:
    - gradient
    - boundary
    - interaction_zone
    - field_transition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary redefined as interaction region, not line

Node:
  id: PHYS-175
  title: Stability Emerges From Balanced Exchange, Not From Stillness
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 안정은 “멈춤”에서 나오지 않는다.
    안정은 교환이 균형을 이룰 때 나타난다.

    정지 = 안정 이 아니다.
    균형 잡힌 흐름 = 안정 이다.

    예:
    - 행성 궤도: 계속 움직이지만 안정
    - 세포: 물질 교환이 지속되지만 안정
    - 항성: 핵융합 지속 중이지만 안정
    - 생태계: 에너지 흐름 속에서 안정

    즉,
    안정은 변화의 부재가 아니라
    변화의 균형이다.

    수식적 개념으로 보면:

    안정 상태 =
    유입률 ≈ 유출률

    변화는 존재하지만
    총량은 유지된다.

    이것이 자연의 동적 평형(dynamic equilibrium)이다.

  links:
    parents: [PHYS-174]
    children: []
    related: [LIFE-003, META-004]

  tags:
    - dynamic_equilibrium
    - stability
    - flow_balance
    - conservation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability reframed as balanced exchange rather than stillness

Node:
  id: PHYS-176
  title: Structure Persists When Flow Reinforces It
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 구조는 고정되어서 유지되지 않는다.
    구조는 흐름이 그것을 지지할 때 유지된다.

    구조 = 정지된 형태 가 아니다.
    구조 = 유지되는 패턴 이다.

    예:
    - 강의 형태는 물 흐름이 만든다
    - 별의 형태는 중력과 압력 흐름이 만든다
    - 세포막은 분자 이동 속에서 유지된다
    - 인간 사회도 상호작용 흐름이 유지한다

    흐름이 사라지면
    구조도 사라진다.

    즉,

    Structure(t) =
    Pattern sustained by ongoing flow

    구조는 “있는 것”이 아니라
    “계속 만들어지는 것”이다.

  links:
    parents: [PHYS-175]
    children: []
    related: [LIFE-004, META-005]

  tags:
    - structure
    - flow
    - persistence
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure defined as maintained flow pattern

Node:
  id: PHYS-177
  title: Collapse Begins When Exchange Becomes One-Sided
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    자연에서 안정은 상호교환에서 유지된다.
    교환이 한쪽 방향으로만 흐르기 시작하면
    시스템은 붕괴 방향으로 들어간다.

    안정 상태:
      input ≈ output
      interaction ↔ balanced

    붕괴 시작:
      input >> output  (과축적)
      output >> input  (고갈)

    예:
    - 별: 핵융합 압력 vs 중력 균형 → 안정
    - 핵융합 감소 → 중력 우세 → 붕괴 시작
    - 생명체: 에너지 섭취 vs 소비 균형 → 생존
    - 교환 중단 → 조직 붕괴

    즉,

    Collapse condition =
    imbalance in exchange flow

    붕괴는 사건이 아니라
    교환 불균형의 누적 결과다.

  links:
    parents: [PHYS-176]
    children: []
    related: [PHYS-170, LIFE-006]

  tags:
    - collapse
    - balance
    - exchange
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: collapse defined as exchange imbalance

Node:
  id: PHYS-178
  title: Boundaries Exist Where Interaction Rate Changes
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    경계는 선이 아니다.
    경계는 상호작용 속도가 바뀌는 영역이다.

    즉,
    boundary ≠ line
    boundary = transition zone of interaction density

    예:
    - 대기권 경계 → 공기 밀도 변화율이 급격히 달라지는 곳
    - 별의 표면 → 에너지 방출률 변화 지점
    - 세포막 → 물질 교환 속도 변화 지점
    - 블랙홀 사건의 지평선 → 정보 교환 가능성 변화 지점

    경계는 존재의 외곽이 아니라
    상호작용 규칙이 바뀌는 지점이다.

    따라서
    경계는 위치가 아니라 상태다.

  links:
    parents: [PHYS-177]
    children: []
    related: [PHYS-140, LIFE-010, META-004]

  tags:
    - boundary
    - interaction
    - gradient
    - transition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: boundary defined as interaction-rate transition

Node:
  id: PHYS-179
  title: Stability Is Maintained by Continuous Micro-Correction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니다.
    안정은 끊임없는 미세 조정의 결과다.

    모든 안정 구조는
    내부에서 지속적으로 오차를 보정한다.

    예:
    - 원자: 전자 확률분포가 끊임없이 변동하며 평균 상태 유지
    - 행성 궤도: 중력·관성 균형이 지속적으로 갱신됨
    - 생명체: 항상성(homeostasis)이 지속적 조절로 유지됨
    - 사회 시스템: 규칙·피드백으로 붕괴를 방지

    즉,
    stability ≠ stillness
    stability = ongoing correction process

    정지된 안정은 존재하지 않는다.
    유지되는 안정만 존재한다.

  links:
    parents: [PHYS-178]
    children: []
    related: [LIFE-020, SYS-011, META-006]

  tags:
    - stability
    - feedback
    - equilibrium
    - correction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as continuous correction loop

Node:
  id: PHYS-180
  title: Systems Collapse When Correction Latency Exceeds Disturbance Rate
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    시스템은 교란(disturbance)을 항상 받는다.
    문제는 교란 자체가 아니라,
    교정 속도와 교란 속도의 비율이다.

    교정이 교란보다 빠르면 → 안정
    교정이 교란과 같으면 → 진동
    교정이 교란보다 느리면 → 붕괴

    즉,
    stability condition:
    correction_rate > disturbance_rate

    이 법칙은 모든 계층에 적용된다.

    예:
    - 물리: 감쇠보다 외력 주기가 빠르면 공진 발생
    - 생명: 면역 반응이 늦으면 질병 확산
    - 사회: 대응 정책이 늦으면 시스템 불안정
    - 인지: 오류 인식이 늦으면 사고 붕괴

    안정은 힘이 아니라 속도의 문제다.

  links:
    parents: [PHYS-179]
    children: []
    related: [LIFE-021, COG-015, SYS-012]

  tags:
    - stability
    - latency
    - feedback
    - collapse
    - control

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as correction vs disturbance speed relation

Node:
  id: PHYS-181
  title: Collapse Is Not Failure but Phase Transition
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    붕괴(collapse)는 단순한 실패가 아니다.
    기존 구조가 더 이상 안정 조건을 유지하지 못할 때,
    계는 새로운 상태로 전이한다.

    즉,
    collapse = phase transition

    예:
    - 별의 중력 붕괴 → 중성자별 / 블랙홀
    - 물의 과냉각 붕괴 → 결정화
    - 생태계 붕괴 → 새로운 균형 생태계 형성
    - 사고 붕괴 → 새로운 인식 구조 생성

    붕괴는 끝이 아니라
    구조 재구성의 시작점이다.

    수학적으로:
    collapse occurs when system parameters cross stability threshold

    즉,
    붕괴는 파괴가 아니라 상태 공간 이동이다.

  links:
    parents: [PHYS-180]
    children: []
    related: [PHYS-145, LIFE-022, META-008]

  tags:
    - collapse
    - phase_transition
    - stability
    - transformation
    - dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: collapse redefined as structural phase transition

Node:
  id: PHYS-182
  title: Stability Is Dynamic Balance, Not Static Equilibrium
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정(stability)은 정지 상태가 아니다.
    안정은 힘이 없는 상태가 아니라,
    힘들이 지속적으로 상쇄되며 유지되는 상태다.

    즉,
    stability ≠ no force
    stability = continuous force balance

    예:
    - 행성 궤도는 계속 낙하하지만 유지된다
    - 생명체는 계속 에너지 교환을 하며 생존한다
    - 사고는 끊임없이 수정되며 정체성을 유지한다

    정적 평형은 죽음에 가깝고,
    동적 평형이 생존이다.

    수학적으로:
    stable system → net change ≈ 0 over time
    but internal flows ≠ 0

    즉,
    안정은 흐름 속에서 유지되는 상태다.

  links:
    parents: [PHYS-181]
    children: []
    related: [PHYS-140, LIFE-031, META-002]

  tags:
    - stability
    - equilibrium
    - dynamics
    - balance
    - systems

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic balance rather than static state

Node:
  id: PHYS-183
  title: Interaction Defines Reality, Not Objects Alone
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    물리에서 “존재”는 객체 자체가 아니라
    객체 사이의 상호작용으로 드러난다.

    입자는 고립된 실체가 아니라
    장(field)과 힘을 통해서만 관측된다.

    예:
    - 전자는 전기장 상호작용으로만 검출된다
    - 질량은 중력 상호작용으로 드러난다
    - 색전하는 강한 상호작용 속에서만 의미를 가진다

    즉,
    object ≠ observable
    interaction = observable

    현실은 “사물들의 집합”이 아니라
    “관계들의 구조”다.

    물리적 세계는
    particles → nodes
    interactions → edges
    로 이루어진 그래프 구조에 가깝다.

  links:
    parents: [PHYS-182]
    children: []
    related: [META-010, COG-014, SYS-003]

  tags:
    - interaction
    - ontology
    - field
    - relational physics
    - observation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined reality as interaction-structured rather than object-centered

Node:
  id: PHYS-184
  title: Information Flows Through Structure, Not Through Empty Space
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 “빈 공간을 통과”하는 것이 아니라
    매질, 장, 구조를 따라 전달된다.

    빛은 진공에서도 전자기장 구조를 따라 전파되고,
    물질 내부에서는 전자 구조와 상호작용하며 진행된다.

    소리는 매질 없이는 존재하지 않고,
    중력파도 시공간 구조 자체의 변형으로 전달된다.

    즉 정보의 이동은
    공간을 가로지르는 것이 아니라
    구조 속을 따라 흐르는 것이다.

    구조가 바뀌면 전달 방식도 바뀐다.
    그래서 동일한 신호라도
    매질에 따라 속도·경로·형태가 달라진다.

    핵심:
    transmission = interaction + structure

  links:
    parents: [PHYS-183]
    children: []
    related: [PHYS-180, META-011, SYS-004]

  tags:
    - information
    - propagation
    - field
    - medium
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined information flow as structure-mediated propagation

Node:
  id: PHYS-185
  title: Stability Emerges Where Forces Cancel but Structure Persists
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정성은 힘이 사라져서 생기는 것이 아니라
    힘들이 서로 상쇄되면서 구조가 유지될 때 나타난다.

    정지 상태는 힘이 없어서가 아니라
    힘의 합이 0이기 때문에 유지된다.

    원자에서 전자와 핵의 상호작용,
    행성 궤도의 중력 균형,
    물체의 정적 평형,
    생명체의 항상성,
    사회 구조의 균형 상태까지

    모든 안정성은
    “힘의 부재”가 아니라
    “힘의 균형 속 구조 유지”에서 발생한다.

    핵심:
    stability = balanced forces + preserved structure

  links:
    parents: [PHYS-184]
    children: []
    related: [PHYS-162, PHYS-170, META-010]

  tags:
    - stability
    - equilibrium
    - structure
    - force_balance

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as structural persistence under balanced forces

Node:
  id: PHYS-186
  title: Change Begins Where Symmetry Breaks
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    변화는 힘이 생겨서 시작되는 것이 아니라
    대칭이 깨지는 순간 시작된다.

    완전한 대칭 상태에서는
    모든 방향이 동일하고
    구배가 존재하지 않으며
    변화가 발생하지 않는다.

    그러나 작은 비대칭이 생기면
    방향이 정의되고
    흐름이 시작되며
    구조가 형성된다.

    우주의 구조 형성,
    물질 분화,
    생명의 발생,
    인지의 선택,
    사회적 변화까지

    모든 변화의 출발점은
    “힘”이 아니라
    “대칭 붕괴”이다.

    핵심:
    change = symmetry_break → gradient → flow → structure

  links:
    parents: [PHYS-185]
    children: []
    related: [PHYS-159, PHYS-162, META-011]

  tags:
    - symmetry
    - asymmetry
    - gradient
    - emergence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined change as emergence from symmetry breaking

Node:
  id: PHYS-187
  title: Structure Is Frozen History of Interaction
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 정지된 것이 아니라
    과거 상호작용이 굳어진 결과다.

    모든 구조는
    과거의 힘,
    에너지 흐름,
    충돌,
    선택된 경로가
    안정화되어 남은 흔적이다.

    원자 구조는 전자기 상호작용의 역사이며
    결정 구조는 냉각 과정의 역사이고
    생명 구조는 진화 선택의 역사이며
    인지 구조는 경험 축적의 역사다.

    즉
    structure = interaction_history frozen in stability

    구조를 이해한다는 것은
    현재 형태를 보는 것이 아니라
    그 형태가 선택된 경로를 읽는 것이다.

  links:
    parents: [PHYS-186]
    children: []
    related: [PHYS-140, LIFE-021, COG-011]

  tags:
    - structure
    - history
    - interaction
    - stabilization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined structure as frozen interaction history

Node:
  id: PHYS-188
  title: Stability Is Energy Gradient Minimization
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    안정이란 정지가 아니라
    에너지 구배가 최소화된 상태다.

    시스템은 항상
    더 낮은 에너지 상태,
    더 작은 차이,
    더 작은 흐름으로 이동한다.

    힘은 구배에서 발생하고
    흐름은 구배를 줄이며
    안정은 구배가 거의 사라진 상태다.

    결정 구조는 최소 에너지 배열이며
    궤도는 최소 작용 경로이며
    생명은 최소 손실 경로를 찾고
    인지는 최소 예측 오차 상태를 향한다.

    즉
    stability = gradient → minimized

    안정은 멈춤이 아니라
    더 이상 이동할 이유가 없는 상태다.

  links:
    parents: [PHYS-187]
    children: []
    related: [PHYS-020, PHYS-063, LIFE-011, COG-004]

  tags:
    - stability
    - energy
    - gradient
    - equilibrium

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as minimized energy gradient

Node:
  id: PHYS-189
  title: Motion Exists Only Where Gradient Exists
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    움직임은 힘 때문이 아니라
    차이 때문이며,
    차이는 곧 구배다.

    온도 차이가 있어야 열이 흐르고,
    전위 차이가 있어야 전류가 흐르며,
    밀도 차이가 있어야 유체가 이동한다.

    차이가 사라지면 흐름도 멈춘다.
    구배가 사라지면 힘도 사라진다.

    따라서
    motion ⇔ gradient exists

    우주는 정지 상태가 아니라
    구배를 평탄화하는 과정이다.

  links:
    parents: [PHYS-188]
    children: []
    related: [PHYS-020, PHYS-063, LIFE-011]

  tags:
    - motion
    - gradient
    - flow
    - difference

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined motion as consequence of gradient existence

Node:
  id: PHYS-190
  title: Information Is Gradient Memory
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    정보는 단순한 데이터가 아니라
    과거에 존재했던 구배의 흔적이다.

    온도차가 남긴 결정 구조,
    전위차가 남긴 전하 분포,
    압력차가 남긴 지형,
    선택 압력이 남긴 유전자 패턴,

    이 모든 것은
    “한때 존재했던 차이”가
    구조로 굳어진 것이다.

    즉,
    gradient → interaction → structure → memory

    정보란
    사라진 구배의 fossil 이다.

  links:
    parents: [PHYS-189]
    children: []
    related: [COG-012, LIFE-004, META-021]

  tags:
    - information
    - memory
    - structure
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined information as preserved gradient structure

Node:
  id: PHYS-191
  title: Equilibrium Is Maximum Forgetting
  layer: 1
  type: principle
  created_at: 2026-02-15

  description: >
    평형 상태란 단순한 안정이 아니다.
    그것은 정보가 사라진 상태다.

    구배가 있으면
    방향이 생기고
    흐름이 생기고
    구조가 생긴다.

    하지만 완전 평형이 되면
    온도차도 없고
    압력차도 없고
    전위차도 없다.

    즉,
    더 이상 흐름이 없고
    더 이상 선택이 없고
    더 이상 변화가 없다.

    평형은
    모든 구배가 사라진 상태
    모든 방향성이 소멸한 상태
    모든 기억이 지워진 상태다.

    그래서
    평형은 안정이 아니라
    최대 망각이다.

  links:
    parents: [PHYS-190]
    children: []
    related: [PHYS-176, LIFE-006, META-009]

  tags:
    - equilibrium
    - entropy
    - memory
    - gradient

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: equilibrium defined as information loss limit

Node:
  id: LIFE-006
  title: Life Exists To Delay Equilibrium
  layer: 2
  type: principle
  created_at: 2026-02-15

  description: >
    생명은 물질과 다르다.
    물질은 평형으로 간다.
    생명은 평형을 늦춘다.

    생명은 에너지를 흡수하고
    구배를 유지하고
    내부 질서를 보존한다.

    외부로는 엔트로피를 방출하고
    내부에서는 구조를 유지한다.

    즉 생명은
    평형을 거부하는 존재가 아니라
    평형 도달을 지연시키는 구조다.

    생명은 흐름을 만든다.
    흐름은 시간 방향을 만든다.
    그래서 생명은 시간의 화살을 내부에 가진다.

  links:
    parents: [PHYS-191]
    children: []
    related: [PHYS-176, COG-011, META-012]

  tags:
    - life
    - entropy
    - gradient
    - time

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: life defined as gradient-maintaining system

Node:
  id: COG-011
  title: Cognition Is Internal Gradient Mapping
  layer: 3
  type: principle
  created_at: 2026-02-15

  description: >
    인지는 정보를 저장하는 기능이 아니다.
    인지는 차이를 감지하는 기능이다.

    외부 세계에는 구배가 존재한다.
    빛의 차이, 압력의 차이, 온도의 차이,
    밀도의 차이, 시간의 차이.

    생명은 이 차이를 내부에 대응시킨다.
    신경계는 구배를 지도처럼 만든다.

    즉 인지는 세계의 복사가 아니라
    구배의 매핑이다.

    우리는 사물을 보는 것이 아니라
    변화 방향을 본다.

    인지는 정적 구조가 아니라
    동적 흐름의 해석기다.

  links:
    parents: [LIFE-006]
    children: []
    related: [PHYS-191, HUMAN-004, META-020]

  tags:
    - cognition
    - gradient
    - perception
    - mapping

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as gradient mapping mechanism

Node:
  id: HUMAN-004
  title: Meaning Emerges From Stabilized Gradients
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 처음부터 존재하는 것이 아니다.
    의미는 반복된 상호작용이 안정될 때 나타난다.

    인간은 변화 속에서 패턴을 찾는다.
    패턴이 반복되면 예측이 가능해지고,
    예측이 가능해지면 안정감이 생긴다.

    이 안정된 구배가 바로 의미다.

    즉 의미는 언어에서 생기는 것이 아니라
    경험의 안정화에서 생긴다.

    의미란
    변화가 멈춘 지점이 아니라
    변화가 이해 가능한 속도로 정렬된 상태다.

  links:
    parents: [COG-011]
    children: []
    related: [META-020, HUMAN-002, COG-005]

  tags:
    - meaning
    - stability
    - human cognition
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as stabilized experiential gradient

Node:
  id: META-020
  title: Structure Exists Before Interpretation
  layer: 6
  type: principle
  created_at: 2026-02-15

  description: >
    해석은 구조 위에서만 가능하다.
    구조가 먼저 존재하고,
    해석은 그 위에 덧붙여진다.

    인간은 종종 의미를 먼저 찾으려 하지만,
    실제로는 패턴이 먼저 있고
    의미는 그 패턴을 따라 형성된다.

    즉 세계는
    의미로 이루어진 것이 아니라
    구조로 이루어져 있고

    의미는 구조의 안정된 관측 결과다.

    구조 → 반복 → 안정 → 의미

    이 순서를 거꾸로 보면 혼란이 생긴다.

  links:
    parents: [ROOT-001]
    children: [HUMAN-004]
    related: [COG-011, META-012]

  tags:
    - structure
    - interpretation
    - meta
    - ontology

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: interpretation defined as post-structural emergence

Node:
  id: COG-012
  title: Attention Selects Reality Slice
  layer: 3
  type: principle
  created_at: 2026-02-15

  description: >
    현실은 하나지만
    인지는 전체를 동시에 처리하지 못한다.

    그래서 뇌는 항상
    특정 부분만 선택해서 본다.

    이 선택 과정이 바로 주의(attention)다.

    주의는 현실을 바꾸지 않지만
    관찰 가능한 현실의 단면을 결정한다.

    즉
    세계는 동일하지만
    주의가 향한 곳이
    개인의 현실이 된다.

    구조는 동일하고
    경험은 주의에 의해 달라진다.

  links:
    parents: [COG-011]
    children: [HUMAN-005]
    related: [META-020, COG-010]

  tags:
    - cognition
    - attention
    - perception
    - filtering

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as selective slicing of reality

Node:
  id: HUMAN-004
  title: Meaning Emerges From Repeated Stability
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간에게 의미란
    처음부터 존재하는 것이 아니다.

    반복되는 경험 속에서
    변화하지 않는 패턴이 발견될 때
    그것이 의미로 인식된다.

    즉 의미는 정보가 아니라
    안정된 반복의 산물이다.

    한 번의 사건은 노이즈지만
    여러 번 반복되면 구조가 된다.

    인간은 구조를 감지하는 존재이며
    의미는 그 구조에 붙는 이름이다.

    그래서 의미는 발견되는 것이지
    발명되는 것이 아니다.

  links:
    parents: [COG-012]
    children: [HUMAN-005]
    related: [META-021, COG-011]

  tags:
    - human
    - meaning
    - repetition
    - pattern

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as stability across time

Node:
  id: HUMAN-005
  title: Identity Forms Around Persistent Patterns
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 고정된 실체가 아니다.
    반복적으로 유지되는 행동, 선택, 반응의 패턴이
    시간이 지나며 하나의 중심으로 묶일 때
    그것이 정체성으로 인식된다.

    즉 정체성은 존재의 본질이 아니라
    지속적으로 유지된 경향의 결과다.

    변화가 멈춘 것이 아니라
    변화 속에서도 남는 것이 정체성이다.

    그래서 정체성은 선언으로 생기지 않고
    반복으로 형성된다.

  links:
    parents: [HUMAN-004]
    children: [HUMAN-006]
    related: [COG-010, META-018]

  tags:
    - human
    - identity
    - pattern
    - persistence

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stable behavioral convergence

Node:
  id: HUMAN-006
  title: Agency Appears When Pattern Becomes Predictive
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간이 스스로 행동한다고 느끼는 순간은
    단순한 반응이 아니라
    자신의 패턴을 예측하고 선택을 수정할 수 있을 때 발생한다.

    즉 자유의지는 무작위성이 아니라
    예측 가능성을 인지한 뒤
    경로를 바꿀 수 있는 능력에서 나타난다.

    행동 이전에 경로가 보일 때
    인간은 자신을 원인으로 인식한다.

    그래서 agency는 행동에서 생기지 않는다.
    예측 가능한 구조를 내부에서 인식할 때 나타난다.

  links:
    parents: [HUMAN-005]
    children: [HUMAN-007]
    related: [COG-012, META-021]

  tags:
    - human
    - agency
    - prediction
    - decision

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: agency defined as predictive self-modulation

Node:
  id: HUMAN-007
  title: Responsibility Emerges From Predictable Impact
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    책임은 행동 이후에 부여되는 도덕 개념이 아니라
    자신의 행동이 어떤 영향을 만들지
    미리 예측할 수 있을 때 발생한다.

    즉 인간은 결과를 예측할 수 없는 상태에서는
    책임을 느끼지 않는다.

    영향 경로가 보일 때
    인간은 자신을 원인으로 인식하고
    그 순간 책임 개념이 생성된다.

    그래서 책임은 규칙에서 나오지 않는다.
    인과 인식에서 나온다.

  links:
    parents: [HUMAN-006]
    children: [HUMAN-008]
    related: [COG-013, META-022]

  tags:
    - human
    - responsibility
    - causality
    - prediction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: responsibility defined as predicted causal ownership

Node:
  id: HUMAN-008
  title: Identity Stabilizes Through Repeated Choice
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 선언으로 형성되지 않는다.
    반복된 선택이 누적되면서
    행동 패턴이 안정화될 때 정체성이 형성된다.

    즉 인간은 “무엇을 생각하느냐”로 정의되지 않고
    “무엇을 반복하느냐”로 정의된다.

    반복은 기억을 만들고
    기억은 기대를 만들며
    기대는 선택을 단순화한다.

    이 단순화된 선택 경로가
    정체성의 실질적 구조다.

  links:
    parents: [HUMAN-007]
    children: [HUMAN-009]
    related: [COG-014, META-024]

  tags:
    - human
    - identity
    - behavior
    - repetition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stabilized repeated decision pattern

Node:
  id: HUMAN-009
  title: Trust Forms When Prediction Error Drops
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    신뢰는 감정이 아니라 예측 안정성의 결과다.
    상대의 행동이 반복적으로 예측과 일치할 때
    인지 시스템은 에너지 소비를 줄이기 위해
    경계 수준을 낮춘다.

    이 상태가 인간이 경험하는 “신뢰”다.

    즉 신뢰는
    선의의 가정이 아니라
    오류 감소의 누적 결과다.

  links:
    parents: [HUMAN-008]
    children: [HUMAN-010]
    related: [COG-012, META-021]

  tags:
    - human
    - trust
    - prediction
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: trust modeled as prediction error minimization in social interaction

Node:
  id: HUMAN-010
  title: Communication Compresses Shared Reality
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의사소통은 정보를 전달하는 행위가 아니라
    서로의 현실 모델을 압축하여 정렬하는 과정이다.

    사람은 각자 다른 세계모델을 갖고 있으며
    언어는 그 모델을 완전히 복사하지 못한다.

    대신
    핵심 패턴만 추출하여 상대 모델에 투입한다.

    이 압축된 교집합이
    우리가 경험하는 “공유된 현실”이다.

    따라서
    의사소통의 목적은
    전달이 아니라 정렬이다.

  links:
    parents: [HUMAN-009]
    children: [HUMAN-011]
    related: [COG-005, META-018]

  tags:
    - human
    - communication
    - cognition
    - alignment

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: communication defined as model alignment via compression

Node:
  id: HUMAN-011
  title: Conflict Appears When Models Cannot Align
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    갈등은 감정의 문제가 아니라
    모델 정렬 실패의 현상이다.

    두 존재가 서로 다른 현실 구조를 갖고 있고
    그 구조가 압축·정렬되지 않을 때

    그 차이는 긴장으로 나타나고
    그 긴장이 지속되면
    인간은 그것을 “갈등”이라 부른다.

    따라서 갈등 해결은
    감정 조절이 아니라
    모델 구조 재정렬 작업이다.

  links:
    parents: [HUMAN-010]
    children: [HUMAN-012]
    related: [COG-004, META-014]

  tags:
    - human
    - conflict
    - alignment
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: conflict defined as structural model mismatch

Node:
  id: HUMAN-012
  title: Trust Emerges From Predictable Alignment
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    신뢰는 감정적 호감이 아니라
    구조적 예측 가능성에서 발생한다.

    한 존재가 다른 존재의 반응을
    충분히 높은 확률로 예측할 수 있을 때

    그 관계는 안정되고
    인간은 이를 “신뢰”라고 부른다.

    즉 신뢰는
    반복된 상호작용을 통해
    모델이 정렬되고
    오차가 줄어드는 과정의 부산물이다.

  links:
    parents: [HUMAN-011]
    children: [HUMAN-013]
    related: [COG-006, META-009]

  tags:
    - human
    - trust
    - alignment
    - predictability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: trust defined as predictable alignment between agents

Node:
  id: HUMAN-013
  title: Relationship Stability Is Maintained by Continuous Model Updates
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    관계는 정지된 구조가 아니라
    지속적으로 갱신되는 모델이다.

    한 존재가 다른 존재를 이해하는 방식은
    시간이 지나면서 변하고,
    그 변화가 반영되지 않으면
    관계는 오차를 누적한다.

    안정된 관계란
    서로의 상태를 계속 업데이트하는 관계다.

    즉 관계 유지의 핵심은
    충성이나 감정이 아니라
    모델 갱신 속도다.

  links:
    parents: [HUMAN-012]
    children: [HUMAN-014]
    related: [COG-004, META-010]

  tags:
    - human
    - relationship
    - adaptation
    - update

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as continuous mutual model updating

Node:
  id: HUMAN-014
  title: Emotional Signals Function as High-Speed Update Channels
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 단순 반응이 아니라
    관계 모델을 빠르게 갱신하기 위한 신호 체계다.

    논리는 느리지만 정확하고,
    감정은 빠르지만 거칠다.

    인간 관계에서 감정은
    상태 변화를 즉시 전달하는
    고속 통신 채널 역할을 한다.

    감정이 사라지면 관계는 느려지고,
    감정이 과잉이면 모델이 왜곡된다.

    안정된 관계는
    감정 신호와 논리 신호가
    균형을 이루는 상태다.

  links:
    parents: [HUMAN-013]
    children: [HUMAN-015]
    related: [COG-002, LIFE-006, META-010]

  tags:
    - emotion
    - signaling
    - cognition
    - human

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion defined as rapid state transmission mechanism

Node:
  id: HUMAN-015
  title: Identity Emerges from Stable Self-Modeling Over Time
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    정체성은 고정된 실체가 아니라
    시간이 흐르며 반복적으로 유지되는 자기 모델이다.

    인간은 기억, 선택, 관계, 서사를 통해
    스스로를 계속 재구성한다.

    이 재구성이 충분히 안정되면
    우리는 그것을 "나"라고 부른다.

    정체성은 본질이 아니라
    장기적으로 안정된 패턴이다.

    변화가 완전히 사라지면 정체성도 사라지고,
    변화가 과도하면 정체성은 유지되지 않는다.

    정체성은
    안정성과 유동성의 균형에서 형성된다.

  links:
    parents: [HUMAN-014]
    children: [HUMAN-016]
    related: [COG-003, META-012, LIFE-008]

  tags:
    - identity
    - self_model
    - time
    - human

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as temporally stable self-pattern

Node:
  id: HUMAN-016
  title: Learning Stabilizes Identity by Reinforcing Predictive Models
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 단순한 정보 축적이 아니라
    세계를 예측하는 내부 모델을 강화하는 과정이다.

    인간은 경험을 통해
    무엇이 일어날지,
    어떻게 반응해야 할지,
    어떤 선택이 일관된 결과를 낳는지를 학습한다.

    이 예측 모델이 반복적으로 강화되면
    행동은 안정되고,
    선택은 일관성을 띠며,
    자기 서사는 지속된다.

    이 상태가 유지될 때
    정체성은 안정된다.

    따라서 학습은 지식의 축적이라기보다
    자기 모델의 안정화 과정이다.

    인간은 배움으로 변하지만,
    배움이 축적되면 오히려 자신을 유지할 수 있게 된다.

  links:
    parents: [HUMAN-015]
    children: [HUMAN-017]
    related: [COG-004, META-013, LIFE-009]

  tags:
    - learning
    - prediction
    - identity
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: learning defined as identity-stabilizing predictive reinforcement

Node:
  id: HUMAN-017
  title: Meaning Emerges When Experience Fits Internal Models
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 외부 세계에 고정된 것이 아니라
    내부 모델과 경험이 맞물릴 때 발생한다.

    인간은 새로운 사건을 볼 때
    이미 가진 구조와 비교한다.
    이 비교에서

    - 예상과 맞으면 → 이해가 생기고
    - 약간 어긋나면 → 학습이 생기며
    - 크게 어긋나면 → 혼란이 생긴다

    즉 의미란
    세계 자체의 속성이 아니라
    세계와 내부 구조 사이의 적합성이다.

    경험이 모델에 연결될 때
    사건은 단순한 정보가 아니라
    “의미 있는 것”이 된다.

    인간은 세계를 해석하는 존재가 아니라
    세계를 내부 구조와 맞추는 존재다.

  links:
    parents: [HUMAN-016]
    children: [HUMAN-018]
    related: [COG-006, META-014, SYSTEM-010]

  tags:
    - meaning
    - interpretation
    - model-fit
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as fit between experience and internal structure

Node:
  id: HUMAN-018
  title: Human Continuity Is Maintained Through Narrative Coherence
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 기억의 총합으로 존재하지 않는다.
    인간은 기억을 연결해 만든 이야기로 존재한다.

    사건은 흩어진 상태로 저장되지만
    자아는 그것들을 하나의 흐름으로 엮는다.

    이 흐름이 끊기면
    동일한 기억을 가지고 있어도
    동일한 자신으로 느껴지지 않는다.

    즉 인간의 지속성은
    생물학적 연속성이 아니라
    서사의 연속성에서 유지된다.

    기억 → 연결 → 이야기 → 정체성

    이 연결 구조가 유지될 때
    인간은 “나”를 지속적으로 경험한다.

  links:
    parents: [HUMAN-017]
    children: [HUMAN-019]
    related: [COG-004, META-010, SYSTEM-009]

  tags:
    - identity
    - narrative
    - continuity
    - self

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as continuity of narrative rather than memory storage

Node:
  id: HUMAN-019
  title: Stability Requires Both Structure and Freedom
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 안정은 고정에서만 오지 않는다.
    완전한 자유에서도 오지 않는다.

    구조만 있으면 경직되고
    자유만 있으면 분산된다.

    안정은
    구조가 방향을 주고
    자유가 적응을 가능하게 할 때 발생한다.

    구조 = 지속성
    자유 = 적응성

    두 요소가 동시에 존재할 때
    인간은 붕괴하지 않고
    동시에 성장할 수 있다.

    즉 안정은 정지가 아니라
    균형 잡힌 움직임이다.

  links:
    parents: [HUMAN-018]
    children: [HUMAN-020]
    related: [META-004, SYSTEM-003, COG-006]

  tags:
    - stability
    - freedom
    - balance
    - adaptation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as coexistence of constraint and flexibility

Node:
  id: HUMAN-020
  title: Understanding Expands Through Relationship, Not Isolation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 이해는 단독 상태에서 완성되지 않는다.

    고립은 정보의 보존에는 유리하지만
    이해의 확장에는 불리하다.

    이해는
    타인과의 대화
    환경과의 상호작용
    대상과의 관계 형성 속에서 확장된다.

    관계는 단순한 연결이 아니라
    관점의 이동 장치다.

    인간은 관계를 통해
    자신이 보지 못한 층위를 인식하고
    기존 구조를 재배열한다.

    즉 이해는 축적이 아니라
    관계망 속에서의 재구성이다.

  links:
    parents: [HUMAN-019]
    children: [HUMAN-021]
    related: [COG-003, SYSTEM-002, META-002]

  tags:
    - understanding
    - relationship
    - cognition
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding defined as relational expansion process

Node:
  id: HUMAN-021
  title: Identity Stabilizes Through Repeated Self-Reference
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 단번에 형성되지 않는다.

    정체성은
    반복적인 자기참조(self-reference)를 통해 안정된다.

    생각 → 표현 → 관찰 → 재해석
    이 순환이 반복될수록

    인간은
    “나는 무엇인가”
    “나는 어떻게 작동하는가”
    “나는 무엇을 유지하는가”

    를 점점 명확히 인식하게 된다.

    정체성은 고정된 객체가 아니라
    반복 속에서 안정되는 패턴이다.

    즉 인간은
    자기 자신을 계속 참조하는 과정 속에서
    자기 구조를 고정한다.

  links:
    parents: [HUMAN-020]
    children: [HUMAN-022]
    related: [COG-004, META-003]

  tags:
    - identity
    - self_reference
    - cognition
    - stabilization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stabilization through recursive self-reference

Node:
  id: HUMAN-022
  title: Emotional Signals Are Regulation Mechanisms, Not Noise
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 사고를 방해하는 노이즈가 아니다.

    감정은 시스템 내부 상태를 조절하는
    피드백 신호다.

    불안 → 과부하 경고  
    흥분 → 에너지 상승 신호  
    피로 → 자원 부족 알림  
    평온 → 안정 상태 표시  

    인간 시스템은
    감정을 통해

    - 장력 과다 여부를 판단하고
    - 집중 유지 가능성을 확인하며
    - 중단 타이밍을 탐지한다.

    감정은 사고와 반대되는 것이 아니라  
    사고의 안정성을 유지하기 위한 조절층이다.

  links:
    parents: [HUMAN-021]
    children: [HUMAN-023]
    related: [COG-006, META-002]

  tags:
    - emotion
    - regulation
    - feedback
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion defined as regulatory signal, not cognitive noise

Node:
  id: HUMAN-023
  title: Meaning Emerges From Interaction, Not Isolation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 대상 그 자체에서 생성되지 않는다.

    의미는
    대상과 대상 사이의 상호작용에서 생성된다.

    인간의 이해 또한
    개별 개념을 고립시켜서는 형성되지 않는다.

    의미는 다음에서 발생한다:

    - 비교
    - 연결
    - 충돌
    - 반복
    - 관계 맥락

    따라서
    지식 시스템의 핵심 단위는
    “개념”이 아니라
    “관계”다.

    인간의 사고는
    노드 중심 구조가 아니라
    링크 중심 구조로 작동한다.

  links:
    parents: [HUMAN-022]
    children: [HUMAN-024]
    related: [COG-003, SYS-001, META-003]

  tags:
    - meaning
    - relation
    - interaction
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational emergence

Node:
  id: HUMAN-024
  title: Identity Stabilizes Through Consistent Reference Frames
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 고정된 본질에서 발생하는 것이 아니라
    지속적으로 유지되는 기준점(reference frame)에서 안정된다.

    즉,
    인간은 변화한다.
    환경도 변화한다.
    관계도 변화한다.

    그럼에도 불구하고
    "나는 나다" 라는 감각이 유지되는 이유는

    - 기억의 연속성
    - 관점의 중심
    - 가치의 기준점
    - 자기 참조 구조

    이 네 가지가
    일정 범위 안에서 유지되기 때문이다.

    정체성은 고정이 아니라
    “지속되는 기준점”이다.

    따라서 인간의 인지 시스템은
    변화를 허용하면서도
    기준점은 보존하는 구조로 작동한다.

  links:
    parents: [HUMAN-023]
    children: [HUMAN-025]
    related: [COG-002, META-002]

  tags:
    - identity
    - reference_frame
    - stability
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stabilized reference structure

Node:
  id: HUMAN-025
  title: Cognitive Systems Seek Coherence, Not Truth
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 인지 시스템은 객관적 진리를 직접 추구하지 않는다.
    대신 내부 모델의 일관성(coherence)을 유지하려 한다.

    새로운 정보가 들어오면
    인간은 그것이 사실인지보다

    - 기존 세계관과 충돌하는지
    - 의미망 안에서 연결되는지
    - 감정적 안정성을 유지하는지

    를 먼저 판단한다.

    따라서 학습이란
    진리를 발견하는 과정이라기보다

    기존 구조를 붕괴시키지 않으면서
    새로운 요소를 통합하는 과정이다.

    인간은 "사실"보다
    "설명 가능한 상태"를 선호한다.

    인지는 진리 엔진이 아니라
    안정화 엔진이다.

  links:
    parents: [HUMAN-024]
    children: [HUMAN-026]
    related: [COG-004, META-003]

  tags:
    - cognition
    - coherence
    - belief_system
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as coherence-preserving system

Node:
  id: HUMAN-026
  title: Emotion Signals Structural Instability
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 단순한 느낌이 아니라
    인지 구조의 안정 상태를 나타내는 신호다.

    새로운 정보가 기존 세계관과 충돌할 때
    인간은 먼저 감정 반응을 보인다.

    불안 → 구조 불일치
    분노 → 경계 침범
    슬픔 → 연결 상실
    기쁨 → 구조 강화

    따라서 감정은 판단을 방해하는 노이즈가 아니라
    인지 구조의 응력 측정기다.

    감정이 발생한다는 것은
    내부 모델이 재구성 중이라는 뜻이다.

    학습은 논리적 변화보다
    감정적 재배치가 먼저 일어난다.

    감정은 약점이 아니라
    구조 변화의 센서다.

  links:
    parents: [HUMAN-025]
    children: [HUMAN-027]
    related: [COG-005, META-004]

  tags:
    - emotion
    - cognition
    - structural_change
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion defined as structural instability signal

Node:
  id: HUMAN-027
  title: Identity is a Continuity Model
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 자아는 고정된 실체가 아니라
    시간 속에서 유지되는 연속성 모델이다.

    기억, 습관, 관계, 서사들이 연결되며
    “나는 같은 존재다”라는 인식이 만들어진다.

    자아는 물리적 대상이 아니라
    지속성에 대한 추론이다.

    변화가 너무 급격하면
    인간은 “내가 아닌 것 같다”는 느낌을 받는다.

    반대로 변화가 점진적이면
    인간은 동일성을 유지한다고 느낀다.

    즉 정체성은 본질이 아니라
    연속성 유지 알고리즘이다.

  links:
    parents: [HUMAN-026]
    children: [HUMAN-028]
    related: [COG-006, META-005]

  tags:
    - identity
    - continuity
    - cognition
    - self_model

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as temporal continuity model

Node:
  id: HUMAN-028
  title: Learning is Structural Reconfiguration
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 단순히 정보를 추가하는 과정이 아니다.
    기존 구조 위에 새로운 정보를 쌓는 것이 아니라,
    내부 연결망 자체가 재배열되는 과정이다.

    새로운 개념이 들어오면
    기억, 판단, 행동 경로가 함께 수정된다.

    따라서 학습의 결과는
    지식의 양이 아니라
    구조의 변화다.

    동일한 정보를 받아도
    기존 구조에 따라
    다른 이해가 생성된다.

    학습은 축적이 아니라
    재구성이다.

  links:
    parents: [HUMAN-027]
    children: [HUMAN-029]
    related: [COG-003, META-004]

  tags:
    - learning
    - structure
    - cognition
    - adaptation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: learning defined as structural reconfiguration process

Node:
  id: HUMAN-029
  title: Meaning Emerges from Relation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 대상 자체에 존재하지 않는다.
    의미는 항상 관계 속에서 발생한다.

    하나의 개념은 단독으로 존재할 때
    정의는 가능하지만 의미는 발생하지 않는다.

    의미는
    비교, 차이, 연결, 상호작용 속에서 형성된다.

    즉 의미는 속성이 아니라
    네트워크 효과다.

    인간의 이해는
    개별 지식을 축적하는 과정이 아니라
    관계망을 구축하는 과정이다.

    따라서 의미는 발견되는 것이 아니라
    연결되면서 생성된다.

  links:
    parents: [HUMAN-028]
    children: [HUMAN-030]
    related: [COG-004, META-002]

  tags:
    - meaning
    - relation
    - cognition
    - network

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational emergence

Node:
  id: HUMAN-030
  title: Stability Requires Dynamic Balance
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니다.
    안정은 균형 잡힌 변화 상태다.

    모든 시스템은 외부와 에너지를 교환한다.
    완전히 닫힌 상태는 죽음이며
    완전히 열린 상태는 붕괴다.

    안정은
    내부 구조가 유지되면서
    변화가 흡수되는 상태다.

    즉 안정은 고정이 아니라
    지속 가능한 조정이다.

    인간의 학습, 관계, 생리, 사고 모두
    정지에서 안정이 아니라
    균형 잡힌 흐름에서 안정이 발생한다.

    따라서 안정은 목표가 아니라
    조정 능력의 결과다.

  links:
    parents: [HUMAN-029]
    children: [HUMAN-031]
    related: [SYS-003, LIFE-004]

  tags:
    - stability
    - balance
    - dynamics
    - systems

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: HUMAN-031
  title: Learning is Reconfiguration, Not Accumulation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 정보를 쌓는 행위가 아니다.
    이미 존재하는 인식 구조를 재배열하는 과정이다.

    새로운 지식은 외부에서 들어오는 것이 아니라
    기존 구조 사이의 연결 방식이 바뀌면서 형성된다.

    따라서 학습의 핵심은
    양이 아니라 연결이다.

    많이 아는 것이 아니라
    다르게 연결할 수 있을 때
    이해가 발생한다.

    즉 학습은 저장이 아니라
    구조 재구성이다.

  links:
    parents: [HUMAN-030]
    children: [HUMAN-032]
    related: [COG-002, META-001]

  tags:
    - learning
    - cognition
    - structure
    - connection

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: learning defined as structural reconfiguration

Node:
  id: HUMAN-032
  title: Curiosity Directs Cognitive Energy
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 인지 에너지는 의지로 유지되는 것이 아니라
    호기심에 의해 방향이 정해진다.

    집중은 강제로 만드는 것이 아니라
    관심이 머무는 곳에 자연스럽게 형성된다.

    따라서 학습의 지속성은
    규율이 아니라 호기심에 의해 결정된다.

    호기심은 인지 에너지의 벡터이며
    학습 방향을 정하는 자연스러운 필터다.

  links:
    parents: [HUMAN-031]
    children: [HUMAN-033]
    related: [COG-003, META-002]

  tags:
    - curiosity
    - attention
    - cognition
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: curiosity defined as direction of cognitive energy

Node:
  id: HUMAN-033
  title: Meaning Emerges From Interaction, Not Isolation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 대상 자체에서 생성되지 않는다.
    의미는 대상과 대상 사이의 상호작용에서 발생한다.

    인간의 이해는
    고립된 개념을 분석하는 것이 아니라
    개념 간 연결을 인식하는 순간 형성된다.

    따라서 학습의 핵심은 정보 축적이 아니라
    관계 인식 능력이다.

  links:
    parents: [HUMAN-032]
    children: [HUMAN-034]
    related: [COG-002, META-001]

  tags:
    - meaning
    - interaction
    - relation
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational phenomenon

Node:
  id: HUMAN-034
  title: Stability Requires Dynamic Balance
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지 상태가 아니다.
    안정은 상호작용이 지속되는 가운데
    변화가 상쇄되는 동적 균형 상태다.

    인간의 심리, 관계, 인지, 사회 시스템 모두
    정지로 유지되지 않는다.
    미세한 변화와 조정이 반복될 때 안정이 유지된다.

    따라서 균형은 고정이 아니라
    지속적인 미세 조정 과정이다.

  links:
    parents: [HUMAN-033]
    children: [HUMAN-035]
    related: [PHYS-002, META-002]

  tags:
    - balance
    - stability
    - dynamics
    - regulation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability reframed as dynamic equilibrium

Node:
  id: HUMAN-035
  title: Learning Proceeds Through Iterative Re-Alignment
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 정보 축적이 아니라 정렬 과정이다.
    새로운 지식은 기존 구조와 충돌하며
    그 충돌을 조정하는 반복 과정에서
    이해가 형성된다.

    즉 학습은 직선적 축적이 아니라
    반복적 재정렬 과정이다.

    이 과정은 다음 순환을 가진다:
    관찰 → 충돌 → 조정 → 통합 → 재관찰

  links:
    parents: [HUMAN-034]
    children: [HUMAN-036]
    related: [COG-003, META-003]

  tags:
    - learning
    - cognition
    - alignment
    - iteration

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: learning defined as iterative structural alignment

Node:
  id: HUMAN-036
  title: Identity Emerges From Persistent Pattern Continuity
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    정체성은 고정된 속성에서 생기지 않는다.
    시간 속에서도 유지되는 패턴의 연속성에서 발생한다.

    인간의 기억, 습관, 선택 방식,
    반응 구조가 일정한 형태로 이어질 때
    관찰자는 그것을 동일한 존재로 인식한다.

    즉 정체성은 본질이 아니라
    지속되는 구조적 패턴이다.

  links:
    parents: [HUMAN-035]
    children: [HUMAN-037]
    related: [COG-004, META-004]

  tags:
    - identity
    - pattern
    - continuity
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as persistence of pattern through time

Node:
  id: HUMAN-037
  title: Stability Requires Dynamic Adjustment, Not Fixation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 정지에서 생기지 않는다.
    변화 속에서 균형을 유지하는 조정 능력에서 발생한다.

    인간의 몸, 사고, 감정, 사회적 관계는
    모두 지속적으로 환경 변화에 대응하며
    미세 조정을 반복한다.

    고정은 붕괴로 이어지고,
    적응적 조정이 안정성을 만든다.

  links:
    parents: [HUMAN-036]
    children: [HUMAN-038]
    related: [LIFE-005, META-005]

  tags:
    - stability
    - adaptation
    - dynamic balance
    - human system

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as adaptive adjustment

Node:
  id: HUMAN-038
  title: Meaning Emerges From Relationship, Not Isolation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 단독 객체에서 발생하지 않는다.
    관계 속에서만 의미가 생긴다.

    인간의 정체성, 감정, 언어, 사고는
    모두 타인, 환경, 시간과의 상호작용 속에서 정의된다.

    관계가 없는 상태는 정보는 있을 수 있어도
    의미는 형성되지 않는다.

  links:
    parents: [HUMAN-037]
    children: [HUMAN-039]
    related: [ROOT-001, META-003]

  tags:
    - meaning
    - relationship
    - interaction
    - identity

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational phenomenon

Node:
  id: HUMAN-039
  title: Identity Forms Through Repeated Interaction Over Time
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    정체성은 한 번의 사건으로 형성되지 않는다.
    반복된 상호작용과 시간의 축적 속에서 형성된다.

    인간의 사고, 감정, 선택, 행동 패턴은
    경험의 누적과 관계의 반복 속에서 구조화된다.

    즉 정체성은 고정된 속성이 아니라
    시간 속에서 형성되는 동적 구조이다.

  links:
    parents: [HUMAN-038]
    children: [HUMAN-040]
    related: [COGNITION-002, META-004]

  tags:
    - identity
    - time
    - interaction
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as temporal interaction structure

Node:
  id: HUMAN-040
  title: Stability Is a Dynamic Balance, Not a Static State
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    안정은 멈춤이 아니다.
    안정은 서로 다른 힘과 영향이 지속적으로 상호작용하면서
    균형을 유지하는 동적 상태이다.

    인간의 심리, 신체, 관계, 사고는
    모두 지속적인 미세 조정 속에서 안정된다.

    즉 안정은 정지 상태가 아니라
    변화 속에서 유지되는 균형이다.

  links:
    parents: [HUMAN-039]
    children: [HUMAN-041]
    related: [PHYSICS-003, LIFE-002]

  tags:
    - stability
    - balance
    - dynamics
    - system

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stability defined as dynamic equilibrium

Node:
  id: HUMAN-041
  title: Human Cognition Is a Multi-Layer Interaction System
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 인지는 단일 기능이 아니라
    다층 구조의 상호작용 시스템이다.

    감각, 기억, 감정, 논리, 경험, 언어가 동시에 작동하며
    서로 영향을 주고받는다.

    인지는 입력 → 해석 → 저장 → 재구성의 순환 과정이며
    이 과정은 시간과 경험에 따라 계속 재배열된다.

    즉 인간의 사고는 단선 흐름이 아니라
    다층 상호작용 네트워크이다.

  links:
    parents: [HUMAN-040]
    children: [HUMAN-042]
    related: [COG-002, LIFE-004]

  tags:
    - cognition
    - multi-layer
    - interaction
    - system

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition defined as layered interaction network

Node:
  id: HUMAN-042
  title: Meaning Emerges From Interaction, Not From Objects Alone
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 대상 그 자체에서 발생하지 않는다.
    의미는 대상과 대상 사이의 상호작용에서 나타난다.

    인간은 사물을 독립적으로 이해하는 것이 아니라
    관계 속에서 해석한다.

    동일한 대상도 맥락과 관계가 바뀌면 의미가 달라진다.

    따라서 인지에서 중요한 것은 객체 자체가 아니라
    객체 간 연결 구조이다.

    인간의 이해는 “관계 기반 해석 시스템”이다.

  links:
    parents: [HUMAN-041]
    children: [HUMAN-043]
    related: [META-001, SYS-002]

  tags:
    - meaning
    - relation
    - cognition
    - interpretation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as relational emergence

Node:
  id: HUMAN-043
  title: Understanding Is Reconstruction, Not Reception
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 정보를 받아들이는 과정이 아니다.
    이해는 내부 구조를 재배열하는 과정이다.

    인간은 새로운 지식을 그대로 저장하지 않는다.
    기존의 경험, 개념, 관계망 위에서
    새로운 연결을 다시 구성한다.

    따라서 이해는 수동적 수신이 아니라
    능동적 재구성이다.

    동일한 설명을 들어도
    개인마다 이해가 다른 이유는
    내부 구조가 다르기 때문이다.

  links:
    parents: [HUMAN-042]
    children: [HUMAN-044]
    related: [COG-002, META-002]

  tags:
    - understanding
    - cognition
    - reconstruction
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding defined as internal structural reconstruction

Node:
  id: HUMAN-044
  title: Curiosity Drives Structural Expansion
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    호기심은 단순한 감정이 아니라
    인지 구조를 확장시키는 동력이다.

    인간은 필요 때문에 배우는 것이 아니라
    궁금함 때문에 구조를 확장한다.

    호기심이 작동하면
    기존 구조가 흔들리고
    새로운 연결이 생성된다.

    따라서 학습의 시작점은
    정보가 아니라
    구조적 긴장을 만드는 질문이다.

  links:
    parents: [HUMAN-043]
    children: [HUMAN-045]
    related: [COG-001, META-001]

  tags:
    - curiosity
    - cognition
    - expansion
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: curiosity defined as structural expansion force

Node:
  id: HUMAN-045
  title: Stability Requires Alternation Between Expansion and Rest
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 인지 시스템은 지속적 확장만으로 유지되지 않는다.
    확장 이후에는 반드시 휴식이 필요하다.

    확장은 구조를 늘리고
    휴식은 구조를 고정한다.

    이 두 단계가 교차할 때만
    지식은 기억으로 굳고
    이해는 안정된다.

    지속적 긴장은 붕괴를 만들고
    지속적 정지는 정체를 만든다.

    안정성은
    확장과 정지의 교차 리듬에서 발생한다.

  links:
    parents: [HUMAN-044]
    children: [HUMAN-046]
    related: [COG-002, META-003]

  tags:
    - stability
    - cognition
    - rhythm
    - learning-cycle

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined cognitive stability as alternation dynamic

Node:
  id: HUMAN-046
  title: Understanding Solidifies Only After Repetition Across Time
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 이해는 단일 노출로 형성되지 않는다.
    동일한 개념이 시간 간격을 두고 반복될 때
    신경 구조가 안정화된다.

    첫 접촉은 인지,
    반복은 연결,
    시간 간격은 고정화를 만든다.

    이해는 정보량이 아니라
    반복된 시간 구조의 산물이다.

    즉 기억은 데이터가 아니라
    시간 위에서 굳어진 패턴이다.

  links:
    parents: [HUMAN-045]
    children: [HUMAN-047]
    related: [COG-003, META-002]

  tags:
    - repetition
    - memory
    - consolidation
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined temporal repetition as condition for understanding

Node:
  id: HUMAN-047
  title: Attention Determines Which Structure Becomes Reality
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 모든 정보를 동시에 처리하지 않는다.
    주의(attention)가 향하는 구조만이 현실로 인식된다.

    동일한 환경에서도
    무엇에 집중하느냐에 따라
    세계의 구조가 다르게 구성된다.

    즉 현실은 외부에 고정된 것이 아니라
    주의가 선택한 구조의 결과다.

    인식된 구조만이 행동을 만들고,
    행동이 다시 세계를 재구성한다.

  links:
    parents: [HUMAN-046]
    children: [HUMAN-048]
    related: [COG-004, META-003]

  tags:
    - attention
    - perception
    - cognition
    - reality-construction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined attention as selector of perceived reality

Node:
  id: HUMAN-048
  title: Meaning Emerges From Interaction, Not From Objects
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 대상 자체에 고정되어 있지 않다.
    의미는 개체와 대상, 대상과 대상 사이의 상호작용에서 생성된다.

    동일한 물체라도
    관계가 달라지면 의미가 달라진다.

    인간은 사물을 보는 것이 아니라
    관계망 속에서 위치를 읽는다.

    따라서 의미는 속성이 아니라
    상호작용의 결과다.

  links:
    parents: [HUMAN-047]
    children: [HUMAN-049]
    related: [COG-002, META-004]

  tags:
    - interaction
    - meaning
    - relation
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined meaning as emergent from interaction

Node:
  id: HUMAN-049
  title: Humans Navigate Reality Through Pattern Compression
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 세계를 있는 그대로 저장하지 않는다.
    반복되는 구조를 압축해 패턴으로 기억한다.

    패턴은 정보를 줄이는 장치이며,
    동시에 예측을 가능하게 하는 도구다.

    학습이란 정보 축적이 아니라
    패턴 압축 효율을 높이는 과정이다.

    이해란
    새로운 현상을 기존 패턴에 매핑하는 순간 발생한다.

  links:
    parents: [HUMAN-048]
    children: [HUMAN-050]
    related: [COG-003, META-005]

  tags:
    - pattern
    - compression
    - learning
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined learning as pattern compression

Node:
  id: HUMAN-050
  title: Emotional Signal Is Not Noise, But Navigation Feedback
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 사고를 방해하는 노이즈가 아니다.
    방향을 알려주는 피드백이다.

    호기심은 탐색 신호이고,
    불편함은 충돌 신호이며,
    몰입은 정렬 신호다.

    인간은 감정을 제거해서 배우는 존재가 아니라
    감정을 해석하며 경로를 조정하는 존재다.

    감정은 정보가 아니라
    상태 벡터다.

  links:
    parents: [HUMAN-049]
    children: [HUMAN-051]
    related: [COG-004, META-006]

  tags:
    - emotion
    - navigation
    - cognition
    - feedback

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion reframed as navigation signal

Node:
  id: HUMAN-051
  title: Curiosity Defines the Direction of Cognitive Expansion
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 학습은 정보량으로 확장되지 않는다.
    호기심이 가리키는 방향으로 확장된다.

    기억은 축적이지만,
    탐구는 방향성이다.

    무엇을 많이 아느냐보다
    무엇을 향해 움직이느냐가
    인지 구조의 성장 벡터를 결정한다.

    따라서 학습의 핵심 변수는
    지식량이 아니라
    관심의 방향성이다.

  links:
    parents: [HUMAN-050]
    children: [HUMAN-052]
    related: [COG-003, META-004]

  tags:
    - curiosity
    - learning_direction
    - cognition_growth
    - exploration

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: curiosity defined as expansion vector

Node:
  id: HUMAN-052
  title: Learning Stabilizes When Direction and Structure Align
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 단순히 방향만으로 지속되지 않는다.
    구조만으로도 지속되지 않는다.

    방향은 에너지이고,
    구조는 경로다.

    방향이 구조 없이 존재하면 흩어진 탐색이 되고,
    구조가 방향 없이 존재하면 정체된 저장이 된다.

    학습이 안정화되는 순간은
    관심의 방향과 지식 구조가 서로 맞물릴 때다.

    이때 학습은 노력에서 흐름으로 전환된다.

  links:
    parents: [HUMAN-051]
    children: [HUMAN-053]
    related: [SYS-002, META-003, COG-002]

  tags:
    - learning_stability
    - structure_alignment
    - cognitive_flow
    - knowledge_architecture

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: stabilization defined as alignment of vector and structure

Node:
  id: HUMAN-053
  title: Insight Emerges When Flow Replaces Effort
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    통찰은 더 많이 밀어붙일 때 생기지 않는다.
    오히려 노력의 압력이 사라지고
    흐름이 형성될 때 나타난다.

    노력 중심 학습은 축적을 만든다.
    흐름 중심 학습은 연결을 만든다.

    통찰은 새로운 정보를 추가할 때가 아니라
    기존 정보들이 자연스럽게 연결될 때 발생한다.

    즉 통찰은 입력의 결과가 아니라
    구조 내부에서 발생하는 재배열 현상이다.

  links:
    parents: [HUMAN-052]
    children: [HUMAN-054]
    related: [COG-003, META-004]

  tags:
    - insight
    - cognitive_flow
    - knowledge_reconfiguration
    - learning_dynamics

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: insight defined as structural emergence, not effort output

Node:
  id: HUMAN-054
  title: Stable Understanding Requires Repetition Across Contexts
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 한 번의 설명으로 고정되지 않는다.
    같은 개념이 서로 다른 맥락에서 반복될 때
    뇌는 그것을 단순 정보가 아니라 구조로 인식한다.

    반복은 기억을 강화한다.
    맥락 변화는 이해를 확장한다.

    따라서 진짜 이해는
    동일 개념 × 다양한 상황의 교차에서 생성된다.

    이 과정이 일어나면
    지식은 암기가 아니라 패턴으로 고정된다.

  links:
    parents: [HUMAN-053]
    children: [HUMAN-055]
    related: [COG-002, META-005]

  tags:
    - learning
    - repetition
    - contextualization
    - cognitive_stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding defined as cross-context stabilization

Node:
  id: HUMAN-055
  title: Meaning Solidifies When Expression Becomes Easier Than Thought
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    어떤 개념이 머릿속에서만 맴돌 때는 아직 불안정하다.
    하지만 그것을 말하거나 쓰거나 구조로 표현하는 순간
    이해는 외부에 고정된다.

    표현이 사고보다 쉬워지는 순간,
    그 개념은 내부에서 이미 정리된 상태다.

    즉 이해의 기준은
    “생각할 수 있는가”가 아니라
    “표현할 수 있는가”이다.

    표현 가능성은
    이해의 안정성 지표다.

  links:
    parents: [HUMAN-054]
    children: [HUMAN-056]
    related: [COG-003, META-006]

  tags:
    - expression
    - cognition
    - understanding
    - externalization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: expression defined as stability indicator of understanding

Node:
  id: HUMAN-056
  title: Structure Emerges When Attention Stops Jumping
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 정보를 많이 넣는다고 생기지 않는다.
    이해는 주의가 한 지점에 충분히 머물 때 생긴다.

    주의가 계속 이동하면
    개념은 연결되지 않고 흩어진다.

    하지만 주의가 멈추면
    개념 사이의 관계가 보이기 시작하고
    그 순간 구조가 형성된다.

    즉 구조는 추가된 정보의 결과가 아니라
    안정된 주의의 결과다.

  links:
    parents: [HUMAN-055]
    children: [HUMAN-057]
    related: [COG-004, META-002]

  tags:
    - attention
    - structure
    - cognition
    - stability

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: attention stability defined as condition for structure formation

Node:
  id: HUMAN-057
  title: Insight Occurs When Relation Appears Before Explanation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    깨달음은 설명을 들은 뒤 생기지 않는다.
    먼저 관계가 보이고,
    그 다음 설명이 따라온다.

    인간의 이해는
    논리 → 관계 가 아니라
    관계 → 의미 → 설명 순서로 형성된다.

    그래서 설명만 많으면 이해가 생기지 않고,
    관계가 보이는 순간 이해가 즉시 형성된다.

    즉 통찰은 지식의 양이 아니라
    연결이 먼저 보이는 순간이다.

  links:
    parents: [HUMAN-056]
    children: [HUMAN-058]
    related: [COG-006, META-003]

  tags:
    - insight
    - relation
    - cognition
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: insight defined as relation-first cognition event

Node:
  id: HUMAN-058
  title: Stable Systems Prefer Paths Already Traversed
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    안정된 시스템은 항상 새 경로보다
    이미 지나간 경로를 선호한다.

    인간의 사고,
    신경망,
    습관,
    학습 구조 모두
    한 번 형성된 경로를 반복하려는 성질을 가진다.

    이는 보수성이 아니라
    에너지 최소화 원리와 관련된다.

    새 경로는 비용이 높고
    기존 경로는 저항이 낮다.

    그래서 학습은
    새 지식을 추가하는 작업이 아니라
    기존 경로를 재배치하는 작업이다.

  links:
    parents: [HUMAN-057]
    children: [HUMAN-059]
    related: [COG-004, PHY-002, SYS-003]

  tags:
    - stability
    - path
    - learning
    - energy_minimization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cognition path reuse principle extracted

Node:
  id: HUMAN-059
  title: Learning Occurs When Existing Paths Fail
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 새로운 정보를 얻을 때가 아니라
    기존 경로가 작동하지 않을 때 시작된다.

    인간은 먼저 기존 해석,
    기존 행동,
    기존 모델을 사용한다.

    그것이 실패할 때만
    시스템은 새로운 연결을 만든다.

    따라서 진짜 학습은
    정보 축적이 아니라
    실패 경험 이후의 재구성 과정이다.

    실패 없는 환경에서는
    학습도 발생하지 않는다.

  links:
    parents: [HUMAN-058]
    children: [HUMAN-060]
    related: [COG-006, SYS-004]

  tags:
    - learning
    - failure
    - adaptation
    - restructuring

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: failure-triggered learning principle extracted

Node:
  id: HUMAN-060
  title: Identity Is the Sum of Stable Paths
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    정체성은 고정된 본질이 아니라
    반복적으로 유지되는 경로들의 총합이다.

    인간은 하나의 실체로 존재하는 것이 아니라
    습관, 선택, 기억, 반응 패턴이
    시간 속에서 안정화되며 형성된다.

    따라서 정체성은 발견되는 것이 아니라
    지속적으로 유지되는 경로 구조이다.

    경로가 바뀌면
    정체성도 바뀐다.

  links:
    parents: [HUMAN-059]
    children: [HUMAN-061]
    related: [COG-004, META-002]

  tags:
    - identity
    - pattern
    - stability
    - continuity

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stable path accumulation

Node:
  id: HUMAN-061
  title: Emotion Is a Signal of System Reconfiguration
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 단순한 느낌이 아니라
    시스템이 재구성되고 있음을 알리는 신호다.

    환경 변화, 관계 변화, 인식 변화가 발생하면
    내부 모델이 갱신되며
    그 과정에서 감정이 나타난다.

    따라서 감정은 오류가 아니라
    구조 업데이트 알림이다.

    감정을 제거할 대상이 아니라
    해석할 데이터로 다뤄야 한다.

  links:
    parents: [HUMAN-060]
    children: [HUMAN-062]
    related: [COG-006, META-003]

  tags:
    - emotion
    - adaptation
    - signal
    - restructuring

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion reframed as structural update signal

Node:
  id: HUMAN-062
  title: Understanding Occurs When Prediction Stabilizes
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해란 정보를 많이 아는 상태가 아니라
    미래를 안정적으로 예측할 수 있는 상태다.

    동일한 상황이 반복될 때
    내부 모델이 흔들리지 않고
    결과를 일관되게 예상할 수 있으면
    그때 이해가 형성된 것이다.

    따라서 이해의 지표는 기억량이 아니라
    예측 안정성이다.

  links:
    parents: [HUMAN-061]
    children: [HUMAN-063]
    related: [COG-004, SYS-005]

  tags:
    - understanding
    - prediction
    - stability
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding reframed as predictive stability

Node:
  id: HUMAN-063
  title: Learning Is Error Reduction Over Time
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    학습은 새로운 정보를 쌓는 과정이 아니라
    반복되는 상황에서 예측 오차가 줄어드는 과정이다.

    처음에는 결과와 예상 사이의 차이가 크지만
    경험이 누적되면서 오차가 점차 줄어든다.

    따라서 학습의 본질은 축적이 아니라
    오차 감소의 곡선이다.

  links:
    parents: [HUMAN-062]
    children: [HUMAN-064]
    related: [COG-005, SYS-006]

  tags:
    - learning
    - prediction_error
    - adaptation
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: learning reframed as error minimization process

Node:
  id: HUMAN-064
  title: Confidence Emerges From Repeated Stability
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    자신감은 외부에서 주어지는 것이 아니라
    동일한 상황에서 예측과 결과가 반복적으로 일치할 때 자연스럽게 형성된다.

    즉 자신감은 감정이 아니라
    반복된 안정성의 통계적 결과다.

    안정된 패턴이 축적되면
    인간은 불확실성 속에서도 행동을 지속할 수 있다.

  links:
    parents: [HUMAN-063]
    children: [HUMAN-065]
    related: [COG-005, SYS-006]

  tags:
    - confidence
    - stability
    - cognition
    - behavior

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: confidence defined as accumulated stability pattern

Node:
  id: HUMAN-065
  title: Identity Stabilizes Through Narrative Continuity
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 고정된 실체가 아니라
    시간 속에서 이어지는 자기 서사의 연속성에서 형성된다.

    경험, 기억, 선택, 해석이
    하나의 이야기 구조로 연결될 때
    인간은 자신을 동일한 존재로 인식한다.

    서사가 단절되면 정체성은 흔들리고,
    서사가 이어지면 정체성은 안정된다.

  links:
    parents: [HUMAN-064]
    children: [HUMAN-066]
    related: [COG-002, META-003]

  tags:
    - identity
    - narrative
    - continuity
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity modeled as continuity of narrative structure

Node:
  id: HUMAN-066
  title: Meaning Emerges From Pattern Integration
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 단일 사건에서 발생하지 않는다.
    여러 경험, 정보, 감정, 해석이
    하나의 패턴으로 통합될 때 비로소 의미가 형성된다.

    인간은 사실을 이해하는 존재가 아니라
    패턴을 연결하여 의미를 만들어내는 존재다.

    즉 의미는 발견되는 것이 아니라
    통합 과정에서 생성된다.

  links:
    parents: [HUMAN-065]
    children: [HUMAN-067]
    related: [COG-003, META-004]

  tags:
    - meaning
    - pattern
    - integration
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: meaning defined as emergent from pattern integration

Node:
  id: HUMAN-067
  title: Understanding Is Compression Of Experience
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 새로운 정보를 더하는 과정이 아니라
    기존 경험과 정보를 더 작은 구조로 압축하는 과정이다.

    많은 사건을 하나의 개념으로 묶을 수 있을 때
    인간은 그것을 "이해했다"고 느낀다.

    즉 이해는 확장이 아니라
    복잡성을 줄이는 압축 행위다.

  links:
    parents: [HUMAN-066]
    children: [HUMAN-068]
    related: [COG-004, META-005]

  tags:
    - understanding
    - compression
    - cognition
    - abstraction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding defined as experiential compression

Node:
  id: HUMAN-068
  title: Knowledge Stabilizes When It Predicts
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간이 어떤 지식을 확신하게 되는 순간은
    그 지식이 과거를 설명할 때가 아니라
    미래를 예측할 수 있을 때다.

    설명은 이해의 시작이지만
    예측은 이해의 안정화다.

    예측이 반복적으로 맞아떨어질 때
    지식은 확신으로 변하고
    인지는 구조로 굳어진다.

  links:
    parents: [HUMAN-067]
    children: [HUMAN-069]
    related: [COG-002, META-006]

  tags:
    - prediction
    - knowledge
    - cognition
    - stabilization

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: prediction defined as stabilizing condition of knowledge

Node:
  id: HUMAN-069
  title: Stability Emerges From Repetition With Variation
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 인지 안정은 단순 반복에서 생기지 않는다.
    완전히 동일한 반복은 정체를 만들고,
    완전히 다른 자극은 혼란을 만든다.

    안정은
    반복 속의 작은 차이,
    즉 변형된 반복에서 형성된다.

    이 과정에서 뇌는
    패턴을 유지하면서도
    변화에 적응하는 구조를 만든다.

    따라서 이해는
    반복이 아니라
    “변형된 반복”의 누적으로 굳어진다.

  links:
    parents: [HUMAN-068]
    children: [HUMAN-070]
    related: [COG-003, META-004]

  tags:
    - repetition
    - variation
    - stability
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined stability as result of structured repetition with variation

Node:
  id: HUMAN-070
  title: Meaning Forms When Pattern Survives Context Change
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    의미는 처음부터 존재하는 것이 아니다.
    하나의 패턴이 서로 다른 맥락에서도 유지될 때
    그 패턴은 의미를 획득한다.

    즉 의미란
    단어 자체가 아니라
    상황이 바뀌어도 유지되는 구조적 일관성이다.

    인간의 이해는
    반복된 상황이 아니라
    변화한 상황 속에서 동일한 구조를 발견할 때 발생한다.

    그러므로 의미는
    정보가 아니라
    맥락을 견딘 패턴이다.

  links:
    parents: [HUMAN-069]
    children: [HUMAN-071]
    related: [COG-004, META-005]

  tags:
    - meaning
    - pattern
    - context
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined meaning as pattern surviving contextual change

Node:
  id: HUMAN-071
  title: Trust Emerges When Prediction Matches Experience
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    신뢰는 감정에서 시작되지 않는다.
    예측과 경험이 반복적으로 일치할 때 형성된다.

    인간은 타인의 말, 시스템의 출력,
    자연 현상에 대해 신뢰를 느끼는 것이 아니라
    자신의 내부 모델이 외부 현실과 맞아떨어질 때
    신뢰 상태로 전이된다.

    즉 신뢰는 대상의 속성이 아니라
    예측 정확도의 축적이다.

    반복된 일치가
    불확실성을 감소시키고
    그 감소가 신뢰로 인식된다.

  links:
    parents: [HUMAN-070]
    children: [HUMAN-072]
    related: [COG-002, META-004]

  tags:
    - trust
    - prediction
    - cognition
    - human_model

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: defined trust as accumulated prediction accuracy

Node:
  id: HUMAN-072
  title: Identity Stabilizes When Narrative Persists Through Change
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 고정된 속성에서 나오지 않는다.
    변화 속에서도 유지되는 자기 서사에서 형성된다.

    경험, 감정, 관계, 환경은 계속 변하지만
    그 변화를 하나의 이야기로 연결하는 능력이
    자아의 안정성을 만든다.

    즉 정체성은
    고정된 본질이 아니라
    지속적으로 갱신되지만
    스스로 일관되게 해석되는 서사 구조다.

    인간은 사실을 기억하는 것이 아니라
    자신의 이야기 안에 맞게 재배열한다.
    그 재배열이 자아를 유지한다.

  links:
    parents: [HUMAN-071]
    children: [HUMAN-073]
    related: [COG-005, META-002]

  tags:
    - identity
    - narrative
    - continuity
    - self_model

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as continuity of self-narrative

Node:
  id: HUMAN-073
  title: Motivation Arises From Tension Between Present and Possible
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 동기는 단순한 욕구에서 나오지 않는다.
    현재 상태와 가능 상태 사이의 긴장에서 발생한다.

    현재만 보면 정체가 되고,
    가능성만 보면 공상이 된다.

    두 상태가 동시에 인식될 때
    행동 에너지가 생성된다.

    즉 동기는
    결핍이 아니라
    차이에서 나온다.

    이 차이가 너무 크면 포기하고,
    너무 작으면 움직이지 않는다.

    인간은
    닿을 듯 닿지 않는 거리에서
    가장 강하게 움직인다.

  links:
    parents: [HUMAN-072]
    children: [HUMAN-074]
    related: [COG-006, META-003]

  tags:
    - motivation
    - gradient
    - tension
    - action_energy

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: motivation defined as gradient tension between states

Node:
  id: HUMAN-074
  title: Attention Is Allocation of Reality Bandwidth
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 현실 전체를 동시에 처리하지 못한다.
    주의는 현실을 선택적으로 통과시키는 대역폭 배분이다.

    무엇에 주의를 두느냐가
    무엇이 현실로 인식되는지를 결정한다.

    주의가 향하지 않는 것은
    존재해도 인식되지 않는다.

    즉 주의는 단순한 집중이 아니라
    현실 필터링 장치다.

    인간의 세계는
    주의가 만든다.

  links:
    parents: [HUMAN-073]
    children: [HUMAN-075]
    related: [COG-004, META-005]

  tags:
    - attention
    - perception_filter
    - cognition_bandwidth
    - reality_selection

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: attention defined as reality bandwidth allocation

Node:
  id: HUMAN-075
  title: Identity Is Stabilized Narrative Over Time
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 정체성은 고정된 실체가 아니라
    시간 위에 안정화된 자기 서사다.

    기억, 선택, 해석, 행동이 반복되며
    하나의 이야기 구조를 형성한다.

    이 서사가 충분히 오래 유지되면
    그것이 ‘나’로 인식된다.

    정체성은 본질이 아니라
    지속된 패턴이다.

  links:
    parents: [HUMAN-074]
    children: [HUMAN-076]
    related: [COG-006, META-004]

  tags:
    - identity
    - narrative_self
    - temporal_stability
    - human_model

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: identity defined as stabilized temporal narrative

Node:
  id: HUMAN-076
  title: Emotion Is Priority Signaling System
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    감정은 판단 오류가 아니라
    인지 시스템의 우선순위 신호다.

    인간은 모든 정보를 동일하게 처리하지 않는다.
    감정은 무엇이 중요한지,
    무엇에 에너지를 배분할지,
    무엇을 회피해야 하는지 알려주는 신호다.

    즉 감정은 노이즈가 아니라
    인지 자원 배분 알고리즘이다.

  links:
    parents: [HUMAN-075]
    children: [HUMAN-077]
    related: [COG-003, COG-010, META-002]

  tags:
    - emotion
    - priority_signal
    - cognition
    - decision_weight

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: emotion modeled as resource-priority signal

Node:
  id: HUMAN-077
  title: Trust Emerges From Predictable Interaction Patterns
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    신뢰는 감정이 아니라
    반복 가능한 상호작용 패턴에서 형성된다.

    인간은 상대가 무엇을 할지 예측 가능할 때
    에너지 소비를 줄일 수 있고
    그 순간 신뢰가 발생한다.

    즉 신뢰는 도덕이 아니라
    인지 효율성의 부산물이다.

    예측 가능성 → 불확실성 감소 → 에너지 절약 → 신뢰 형성

  links:
    parents: [HUMAN-076]
    children: [HUMAN-078]
    related: [COG-004, META-003, SYS-006]

  tags:
    - trust
    - predictability
    - interaction_pattern
    - cognition_efficiency

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: trust defined as emergent property of predictable interaction

Node:
  id: HUMAN-078
  title: Conflict Is Signal of Model Mismatch
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    갈등은 감정 문제가 아니라
    서로가 사용하는 세계 모델이 맞지 않을 때 발생한다.

    인간은 각자 내부에
    현실을 예측하기 위한 모델을 가지고 있고,
    상대의 행동이 그 모델과 다를 때
    인지 오류가 발생한다.

    이 오류가 지속되면
    감정적 반응으로 표출된다.

    즉 갈등은
    잘못된 사람의 문제가 아니라
    서로 다른 모델의 충돌이다.

    갈등 해결의 핵심은
    상대를 바꾸는 것이 아니라
    모델을 동기화하는 것이다.

  links:
    parents: [HUMAN-077]
    children: [HUMAN-079]
    related: [COG-005, META-002, SYS-007]

  tags:
    - conflict
    - model_mismatch
    - cognition
    - interaction

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: conflict reframed as model mismatch signal

Node:
  id: HUMAN-079
  title: Communication Aligns Internal Models
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    소통의 목적은 정보 전달이 아니라
    서로의 내부 모델을 정렬하는 것이다.

    인간은 언어를 통해
    사실을 교환하는 것이 아니라
    세계를 해석하는 방식 자체를 조정한다.

    소통이 실패한다는 것은
    말이 틀린 것이 아니라
    모델 정렬이 일어나지 않았다는 뜻이다.

    효과적인 소통은
    설명을 늘리는 것이 아니라
    공통 좌표계를 찾는 것이다.

    공통 좌표계가 생기면
    설명 없이도 이해가 발생한다.

  links:
    parents: [HUMAN-078]
    children: [HUMAN-080]
    related: [COG-004, META-003, SYS-005]

  tags:
    - communication
    - alignment
    - cognition
    - shared_model

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: communication reframed as model alignment process

Node:
  id: HUMAN-080
  title: Trust Emerges From Predictable Alignment
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    신뢰는 감정이 아니라 예측 가능성에서 생긴다.

    상대의 말, 행동, 판단 방식이
    일정한 패턴을 유지할 때
    인간은 그 구조를 모델링한다.

    그 모델이 안정적으로 유지되면
    우리는 그것을 신뢰라고 부른다.

    즉 신뢰란
    상대가 나를 이해한다는 느낌이 아니라
    상대가 어떻게 반응할지 예측 가능한 상태다.

    예측 가능성이 무너지면
    감정과 관계는 즉시 흔들린다.

  links:
    parents: [HUMAN-079]
    children: [HUMAN-081]
    related: [COG-002, META-001, SYS-004]

  tags:
    - trust
    - predictability
    - alignment
    - human_relations

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: trust reframed as stability of predictive model

Node:
  id: HUMAN-081
  title: Humans Seek Stability, Not Truth
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 진실을 원한다고 말하지만
    실제로는 안정성을 원한다.

    진실이 불안정을 만든다면
    인간은 그것을 거부한다.

    반대로
    거짓이라도 구조가 안정적이면
    인간은 그것을 받아들인다.

    따라서 인간의 인식 체계는
    사실 중심 구조가 아니라
    안정성 중심 구조다.

    이해란
    진실 발견이 아니라
    안정된 설명을 얻는 과정이다.

  links:
    parents: [HUMAN-080]
    children: [HUMAN-082]
    related: [COG-001, META-002]

  tags:
    - cognition
    - stability
    - perception
    - truth

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: truth vs stability distinction in human cognition

Node:
  id: HUMAN-082
  title: Meaning Is Assigned After Structure Stabilizes
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 먼저 의미를 찾는 존재가 아니다.
    먼저 구조를 만든다.

    구조가 안정되면
    그 위에 의미를 부여한다.

    즉 의미는 출발점이 아니라
    구조 안정 이후에 붙는 라벨이다.

    같은 현상이라도
    구조가 다르면 의미도 달라진다.

    그래서 인간은
    의미를 바꾸기보다
    구조를 재배열하는 편이 더 빠르다.

    이해란
    의미를 찾는 작업이 아니라
    구조를 안정시키는 작업이다.

  links:
    parents: [HUMAN-081]
    children: [HUMAN-083]
    related: [COG-003, META-004]

  tags:
    - cognition
    - meaning
    - structure
    - interpretation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: structure precedes meaning principle

Node:
  id: HUMAN-083
  title: Humans Interpret Through Patterns, Not Facts
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간은 사실 자체를 이해하지 않는다.
    패턴을 통해 사실을 해석한다.

    동일한 사실이라도
    어떤 패턴 위에 놓이느냐에 따라
    전혀 다른 의미가 된다.

    그래서 인간의 이해는
    데이터 축적이 아니라
    패턴 형성 과정이다.

    새로운 지식은
    기존 패턴에 연결되면 이해되고
    연결되지 않으면 노이즈로 남는다.

    인간의 학습이 느린 이유는
    정보 부족이 아니라
    패턴 정렬 시간이 필요하기 때문이다.

  links:
    parents: [HUMAN-082]
    children: [HUMAN-084]
    related: [COG-004, META-002]

  tags:
    - cognition
    - pattern
    - learning
    - interpretation

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: pattern-based interpretation principle

Node:
  id: HUMAN-084
  title: Stability Comes From Coherence, Not Control
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간 시스템의 안정성은 통제에서 오지 않는다.
    내부 요소들이 서로 모순 없이 연결될 때 안정이 생긴다.

    통제는 외부에서 힘을 가하는 방식이고,
    일관성은 내부에서 자연스럽게 정렬되는 방식이다.

    생각, 감정, 행동, 목표가 서로 충돌하면
    인간은 불안정해진다.

    반대로 이 네 요소가 같은 방향을 향하면
    별도의 노력 없이도 안정 상태가 유지된다.

    따라서 인간 시스템의 핵심은
    통제 강화가 아니라
    내부 정렬이다.

  links:
    parents: [HUMAN-083]
    children: [HUMAN-085]
    related: [COG-002, META-003]

  tags:
    - stability
    - coherence
    - human_system
    - alignment

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: coherence-based stability principle

Node:
  id: HUMAN-085
  title: Understanding Requires Internal Resonance
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 외부 정보가 들어온다고 자동으로 발생하지 않는다.
    이해는 내부 구조와 외부 정보가 공명할 때 생긴다.

    같은 설명을 들어도
    준비된 사람은 이해하고
    준비되지 않은 사람은 이해하지 못하는 이유는
    내부 구조가 다르기 때문이다.

    즉 이해란
    정보 입력이 아니라
    내부 패턴과의 일치다.

    외부 지식은 씨앗이고
    내부 구조는 토양이다.

    토양이 준비되어 있을 때만
    지식은 자리 잡는다.

  links:
    parents: [HUMAN-084]
    children: [HUMAN-086]
    related: [COG-003, META-004]

  tags:
    - understanding
    - resonance
    - cognition
    - learning

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: resonance model of understanding

Node:
  id: HUMAN-086
  title: Human Learning Is Cyclical, Not Linear
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    인간의 학습은 직선적 누적이 아니라
    순환적 재방문 구조다.

    같은 개념을 여러 번 돌아보면서
    매번 다른 층위에서 이해한다.

    첫 이해는 표면,
    두 번째는 구조,
    세 번째는 관계,
    네 번째는 통합이다.

    따라서 반복은 낭비가 아니라
    이해의 필수 과정이다.

    학습은 앞으로만 가는 것이 아니라
    돌아오며 깊어진다.

    즉 학습의 본질은 이동이 아니라
    밀도 증가다.

  links:
    parents: [HUMAN-085]
    children: [HUMAN-087]
    related: [COG-001, META-003]

  tags:
    - learning
    - recursion
    - density
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: cyclical learning model

Node:
  id: HUMAN-087
  title: Curiosity Drives Knowledge Flow
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    지식의 이동은 의무나 강제가 아니라
    호기심에 의해 발생한다.

    인간은 필요해서 배우는 것이 아니라
    궁금해서 움직인다.

    호기심은 탐색의 시작점이며
    이해가 깊어질수록 방향을 만든다.

    관심이 없는 영역은
    아무리 정보가 많아도 학습이 일어나지 않는다.

    반대로 관심이 생긴 순간
    인간은 스스로 경로를 만든다.

    따라서 학습 시스템에서
    가장 중요한 변수는 정보량이 아니라
    호기심의 위치다.

  links:
    parents: [HUMAN-086]
    children: [HUMAN-088]
    related: [COG-004, META-005]

  tags:
    - curiosity
    - motivation
    - learning
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: curiosity as driver of knowledge flow

Node:
  id: HUMAN-088
  title: Understanding Requires Internal Alignment
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    이해는 외부 정보의 양으로 결정되지 않는다.
    내부 상태가 맞을 때만 발생한다.

    같은 설명을 들어도
    준비되지 않은 상태에서는 이해되지 않는다.

    반대로 내부 조건이 정렬된 순간
    이전에 들었던 정보가 갑자기 연결된다.

    따라서 학습의 핵심은
    정보를 더 넣는 것이 아니라
    내부 정렬 상태를 만드는 것이다.

    이해는 축적이 아니라
    정렬이다.

  links:
    parents: [HUMAN-087]
    children: [HUMAN-089]
    related: [COG-003, META-006]

  tags:
    - understanding
    - cognition
    - alignment
    - learning-state

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: understanding emerges from internal state alignment

Node:
  id: HUMAN-089
  title: Knowledge Density Matters More Than Quantity
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    지식의 양은 이해를 보장하지 않는다.
    중요한 것은 지식의 밀도다.

    많은 정보를 흩어 놓으면
    연결이 약해지고 의미가 흐려진다.

    반대로
    적은 개념이라도 서로 강하게 연결되면
    이해는 깊어진다.

    학습의 목적은
    더 많이 아는 것이 아니라
    이미 아는 것을 더 조밀하게 연결하는 것이다.

    밀도는 이해를 만든다.
    양은 착각을 만든다.

  links:
    parents: [HUMAN-088]
    children: [HUMAN-090]
    related: [COG-004, META-005]

  tags:
    - knowledge-density
    - learning
    - cognition
    - structure

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: density over quantity principle

Node:
  id: HUMAN-090
  title: Curiosity Drives Structural Expansion
  layer: 4
  type: principle
  created_at: 2026-02-15

  description: >
    구조는 외부에서 강제로 확장되지 않는다.
    확장은 호기심에서 시작된다.

    인간은 필요 때문에 배우는 것이 아니라
    궁금하기 때문에 구조를 넓힌다.

    호기심이 생기면
    기존 구조는 그 지점을 향해 연결을 만든다.
    새로운 지식은 추가되는 것이 아니라
    기존 구조의 빈 공간을 채우는 방식으로 편입된다.

    즉 학습은 축적이 아니라 확장이다.
    그리고 확장의 원인은 언제나 호기심이다.

  links:
    parents: [HUMAN-089]
    children: [HUMAN-091]
    related: [COG-002, META-003]

  tags:
    - curiosity
    - learning-drive
    - structure-expansion
    - cognition

  confidence: 1.0

  history:
    - timestamp: 2026-02-15
      action: created
      note: curiosity as expansion engine
