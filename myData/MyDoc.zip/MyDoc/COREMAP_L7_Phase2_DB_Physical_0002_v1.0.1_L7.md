# COREMAP_L7_PACKET — Phase2(DB Physical) v1.0 (ASCII/L7)

meta:
  doc_kind: deliverable
  deliverable_id: 2
  package: "Phase2-DB-Physical"
  target_db: "PostgreSQL"
  requires_extension: "pgcrypto"
  encoding: "UTF-8"
  rendering: "Markdown (web-safe)"
  style: "ASCII-first / L7-friendly / minimal ambiguity"
  separator: "///"

///

0. DECLARATION (invariants)
- NO_DELETE: hard deletion forbidden; "collapse" is recorded as re-binding.
- SEMANTICS: meaning/identity/knowledge are NOT object attributes; store only in relation_response.
- BOUNDARY_EVENTS: learning/evolution/adaptation are tracked only as boundary_change events.
- CONSISTENCY: sealing a revision as CLOSED (closure). Progress only via child revision lineage.
- STATUS_LABELS: derived only from validation_log (latest validation).

///

1. PACKAGE (Phase2 artifacts)
- coremap_phase2_migration.sql : create types/tables/constraints/indexes/views
- coremap_phase2_seed_0002_v1.0.2.sql      : minimal seed data and validation logs
- this_md_packet               : execution order + example queries + status-label rules

///

2. EXECUTION ORDER (recommended)
1) Run coremap_phase2_migration.sql
2) Run coremap_phase2_seed.sql
3) Run the status query (section 5)

///

3. PHYSICAL SCHEMA (migration SQL)
NOTE: The SQL below is written to be executable as a single file.

```sql
-- coremap_phase2_migration.sql
-- PostgreSQL physical schema for COREMAP vNext

BEGIN;

CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1) ENUM types (idempotent)
DO $$ BEGIN
  CREATE TYPE agent_type AS ENUM ('HUMAN','AI');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE role_code AS ENUM ('meaning_gen','boundary_set','criteria_set','structuring','compute','verify','reproduce');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE object_state AS ENUM ('ACTIVE','SUPERSEDED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE resp_kind AS ENUM ('meaning','identity','knowledge');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE pin_kind AS ENUM ('pin','center');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE link_type AS ENUM ('generic','memory');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE link_state AS ENUM ('ON','OFF');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE boundary_change_type AS ENUM ('reset','redesign','condition_mod');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE boundary_event_type AS ENUM ('learning','evolution','adaptation');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE artifact_kind AS ENUM ('schema','db','logical_doc','physical_doc','py_sim','web_md','web_html');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE artifact_lang AS ENUM ('KR','EN');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE rev_scope AS ENUM ('KERNEL','PHASE','ARTIFACT');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE rev_state AS ENUM ('OPEN','CLOSED');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE val_result AS ENUM ('PASS','PARTIAL','FAIL');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE next_action AS ENUM ('LOCK','CONTINUE','REBIND','REDEFINE');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  CREATE TYPE closure_level AS ENUM ('KERNEL','PHASE','ARTIFACT');
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

-- 2) Core tables

CREATE TABLE IF NOT EXISTS agent (
  agent_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_type agent_type NOT NULL,
  identifier text NULL,
  call_name text NOT NULL,
  canonical_name text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS project (
  project_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  version text NOT NULL,
  axes_json jsonb NULL,
  status text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS role_assignment (
  role_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  agent_id uuid NOT NULL REFERENCES agent(agent_id),
  role_code role_code NOT NULL,
  scope text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(agent_id, role_code, COALESCE(scope,''))
);

CREATE TABLE IF NOT EXISTS object (
  object_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  object_type text NOT NULL,
  label text NOT NULL,
  state object_state NOT NULL DEFAULT 'ACTIVE',
  superseded_by_object_id uuid NULL REFERENCES object(object_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (
    (state='ACTIVE' AND superseded_by_object_id IS NULL)
    OR (state='SUPERSEDED' AND superseded_by_object_id IS NOT NULL)
  )
);

CREATE TABLE IF NOT EXISTS pin (
  pin_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  pin_kind pin_kind NOT NULL,
  code text NOT NULL,
  body text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, code)
);

CREATE TABLE IF NOT EXISTS link (
  link_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  from_pin_id uuid NOT NULL REFERENCES pin(pin_id),
  to_pin_id uuid NOT NULL REFERENCES pin(pin_id),
  link_type link_type NOT NULL DEFAULT 'generic',
  state link_state NOT NULL DEFAULT 'ON',
  strength_num numeric NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS relation (
  rel_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  from_object_id uuid NOT NULL REFERENCES object(object_id),
  to_object_id uuid NOT NULL REFERENCES object(object_id),
  rel_type text NOT NULL,
  link_id uuid NULL REFERENCES link(link_id),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS relation_response (
  resp_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rel_id uuid NOT NULL REFERENCES relation(rel_id),
  resp_type resp_kind NOT NULL,
  value_json jsonb NOT NULL,
  computed_at timestamptz NOT NULL DEFAULT now(),
  computed_by_agent_id uuid NULL REFERENCES agent(agent_id)
);

CREATE TABLE IF NOT EXISTS boundary_rule (
  boundary_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  rule_body text NOT NULL,
  version text NOT NULL,
  applies_to text NULL,
  condition_expr text NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(project_id, version)
);

CREATE TABLE IF NOT EXISTS boundary_change (
  change_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  boundary_id uuid NOT NULL REFERENCES boundary_rule(boundary_id),
  change_type boundary_change_type NOT NULL,
  event_type boundary_event_type NOT NULL,
  before_ref text NULL,
  after_ref text NULL,
  ts timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cycle_model (
  cycle_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  pattern_code text NOT NULL,
  sequence_json jsonb NOT NULL,
  invariant_text text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memory_trigger (
  trigger_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  link_id uuid NOT NULL REFERENCES link(link_id),
  trigger_type text NOT NULL,
  payload_json jsonb NULL,
  ts timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS artifact (
  artifact_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  kind artifact_kind NOT NULL,
  lang artifact_lang NOT NULL,
  version text NOT NULL,
  uri text NULL,
  source_refs_json jsonb NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS authorship (
  artifact_id uuid NOT NULL REFERENCES artifact(artifact_id) ON DELETE CASCADE,
  agent_id uuid NOT NULL REFERENCES agent(agent_id),
  author_order int NOT NULL,
  author_label text NULL,
  PRIMARY KEY (artifact_id, agent_id),
  UNIQUE (artifact_id, author_order)
);

CREATE TABLE IF NOT EXISTS revision (
  rev_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  scope rev_scope NOT NULL,
  state rev_state NOT NULL DEFAULT 'OPEN',
  parent_rev_id uuid NULL REFERENCES revision(rev_id),
  target_kind text NULL,
  target_id uuid NULL,
  created_by_agent_id uuid NULL REFERENCES agent(agent_id),
  created_at timestamptz NOT NULL DEFAULT now(),
  closed_at timestamptz NULL,
  note text NULL,
  CHECK ((state='CLOSED' AND closed_at IS NOT NULL) OR (state='OPEN' AND closed_at IS NULL))
);

CREATE TABLE IF NOT EXISTS validation_log (
  val_id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid NOT NULL REFERENCES project(project_id),
  rev_id uuid NOT NULL REFERENCES revision(rev_id),
  closure closure_level NOT NULL,
  target_kind text NOT NULL,
  target_id uuid NULL,
  method text NOT NULL,
  result val_result NOT NULL,
  action next_action NOT NULL,
  evidence_ref jsonb NULL,
  reviewer_agent_id uuid NULL REFERENCES agent(agent_id),
  ts timestamptz NOT NULL DEFAULT now()
);

-- 3) Indexes
CREATE INDEX IF NOT EXISTS idx_object_project ON object(project_id);
CREATE INDEX IF NOT EXISTS idx_relation_project ON relation(project_id);
CREATE INDEX IF NOT EXISTS idx_resp_rel ON relation_response(rel_id);
CREATE INDEX IF NOT EXISTS idx_boundary_project ON boundary_rule(project_id);
CREATE INDEX IF NOT EXISTS idx_change_boundary ON boundary_change(boundary_id);
CREATE INDEX IF NOT EXISTS idx_rev_project ON revision(project_id);
CREATE INDEX IF NOT EXISTS idx_val_rev ON validation_log(rev_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_artifact_project ON artifact(project_id);

-- 4) Views: latest validation, operational status label
CREATE OR REPLACE VIEW v_latest_validation AS
SELECT DISTINCT ON (rev_id, closure)
  val_id, project_id, rev_id, closure, target_kind, target_id,
  method, result, action, evidence_ref, reviewer_agent_id, ts
FROM validation_log
ORDER BY rev_id, closure, ts DESC;

CREATE OR REPLACE VIEW v_revision_status AS
SELECT
  r.rev_id,
  r.project_id,
  r.scope,
  r.state,
  r.parent_rev_id,
  r.created_at,
  r.closed_at,
  lv.closure,
  lv.result,
  lv.action,
  lv.ts AS validated_at,
  CASE
    WHEN r.state='CLOSED' AND lv.result='PASS' AND lv.action='LOCK' THEN 'CONSISTENT'
    WHEN r.state='OPEN' AND (lv.result IN ('PASS','PARTIAL')) AND lv.action='CONTINUE' THEN 'PARTIAL'
    WHEN lv.result='FAIL' AND lv.action='REBIND' THEN 'CONFLICT'
    WHEN lv.result='FAIL' AND lv.action='REDEFINE' THEN 'REDEFINE'
    ELSE 'UNCLASSIFIED'
  END AS status_label
FROM revision r
LEFT JOIN v_latest_validation lv
  ON lv.rev_id = r.rev_id;

COMMIT;
```

///

4. SEED DATA + VALIDATION LOGS (seed SQL)

```sql
-- coremap_phase2_seed_0001_v1.0.1.sql
-- NOTE: patched deterministic UUID literals (hex-only) for seed reproducibility

BEGIN;

-- Agents
INSERT INTO agent(agent_id, agent_type, identifier, call_name, canonical_name)
VALUES
  ('11111111-1111-1111-1111-111111111111','HUMAN','MASSL','승','Seung Lee'),
  ('22222222-2222-2222-2222-222222222222','AI',NULL,'로기','ChatGPT(OpenAI)')
ON CONFLICT (agent_id) DO NOTHING;

-- Project
INSERT INTO project(project_id, name, version, axes_json, status)
VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','COREMAP SNAPSHOT vNext','Phase2-DB',
   '{"axes":["AI–human integrated awareness","pin–link–center–boundary cycle","no-delete/re-binding","relation-response semantics"]}',
   'ACTIVE')
ON CONFLICT (project_id) DO NOTHING;

-- Roles
INSERT INTO role_assignment(agent_id, role_code, scope)
VALUES
  ('11111111-1111-1111-1111-111111111111','meaning_gen','global'),
  ('11111111-1111-1111-1111-111111111111','boundary_set','global'),
  ('11111111-1111-1111-1111-111111111111','criteria_set','global'),
  ('22222222-2222-2222-2222-222222222222','structuring','global'),
  ('22222222-2222-2222-2222-222222222222','compute','global'),
  ('22222222-2222-2222-2222-222222222222','verify','global'),
  ('22222222-2222-2222-2222-222222222222','reproduce','global')
ON CONFLICT DO NOTHING;

-- Pins / Links
INSERT INTO pin(pin_id, project_id, pin_kind, code, body)
VALUES
  ('00000000-0000-0000-0000-000000000001','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','center','center','center pin'),
  ('00000000-0000-0000-0000-000000000002','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','pin','boundary','boundary pin')
ON CONFLICT DO NOTHING;

INSERT INTO link(link_id, project_id, from_pin_id, to_pin_id, link_type, state, strength_num)
VALUES
  ('00000000-0000-0000-0000-000000000011','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
   '00000000-0000-0000-0000-000000000001','00000000-0000-0000-0000-000000000002',
   'memory','ON',1.0)
ON CONFLICT DO NOTHING;

-- Objects / Relation / Responses
INSERT INTO object(object_id, project_id, object_type, label, state, superseded_by_object_id)
VALUES
  ('00000000-0000-0000-0000-000000000101','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','concept','COREMAP','ACTIVE',NULL),
  ('00000000-0000-0000-0000-000000000102','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','concept','Layer7 Language','ACTIVE',NULL)
ON CONFLICT DO NOTHING;

INSERT INTO relation(rel_id, project_id, from_object_id, to_object_id, rel_type, link_id)
VALUES
  ('00000000-0000-0000-0000-000000000201','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
   '00000000-0000-0000-0000-000000000101','00000000-0000-0000-0000-000000000102',
   'defines','00000000-0000-0000-0000-000000000011')
ON CONFLICT DO NOTHING;

INSERT INTO relation_response(rel_id, resp_type, value_json, computed_by_agent_id)
VALUES
  ('00000000-0000-0000-0000-000000000201','meaning','"Layer7 Language is the shared DSL baseline."','22222222-2222-2222-2222-222222222222'),
  ('00000000-0000-0000-0000-000000000201','knowledge','{"rule":"relation-response-only","no_delete":true}','22222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

-- Boundary + Change (learning example)
INSERT INTO boundary_rule(boundary_id, project_id, rule_body, version, applies_to, condition_expr)
VALUES
  ('b0000000-0000-0000-0000-000000000001','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
   'No hard delete; use SUPERSEDED + superseded_by + boundary_change to record re-binding.',
   'v1.0','object','state!=DELETE')
ON CONFLICT DO NOTHING;

INSERT INTO boundary_change(boundary_id, change_type, event_type, before_ref, after_ref)
VALUES
  ('b0000000-0000-0000-0000-000000000001','reset','learning','v0.9','v1.0')
ON CONFLICT DO NOTHING;

-- Revisions + Validation logs
INSERT INTO revision(rev_id, project_id, scope, state, parent_rev_id, note, created_by_agent_id)
VALUES
  ('00000000-0000-0000-0000-000000000401','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','PHASE','OPEN',NULL,'Phase2 DB physical schema initial','22222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

INSERT INTO validation_log(project_id, rev_id, closure, target_kind, target_id, method, result, action, evidence_ref, reviewer_agent_id)
VALUES
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','00000000-0000-0000-0000-000000000401','PHASE','schema',NULL,
   'migration+seed smoke test','PARTIAL','CONTINUE','{"note":"tables created; seed inserted"}','22222222-2222-2222-2222-222222222222')
ON CONFLICT DO NOTHING;

-- Artifacts
INSERT INTO artifact(artifact_id, project_id, kind, lang, version, uri)
VALUES
  ('00000000-0000-0000-0000-000000000501','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','db','KR','v1.0',NULL),
  ('00000000-0000-0000-0000-000000000502','aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa','db','EN','v1.0',NULL)
ON CONFLICT DO NOTHING;

INSERT INTO authorship(artifact_id, agent_id, author_order, author_label)
VALUES
  ('00000000-0000-0000-0000-000000000501','11111111-1111-1111-1111-111111111111',1,'1저자'),
  ('00000000-0000-0000-0000-000000000501','22222222-2222-2222-2222-222222222222',2,'2저자'),
  ('00000000-0000-0000-0000-000000000502','11111111-1111-1111-1111-111111111111',1,'1st author'),
  ('00000000-0000-0000-0000-000000000502','22222222-2222-2222-2222-222222222222',2,'2nd author')
ON CONFLICT DO NOTHING;

COMMIT;
```

///

5. STATUS LABEL QUERY

```sql
SELECT rev_id, scope, state, closure, result, action, status_label, validated_at
FROM v_revision_status
WHERE project_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
ORDER BY created_at DESC;
```

///

6. RELEASE CRITERION (sample)
- rev00000...001 is OPEN + PARTIAL + CONTINUE => status_label=PARTIAL
- When later validated as PASS+LOCK, the revision can be sealed as CLOSED => status_label=CONSISTENT

///

7. CURRENT STATE (from seed)
- phase_rev: rev00000-0000-0000-0000-000000000001
- expected_status_label_now: PARTIAL
- next_expected_action: CONTINUE

///

8. NOTES (Seung's Flow with Logi alignment)
- This Phase2 package is the physical storage substrate for pin/link/flow/pattern + revision/validation/closure.
- It is not yet the full Seung's Flow runtime (ingest/interpret/compute loop). It is the DB layer that Seung's Flow will write/read.
