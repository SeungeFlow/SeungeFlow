# COREMAP L7 — Phase2(DB Physical) Release — 0004
DocType: Deliverable #2 (Physical DB schema + seed + validation samples)  
Target: PostgreSQL + pgcrypto  
Encoding: UTF-8  
Render: Markdown  

///

## 0) INVARIANTS
- No Delete: hard deletion forbidden; collapse recorded as re-binding
- meaning/identity/knowledge: NOT object attributes; stored only as relation_response values
- learning/evolution/adaptation: tracked only as boundary_change events
- Consistency: sealing revision as CLOSED (closure). Progress only via child revision lineage
- Status labels: derived only from validation_log (latest validation)

///

## 1) PACKAGE
- Migration SQL: coremap_phase2_migration_0004_v1.0.2.sql
- Seed SQL:      coremap_phase2_seed_0004_v1.0.2.sql
- This doc:      COREMAP_L7_Phase2_DB_Physical_0004_v1.0.3_L7.md

///

## 2) EXECUTION ORDER
1) Run migration SQL
2) Run seed SQL
3) Run STATUS query (section 4)

///

## 3) EXPECTED RESULT (smoke)
- Tables / indexes / views created
- Seed inserted (agents/project/pins/link/objects/relation/responses/boundary/revision/validation_log)
- v_revision_status returns label = PARTIAL for the Phase2 revision (OPEN + PARTIAL + CONTINUE)

///

## 4) STATUS LABEL QUERY
```sql
SELECT rev_id, scope, state, closure, result, action, status_label, validated_at
FROM v_revision_status
WHERE project_id='aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
ORDER BY created_at DESC;
```

///

## 5) RELEASE CRITERION (sample)
- When later validated as PASS+LOCK, revision can be sealed as CLOSED => CONSISTENT
- If FAIL+REBIND => CONFLICT
- If FAIL+REDEFINE => REDEFINE

///
