# COREMAP Layer7 Language v1.0 (KR)
문서 성격: 의미확장 버전 / Human+AI 공용 언어 스펙
인코딩: UTF-8
렌더링: Markdown(Web-safe)
상태: Layer7 Baseline (의미 변경 불가, 확장만 허용)

///

0. 목적
- 사람과 AI가 동일하게 읽고/기록하고/검증하기 위한 공용 언어(DSL) 규격을 정의한다.
- L7 Language는 “문장”이 아니라 “구조-연산-검증”을 우선한다.
- DB로 1:1 매핑 가능한 결정적 형식을 유지한다.

///

1. L7 Invariants
- No Delete / re-binding 기록
- Object Independence
- Relation Response
- Boundary-Event
- Consistency = Closure (revision CLOSED)
- Verification First (validation_log)

///

2. 섹션 구조(고정)
META / DECL / DATA / VALID / PUB

///

3. 문장 형식
KEY <id> : k=v ; k=v ; k=v
- 한 줄 = 한 문장
- 주석 = # 이후
- 섹션 = '///'
- 문자열 = "..."

///

4. 키워드 매핑
AGENT, ROLE, PROJECT, OBJECT, REL, RESP, PIN, LINK, BOUNDARY, CHANGE, REV, VALID, ARTIFACT, AUTHOR

///

5. 상태 라벨
- CONSISTENT / PARTIAL / CONFLICT / REDEFINE 는 (REV + VALID 최신 로그)로만 결정한다.
