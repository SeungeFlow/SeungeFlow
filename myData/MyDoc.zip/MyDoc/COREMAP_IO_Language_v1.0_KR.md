# COREMAP IO Language v1.0 (KR)
문서 성격: Human ↔ AI 공용 입력 언어(채팅 입력 + 파일 업로드) / Web-safe Markdown
인코딩: UTF-8
목표: 사람이 이해 가능한 문장으로 쓰되, AI가 결정적으로 파싱/검증/산출할 수 있게 한다.

///

0. 핵심 원칙
- 입력은 “의도(what)”와 “방법(how)”을 분리한다.
- 문서/채팅은 동일 형식(패킷)으로 취급한다. (채팅 = 단일 패킷, 업로드 = 패킷 + 파일목록)
- 변경은 삭제가 아니라 “PATCH(추가/대체)”로 기록한다.
- 출력은 항상 검증 결과(STATUS)를 동반한다.

///

1. 패킷 기본 형식 (COREMAP-PACKET)
- 한 줄 = 한 항목
- 항목 형식 = KEY: VALUE
- 섹션 구분 = '///'
- 주석 = # 이후
- 값에 줄바꿈이 필요하면, 다음 섹션의 BODY에서 작성한다.

///

2. 헤더(필수 6개)
PROTOCOL: COREMAP-IO
LANG: KR
VERSION: 1.0
MODE: CHAT | FILE
INTENT: ASK | DEFINE | PATCH | VALIDATE | RUN | PUBLISH
PROJECT: <project_id or name>

(권장)
REV: <rev_id>
TARGET: <target_kind/target_id>
TS: <ISO-8601 timestamp>

///

3. 본문 섹션(고정 순서)
CONTEXT:
- 배경/전제(짧게)

INPUT:
- 사용자가 전달하는 핵심 내용(질문/정의/요구사항)

FILES: (MODE=FILE일 때만)
- 업로드 파일을 사람이 읽을 수 있게 “목록”으로 선언한다.
- 각 파일은 1줄로 적는다.

RULES:
- 금지/불변/제약(예: No Delete, relation_response-only 등)

REQUEST:
- AI가 수행해야 할 작업(산출물, 검증, 변환 등)

OUTPUT:
- 원하는 출력 형식(예: Markdown, SQL, JSON, ZIP)
- 원하는 파일명/폴더 구조(있으면)

///

4. FILES 섹션 규격(권장)
- FILE: <name> | TYPE: <md/sql/pdf/zip/...> | ROLE: <phase1/phase2/layer7/...> | NOTE: <짧게>

///

5. AI 응답 규칙(최소)
- AI는 아래 3블록을 항상 포함한다.
[INPUT] 사용자가 준 INPUT의 원문 재현
[MY JUDGMENT] 구조화/검증/충돌 탐지/산출 계획
[STATUS] ✅정합 / ⚠️부분정합 / ❌충돌 / 🔄재정의 필요

(산출물이 있으면)
ARTIFACTS:
- FILE: <path or name> | DESC: <설명>

///

6. 예시 A: 채팅 입력(질문)
```text
PROTOCOL: COREMAP-IO
LANG: KR
VERSION: 1.0
MODE: CHAT
INTENT: ASK
PROJECT: COREMAP vNext
///
CONTEXT:
Phase 2로 넘어가기 전, 상태 라벨 규칙이 일관적인지 확인.
///
INPUT:
revision + validation_log 기반 status_label 계산이 “정합=closure” 원칙을 위반하지 않는가?
///
RULES:
No Delete
Consistency = Closure
///
REQUEST:
논리 충돌 여부를 검증하고, 충돌이면 PATCH 제안.
///
OUTPUT:
Markdown
```

///

7. 예시 B: 파일 업로드(번들 검증)
```text
PROTOCOL: COREMAP-IO
LANG: KR
VERSION: 1.0
MODE: FILE
INTENT: VALIDATE
PROJECT: COREMAP vNext
REV: rev-Phase2-001
///
CONTEXT:
ZIP에 들어있는 Phase2 SQL과 문서가 서로 불일치하는지 검사.
///
FILES:
FILE: coremap_phase2_migration.sql | TYPE: sql | ROLE: phase2 | NOTE: physical schema
FILE: coremap_phase2_seed.sql | TYPE: sql | ROLE: phase2 | NOTE: sample seed
FILE: Phase2_Release_KR.md | TYPE: md | ROLE: docs | NOTE: KR doc
///
RULES:
No Delete
Relation Response Only
Boundary-Event Only
///
REQUEST:
1) DDL 실행 가능성 점검  2) 문서-코드 불일치 탐지  3) PASS/PARTIAL/FAIL 판정
///
OUTPUT:
Markdown + (필요 시) patched SQL 파일
```

///

8. 최소 체크리스트(사용자용)
- MODE/INTENT/PROJECT는 항상 적었는가?
- RULES에 “지켜야 하는 불변”을 적었는가?
- REQUEST에 “무엇을 내놓을지”를 적었는가?
- OUTPUT에 파일 형태/이름을 지정했는가(원하면)?
