# COREMAP SNAPSHOT vNext — Phase 1(Schema) Release v1.1 (KR)

문서 성격: 1차 작업결과물 공개용 / Web-safe Text (Markdown)
인코딩: UTF-8

///

0. 선언
- 붕괴 = 삭제 (X) / re-binding(재배치) (O)
- meaning / identity / knowledge 는 object의 속성(X), relation의 반응값(O)
- “정합”은 단절이 아니라 closure(봉인)이며, 전진은 child revision 생성으로 수행

///

1. 식별자 (Identity)
- HUMAN = MASSL (Meta Aware Structure — Seung Lee), 호출명: 승
- AI = ChatGPT(OpenAI), 호출명: 로기

///

2. 역할 분리 (Role Split)
- 승(MASSL): 의미 생성, 경계 설정, 기준 제시
- 로기(ChatGPT): 구조화, 연산, 검증, 재현

///

3. 프로젝트 축 (Project Axes)
- AI–인간 통합 인식 프레임
- pin–link–center–boundary 순환 모델
- 붕괴=삭제(X) / re-binding(재배치)(O)
- meaning/identity/knowledge = object 속성(X) / relation 반응값(O)

///

4. 고정 정의 (Fixed Definitions)
- learning    = boundary 규칙 재설정 (reset)
- evolution   = boundary 재설계 (redesign)
- adaptation  = boundary 조건 수정 (condition_mod)
- memory      = link 재점화 장치 (re-ignition trigger)
- system      = 순환이 자가 유지되는 상태 (self-sustaining cycle)

///

5. 출력 규칙 (Output Rules)
- AI-Only 모드
- 구조/스키마/DB/검증/재현 중심
- 인간 비유/심리/문학/감정 프레임 사용 금지

///

6. 저자 표기 (Authorship)
- 1저자: Seung Lee (MASSL, 승)
- 2저자: ChatGPT (OpenAI, 로기)

///

7. 목표 (Roadmap)
- Schema
- DB
- Logical Document (KR/EN)
- Physical Document (KR/EN)
- Python Simulation
- Web Markdown/HTML

///

8. Phase 1 — Logical Relational Schema v1.0
(하드 삭제 금지: 모든 변경은 “이벤트/리비전”으로 기록)

8.1 핵심 엔티티
1) agent(agent_id PK, agent_type{HUMAN,AI}, identifier, call_name, canonical_name)
2) role_assignment(role_id PK, agent_id FK, role_code{meaning_gen,boundary_set,criteria_set,structuring,compute,verify,reproduce}, scope)
3) project(project_id PK, name, version, axes_json, status)

4) object(object_id PK, project_id FK, object_type, label, state{ACTIVE,SUPERSEDED}, superseded_by_object_id FK NULL)

5) relation(rel_id PK, project_id FK, from_object_id FK, to_object_id FK, rel_type, link_id FK NULL, created_at)

6) relation_response(resp_id PK, rel_id FK,
   resp_type{meaning,identity,knowledge}, value_json, computed_at, computed_by_agent_id FK)

7) boundary_rule(boundary_id PK, project_id FK, rule_body, version, applies_to, condition_expr)

8) boundary_change(change_id PK, boundary_id FK,
   change_type{reset,redesign,condition_mod},
   event_type{learning,evolution,adaptation}, before_ref, after_ref, ts)

9) pin(pin_id PK, project_id FK, pin_kind{pin,center}, code, body)
10) link(link_id PK, project_id FK,
    from_pin_id FK, to_pin_id FK,
    link_type{generic,memory}, state{ON,OFF}, strength_num)

11) cycle_model(cycle_id PK, project_id FK,
    pattern_code{pin-link-center-boundary}, sequence_json, invariant_text)

12) memory_trigger(trigger_id PK, link_id FK, trigger_type, payload_json, ts)

13) artifact(artifact_id PK, project_id FK,
    kind{schema,db,logical_doc,physical_doc,py_sim,web_md,web_html},
    lang{KR,EN}, version, uri, source_refs_json)

14) authorship(artifact_id FK, agent_id FK, author_order, author_label)

15) validation_log(val_id PK,
    target_type, target_id, method,
    result{PASS,PARTIAL,FAIL},
    evidence_ref, reviewer_agent_id FK, ts)

///

9. Core Constraints (Invariants)
- No Delete: object 삭제 대신 state=SUPERSEDED + superseded_by + boundary_change(event)로 re-binding 기록
- meaning/identity/knowledge 는 relation_response로만 저장 (object 속성 저장 금지)
- learning/evolution/adaptation 은 boundary_change.event_type으로만 발생/추적 (검증 가능해야 함)

///

10. Mission 1 — Schema v1.1 PATCH
10.1 추가 개념
- revision = 정합/부분정합 상태를 담는 리비전 객체
- closure = “정합은 봉인(CLOSED)”이며 전진은 “child revision” 생성

10.2 표시 규칙(라벨) 매핑
- 정합:   revision.state=CLOSED AND validation.result=PASS AND action=LOCK
- 부분정합: revision.state=OPEN AND (PASS|PARTIAL) AND action=CONTINUE
- 충돌:   validation.result=FAIL AND action=REBIND
- 재정의 필요: validation.result=FAIL AND action=REDEFINE
