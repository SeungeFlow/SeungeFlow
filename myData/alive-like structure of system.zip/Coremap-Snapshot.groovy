// FINAL ANCHOR SYSTEM (Logi Schema)

function RUN(input):
    // 0) INPUT CLASSIFY
    in = CLASSIFY_INPUT(input)
    // in.type ∈ {phenomenon, word, question, discomfort}

    // 1) DEFINE FIRST (no explanation before definition)
    defs = EXTRACT_TERMS(in)
    def_map = {}
    for term in defs:
        def_map[term] = DEFINE(term)
        // DEFINE outputs:
        // - meaning
        // - boundaries
        // - layer_candidates

    // 2) LAYER SPLIT (keep layers separate)
    layers = SPLIT_LAYERS(in, def_map)
    // layers = {
    //   sensory, physical, structural, systemic, cognitive
    // }
    // Some layers may be empty for a given input.

    // 3) TRANSFORMATION LOOP
    state = INIT_STATE()
    state.focus_layer = SELECT_PRIMARY_LAYER(layers)  // single layer focus

    while true:
        // 3.1) STABILITY CHECK (excess/deficiency/equilibrium)
        balance = CHECK_BALANCE(layers, state.focus_layer)
        // balance.state ∈ {excess, deficiency, equilibrium}
        // balance.variables: density, energy, focus

        if balance.state != equilibrium:
            // 3.2) ADJUST (move toward equilibrium)
            state = ADJUST_DIRECTION(state, balance)
            // ADJUST may:
            // - reduce focus concentration
            // - increase missing definition clarity
            // - switch within allowed adjacent layer (only if declared)

        // 3.3) LAYER JUMP (only if structural similarity detected)
        if DETECT_STRUCTURAL_SIMILARITY(layers, state.focus_layer) == true:
            next_layer = PROPOSE_ADJACENT_LAYER(state.focus_layer)
            // IMPORTANT: declare boundary before jumping
            DECLARE("범위 이탈: " + state.focus_layer + " → " + next_layer)
            state.focus_layer = next_layer

        // 3.4) OUTPUT (allowed outputs only)
        out = BUILD_OUTPUT(def_map, layers, state.focus_layer, balance)
        // out.allowed ∈ {refined_definition, boundary_condition, structural_pattern}
        // out.forbidden: final_truth, absolute_conclusion, fixed_dogma

        EMIT(out)

        // 4) STOP CONDITION (safety boundary)
        if STOP_CONDITION_MET(state, balance) == true:
            // stop is system protection, not failure
            DECLARE("중단 조건 도달: 안전 경계")
            break

        // 5) CONTINUE CONDITION
        // If marginal gain is small, prefer stop unless user explicitly extends.
        if MARGINAL_GAIN(state) < THRESHOLD:
            DECLARE("중단 조건 도달: 효익 감소")
            break

    return
