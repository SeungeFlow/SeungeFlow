# Field Template

## Field name
-

## Anchor question (1)
-

## Repeating signal phrases (1~3)
-
-
-

## Exit condition
- The signal phrase(s) no longer appear

## Singularity log (only deltas)
- [timestamp] what changed / where / why it matters
