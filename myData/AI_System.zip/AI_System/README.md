# 이해1번

부제: 전체 1회 순환 = 이해 1회

이 레포는 승이의 학습패턴(전체 인덱싱 → 전체 순환)을 문서프로그램 형태로 고정한다.

구성:
- `manual/AI_USER_MANUAL_KR.md` : 사용설명서(승이 관점)
- `specs/DOMAIN_INDEX_KR.md` : 의미 Domain 인덱스(0000~0009)
- `lock/BOOT_RULES.md` : 세션 부트 규칙
- `examples/field_template.md` : Field 기록 템플릿

- `lock/BOOTLOADER_V0_3.md` : v0.3 부트로더(존재 정의 + 존재 이해)
