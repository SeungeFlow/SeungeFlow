
import json
from pathlib import Path

INPUT = Path("../reports/process_graph.json")
OUTPUT = Path("../reports/neo4j_import.cypher")

if not INPUT.exists():
    print("process_graph.json missing")
    exit()

with open(INPUT) as f:
    edges = json.load(f)

nodes=set()
for e in edges:
    nodes.add(e["from"])
    nodes.add(e["to"])

lines=[]

for n in nodes:
    lines.append(f'CREATE (:Process {{name:"{n}"}});')

for e in edges:
    a=e["from"]
    b=e["to"]
    w=e.get("weight",1)
    lines.append(
        f'MATCH (a:Process {{name:"{a}"}}),(b:Process {{name:"{b}"}}) CREATE (a)-[:FLOW {{weight:{w}}}]->(b);'
    )

with open(OUTPUT,"w") as f:
    f.write("\n".join(lines))

print("Neo4j export created:",OUTPUT)
