
import json
from pathlib import Path

INPUT = Path("../reports/process_graph.json")
OUTPUT = Path("../reports/live_network.html")

if not INPUT.exists():
    print("process_graph.json missing")
    exit()

with open(INPUT) as f:
    edges=json.load(f)

nodes=set()
for e in edges:
    nodes.add(e["from"])
    nodes.add(e["to"])

html=f"""
<html>
<head>
<title>Live Network</title>
</head>
<body>
<h1>Process Network</h1>
<pre>
Nodes: {list(nodes)}
Edges: {edges[:20]}
</pre>
</body>
</html>
"""

with open(OUTPUT,"w") as f:
    f.write(html)

print("live network page generated")
