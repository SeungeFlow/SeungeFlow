
import json
from pathlib import Path

INPUT = Path("../reports/process_graph.json")
OUTPUT = Path("../reports/research_dataset.json")

if not INPUT.exists():
    print("process graph missing")
    exit()

with open(INPUT) as f:
    edges=json.load(f)

dataset={
"dataset":"SeungeFlow Process Network",
"edge_count":len(edges),
"sample":edges[:50]
}

with open(OUTPUT,"w") as f:
    json.dump(dataset,f,indent=2)

print("research dataset exported")
