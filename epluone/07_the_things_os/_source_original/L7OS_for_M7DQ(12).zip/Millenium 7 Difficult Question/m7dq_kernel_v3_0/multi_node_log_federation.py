
import os
import json

BASE="../logs"
OUTPUT="../reports/federated_logs.json"

all_logs=[]

for f in os.listdir(BASE):
    if f.endswith(".log"):
        path=os.path.join(BASE,f)
        with open(path,"r",errors="ignore") as fh:
            lines=fh.readlines()[-50:]
            all_logs.append({
                "source":f,
                "events":len(lines)
            })

with open(OUTPUT,"w") as out:
    json.dump(all_logs,out,indent=2)

print("federated log snapshot created")
