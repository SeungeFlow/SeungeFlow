
import os

print("Running SeungeFlow Engine v3.0")

cmds=[
"python3 run_analysis_v2_1.py",
"python3 neo4j_graph_exporter.py",
"python3 live_network_visualizer.py",
"python3 multi_node_log_federation.py",
"python3 research_dataset_exporter.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("v3.0 complete")
