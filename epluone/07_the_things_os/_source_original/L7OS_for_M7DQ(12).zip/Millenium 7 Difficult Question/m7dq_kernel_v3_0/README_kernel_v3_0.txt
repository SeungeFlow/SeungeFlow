
Kernel v3.0

Major expansion

neo4j_graph_exporter.py
live_network_visualizer.py
multi_node_log_federation.py
research_dataset_exporter.py

Purpose

export network to graph DB
visualize process topology
combine logs from multiple nodes
export datasets for research

Run

cd /opt/m7dq/kernel
python3 run_analysis_v3_0.py

Outputs

neo4j_import.cypher
live_network.html
federated_logs.json
research_dataset.json
