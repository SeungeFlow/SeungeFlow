Kernel v5.0

Adds self-learning and hypothesis generation

Modules
- pattern_memory_db.py
- self_learning_model.py
- adaptive_anomaly_detector.py
- auto_hypothesis_generator.py
- run_analysis_v5_0.py

Purpose
- accumulate pattern memory
- update learned weights from recurring process flows
- adjust anomaly thresholds using learned history
- generate structural hypotheses from current reports

Run
cd /opt/m7dq/kernel
python3 run_analysis_v5_0.py

Key outputs
- ../reports/pattern_memory_db.json
- ../reports/self_learning_model_report.json
- ../reports/adaptive_anomaly_report.json
- ../reports/hypothesis_report.json
