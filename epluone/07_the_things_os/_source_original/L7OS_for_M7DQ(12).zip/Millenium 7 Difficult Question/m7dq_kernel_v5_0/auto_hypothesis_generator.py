import json
from pathlib import Path

PHASE_FILE = Path("../reports/phase_transition_report.json")
PATTERN_FILE = Path("../reports/ai_pattern_report.json")
OUTPUT_FILE = Path("../reports/hypothesis_report.json")

phase = {}
patterns = {}

if PHASE_FILE.exists():
    with open(PHASE_FILE, "r", encoding="utf-8") as f:
        phase = json.load(f)

if PATTERN_FILE.exists():
    with open(PATTERN_FILE, "r", encoding="utf-8") as f:
        patterns = json.load(f)

alerts = phase.get("alerts", [])
top_patterns = patterns.get("top_patterns", [])[:5]

hypotheses = []

if alerts:
    hypotheses.append(
        "Phase transition alerts suggest the system may be entering a temporary instability window."
    )

if top_patterns:
    dominant = ", ".join([p[0] for p in top_patterns[:3]])
    hypotheses.append(
        f"Dominant process flows appear to concentrate around: {dominant}."
    )

if alerts and top_patterns:
    hypotheses.append(
        "A repeated dominant flow combined with abrupt window changes may indicate a controllable structural bottleneck."
    )

if not hypotheses:
    hypotheses.append("Insufficient evidence. Run the upstream analysis pipeline first.")

report = {
    "hypothesis_count": len(hypotheses),
    "hypotheses": hypotheses
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("auto hypothesis report generated")
