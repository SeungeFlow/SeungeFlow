import json
from pathlib import Path
from collections import Counter

PATTERN_FILE = Path("../reports/ai_pattern_report.json")
MEMORY_FILE = Path("../reports/pattern_memory_db.json")
OUTPUT_FILE = Path("../reports/self_learning_model_report.json")

if not PATTERN_FILE.exists():
    print("ai_pattern_report.json missing")
    raise SystemExit(0)

with open(PATTERN_FILE, "r", encoding="utf-8") as f:
    pattern_report = json.load(f)

top_patterns = pattern_report.get("top_patterns", [])

memory = {}
if MEMORY_FILE.exists():
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        memory = json.load(f)

pattern_counter = Counter(memory.get("pattern_weights", {}))
for pair, weight in top_patterns:
    pattern_counter[pair] += weight

learned = {
    "pattern_weights": dict(pattern_counter),
    "update_count": memory.get("update_count", 0) + 1
}

with open(MEMORY_FILE, "w", encoding="utf-8") as f:
    json.dump(learned, f, indent=2)

report = {
    "status": "updated",
    "update_count": learned["update_count"],
    "top_learned_patterns": pattern_counter.most_common(20)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("self learning model updated")
