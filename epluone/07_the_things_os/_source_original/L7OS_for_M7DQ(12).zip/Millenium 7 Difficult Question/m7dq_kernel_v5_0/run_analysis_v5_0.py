import os

print("Running SeungeFlow Engine v5.0")

cmds = [
    "python3 run_analysis_v4_0.py",
    "python3 pattern_memory_db.py",
    "python3 self_learning_model.py",
    "python3 adaptive_anomaly_detector.py",
    "python3 auto_hypothesis_generator.py",
]

for c in cmds:
    print(">", c)
    os.system(c)

print("v5.0 complete")
