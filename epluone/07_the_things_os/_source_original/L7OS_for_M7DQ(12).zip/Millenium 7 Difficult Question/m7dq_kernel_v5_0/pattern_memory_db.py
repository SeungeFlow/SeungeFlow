import json
from pathlib import Path

MEMORY_FILE = Path("../reports/pattern_memory_db.json")
OUTPUT_FILE = Path("../reports/pattern_memory_status.json")

if not MEMORY_FILE.exists():
    initial = {
        "pattern_weights": {},
        "update_count": 0
    }
    with open(MEMORY_FILE, "w", encoding="utf-8") as f:
        json.dump(initial, f, indent=2)

with open(MEMORY_FILE, "r", encoding="utf-8") as f:
    memory = json.load(f)

report = {
    "status": "ready",
    "pattern_count": len(memory.get("pattern_weights", {})),
    "update_count": memory.get("update_count", 0)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("pattern memory db ready")
