import json
from pathlib import Path

ANOMALY_FILE = Path("../reports/anomaly_score.json")
MEMORY_FILE = Path("../reports/pattern_memory_db.json")
OUTPUT_FILE = Path("../reports/adaptive_anomaly_report.json")

if not ANOMALY_FILE.exists():
    print("anomaly_score.json missing")
    raise SystemExit(0)

with open(ANOMALY_FILE, "r", encoding="utf-8") as f:
    anomaly = json.load(f)

scores = anomaly.get("anomaly_scores", {})

memory = {"update_count": 0}
if MEMORY_FILE.exists():
    with open(MEMORY_FILE, "r", encoding="utf-8") as f:
        memory = json.load(f)

update_count = memory.get("update_count", 0)

# As learning increases, threshold tightens slightly.
high_threshold = max(0.60, 0.90 - min(update_count * 0.02, 0.20))
medium_threshold = max(0.40, 0.70 - min(update_count * 0.02, 0.20))

alerts = []
for process, score in scores.items():
    if score >= high_threshold:
        alerts.append({"process": process, "score": score, "risk": "high"})
    elif score >= medium_threshold:
        alerts.append({"process": process, "score": score, "risk": "medium"})

report = {
    "memory_update_count": update_count,
    "high_threshold": high_threshold,
    "medium_threshold": medium_threshold,
    "alert_count": len(alerts),
    "alerts": sorted(alerts, key=lambda x: x["score"], reverse=True)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("adaptive anomaly detector complete")
