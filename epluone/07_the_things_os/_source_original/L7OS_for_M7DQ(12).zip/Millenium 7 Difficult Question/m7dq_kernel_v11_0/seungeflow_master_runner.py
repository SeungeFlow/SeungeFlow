import os

print("Running SeungeFlow Master Runner v11.0")

cmds = [
    "python3 run_analysis_v10_0.py",
    "python3 peer_review_simulator.py",
    "python3 contradiction_scanner.py",
    "python3 archive_release_builder.py",
]

for c in cmds:
    print(">", c)
    os.system(c)

print("master runner complete")
