import json
import zipfile
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "release_manifest.json"
ZIP_OUT = REPORT_DIR / "seungeflow_release_bundle.zip"

artifacts = [
    "final_research_report.md",
    "publication_draft.md",
    "theory_synthesis_report.json",
    "discovery_ranking.json",
    "peer_review_report.json",
    "contradiction_scan.json",
]

manifest = {"artifact_count": 0, "artifacts": []}

with zipfile.ZipFile(ZIP_OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for name in artifacts:
        p = REPORT_DIR / name
        if not p.exists():
            continue
        z.write(p, arcname=name)
        manifest["artifacts"].append(name)

manifest["artifact_count"] = len(manifest["artifacts"])

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(manifest, f, indent=2)

print("archive release bundle created")
