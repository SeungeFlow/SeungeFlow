import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "peer_review_report.json"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

theory = load("theory_synthesis_report.json")
ranking = load("discovery_ranking.json")
reflection = load("self_reflection_report.json")

reviews = []
for t in theory.get("theories", [])[:10]:
    confidence = t.get("confidence", 0.0)
    verdict = "accept" if confidence >= 0.5 else "revise"
    reviews.append({
        "theory_id": t.get("theory_id"),
        "verdict": verdict,
        "confidence": confidence,
        "comment": "Supported by current evidence." if verdict == "accept" else "Needs stronger evidence and clearer linkage."
    })

report = {
    "review_count": len(reviews),
    "top_ranked_candidates": ranking.get("rankings", [])[:5],
    "gaps": reflection.get("gaps", []),
    "reviews": reviews
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("peer review simulation complete")
