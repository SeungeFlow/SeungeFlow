import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "contradiction_scan.json"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

hyp = load("hypothesis_report.json")
ver = load("hypothesis_verification.json")
reflection = load("self_reflection_report.json")

contradictions = []

verified = {item.get("hypothesis"): item for item in ver.get("verified_hypotheses", [])}

for h in hyp.get("hypotheses", []):
    v = verified.get(h)
    if v and v.get("confidence", 0) < 0.3:
        contradictions.append({
            "type": "low_confidence_hypothesis",
            "hypothesis": h,
            "confidence": v.get("confidence", 0)
        })

for gap in reflection.get("gaps", []):
    contradictions.append({
        "type": "system_gap",
        "detail": gap
    })

report = {
    "contradiction_count": len(contradictions),
    "contradictions": contradictions
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("contradiction scan complete")
