Kernel v11.0

Adds
- peer_review_simulator.py
- contradiction_scanner.py
- archive_release_builder.py
- seungeflow_master_runner.py

Purpose
- simulate a lightweight peer review pass on synthesized theories
- scan for low-confidence contradictions and system gaps
- package release-ready research artifacts
- provide one master runner for the full stack

Run
cd /opt/m7dq/kernel
python3 seungeflow_master_runner.py

Key outputs
- ../reports/peer_review_report.json
- ../reports/contradiction_scan.json
- ../reports/release_manifest.json
- ../reports/seungeflow_release_bundle.zip
