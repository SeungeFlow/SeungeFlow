
import json
from pathlib import Path

INPUT_DIR = Path("../inputs")
OUTPUT = Path("../reports/universal_input_summary.json")

records = []

for f in INPUT_DIR.glob("*"):
    if f.is_file():
        records.append({
            "file": f.name,
            "size_bytes": f.stat().st_size
        })

report = {
    "input_count": len(records),
    "inputs": records
}

OUTPUT.parent.mkdir(parents=True, exist_ok=True)

with open(OUTPUT,"w") as out:
    json.dump(report,out,indent=2)

print("universal input scan complete")
