
import json
from pathlib import Path

INPUT = Path("../reports/universal_input_summary.json")
OUTPUT = Path("../reports/domain_classification.json")

domains = []

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for r in data.get("inputs",[]):
        name=r["file"].lower()

        if "trade" in name or "market" in name:
            d="trading"
        elif "brain" in name or "neuro" in name:
            d="brain"
        elif "paper" in name or "research" in name:
            d="science"
        elif "log" in name:
            d="system"
        else:
            d="unknown"

        domains.append({"file":r["file"],"domain":d})

report={"classified":domains,"count":len(domains)}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("domain classification complete")
