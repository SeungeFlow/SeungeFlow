
import os

print("Running Universal Input Layer v13.0")

steps=[
"python3 universal_input_adapter.py",
"python3 data_domain_classifier.py",
"python3 universal_pipeline_router.py"
]

for s in steps:
    print(">",s)
    os.system(s)

print("universal input pipeline complete")
