
Kernel v13.0

Universal Input Layer

Modules
- universal_input_adapter.py
- data_domain_classifier.py
- universal_pipeline_router.py
- run_universal_pipeline.py

Purpose

Allow SeungeFlow Engine to ingest arbitrary datasets
Classify domain automatically
Route input to correct analysis pipeline

Usage

cd /opt/m7dq/kernel
python3 run_universal_pipeline.py

Input folder

/opt/m7dq/inputs
