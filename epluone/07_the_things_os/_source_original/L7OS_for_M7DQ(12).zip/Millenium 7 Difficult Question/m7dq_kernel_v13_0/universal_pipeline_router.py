
import json
from pathlib import Path

INPUT = Path("../reports/domain_classification.json")
OUTPUT = Path("../reports/universal_routing.json")

routes=[]

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for item in data.get("classified",[]):
        d=item["domain"]

        if d=="system":
            pipe="system_analysis"
        elif d=="trading":
            pipe="trading_analysis"
        elif d=="brain":
            pipe="cognitive_analysis"
        elif d=="science":
            pipe="research_analysis"
        else:
            pipe="generic_analysis"

        routes.append({
            "file":item["file"],
            "pipeline":pipe
        })

report={"routes":routes,"route_count":len(routes)}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("universal routing complete")
