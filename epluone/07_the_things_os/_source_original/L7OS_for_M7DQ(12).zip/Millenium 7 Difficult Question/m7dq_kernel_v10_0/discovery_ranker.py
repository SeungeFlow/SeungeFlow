import json
from pathlib import Path

INPUT = Path("../reports/discovery_report.json")
OUTPUT = Path("../reports/discovery_ranking.json")

discoveries = []
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        discoveries = json.load(f).get("discovery_candidates", [])

ranked = []
for i, d in enumerate(discoveries, start=1):
    score = 1.0 / i
    ranked.append({
        "rank": i,
        "candidate": d.get("candidate"),
        "domain": d.get("domain"),
        "score": round(score, 4),
        "status": d.get("status", "candidate_pattern")
    })

report = {
    "ranked_count": len(ranked),
    "rankings": ranked
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("discovery ranking complete")
