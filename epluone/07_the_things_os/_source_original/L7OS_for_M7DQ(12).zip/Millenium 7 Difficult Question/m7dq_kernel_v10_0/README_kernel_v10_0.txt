Kernel v10.0

Adds
- self_reflection_engine.py
- theory_synthesis_engine.py
- discovery_ranker.py
- publication_builder.py
- run_analysis_v10_0.py

Purpose
- reflect on current system strengths and gaps
- synthesize hypotheses plus discoveries into theory candidates
- rank discovery candidates
- compile a publication-style draft

Run
cd /opt/m7dq/kernel
python3 run_analysis_v10_0.py

Key outputs
- ../reports/self_reflection_report.json
- ../reports/theory_synthesis_report.json
- ../reports/discovery_ranking.json
- ../reports/publication_draft.md
