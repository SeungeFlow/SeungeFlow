import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "publication_draft.md"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

reflection = load("self_reflection_report.json")
theory = load("theory_synthesis_report.json")
ranking = load("discovery_ranking.json")

lines = [
    "# SeungeFlow Publication Draft",
    "",
    "## Reflection",
    f"- summary: {reflection.get('reflection_summary', '')}",
    f"- strengths: {reflection.get('strengths', [])}",
    f"- gaps: {reflection.get('gaps', [])}",
    "",
    "## Theory Synthesis",
    f"- theory_count: {theory.get('theory_count', 0)}",
    "",
    "## Discovery Ranking",
    f"- ranked_count: {ranking.get('ranked_count', 0)}",
    f"- top_rankings: {ranking.get('rankings', [])[:5]}",
    "",
    "## Notes",
    "- This is an automatically generated draft for further human review.",
    ""
]

with open(OUTPUT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("publication draft generated")
