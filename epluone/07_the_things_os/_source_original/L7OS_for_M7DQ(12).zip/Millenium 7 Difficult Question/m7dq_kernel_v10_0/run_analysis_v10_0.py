import os

print("Running SeungeFlow Engine v10.0")

cmds = [
    "python3 run_analysis_v9_0.py",
    "python3 self_reflection_engine.py",
    "python3 theory_synthesis_engine.py",
    "python3 discovery_ranker.py",
    "python3 publication_builder.py",
]

for c in cmds:
    print(">", c)
    os.system(c)

print("v10.0 complete")
