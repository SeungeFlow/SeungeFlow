import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "self_reflection_report.json"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

global_state = load("global_state.json")
discovery = load("discovery_report.json")
verification = load("hypothesis_verification.json")

strengths = []
gaps = []

if global_state.get("entropy"):
    strengths.append("global state assembled")
else:
    gaps.append("missing global state")

if discovery.get("count", 0) > 0:
    strengths.append("discovery candidates available")
else:
    gaps.append("no discovery candidates")

if verification.get("hypothesis_count", 0) > 0:
    strengths.append("hypothesis verification available")
else:
    gaps.append("no verified hypotheses")

report = {
    "strengths": strengths,
    "gaps": gaps,
    "reflection_summary": f"strengths={len(strengths)}, gaps={len(gaps)}"
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("self reflection complete")
