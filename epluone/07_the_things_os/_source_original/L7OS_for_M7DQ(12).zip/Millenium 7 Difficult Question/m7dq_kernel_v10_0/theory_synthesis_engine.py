import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "theory_synthesis_report.json"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

hyp = load("hypothesis_report.json")
ver = load("hypothesis_verification.json")
disc = load("discovery_report.json")

hypotheses = hyp.get("hypotheses", [])
verified = ver.get("verified_hypotheses", [])
discoveries = disc.get("discovery_candidates", [])

theories = []

for i, h in enumerate(hypotheses[:10], start=1):
    confidence = 0.0
    for v in verified:
        if v.get("hypothesis") == h:
            confidence = v.get("confidence", 0.0)
            break

    linked = discoveries[:3]
    theories.append({
        "theory_id": f"TH-{i:03d}",
        "base_hypothesis": h,
        "confidence": confidence,
        "linked_discoveries": linked
    })

report = {
    "theory_count": len(theories),
    "theories": theories
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("theory synthesis complete")
