import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT_FILE = REPORT_DIR / "cross_domain_fusion_report.json"

def load_json(name):
    path = REPORT_DIR / name
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

entropy = load_json("entropy_report.json")
trading = load_json("trading_log_report.json")
brain = load_json("brain_log_report.json")
adaptive = load_json("adaptive_anomaly_report.json")

fusion = {
    "domains_present": {
        "system": bool(entropy),
        "trading": bool(trading) and trading.get("status") != "missing",
        "brain": bool(brain) and brain.get("status") != "missing",
    },
    "signals": [],
    "summary": ""
}

if entropy:
    fusion["signals"].append({
        "domain": "system",
        "metric": "entropy",
        "value": entropy.get("entropy")
    })

if trading and trading.get("status") != "missing":
    fusion["signals"].append({
        "domain": "trading",
        "metric": "rows",
        "value": trading.get("rows")
    })

if brain and brain.get("status") != "missing":
    fusion["signals"].append({
        "domain": "brain",
        "metric": "rows",
        "value": brain.get("rows")
    })

if adaptive:
    fusion["signals"].append({
        "domain": "system",
        "metric": "adaptive_alert_count",
        "value": adaptive.get("alert_count")
    })

active_domains = [k for k, v in fusion["domains_present"].items() if v]
fusion["summary"] = f"Active domains: {', '.join(active_domains) if active_domains else 'none'}"

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(fusion, f, indent=2)

print("cross domain fusion complete")
