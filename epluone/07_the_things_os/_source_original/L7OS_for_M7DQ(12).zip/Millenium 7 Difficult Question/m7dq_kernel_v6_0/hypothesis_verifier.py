import json
from pathlib import Path

HYPOTHESIS_FILE = Path("../reports/hypothesis_report.json")
PHASE_FILE = Path("../reports/phase_transition_report.json")
PATTERN_FILE = Path("../reports/ai_pattern_report.json")
OUTPUT_FILE = Path("../reports/hypothesis_verification.json")

hypotheses = []
phase = {}
patterns = {}

if HYPOTHESIS_FILE.exists():
    with open(HYPOTHESIS_FILE, "r", encoding="utf-8") as f:
        hypotheses = json.load(f).get("hypotheses", [])

if PHASE_FILE.exists():
    with open(PHASE_FILE, "r", encoding="utf-8") as f:
        phase = json.load(f)

if PATTERN_FILE.exists():
    with open(PATTERN_FILE, "r", encoding="utf-8") as f:
        patterns = json.load(f)

alerts = phase.get("alerts", [])
top_patterns = patterns.get("top_patterns", [])

results = []
for h in hypotheses:
    score = 0.0
    evidence = []

    if "instability" in h.lower() and alerts:
        score += 0.5
        evidence.append("phase_transition_alerts_present")

    if "dominant process flows" in h.lower() and top_patterns:
        score += 0.3
        evidence.append("dominant_patterns_present")

    if "bottleneck" in h.lower() and alerts and top_patterns:
        score += 0.2
        evidence.append("alerts_plus_patterns_support_bottleneck")

    results.append({
        "hypothesis": h,
        "confidence": round(min(score, 1.0), 3),
        "evidence": evidence
    })

report = {
    "hypothesis_count": len(results),
    "verified_hypotheses": results
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("hypothesis verification complete")
