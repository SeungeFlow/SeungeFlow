import json
from pathlib import Path
from datetime import datetime

REPORT_DIR = Path("../reports")
ARCHIVE_DIR = REPORT_DIR / "snapshots"
ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)

tracked = [
    "entropy_report.json",
    "network_density.json",
    "centrality_report.json",
    "anomaly_score.json",
    "adaptive_anomaly_report.json",
    "hypothesis_report.json",
    "hypothesis_verification.json",
]

timestamp = datetime.utcnow().strftime("%Y%m%dT%H%M%SZ")
archive_manifest = {
    "timestamp": timestamp,
    "files": []
}

for name in tracked:
    src = REPORT_DIR / name
    if not src.exists():
        continue

    dst = ARCHIVE_DIR / f"{timestamp}_{name}"
    dst.write_text(src.read_text(encoding="utf-8"), encoding="utf-8")
    archive_manifest["files"].append(dst.name)

manifest_path = ARCHIVE_DIR / f"{timestamp}_manifest.json"
with open(manifest_path, "w", encoding="utf-8") as f:
    json.dump(archive_manifest, f, indent=2)

print("snapshot archived:", manifest_path.name)
