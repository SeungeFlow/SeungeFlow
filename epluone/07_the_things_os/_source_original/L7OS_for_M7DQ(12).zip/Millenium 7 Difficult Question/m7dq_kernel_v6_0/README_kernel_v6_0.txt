Kernel v6.0

Adds
- hypothesis_verifier.py
- memory_snapshot_archiver.py
- cross_domain_fusion_engine.py
- autonomous_report_scheduler.py
- run_analysis_v6_0.py

Purpose
- verify generated hypotheses with available evidence
- archive report snapshots over time
- fuse signals across system, trading, and brain domains
- define autonomous reporting cadence

Run
cd /opt/m7dq/kernel
python3 run_analysis_v6_0.py

Key outputs
- ../reports/hypothesis_verification.json
- ../reports/cross_domain_fusion_report.json
- ../reports/autonomous_report_schedule.txt
- ../reports/snapshots/
