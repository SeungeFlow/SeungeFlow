from pathlib import Path

OUTPUT_FILE = Path("../reports/autonomous_report_schedule.txt")

schedule = """
SeungeFlow Autonomous Report Schedule

1. Run every 5 minutes:
   cd /opt/m7dq/kernel && python3 run_analysis_v6_0.py

2. Daily archive:
   0 0 * * * cd /opt/m7dq/kernel && python3 memory_snapshot_archiver.py

3. Weekly review:
   0 9 * * MON review hypothesis_verification.json and cross_domain_fusion_report.json
""".strip()

OUTPUT_FILE.write_text(schedule + "\n", encoding="utf-8")

print("autonomous report schedule generated")
