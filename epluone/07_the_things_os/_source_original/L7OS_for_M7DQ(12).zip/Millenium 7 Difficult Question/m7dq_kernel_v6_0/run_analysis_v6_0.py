import os

print("Running SeungeFlow Engine v6.0")

cmds = [
    "python3 run_analysis_v5_0.py",
    "python3 hypothesis_verifier.py",
    "python3 cross_domain_fusion_engine.py",
    "python3 autonomous_report_scheduler.py",
    "python3 memory_snapshot_archiver.py",
]

for c in cmds:
    print(">", c)
    os.system(c)

print("v6.0 complete")
