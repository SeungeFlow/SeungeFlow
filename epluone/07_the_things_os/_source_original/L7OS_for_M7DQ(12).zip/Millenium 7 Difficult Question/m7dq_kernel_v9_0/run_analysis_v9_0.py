
import os

print("Running SeungeFlow Engine v9.0")

cmds=[
"python3 run_analysis_v8_0.py",
"python3 global_state_engine.py",
"python3 multi_machine_cluster_controller.py",
"python3 knowledge_graph_builder.py",
"python3 autonomous_discovery_engine.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("v9.0 complete")
