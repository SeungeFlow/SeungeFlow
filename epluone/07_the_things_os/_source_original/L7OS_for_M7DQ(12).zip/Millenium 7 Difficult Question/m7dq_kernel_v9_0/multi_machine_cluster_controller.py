
import json
from pathlib import Path

LOG_DIR = Path("../logs")
OUTPUT = Path("../reports/cluster_controller.json")

nodes = []

for f in LOG_DIR.glob("*.log"):
    nodes.append({
        "node": f.name,
        "status": "active"
    })

report = {
    "cluster_nodes": nodes,
    "node_count": len(nodes)
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("cluster controller report generated")
