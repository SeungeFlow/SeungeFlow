
import json
from pathlib import Path

KG = Path("../reports/knowledge_graph.json")
OUTPUT = Path("../reports/discovery_report.json")

discoveries=[]

if KG.exists():
    with open(KG) as f:
        nodes=json.load(f).get("knowledge_nodes",[])

    for n in nodes:
        discoveries.append({
            "candidate": n.get("goal","unknown"),
            "domain": n.get("domain","unknown"),
            "status": "candidate_pattern"
        })

report={
    "discovery_candidates": discoveries,
    "count": len(discoveries)
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("autonomous discovery engine complete")
