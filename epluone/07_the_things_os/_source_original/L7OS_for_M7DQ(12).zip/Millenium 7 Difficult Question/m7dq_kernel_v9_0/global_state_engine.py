
import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "global_state.json"

state = {}

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p,"r") as f:
            return json.load(f)
    return {}

state["entropy"] = load("entropy_report.json")
state["density"] = load("network_density.json")
state["policies"] = load("policy_engine_report.json")
state["resources"] = load("resource_allocation_report.json")

with open(OUTPUT,"w") as f:
    json.dump(state,f,indent=2)

print("global state generated")
