
import json
from pathlib import Path

INPUT = Path("../reports/experiment_memory_graph.json")
OUTPUT = Path("../reports/knowledge_graph.json")

graph = []

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)
        graph=data.get("nodes",[])

knowledge = {
    "knowledge_nodes": graph,
    "node_count": len(graph)
}

with open(OUTPUT,"w") as f:
    json.dump(knowledge,f,indent=2)

print("knowledge graph generated")
