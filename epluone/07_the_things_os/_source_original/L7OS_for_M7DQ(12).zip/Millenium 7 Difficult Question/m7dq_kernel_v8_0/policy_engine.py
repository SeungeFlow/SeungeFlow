
import json
from pathlib import Path

INPUT = Path("../reports/meta_feedback_report.json")
OUTPUT = Path("../reports/policy_engine_report.json")

feedback = {}
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        feedback = json.load(f)

recs = feedback.get("recommendations", [])

policies = []
for r in recs:
    if "Promote" in r:
        policies.append({"policy": "promote_hypothesis", "priority": "high"})
    elif "Track queued experiments" in r:
        policies.append({"policy": "monitor_experiments", "priority": "medium"})
    else:
        policies.append({"policy": "continue_observation", "priority": "low"})

report = {
    "policy_count": len(policies),
    "policies": policies
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("policy engine complete")
