
import json
from pathlib import Path

INPUT = Path("../reports/experiment_orchestrator_report.json")
OUTPUT = Path("../reports/experiment_memory_graph.json")

experiments = []
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        experiments = json.load(f).get("experiments", [])

graph = []

for e in experiments:
    graph.append({
        "node": e["experiment_id"],
        "goal": e["goal"],
        "domain": e["target_domain"]
    })

report = {
    "node_count": len(graph),
    "nodes": graph
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("experiment memory graph generated")
