
import json
from pathlib import Path

INPUT = Path("../reports/policy_engine_report.json")
OUTPUT = Path("../reports/resource_allocation_report.json")

policies = []
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        policies = json.load(f).get("policies", [])

allocations = []
for i, p in enumerate(policies, start=1):
    allocations.append({
        "resource_id": f"RES-{i:03d}",
        "policy": p["policy"],
        "cpu_budget": "low" if p["priority"]=="low" else "medium" if p["priority"]=="medium" else "high"
    })

report = {
    "allocation_count": len(allocations),
    "allocations": allocations
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("resource allocation complete")
