
import os

print("Running SeungeFlow Engine v8.0")

cmds = [
"python3 run_analysis_v7_0.py",
"python3 policy_engine.py",
"python3 resource_allocator.py",
"python3 experiment_memory_graph.py",
"python3 mission_control_dashboard.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("v8.0 complete")
