
import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "mission_control_dashboard.md"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p,"r") as f:
            return json.load(f)
    return {}

policy = load("policy_engine_report.json")
resources = load("resource_allocation_report.json")
fusion = load("cross_domain_fusion_report.json")

lines = [
"# SeungeFlow Mission Control",
"",
"## Active Domains",
str(fusion.get("domains_present",{})),
"",
"## Policies",
str(policy.get("policies",[])),
"",
"## Resource Allocation",
str(resources.get("allocations",[])),
""
]

with open(OUTPUT,"w") as f:
    f.write("\n".join(lines))

print("mission control dashboard generated")
