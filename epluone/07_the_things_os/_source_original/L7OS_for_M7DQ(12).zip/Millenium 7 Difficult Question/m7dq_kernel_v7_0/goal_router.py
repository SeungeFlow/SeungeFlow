import json
from pathlib import Path

INPUT = Path("../reports/cross_domain_fusion_report.json")
OUTPUT = Path("../reports/goal_router_report.json")

fusion = {}
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        fusion = json.load(f)

domains = fusion.get("domains_present", {})
active = [k for k, v in domains.items() if v]

routes = []
for domain in active:
    if domain == "system":
        routes.append({"goal": "stability_analysis", "target_domain": domain})
    elif domain == "trading":
        routes.append({"goal": "strategy_pattern_review", "target_domain": domain})
    elif domain == "brain":
        routes.append({"goal": "cognitive_signal_review", "target_domain": domain})

report = {
    "active_domains": active,
    "route_count": len(routes),
    "routes": routes
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("goal router complete")
