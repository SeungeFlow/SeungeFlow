import os

print("Running SeungeFlow Engine v7.0")

cmds = [
    "python3 run_analysis_v6_0.py",
    "python3 goal_router.py",
    "python3 experiment_orchestrator.py",
    "python3 meta_feedback_loop.py",
    "python3 final_report_compiler.py",
]

for c in cmds:
    print(">", c)
    os.system(c)

print("v7.0 complete")
