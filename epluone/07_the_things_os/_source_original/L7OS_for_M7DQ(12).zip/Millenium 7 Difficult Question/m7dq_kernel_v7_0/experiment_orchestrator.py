import json
from pathlib import Path

INPUT = Path("../reports/goal_router_report.json")
OUTPUT = Path("../reports/experiment_orchestrator_report.json")

routes = []
if INPUT.exists():
    with open(INPUT, "r", encoding="utf-8") as f:
        routes = json.load(f).get("routes", [])

experiments = []
for i, route in enumerate(routes, start=1):
    experiments.append({
        "experiment_id": f"EXP-{i:03d}",
        "goal": route["goal"],
        "target_domain": route["target_domain"],
        "status": "queued"
    })

report = {
    "experiment_count": len(experiments),
    "experiments": experiments
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("experiment orchestrator complete")
