import json
from pathlib import Path

VERIFICATION = Path("../reports/hypothesis_verification.json")
EXPERIMENTS = Path("../reports/experiment_orchestrator_report.json")
OUTPUT = Path("../reports/meta_feedback_report.json")

verification = {}
experiments = {}

if VERIFICATION.exists():
    with open(VERIFICATION, "r", encoding="utf-8") as f:
        verification = json.load(f)

if EXPERIMENTS.exists():
    with open(EXPERIMENTS, "r", encoding="utf-8") as f:
        experiments = json.load(f)

verified = verification.get("verified_hypotheses", [])
queued = experiments.get("experiments", [])

high_conf = [h for h in verified if h.get("confidence", 0) >= 0.5]

feedback = {
    "high_confidence_hypotheses": len(high_conf),
    "queued_experiments": len(queued),
    "recommendations": []
}

if high_conf:
    feedback["recommendations"].append("Promote high-confidence hypotheses into active experiment review.")
if queued:
    feedback["recommendations"].append("Track queued experiments and compare outcomes with future anomaly shifts.")
if not high_conf and not queued:
    feedback["recommendations"].append("Insufficient signal. Continue observation loop.")

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(feedback, f, indent=2)

print("meta feedback loop complete")
