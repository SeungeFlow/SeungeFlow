import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "final_research_report.md"

def load(name):
    path = REPORT_DIR / name
    if not path.exists():
        return {}
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

goal_router = load("goal_router_report.json")
orchestrator = load("experiment_orchestrator_report.json")
feedback = load("meta_feedback_report.json")
verification = load("hypothesis_verification.json")
fusion = load("cross_domain_fusion_report.json")

lines = [
    "# SeungeFlow Final Research Report",
    "",
    "## Goal Routing",
    f"- active_domains: {goal_router.get('active_domains', [])}",
    f"- route_count: {goal_router.get('route_count', 0)}",
    "",
    "## Experiment Orchestration",
    f"- experiment_count: {orchestrator.get('experiment_count', 0)}",
    "",
    "## Hypothesis Verification",
    f"- hypothesis_count: {verification.get('hypothesis_count', 0)}",
    "",
    "## Cross Domain Fusion",
    f"- summary: {fusion.get('summary', '')}",
    "",
    "## Meta Feedback",
    f"- recommendations: {feedback.get('recommendations', [])}",
    ""
]

with open(OUTPUT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("final research report compiled")
