Kernel v7.0

Adds
- goal_router.py
- experiment_orchestrator.py
- meta_feedback_loop.py
- final_report_compiler.py
- run_analysis_v7_0.py

Purpose
- route active domains into goal tracks
- queue experiments from routed goals
- generate meta feedback from verification plus experiment state
- compile a final research-facing report

Run
cd /opt/m7dq/kernel
python3 run_analysis_v7_0.py

Key outputs
- ../reports/goal_router_report.json
- ../reports/experiment_orchestrator_report.json
- ../reports/meta_feedback_report.json
- ../reports/final_research_report.md
