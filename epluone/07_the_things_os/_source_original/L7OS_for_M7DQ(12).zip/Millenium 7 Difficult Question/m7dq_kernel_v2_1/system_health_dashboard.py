
import os

BASE="/opt/m7dq"

dirs=[
"kernel",
"logs",
"reports",
"systems"
]

print("System Health")

for d in dirs:
    path=os.path.join(BASE,d)
    if os.path.exists(path):
        print("[OK]",path)
    else:
        print("[MISSING]",path)
