
import json
from pathlib import Path

PHASE_FILE = Path("../reports/phase_transition_report.json")

if not PHASE_FILE.exists():
    print("No phase transition report")
    exit()

with open(PHASE_FILE) as f:
    data = json.load(f)

alerts = data.get("alerts",[])

if not alerts:
    print("No alerts")
else:
    print("ALERT: phase transition detected")
    for a in alerts:
        print(a)
