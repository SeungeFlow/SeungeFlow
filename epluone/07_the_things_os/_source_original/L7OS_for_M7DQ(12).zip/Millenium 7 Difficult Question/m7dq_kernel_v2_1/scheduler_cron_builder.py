
import os

CRON_LINE = "*/5 * * * * cd /opt/m7dq/kernel && python3 run_analysis_v2_0.py\n"

cron_file = "/tmp/m7dq_cron"

with open(cron_file, "w") as f:
    f.write(CRON_LINE)

print("Cron template created at:", cron_file)
print("Install with: crontab /tmp/m7dq_cron")
