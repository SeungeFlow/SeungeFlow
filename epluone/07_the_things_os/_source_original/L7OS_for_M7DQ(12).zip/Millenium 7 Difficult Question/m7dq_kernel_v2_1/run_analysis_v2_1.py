
import os

print("Running SeungeFlow Engine v2.1")

cmds=[
"python3 run_analysis_v2_0.py",
"python3 html_report_generator.py",
"python3 alert_dispatcher.py",
"python3 system_health_dashboard.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("v2.1 analysis complete")
