
Kernel v2.1

Adds

scheduler_cron_builder.py
html_report_generator.py
alert_dispatcher.py
system_health_dashboard.py

Purpose

automatic scheduling
HTML dashboard
alert system
system health monitor

Run

cd /opt/m7dq/kernel
python3 run_analysis_v2_1.py
