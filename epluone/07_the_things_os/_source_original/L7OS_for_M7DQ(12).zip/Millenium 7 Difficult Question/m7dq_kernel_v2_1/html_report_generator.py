
import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "dashboard.html"

def load(name):
    p = REPORT_DIR / name
    if p.exists():
        with open(p,"r") as f:
            return json.load(f)
    return {}

entropy = load("entropy_report.json")
density = load("network_density.json")
centrality = load("centrality_report.json")
anomaly = load("anomaly_score.json")

html = f"""
<html>
<head>
<title>SeungeFlow Dashboard</title>
<style>
body {{ font-family: Arial; margin:40px }}
h2 {{ border-bottom:1px solid #ccc }}
</style>
</head>
<body>

<h1>SeungeFlow Engine Report</h1>

<h2>Entropy</h2>
<pre>{entropy}</pre>

<h2>Network Density</h2>
<pre>{density}</pre>

<h2>Centrality</h2>
<pre>{centrality}</pre>

<h2>Anomaly</h2>
<pre>{anomaly}</pre>

</body>
</html>
"""

with open(OUTPUT,"w") as f:
    f.write(html)

print("HTML dashboard generated:", OUTPUT)
