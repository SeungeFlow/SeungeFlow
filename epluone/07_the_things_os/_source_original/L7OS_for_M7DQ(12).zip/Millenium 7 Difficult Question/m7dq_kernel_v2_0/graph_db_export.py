import json
from pathlib import Path

INPUT_FILE = Path("../reports/process_graph.json")
OUTPUT_FILE = Path("../reports/graph_db_export.jsonl")

if not INPUT_FILE.exists():
    raise FileNotFoundError("process_graph.json not found. Run process_graph_generator.py first.")

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    graph = json.load(f)

nodes = set()
for edge in graph:
    nodes.add(edge["from"])
    nodes.add(edge["to"])

with open(OUTPUT_FILE, "w", encoding="utf-8") as out:
    for n in sorted(nodes):
        out.write(json.dumps({"type": "node", "id": n, "label": "Process"}) + "\n")
    for edge in graph:
        out.write(json.dumps({
            "type": "edge",
            "from": edge["from"],
            "to": edge["to"],
            "label": "FLOWS_TO",
            "weight": edge.get("weight", 1)
        }) + "\n")

print("graph db export created")
