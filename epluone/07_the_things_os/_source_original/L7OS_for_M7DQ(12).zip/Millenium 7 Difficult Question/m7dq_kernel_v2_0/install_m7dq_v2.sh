#!/bin/bash
set -e

echo "Installing SeungeFlow Engine v2.0"

sudo mkdir -p /opt/m7dq/kernel
sudo mkdir -p /opt/m7dq/logs
sudo mkdir -p /opt/m7dq/reports
sudo mkdir -p /opt/m7dq/systems

for d in navier_stokes p_vs_np yang_mills hodge birch_swinnerton_dyer riemann poincare
do
  sudo mkdir -p /opt/m7dq/systems/$d
done

echo "Directory skeleton ready:"
echo "/opt/m7dq/{kernel,logs,reports,systems}"
