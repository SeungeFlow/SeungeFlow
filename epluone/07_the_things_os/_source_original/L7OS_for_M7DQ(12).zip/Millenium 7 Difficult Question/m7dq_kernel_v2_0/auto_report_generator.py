import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT_FILE = REPORT_DIR / "auto_report.md"

def load_json(name):
    path = REPORT_DIR / name
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

entropy = load_json("entropy_report.json")
density = load_json("network_density.json")
centrality = load_json("centrality_report.json")
phase = load_json("phase_transition_report.json")
anomaly = load_json("anomaly_score.json")
realtime = load_json("realtime_state.json")

lines = ["# SeungeFlow Auto Report", ""]

if entropy:
    lines += [
        "## Entropy",
        f"- total_events: {entropy.get('total_events')}",
        f"- unique_processes: {entropy.get('unique_processes')}",
        f"- entropy: {entropy.get('entropy')}",
        ""
    ]

if density:
    lines += [
        "## Network Density",
        f"- nodes: {density.get('nodes')}",
        f"- observed_unique_edges: {density.get('observed_unique_edges')}",
        f"- possible_directed_edges: {density.get('possible_directed_edges')}",
        f"- density: {density.get('density')}",
        ""
    ]

if centrality:
    lines += [
        "## Centrality",
        f"- total_nodes: {centrality.get('total_nodes')}",
        f"- top_out_degree: {centrality.get('top_out_degree', [])[:5]}",
        f"- top_in_degree: {centrality.get('top_in_degree', [])[:5]}",
        ""
    ]

if phase:
    lines += [
        "## Phase Transition",
        f"- window_count: {phase.get('window_count')}",
        f"- alert_count: {len(phase.get('alerts', []))}",
        ""
    ]

if anomaly:
    scores = anomaly.get("anomaly_scores", {})
    top_anomalies = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:10]
    lines += [
        "## Anomaly Scores",
        f"- top_anomalies: {top_anomalies}",
        ""
    ]

if realtime:
    lines += [
        "## Realtime Snapshot",
        f"- recent_event_count: {realtime.get('recent_event_count')}",
        f"- top_processes: {realtime.get('top_processes', [])[:5]}",
        ""
    ]

if len(lines) <= 2:
    lines += ["No input reports found. Run the analysis pipeline first.", ""]

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("auto report generated")
