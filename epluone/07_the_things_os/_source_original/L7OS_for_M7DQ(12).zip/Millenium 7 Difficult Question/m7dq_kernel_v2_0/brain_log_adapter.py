import json
from collections import Counter
from pathlib import Path

INPUT_FILE = Path("../logs/brain.log")
OUTPUT_FILE = Path("../reports/brain_log_report.json")

if not INPUT_FILE.exists():
    sample = {
        "status": "missing",
        "message": "brain.log not found",
        "expected_format": "timestamp|tag|value"
    }
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(sample, f, indent=2)
    print("brain log missing report generated")
    raise SystemExit(0)

tags = Counter()
rows = 0

with open(INPUT_FILE, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        parts = [p.strip() for p in line.strip().split("|")]
        if len(parts) < 3:
            continue
        _, tag, _ = parts[:3]
        tags[tag] += 1
        rows += 1

report = {
    "rows": rows,
    "top_tags": tags.most_common(20)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("brain log report generated")
