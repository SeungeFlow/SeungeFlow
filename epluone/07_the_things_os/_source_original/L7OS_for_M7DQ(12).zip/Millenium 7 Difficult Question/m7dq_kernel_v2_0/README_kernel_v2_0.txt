Kernel v2.0 package

Concept
- Linux log analysis expands into SeungeFlow Engine
- Supports structure analysis, topology export, automatic reporting
- Adapters prepared for trading logs and brain logs

New files
- realtime_log_stream_analyzer.py
- graph_db_export.py
- auto_report_generator.py
- trading_log_adapter.py
- brain_log_adapter.py
- run_analysis_v2_0.py
- install_m7dq_v2.sh

Required existing files from previous versions
- process_graph_generator.py
- entropy_monitor.py
- network_density.py
- centrality_detector.py
- phase_transition_detector.py
- anomaly_score.py
- time_window_flow_map.py
- graph_visualizer.py

Recommended layout
/opt/m7dq
  kernel/
  logs/
    raw.log
    trading.log
    brain.log
  reports/
  systems/

Run
cd /opt/m7dq/kernel
python3 run_analysis_v2_0.py

Main outputs
- ../reports/realtime_state.json
- ../reports/graph_db_export.jsonl
- ../reports/auto_report.md
- ../reports/trading_log_report.json
- ../reports/brain_log_report.json
