import re
import json
import time
from collections import Counter, defaultdict, deque

LOG_FILE = "../logs/raw.log"
STATE_FILE = "../reports/realtime_state.json"
POLL_INTERVAL = 2.0
MAX_EVENTS = 200

process_pattern = re.compile(r'(\w+)\[\d+\]')

def analyze_recent(lines):
    processes = []
    edges = defaultdict(int)

    prev = None
    for line in lines:
        m = process_pattern.search(line)
        if not m:
            continue
        p = m.group(1)
        processes.append(p)
        if prev is not None:
            edges[(prev, p)] += 1
        prev = p

    freq = Counter(processes)
    return {
        "recent_event_count": len(processes),
        "top_processes": freq.most_common(10),
        "recent_edges": [
            {"from": a, "to": b, "weight": w}
            for (a, b), w in sorted(edges.items(), key=lambda x: x[1], reverse=True)[:20]
        ]
    }

def main():
    with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
        lines = deque(f.readlines()[-MAX_EVENTS:], maxlen=MAX_EVENTS)

    report = {
        "mode": "snapshot_tail",
        "poll_interval_seconds": POLL_INTERVAL,
        **analyze_recent(list(lines))
    }

    with open(STATE_FILE, "w", encoding="utf-8") as out:
        json.dump(report, out, indent=2)

    print("realtime snapshot updated")

if __name__ == "__main__":
    main()
