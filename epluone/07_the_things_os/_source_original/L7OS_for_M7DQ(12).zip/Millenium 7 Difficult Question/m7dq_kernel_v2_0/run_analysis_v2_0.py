import os

print("Running SeungeFlow Engine v2.0")

commands = [
    "python3 process_graph_generator.py",
    "python3 entropy_monitor.py",
    "python3 network_density.py",
    "python3 centrality_detector.py",
    "python3 phase_transition_detector.py",
    "python3 anomaly_score.py",
    "python3 time_window_flow_map.py",
    "python3 graph_visualizer.py",
    "python3 realtime_log_stream_analyzer.py",
    "python3 graph_db_export.py",
    "python3 auto_report_generator.py",
    "python3 trading_log_adapter.py",
    "python3 brain_log_adapter.py",
]

for cmd in commands:
    print(">", cmd)
    rc = os.system(cmd)
    if rc != 0:
        print("warning:", cmd, "returned", rc)

print("SeungeFlow Engine v2.0 complete")
