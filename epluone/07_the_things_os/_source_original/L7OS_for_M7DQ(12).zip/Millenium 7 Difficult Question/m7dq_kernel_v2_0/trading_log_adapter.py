import json
from collections import Counter
from pathlib import Path

INPUT_FILE = Path("../logs/trading.log")
OUTPUT_FILE = Path("../reports/trading_log_report.json")

if not INPUT_FILE.exists():
    sample = {
        "status": "missing",
        "message": "trading.log not found",
        "expected_format": "timestamp,symbol,side,status"
    }
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(sample, f, indent=2)
    print("trading log missing report generated")
    raise SystemExit(0)

symbols = Counter()
sides = Counter()
statuses = Counter()
rows = 0

with open(INPUT_FILE, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        parts = [p.strip() for p in line.strip().split(",")]
        if len(parts) < 4:
            continue
        _, symbol, side, status = parts[:4]
        symbols[symbol] += 1
        sides[side] += 1
        statuses[status] += 1
        rows += 1

report = {
    "rows": rows,
    "top_symbols": symbols.most_common(10),
    "side_distribution": sides,
    "status_distribution": statuses
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("trading log report generated")
