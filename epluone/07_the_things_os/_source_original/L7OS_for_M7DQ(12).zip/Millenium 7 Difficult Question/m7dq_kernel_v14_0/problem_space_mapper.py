
import json
from pathlib import Path

INPUT = Path("../reports/curiosity_priorities.json")
OUTPUT = Path("../reports/problem_space_map.json")

space = []

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for p in data.get("priorities",[]):
        space.append({
            "problem": p["question"],
            "exploration_status": "unexplored"
        })

report={
"problem_count":len(space),
"problem_space":space
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("problem space mapping complete")
