
import json
from pathlib import Path

INPUT = Path("../reports/problem_space_map.json")
OUTPUT = Path("../reports/discovery_plan.json")

plan=[]

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for i,p in enumerate(data.get("problem_space",[])[:10],start=1):
        plan.append({
            "task_id":f"DISC-{i:03d}",
            "objective":p["problem"],
            "status":"planned"
        })

report={
"planned_tasks":len(plan),
"tasks":plan
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("next discovery plan created")
