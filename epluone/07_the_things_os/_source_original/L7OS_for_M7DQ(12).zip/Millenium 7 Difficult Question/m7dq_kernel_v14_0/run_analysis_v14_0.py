
import os

print("Running SeungeFlow Curiosity Engine v14.0")

steps=[
"python3 run_universal_pipeline.py",
"python3 question_generator.py",
"python3 curiosity_engine.py",
"python3 problem_space_mapper.py",
"python3 next_discovery_planner.py"
]

for s in steps:
    print(">",s)
    os.system(s)

print("curiosity cycle complete")
