
import json
from pathlib import Path

INPUT = Path("../reports/universal_routing.json")
OUTPUT = Path("../reports/generated_questions.json")

questions = []

if INPUT.exists():
    with open(INPUT) as f:
        routes = json.load(f).get("routes", [])

    for r in routes:
        pipe = r.get("pipeline")
        file = r.get("file")

        if pipe == "system_analysis":
            q = f"What structural anomaly patterns exist in {file}?"
        elif pipe == "trading_analysis":
            q = f"What repeating market behaviors appear in {file}?"
        elif pipe == "cognitive_analysis":
            q = f"What cognitive signal patterns emerge from {file}?"
        elif pipe == "research_analysis":
            q = f"What hypotheses can be derived from {file}?"
        else:
            q = f"What hidden patterns might exist in {file}?"

        questions.append({
            "source": file,
            "question": q
        })

report = {
    "question_count": len(questions),
    "questions": questions
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("question generation complete")
