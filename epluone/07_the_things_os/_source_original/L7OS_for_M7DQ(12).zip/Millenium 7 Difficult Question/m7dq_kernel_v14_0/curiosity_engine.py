
import json
from pathlib import Path

INPUT = Path("../reports/generated_questions.json")
OUTPUT = Path("../reports/curiosity_priorities.json")

priorities = []

if INPUT.exists():
    with open(INPUT) as f:
        data = json.load(f)

    for i,q in enumerate(data.get("questions",[]),start=1):
        priorities.append({
            "priority_rank": i,
            "question": q["question"],
            "curiosity_score": round(1.0/(i),4)
        })

report = {
    "priority_count": len(priorities),
    "priorities": priorities
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("curiosity prioritization complete")
