
Kernel v14.0

Curiosity Engine

Modules
question_generator.py
curiosity_engine.py
problem_space_mapper.py
next_discovery_planner.py

Purpose

Generate research questions automatically
Rank questions by curiosity priority
Map unexplored problem space
Plan next discovery tasks

Run

cd /opt/m7dq/kernel
python3 run_analysis_v14_0.py

Outputs

generated_questions.json
curiosity_priorities.json
problem_space_map.json
discovery_plan.json
