import re
import math
import json
from collections import Counter

log_file = "../logs/raw.log"

process_pattern = re.compile(r'(\w+)\[\d+\]')

processes = []

with open(log_file) as f:
    for line in f:
        m = process_pattern.search(line)
        if m:
            processes.append(m.group(1))

freq = Counter(processes)

total = sum(freq.values())

entropy = -sum((c/total)*math.log2(c/total) for c in freq.values())

report = {
    "total_events": total,
    "unique_processes": len(freq),
    "entropy": entropy
}

with open("../reports/entropy_report.json","w") as f:
    json.dump(report,f,indent=2)

print("entropy:",entropy)