import re
import json
from collections import defaultdict

log_file = "../logs/raw.log"

process_pattern = re.compile(r'(\w+)\[\d+\]')

edges = defaultdict(int)

with open(log_file) as f:
    prev = None
    for line in f:
        m = process_pattern.search(line)
        if not m:
            continue
        process = m.group(1)

        if prev:
            edges[(prev, process)] += 1

        prev = process

graph = []

for (a,b),count in edges.items():
    graph.append({
        "from": a,
        "to": b,
        "weight": count
    })

with open("../reports/process_graph.json","w") as f:
    json.dump(graph,f,indent=2)

print("process graph generated")