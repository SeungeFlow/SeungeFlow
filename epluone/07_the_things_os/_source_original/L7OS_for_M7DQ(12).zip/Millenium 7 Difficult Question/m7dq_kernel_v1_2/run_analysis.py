import os

print("Running SeungeFlow Structure Interpreter")

os.system("python3 process_graph_generator.py")
os.system("python3 entropy_monitor.py")

print("analysis complete")