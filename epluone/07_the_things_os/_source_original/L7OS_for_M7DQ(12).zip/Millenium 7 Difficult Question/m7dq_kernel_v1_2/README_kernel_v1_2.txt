Kernel v1.2 structure

kernel/
  process_graph_generator.py
  entropy_monitor.py
  run_analysis.py

logs/
  raw.log

reports/
  process_graph.json
  entropy_report.json

Run:
cd kernel
python3 run_analysis.py