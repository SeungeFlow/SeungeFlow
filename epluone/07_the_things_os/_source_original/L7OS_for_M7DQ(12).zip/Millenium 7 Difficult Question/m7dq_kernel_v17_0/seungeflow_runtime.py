import os
import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "runtime_status.json"

steps = [
    "python3 seungeflow_core_engine.py",
    "python3 system_introspection_engine.py",
    "python3 unified_graph_brain.py",
    "python3 infinite_research_loop.py",
]

executed = []
for step in steps:
    rc = os.system(step)
    executed.append({"step": step, "return_code": rc})

report = {
    "runtime": "SeungeFlow Master Runtime v17.0",
    "executed_steps": executed,
    "step_count": len(executed)
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("seungeflow runtime complete")
