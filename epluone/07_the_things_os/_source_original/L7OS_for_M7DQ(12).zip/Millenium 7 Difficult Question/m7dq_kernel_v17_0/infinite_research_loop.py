import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "infinite_research_loop.json"

loop = {
    "cycle": [
        "observe",
        "learn",
        "hypothesize",
        "verify",
        "discover",
        "synthesize",
        "review",
        "publish",
        "ask_new_questions"
    ],
    "loop_state": "ready",
    "next_action": "observe"
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(loop, f, indent=2)

print("infinite research loop ready")
