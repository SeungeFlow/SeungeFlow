import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "system_introspection.json"

targets = [
    "global_state.json",
    "knowledge_evolution.json",
    "publication_draft.md",
    "final_research_report.md",
    "mission_control_dashboard.md",
]

status = []
for name in targets:
    p = REPORT_DIR / name
    status.append({
        "artifact": name,
        "present": p.exists()
    })

report = {
    "artifact_checks": status,
    "present_count": sum(1 for s in status if s["present"]),
    "missing_count": sum(1 for s in status if not s["present"])
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("system introspection complete")
