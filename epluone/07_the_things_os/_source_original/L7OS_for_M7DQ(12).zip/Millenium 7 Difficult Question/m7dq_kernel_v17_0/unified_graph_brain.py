import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "unified_graph_brain.json"

def load_json(name):
    p = REPORT_DIR / name
    if not p.exists():
        return {}
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

knowledge = load_json("knowledge_graph.json")
memory = load_json("experiment_memory_graph.json")
questions = load_json("question_dependency_graph.json")

brain = {
    "knowledge_nodes": knowledge.get("node_count", 0),
    "memory_nodes": memory.get("node_count", 0),
    "question_nodes": questions.get("node_count", 0),
    "brain_state": "integrated"
}

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(brain, f, indent=2)

print("unified graph brain complete")
