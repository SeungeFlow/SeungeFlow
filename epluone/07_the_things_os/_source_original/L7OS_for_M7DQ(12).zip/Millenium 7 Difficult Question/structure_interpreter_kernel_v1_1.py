#!/usr/bin/env python3
"""
Structure Interpreter Kernel v1.1

Reads a Linux-style log file, extracts process occurrences, builds a simple
process-to-process interaction graph from sequential log appearance,
computes process frequency, Shannon entropy, basic flow density,
and detects simple anomalies such as sudden bursts.

Usage:
    python3 structure_interpreter_kernel_v1_1.py raw.log
    python3 structure_interpreter_kernel_v1_1.py /path/to/raw.log --json

Outputs:
    - Console summary
    - Optional JSON summary when --json is used
"""

from __future__ import annotations

import argparse
import json
import math
import re
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Deque, Dict, Iterable, List, Optional, Tuple

# Common syslog timestamp prefix, e.g. "Mar  9 20:31:05"
TIMESTAMP_RE = re.compile(r"^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<hms>\d{2}:\d{2}:\d{2})")
# Process name like: sshd[1234], bash[22], CRON[999]
PROCESS_RE = re.compile(r"(?P<proc>[A-Za-z0-9_.@+\-/]+)\[(?P<pid>\d+)\]")

MONTHS = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4,
    "May": 5, "Jun": 6, "Jul": 7, "Aug": 8,
    "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
}


@dataclass
class Event:
    line_no: int
    timestamp: Optional[datetime]
    process: str
    pid: str
    raw: str


@dataclass
class BurstAnomaly:
    process: str
    count_in_window: int
    window_seconds: int
    first_line: int
    last_line: int


@dataclass
class MissingFileAnomaly:
    process: str
    line_no: int
    detail: str


def parse_timestamp(line: str, year: Optional[int] = None) -> Optional[datetime]:
    match = TIMESTAMP_RE.search(line)
    if not match:
        return None
    year = year or datetime.now().year
    mon = MONTHS[match.group("mon")]
    day = int(match.group("day"))
    h, m, s = map(int, match.group("hms").split(":"))
    try:
        return datetime(year, mon, day, h, m, s)
    except ValueError:
        return None


def parse_events(log_path: Path, year: Optional[int] = None) -> List[Event]:
    events: List[Event] = []
    with log_path.open("r", encoding="utf-8", errors="replace") as f:
        for line_no, line in enumerate(f, start=1):
            match = PROCESS_RE.search(line)
            if not match:
                continue
            events.append(
                Event(
                    line_no=line_no,
                    timestamp=parse_timestamp(line, year=year),
                    process=match.group("proc"),
                    pid=match.group("pid"),
                    raw=line.rstrip("\n"),
                )
            )
    return events


def build_process_graph(events: Iterable[Event]) -> Dict[Tuple[str, str], int]:
    edges: Dict[Tuple[str, str], int] = defaultdict(int)
    prev: Optional[Event] = None
    for event in events:
        if prev is not None:
            edges[(prev.process, event.process)] += 1
        prev = event
    return dict(edges)


def compute_entropy(freq: Counter) -> float:
    total = sum(freq.values())
    if total == 0:
        return 0.0
    return -sum((count / total) * math.log2(count / total) for count in freq.values())


def compute_flow_density(events: List[Event], edge_count: int) -> Dict[str, float]:
    timestamps = [e.timestamp for e in events if e.timestamp is not None]
    if len(timestamps) < 2:
        return {
            "interaction_count": float(edge_count),
            "duration_seconds": 0.0,
            "flow_density": 0.0,
        }

    duration_seconds = max((max(timestamps) - min(timestamps)).total_seconds(), 0.0)
    density = edge_count / duration_seconds if duration_seconds > 0 else 0.0
    return {
        "interaction_count": float(edge_count),
        "duration_seconds": float(duration_seconds),
        "flow_density": float(density),
    }


def detect_bursts(events: List[Event], window_seconds: int = 60, threshold: int = 5) -> List[BurstAnomaly]:
    queues: Dict[str, Deque[Event]] = defaultdict(deque)
    anomalies: List[BurstAnomaly] = []

    for event in events:
        if event.timestamp is None:
            continue
        q = queues[event.process]
        q.append(event)

        while q and (event.timestamp - q[0].timestamp).total_seconds() > window_seconds:
            q.popleft()

        if len(q) >= threshold:
            anomalies.append(
                BurstAnomaly(
                    process=event.process,
                    count_in_window=len(q),
                    window_seconds=window_seconds,
                    first_line=q[0].line_no,
                    last_line=q[-1].line_no,
                )
            )
            q.clear()

    return anomalies


def detect_missing_file_anomalies(events: List[Event]) -> List[MissingFileAnomaly]:
    anomalies: List[MissingFileAnomaly] = []
    keywords = (
        "No such file",
        "not found",
        "can't open file",
        "cannot open",
    )
    for event in events:
        if any(keyword.lower() in event.raw.lower() for keyword in keywords):
            anomalies.append(
                MissingFileAnomaly(
                    process=event.process,
                    line_no=event.line_no,
                    detail=event.raw.strip(),
                )
            )
    return anomalies


def build_summary(events: List[Event]) -> Dict[str, object]:
    freq = Counter(event.process for event in events)
    edges = build_process_graph(events)
    edge_counter = Counter(edges)
    entropy = compute_entropy(freq)
    flow_density = compute_flow_density(events, edge_count=sum(edges.values()))
    burst_anomalies = detect_bursts(events)
    missing_file_anomalies = detect_missing_file_anomalies(events)

    top_edges = [
        {"from": src, "to": dst, "count": count}
        for (src, dst), count in edge_counter.most_common(15)
    ]

    return {
        "event_count": len(events),
        "unique_process_count": len(freq),
        "top_processes": freq.most_common(15),
        "entropy": entropy,
        "flow_density": flow_density,
        "top_edges": top_edges,
        "anomalies": {
            "bursts": [asdict(a) for a in burst_anomalies[:20]],
            "missing_file": [asdict(a) for a in missing_file_anomalies[:20]],
        },
    }


def print_summary(summary: Dict[str, object]) -> None:
    print("=" * 64)
    print("Structure Interpreter Kernel v1.1")
    print("=" * 64)
    print(f"Total events          : {summary['event_count']}")
    print(f"Unique processes      : {summary['unique_process_count']}")
    print(f"Entropy               : {summary['entropy']:.6f}")

    fd = summary["flow_density"]
    print(f"Interactions          : {int(fd['interaction_count'])}")
    print(f"Duration (seconds)    : {fd['duration_seconds']:.2f}")
    print(f"Flow density          : {fd['flow_density']:.6f}")

    print("\nTop processes")
    print("-" * 64)
    for proc, count in summary["top_processes"]:
        print(f"{proc:<28} {count:>8}")

    print("\nTop edges")
    print("-" * 64)
    for edge in summary["top_edges"]:
        print(f"{edge['from']:<20} -> {edge['to']:<20} {edge['count']:>6}")

    print("\nAnomalies")
    print("-" * 64)
    bursts = summary["anomalies"]["bursts"]
    missing = summary["anomalies"]["missing_file"]
    print(f"Burst anomalies       : {len(bursts)}")
    print(f"Missing-file anomalies: {len(missing)}")

    if missing:
        print("\nSample missing-file anomalies")
        print("-" * 64)
        for item in missing[:5]:
            print(f"line {item['line_no']}: {item['process']} | {item['detail']}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Structure Interpreter Kernel v1.1")
    parser.add_argument("logfile", nargs="?", default="raw.log", help="Path to log file")
    parser.add_argument("--year", type=int, default=None, help="Year to use for syslog timestamps")
    parser.add_argument("--json", action="store_true", help="Print JSON summary")
    parser.add_argument("--save-json", default=None, help="Save JSON summary to path")
    args = parser.parse_args()

    log_path = Path(args.logfile)
    if not log_path.exists():
        raise SystemExit(f"Log file not found: {log_path}")

    events = parse_events(log_path, year=args.year)
    summary = build_summary(events)

    if args.json:
        print(json.dumps(summary, indent=2, ensure_ascii=False))
    else:
        print_summary(summary)

    if args.save_json:
        out_path = Path(args.save_json)
        out_path.write_text(json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()
