Kernel v1.3 package

Required existing files:
- process_graph_generator.py
- entropy_monitor.py

New files:
- network_density.py
- centrality_detector.py
- phase_transition_detector.py
- graph_visualizer.py
- run_analysis_v1_3.py

Recommended layout:
/opt/m7dq
  kernel/
    process_graph_generator.py
    entropy_monitor.py
    network_density.py
    centrality_detector.py
    phase_transition_detector.py
    graph_visualizer.py
    run_analysis_v1_3.py
  logs/
    raw.log
  reports/

Run:
cd /opt/m7dq/kernel
python3 run_analysis_v1_3.py

Outputs:
- ../reports/network_density.json
- ../reports/centrality_report.json
- ../reports/phase_transition_report.json
- ../reports/process_graph_mermaid.md
