import os

print("Running SeungeFlow Structure Interpreter v1.3")

commands = [
    "python3 process_graph_generator.py",
    "python3 entropy_monitor.py",
    "python3 network_density.py",
    "python3 centrality_detector.py",
    "python3 phase_transition_detector.py",
    "python3 graph_visualizer.py",
]

for cmd in commands:
    print(">", cmd)
    rc = os.system(cmd)
    if rc != 0:
        print("warning: command failed:", cmd)

print("analysis complete")
