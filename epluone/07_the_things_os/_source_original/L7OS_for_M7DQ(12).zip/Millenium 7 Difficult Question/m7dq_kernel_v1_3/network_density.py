import re
import json
from collections import defaultdict

LOG_FILE = "../logs/raw.log"
OUTPUT_FILE = "../reports/network_density.json"

process_pattern = re.compile(r'(\w+)\[\d+\]')

nodes = set()
edges = defaultdict(int)
total_interactions = 0

with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
    prev = None
    for line in f:
        m = process_pattern.search(line)
        if not m:
            continue

        process = m.group(1)
        nodes.add(process)

        if prev is not None:
            edges[(prev, process)] += 1
            total_interactions += 1

        prev = process

n = len(nodes)
possible_directed_edges = n * (n - 1) if n > 1 else 0
observed_unique_edges = len(edges)
density = (observed_unique_edges / possible_directed_edges) if possible_directed_edges else 0.0

report = {
    "nodes": n,
    "observed_unique_edges": observed_unique_edges,
    "possible_directed_edges": possible_directed_edges,
    "density": density,
    "total_interactions": total_interactions
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("network density:", density)
