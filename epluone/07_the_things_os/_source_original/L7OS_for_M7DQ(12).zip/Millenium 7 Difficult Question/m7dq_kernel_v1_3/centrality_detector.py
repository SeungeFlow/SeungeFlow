import re
import json
from collections import Counter, defaultdict

LOG_FILE = "../logs/raw.log"
OUTPUT_FILE = "../reports/centrality_report.json"

process_pattern = re.compile(r'(\w+)\[\d+\]')

in_degree = Counter()
out_degree = Counter()
weighted_out = Counter()
weighted_in = Counter()
nodes = set()

with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
    prev = None
    for line in f:
        m = process_pattern.search(line)
        if not m:
            continue

        process = m.group(1)
        nodes.add(process)

        if prev is not None:
            out_degree[prev] += 1
            in_degree[process] += 1
            weighted_out[prev] += 1
            weighted_in[process] += 1

        prev = process

report = {
    "top_out_degree": out_degree.most_common(10),
    "top_in_degree": in_degree.most_common(10),
    "top_weighted_out": weighted_out.most_common(10),
    "top_weighted_in": weighted_in.most_common(10),
    "total_nodes": len(nodes)
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("centrality report generated")
