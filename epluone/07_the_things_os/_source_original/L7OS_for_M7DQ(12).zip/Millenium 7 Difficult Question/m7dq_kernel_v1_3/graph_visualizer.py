import json
from pathlib import Path

INPUT_FILE = Path("../reports/process_graph.json")
OUTPUT_FILE = Path("../reports/process_graph_mermaid.md")

if not INPUT_FILE.exists():
    raise FileNotFoundError("process_graph.json not found. Run process_graph_generator.py first.")

with open(INPUT_FILE, "r", encoding="utf-8") as f:
    graph = json.load(f)

lines = ["```mermaid", "graph LR"]

for edge in graph:
    src = edge["from"].replace("-", "_")
    dst = edge["to"].replace("-", "_")
    weight = edge.get("weight", 1)
    lines.append(f'    {src} -->|{weight}| {dst}')

lines.append("```")

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    f.write("\n".join(lines) + "\n")

print("graph visualization markdown generated")
