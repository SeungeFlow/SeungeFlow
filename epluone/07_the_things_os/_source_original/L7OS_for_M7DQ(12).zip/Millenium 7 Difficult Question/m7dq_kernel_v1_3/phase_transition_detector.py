import re
import json
from collections import Counter

LOG_FILE = "../logs/raw.log"
OUTPUT_FILE = "../reports/phase_transition_report.json"

process_pattern = re.compile(r'(\w+)\[\d+\]')
timestamp_pattern = re.compile(r'^([A-Z][a-z]{2}\s+\d+\s+\d+:\d+:\d+)')

WINDOW_SIZE = 50

processes = []
timestamps = []

with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        pm = process_pattern.search(line)
        if not pm:
            continue
        processes.append(pm.group(1))
        tm = timestamp_pattern.search(line)
        timestamps.append(tm.group(1) if tm else None)

windows = []
for start in range(0, len(processes), WINDOW_SIZE):
    chunk = processes[start:start + WINDOW_SIZE]
    if not chunk:
        continue

    freq = Counter(chunk)
    dominant_process, dominant_count = freq.most_common(1)[0]
    diversity = len(freq)
    dominance_ratio = dominant_count / len(chunk)

    windows.append({
        "window_index": len(windows),
        "start_event": start,
        "end_event": start + len(chunk) - 1,
        "start_time_hint": timestamps[start] if start < len(timestamps) else None,
        "end_time_hint": timestamps[min(start + len(chunk) - 1, len(timestamps) - 1)] if timestamps else None,
        "dominant_process": dominant_process,
        "dominance_ratio": dominance_ratio,
        "diversity": diversity,
        "event_count": len(chunk)
    })

alerts = []
for i in range(1, len(windows)):
    prev = windows[i - 1]
    cur = windows[i]

    diversity_jump = cur["diversity"] - prev["diversity"]
    dominance_jump = abs(cur["dominance_ratio"] - prev["dominance_ratio"])
    changed_process = cur["dominant_process"] != prev["dominant_process"]

    if diversity_jump >= 3 or dominance_jump >= 0.30 or changed_process:
        alerts.append({
            "from_window": prev["window_index"],
            "to_window": cur["window_index"],
            "reason": {
                "dominant_process_changed": changed_process,
                "diversity_jump": diversity_jump,
                "dominance_ratio_delta": round(dominance_jump, 4)
            }
        })

report = {
    "window_size": WINDOW_SIZE,
    "window_count": len(windows),
    "alerts": alerts,
    "windows": windows
}

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("phase transition alerts:", len(alerts))
