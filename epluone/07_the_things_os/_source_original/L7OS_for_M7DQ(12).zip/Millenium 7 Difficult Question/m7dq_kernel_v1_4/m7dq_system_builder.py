
import os

BASE="/opt/m7dq/systems"

systems=[
"navier_stokes",
"p_vs_np",
"yang_mills",
"hodge",
"birch_swinnerton_dyer",
"riemann",
"poincare"
]

for s in systems:
    path=os.path.join(BASE,s)
    os.makedirs(path,exist_ok=True)

    with open(os.path.join(path,"README.md"),"w") as f:
        f.write(f"# {s} experiment node\n")

print("M7DQ system skeleton created")
