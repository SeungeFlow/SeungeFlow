
Kernel v1.4

New modules
- anomaly_score.py
- time_window_flow_map.py
- m7dq_system_builder.py
- install_m7dq.sh

Purpose

Detect abnormal processes
Track time window flow
Build Millennium problem experiment folders
Automate system install

Run

cd /opt/m7dq/kernel
python3 run_analysis_v1_4.py
