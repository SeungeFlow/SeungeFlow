
import re
import json
from collections import Counter

LOG_FILE = "../logs/raw.log"
OUTPUT_FILE = "../reports/anomaly_score.json"

process_pattern = re.compile(r'(\w+)\[\d+\]')

processes = []

with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
    for line in f:
        m = process_pattern.search(line)
        if m:
            processes.append(m.group(1))

freq = Counter(processes)
total = sum(freq.values())

scores = {}

for p,c in freq.items():
    p_norm = c/total
    scores[p] = 1 - p_norm

report = {
    "total_events": total,
    "process_count": len(freq),
    "anomaly_scores": scores
}

with open(OUTPUT_FILE,"w") as f:
    json.dump(report,f,indent=2)

print("anomaly score generated")
