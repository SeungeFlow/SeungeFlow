
import os

print("Running SeungeFlow Kernel v1.4")

cmds=[
"python3 process_graph_generator.py",
"python3 entropy_monitor.py",
"python3 network_density.py",
"python3 centrality_detector.py",
"python3 phase_transition_detector.py",
"python3 anomaly_score.py",
"python3 time_window_flow_map.py",
"python3 graph_visualizer.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("analysis complete")
