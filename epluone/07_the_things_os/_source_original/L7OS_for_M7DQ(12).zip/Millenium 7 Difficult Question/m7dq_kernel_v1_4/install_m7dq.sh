
#!/bin/bash

echo "Installing M7DQ Structure System"

sudo mkdir -p /opt/m7dq/kernel
sudo mkdir -p /opt/m7dq/logs
sudo mkdir -p /opt/m7dq/reports
sudo mkdir -p /opt/m7dq/systems

echo "Directories created"

echo "Setup complete"
