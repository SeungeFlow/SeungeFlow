
import re
import json
from collections import defaultdict

LOG_FILE = "../logs/raw.log"
OUTPUT_FILE = "../reports/time_flow_map.json"

process_pattern = re.compile(r'(\w+)\[\d+\]')

WINDOW=30

flows=[]
buffer=[]

with open(LOG_FILE,"r",encoding="utf-8",errors="ignore") as f:
    for line in f:
        m=process_pattern.search(line)
        if not m:
            continue

        buffer.append(m.group(1))

        if len(buffer)>=WINDOW:
            counts=defaultdict(int)
            prev=None

            for p in buffer:
                if prev:
                    counts[(prev,p)]+=1
                prev=p

            flows.append({
                "window_size":WINDOW,
                "edges":[{"from":a,"to":b,"weight":w} for (a,b),w in counts.items()]
            })

            buffer=[]

with open(OUTPUT_FILE,"w") as f:
    json.dump(flows,f,indent=2)

print("time window flow map created")
