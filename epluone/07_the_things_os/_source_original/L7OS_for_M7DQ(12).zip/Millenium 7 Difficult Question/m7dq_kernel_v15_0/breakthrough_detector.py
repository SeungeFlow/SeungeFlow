
import json
from pathlib import Path

INPUT = Path("../reports/theory_synthesis_report.json")
OUTPUT = Path("../reports/breakthrough_candidates.json")

candidates=[]

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for t in data.get("theories",[]):
        if t.get("confidence",0)>=0.7:
            candidates.append({
                "theory_id":t.get("theory_id"),
                "confidence":t.get("confidence"),
                "status":"breakthrough_candidate"
            })

report={
"candidate_count":len(candidates),
"candidates":candidates
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("breakthrough detection complete")
