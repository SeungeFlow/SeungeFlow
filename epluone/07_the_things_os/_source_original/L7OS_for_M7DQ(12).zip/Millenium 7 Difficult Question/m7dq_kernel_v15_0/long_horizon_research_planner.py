
import json
from pathlib import Path

INPUT = Path("../reports/discovery_plan.json")
OUTPUT = Path("../reports/long_horizon_plan.json")

plan = []
if INPUT.exists():
    with open(INPUT) as f:
        tasks = json.load(f).get("tasks", [])

    for i,t in enumerate(tasks, start=1):
        plan.append({
            "milestone_id": f"MILE-{i:03d}",
            "objective": t.get("objective"),
            "time_horizon": "long_term",
            "status": "scheduled"
        })

report = {
    "milestone_count": len(plan),
    "milestones": plan
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("long horizon research plan created")
