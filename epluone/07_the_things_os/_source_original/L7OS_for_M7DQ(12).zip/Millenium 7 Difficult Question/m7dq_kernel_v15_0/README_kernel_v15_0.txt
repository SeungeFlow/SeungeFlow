
Kernel v15.0

Long-Horizon Research Engine

Modules
long_horizon_research_planner.py
multi_question_dependency_graph.py
breakthrough_detector.py
grand_problem_mapper.py

Purpose

Plan long-term research milestones
Build dependency graph between questions
Detect potential breakthrough theories
Map large open research problems

Run

cd /opt/m7dq/kernel
python3 run_analysis_v15_0.py

Outputs

long_horizon_plan.json
question_dependency_graph.json
breakthrough_candidates.json
grand_problem_map.json
