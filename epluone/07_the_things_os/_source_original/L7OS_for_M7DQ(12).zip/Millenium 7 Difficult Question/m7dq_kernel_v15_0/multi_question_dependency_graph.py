
import json
from pathlib import Path

INPUT = Path("../reports/generated_questions.json")
OUTPUT = Path("../reports/question_dependency_graph.json")

graph=[]

if INPUT.exists():
    with open(INPUT) as f:
        qs=json.load(f).get("questions",[])

    for i,q in enumerate(qs):
        graph.append({
            "node": f"Q-{i+1:03d}",
            "question": q.get("question"),
            "depends_on": f"Q-{i:03d}" if i>0 else None
        })

report={
"node_count":len(graph),
"graph":graph
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("question dependency graph built")
