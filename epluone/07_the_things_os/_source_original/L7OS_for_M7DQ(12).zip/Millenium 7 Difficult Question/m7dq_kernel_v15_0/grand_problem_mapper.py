
import json
from pathlib import Path

INPUT = Path("../reports/problem_space_map.json")
OUTPUT = Path("../reports/grand_problem_map.json")

problems=[]

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for p in data.get("problem_space",[]):
        problems.append({
            "problem":p.get("problem"),
            "category":"open_research_problem"
        })

report={
"grand_problem_count":len(problems),
"problems":problems
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("grand problem map created")
