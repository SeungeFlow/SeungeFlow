
import os

print("Running SeungeFlow Long-Horizon Research Engine v15.0")

steps=[
"python3 run_analysis_v14_0.py",
"python3 multi_question_dependency_graph.py",
"python3 long_horizon_research_planner.py",
"python3 breakthrough_detector.py",
"python3 grand_problem_mapper.py"
]

for s in steps:
    print(">",s)
    os.system(s)

print("long horizon research cycle complete")
