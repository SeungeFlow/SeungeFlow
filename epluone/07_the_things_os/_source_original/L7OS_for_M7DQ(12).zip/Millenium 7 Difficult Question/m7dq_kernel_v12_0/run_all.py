
import os

print("Running SeungeFlow Unified System v12.0")

pipeline = [
"python3 run_analysis_v9_0.py",
"python3 run_analysis_v10_0.py",
"python3 peer_review_simulator.py",
"python3 contradiction_scanner.py",
"python3 archive_release_builder.py"
]

for step in pipeline:
    print(">", step)
    os.system(step)

print("Unified pipeline complete")
