
import json
from pathlib import Path

INPUT = Path("../reports/grand_problem_map.json")
OUTPUT = Path("../reports/civilization_problem_index.json")

index = []

if INPUT.exists():
    with open(INPUT) as f:
        data = json.load(f)

    for i,p in enumerate(data.get("problems",[]), start=1):
        index.append({
            "problem_id": f"CIV-{i:04d}",
            "description": p.get("problem"),
            "scope": "civilization_scale"
        })

report = {
    "problem_count": len(index),
    "index": index
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("civilization scale problem index created")
