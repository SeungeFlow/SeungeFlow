
import json
from pathlib import Path

REPORT_DIR = Path("../reports")
OUTPUT = REPORT_DIR / "knowledge_evolution.json"

signals = []

for name in [
"ai_pattern_report.json",
"hypothesis_report.json",
"theory_synthesis_report.json",
"discovery_report.json"
]:
    p = REPORT_DIR / name
    if p.exists():
        signals.append({"source": name, "status": "present"})
    else:
        signals.append({"source": name, "status": "missing"})

report = {
    "knowledge_layers": signals,
    "layer_count": len(signals)
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("knowledge evolution tracked")
