
import json
from pathlib import Path

INPUT = Path("../reports/long_horizon_plan.json")
OUTPUT = Path("../reports/lab_simulation_results.json")

results=[]

if INPUT.exists():
    with open(INPUT) as f:
        data=json.load(f)

    for m in data.get("milestones",[]):
        results.append({
            "milestone": m.get("milestone_id"),
            "experiment_status": "simulated",
            "outcome_signal": "weak_signal"
        })

report={
"simulation_count":len(results),
"results":results
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("autonomous lab simulation complete")
