
import os

print("Running SeungeFlow Core Engine v16.0")

steps=[
"python3 run_analysis_v15_0.py",
"python3 civilization_scale_problem_index.py",
"python3 autonomous_lab_simulator.py",
"python3 knowledge_evolution_tracker.py"
]

for s in steps:
    print(">",s)
    os.system(s)

print("SeungeFlow Core Engine cycle complete")
