
import os

print("Running SeungeFlow Engine v4.0")

cmds=[
"python3 run_analysis_v3_0.py",
"python3 ai_pattern_engine.py",
"python3 cluster_analysis.py",
"python3 anomaly_predictor.py",
"python3 autonomous_research_node.py"
]

for c in cmds:
    print(">",c)
    os.system(c)

print("v4.0 complete")
