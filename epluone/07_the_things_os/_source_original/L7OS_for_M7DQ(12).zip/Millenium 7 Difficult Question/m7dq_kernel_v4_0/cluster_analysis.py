
import json
from pathlib import Path
from collections import defaultdict

INPUT = Path("../reports/process_graph.json")
OUTPUT = Path("../reports/cluster_analysis.json")

if not INPUT.exists():
    print("process graph missing")
    exit()

with open(INPUT) as f:
    edges=json.load(f)

clusters=defaultdict(list)

for e in edges:
    clusters[e["from"]].append(e["to"])

cluster_map={k:list(set(v)) for k,v in clusters.items()}

with open(OUTPUT,"w") as f:
    json.dump(cluster_map,f,indent=2)

print("cluster analysis complete")
