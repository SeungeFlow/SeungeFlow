
import json
from pathlib import Path
from collections import Counter

INPUT = Path("../reports/process_graph.json")
OUTPUT = Path("../reports/ai_pattern_report.json")

if not INPUT.exists():
    print("process_graph.json missing")
    exit()

with open(INPUT) as f:
    edges = json.load(f)

patterns = Counter()

for e in edges:
    pair = f'{e["from"]}->{e["to"]}'
    patterns[pair] += e.get("weight",1)

top_patterns = patterns.most_common(20)

report = {
    "pattern_count": len(patterns),
    "top_patterns": top_patterns
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("AI pattern analysis complete")
