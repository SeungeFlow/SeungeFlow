
import json
from pathlib import Path

INPUT = Path("../reports/anomaly_score.json")
OUTPUT = Path("../reports/anomaly_prediction.json")

if not INPUT.exists():
    print("anomaly score missing")
    exit()

with open(INPUT) as f:
    data=json.load(f)

scores=data.get("anomaly_scores",{})

predictions=[]

for p,s in scores.items():
    if s>0.9:
        predictions.append({"process":p,"risk":"high"})
    elif s>0.7:
        predictions.append({"process":p,"risk":"medium"})

with open(OUTPUT,"w") as f:
    json.dump(predictions,f,indent=2)

print("anomaly prediction generated")
