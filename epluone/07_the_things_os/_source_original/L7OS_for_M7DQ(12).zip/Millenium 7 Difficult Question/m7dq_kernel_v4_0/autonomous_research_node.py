
import json
from pathlib import Path

DATA = Path("../reports/research_dataset.json")
OUTPUT = Path("../reports/research_node_report.json")

if not DATA.exists():
    print("dataset missing")
    exit()

with open(DATA) as f:
    d=json.load(f)

report={
"dataset":d.get("dataset"),
"edge_count":d.get("edge_count"),
"status":"ready_for_research"
}

with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("research node ready")
