# =========================================
# the_things_builder_parser v0.1
# Pattern 0.41 — Markdown SPEC Parser
#
# 목적
# Markdown 문서에서 things_spec 블록을 추출한다.
#
# Human Zone
# 사람이 읽는 영역
#
# Machine Zone
# Builder가 읽는 영역
#
# =========================================


# =========================================
# HUMAN ZONE
# =========================================

# Builder는 Markdown 문서를 읽는다.
#
# 그러나 모든 내용을 해석하지 않는다.
#
# Builder가 읽는 것은 오직 이것 하나다.
#
# things_spec:
#
# 이 블록 안의 내용만 Machine Zone이다.
#
# 나머지 문장은 설명이다.


# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  parser:

    name: markdown_spec_parser

    version: 0.1

  rule:

    extract_block: things_spec

  pipeline:

    - read_markdown
    - locate_things_spec
    - extract_yaml
    - parse_yaml


# =========================================
# MACHINE CODE
# =========================================

```python
import re
import yaml


def load_markdown(path):

    with open(path, "r") as f:
        return f.read()


def extract_things_spec(text):

    pattern = r"things_spec:(.*?)(\n\S|\Z)"

    match = re.search(pattern, text, re.S)

    if not match:
        return None

    block = "things_spec:" + match.group(1)

    return block


def parse_things_spec(text):

    block = extract_things_spec(text)

    if not block:
        return None

    return yaml.safe_load(block)


def load_spec_from_md(path):

    md = load_markdown(path)

    return parse_things_spec(md)
```