
# =========================================
# the_things_builder_spec_validator v0.1
# Pattern 0.43 — SPEC Validator
#
# 목적
# Builder가 SPEC을 실행하기 전에
# 구조 오류를 검증한다.
#
# 잘못된 SPEC이 시스템을 손상시키는 것을 방지한다.
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# Builder가 DB를 생성하기 전에 반드시 확인해야 하는 단계다.
#
# 이유
#
# SPEC 문서는 인간이 작성한다.
# 인간은 실수한다.
#
# 예
#
# table 이름 누락
# column 타입 오류
# relation 충돌
#
# 이런 오류 상태에서 Builder가 실행되면
#
# 시스템 구조 자체가 깨질 수 있다.
#
# 그래서 Builder는 다음 순서를 따른다.
#
# SPEC 입력
# ↓
# Validator
# ↓
# Builder 실행
#
# Validator는 구조 안정성을 검사한다.



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  validator:

    name: spec_validator

    version: 0.1

  rules:

    - spec_exists
    - table_definition_exists
    - column_type_valid
    - relation_integrity

  pipeline:

    - load_spec
    - validate_structure
    - validate_tables
    - validate_columns
    - validate_relations
    - return_result



# =========================================
# MACHINE CODE
# =========================================

```python
VALID_TYPES = [
    "id",
    "text",
    "number",
    "time"
]


def validate_spec_exists(spec):

    if "things_spec" not in spec:
        raise Exception("SPEC missing things_spec root")

    return True


def validate_tables(spec):

    db = spec["things_spec"].get("db")

    if not db:
        raise Exception("db definition missing")

    tables = db.get("tables")

    if not tables:
        raise Exception("tables definition missing")

    return True


def validate_columns(spec):

    tables = spec["things_spec"]["db"]["tables"]

    for table, columns in tables.items():

        for column, t in columns.items():

            if t not in VALID_TYPES:
                raise Exception(
                    f"invalid type {t} in {table}.{column}"
                )

    return True


def validate_spec(spec):

    validate_spec_exists(spec)
    validate_tables(spec)
    validate_columns(spec)

    return True
```
