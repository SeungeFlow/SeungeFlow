
# =========================================
# the_things_builder_db_deploy v0.1
# Pattern 0.42 — DB Auto Deploy
#
# 목적
# SPEC 문서를 통해 실제 DB를 생성한다.
#
# SPEC
# ↓
# Builder
# ↓
# SQL 생성
# ↓
# PostgreSQL / SQLite 적용
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# 지금 단계에서 Builder는 실제 시스템에 영향을 준다.
#
# 이전 단계
#
# Pattern 0.4
#   DB SQL 생성
#
# Pattern 0.41
#   Markdown SPEC 파싱
#
# 이제 Builder는 실제 DB에 SQL을 적용한다.
#
# 즉
#
# SPEC
# ↓
# Builder
# ↓
# Database 생성
#
# 이 단계가 지나면 시스템은
#
# "문서 → 실제 구조"
#
# 로 전환된다.
#
# 이것이 Builder의 첫 번째 현실 생성 단계다.



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  builder:

    name: the_things_builder_db_deploy

    version: 0.1

  target:

    - postgresql
    - sqlite

  pipeline:

    - parse_spec
    - generate_sql
    - connect_db
    - apply_schema

  adapters:

    postgres: psycopg2
    sqlite: sqlite3



# =========================================
# MACHINE CODE
# =========================================

```python
import psycopg2
import sqlite3


def apply_postgres(sql_list, config):

    conn = psycopg2.connect(
        host=config["host"],
        user=config["user"],
        password=config["password"],
        dbname=config["dbname"]
    )

    cur = conn.cursor()

    for sql in sql_list:
        cur.execute(sql)

    conn.commit()
    cur.close()
    conn.close()


def apply_sqlite(sql_list, db_path):

    conn = sqlite3.connect(db_path)

    cur = conn.cursor()

    for sql in sql_list:
        cur.execute(sql)

    conn.commit()
    cur.close()
    conn.close()


def deploy_schema(sql_list, target, config):

    if target == "postgres":
        apply_postgres(sql_list, config)

    if target == "sqlite":
        apply_sqlite(sql_list, config["path"])
```
