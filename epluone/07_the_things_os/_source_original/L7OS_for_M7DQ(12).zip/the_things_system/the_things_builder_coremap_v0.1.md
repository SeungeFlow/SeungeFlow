
# =========================================
# the_things_builder_coremap v0.1
# Pattern 0.44 — COREMAP Graph Builder
#
# 목적
# SPEC 문서를 COREMAP Object Graph로 변환한다.
#
# SPEC
# ↓
# COREMAP GRAPH
# ↓
# DB + Runtime 관계 구조 생성
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# DB는 저장 구조다.
#
# 그러나 시스템의 실제 의미 구조는
#
# 관계
#
# 에서 나온다.
#
# 그래서 Builder는 SPEC을
#
# pin
# link
# graph
#
# 구조로 변환한다.
#
# 이것이 COREMAP이다.
#
#
# pin
# = 개별 개념 / 노드
#
# link
# = 관계
#
# graph
# = 전체 구조
#
#
# 예
#
# fragment → relation
#
# 이것은 COREMAP에서
#
# pin → link → pin
#
# 구조가 된다.
#
#
# COREMAP은 다음을 가능하게 한다.
#
# 구조 시각화
# 관계 탐색
# 구조 분석
# runtime fabric 생성



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  builder:

    name: the_things_builder_coremap

    version: 0.1

  graph_model:

    node: pin
    edge: link

  pipeline:

    - load_spec
    - extract_entities
    - build_nodes
    - build_links
    - emit_coremap

  outputs:

    - coremap_json
    - graph_structure



# =========================================
# MACHINE CODE
# =========================================

```python

class Pin:

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind


class Link:

    def __init__(self, source, target, relation):
        self.source = source
        self.target = target
        self.relation = relation


class CoreMap:

    def __init__(self):
        self.nodes = []
        self.links = []

    def add_node(self, node):
        self.nodes.append(node)

    def add_link(self, link):
        self.links.append(link)


def build_coremap(spec):

    cm = CoreMap()

    db = spec["things_spec"].get("db", {})
    tables = db.get("tables", {})

    for table, columns in tables.items():

        table_node = Pin(table, "table")
        cm.add_node(table_node)

        for column in columns:

            column_node = Pin(column, "column")
            cm.add_node(column_node)

            cm.add_link(
                Link(table, column, "has_column")
            )

    return cm
```
