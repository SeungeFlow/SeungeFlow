
# =========================================
# the_things_fabric_runtime v0.1
# Pattern 0.45 — Fabric Runtime Engine
#
# 목적
# COREMAP Graph 구조를 Runtime Fabric으로 실행한다.
#
# COREMAP
# ↓
# Runtime Fabric
# ↓
# System Interaction
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# COREMAP은 구조다.
# pin / link 관계 그래프다.
#
# 그러나 그래프만으로는 시스템이 동작하지 않는다.
#
# Runtime Fabric은
# COREMAP 구조를 실행 가능한 상태로 만든다.
#
# pin
# = 노드
#
# link
# = 관계
#
# Runtime Fabric은
# 노드와 링크를 순환시키고
# 시스템 상호작용을 발생시킨다.
#
# 이 단계에서 시스템은
#
# static structure
# ↓
# dynamic system
#
# 으로 전환된다.
#
# 이것이 Fabric Runtime이다.



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  runtime:

    name: fabric_runtime_engine

    version: 0.1

  model:

    node: pin
    edge: link

  pipeline:

    - load_coremap
    - build_runtime_nodes
    - build_runtime_links
    - activate_runtime_loop

  runtime_modes:

    - event_loop
    - flow_cycle
    - relation_trigger

  outputs:

    - runtime_state
    - event_stream



# =========================================
# MACHINE CODE
# =========================================

```python

class RuntimeNode:

    def __init__(self, name, kind):
        self.name = name
        self.kind = kind
        self.links = []

    def connect(self, link):
        self.links.append(link)


class RuntimeLink:

    def __init__(self, source, target, relation):
        self.source = source
        self.target = target
        self.relation = relation


class FabricRuntime:

    def __init__(self):
        self.nodes = {}
        self.links = []

    def add_node(self, node):

        self.nodes[node.name] = node

    def add_link(self, link):

        self.links.append(link)

        src = self.nodes.get(link.source)
        tgt = self.nodes.get(link.target)

        if src:
            src.connect(link)

        if tgt:
            tgt.connect(link)


def load_coremap(coremap):

    runtime = FabricRuntime()

    for node in coremap.nodes:

        runtime.add_node(
            RuntimeNode(node.name, node.kind)
        )

    for link in coremap.links:

        runtime.add_link(
            RuntimeLink(
                link.source,
                link.target,
                link.relation
            )
        )

    return runtime


def run_fabric(runtime):

    for name, node in runtime.nodes.items():

        for link in node.links:

            print(
                f"{link.source} -> {link.target} ({link.relation})"
            )
```
