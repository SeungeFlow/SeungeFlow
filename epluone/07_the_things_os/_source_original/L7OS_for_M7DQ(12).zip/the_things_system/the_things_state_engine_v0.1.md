
# =========================================
# the_things_state_engine v0.1
# Pattern 0.47 — State Engine
#
# 목적
# Event / Trigger Engine 위에서 상태(state)를 기록하고 전이시킨다.
#
# Fabric Runtime
# ↓
# Event / Trigger
# ↓
# State Engine
# ↓
# Next Event
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# 시스템은 결국 상태 위에서 움직인다.
#
# Event가 발생하면
# 상태가 바뀐다.
#
# 상태가 바뀌면
# 다음 Event 조건이 생긴다.
#
# 이 반복이 시스템의 실제 생명이다.
#
# 기본 개념
#
# state
# = 현재 구조의 값
#
# transition
# = 상태 변화
#
# history
# = 상태 변화 기록
#
#
# 예
#
# idle
# ↓ event
# processing
# ↓ event
# done
#
#
# 이 단계가 생기면
# 시스템은 단순 반응을 넘어서
#
# "지속되는 구조"
#
# 가 된다.
#
# Event Engine이 움직임을 만든다면
# State Engine은
# 그 움직임의 현재값과 이전값을 보존한다.
#
# 즉
#
# Event = 변화의 계기
# State = 변화의 자리



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  engine:

    name: state_engine

    version: 0.1

  state_model:

    state: current_value
    transition: state_change
    history: append_only_log

  pipeline:

    - read_current_state
    - apply_event
    - compute_next_state
    - record_transition
    - emit_next_event

  runtime_modes:

    - finite_state
    - append_only_history
    - state_snapshot

  invariants:

    - no_delete_only_add
    - append_only_state_history
    - state_transition_recorded



# =========================================
# MACHINE CODE
# =========================================

```python

class StateRecord:

    def __init__(self, node_name, current_state):
        self.node_name = node_name
        self.current_state = current_state
        self.history = [current_state]

    def transition(self, new_state):
        self.current_state = new_state
        self.history.append(new_state)


class StateEngine:

    def __init__(self):
        self.states = {}

    def ensure_node(self, node_name, initial_state="idle"):
        if node_name not in self.states:
            self.states[node_name] = StateRecord(
                node_name,
                initial_state
            )

    def apply_event(self, node_name, event_name):

        self.ensure_node(node_name)

        state = self.states[node_name]

        if state.current_state == "idle" and event_name == "start":
            state.transition("processing")

        elif state.current_state == "processing" and event_name == "finish":
            state.transition("done")

        elif event_name == "reset":
            state.transition("idle")

        return state.current_state


def handle_runtime_event(state_engine, event):

    target = event.payload.get("target") if event.payload else event.source

    if event.name == "link_propagation":
        return state_engine.apply_event(target, "start")

    if event.name == "complete":
        return state_engine.apply_event(target, "finish")

    if event.name == "reset":
        return state_engine.apply_event(target, "reset")

    return None
```
