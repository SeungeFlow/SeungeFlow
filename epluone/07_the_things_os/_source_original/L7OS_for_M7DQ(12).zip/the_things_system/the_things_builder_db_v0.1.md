
# =========================================
# the_things_builder_db v0.1
# Pattern 0.4 — Builder Implementation Start
#
# 목적
# SPEC 문서를 DB Schema로 변환한다.
#
# SPEC
# ↓
# Builder
# ↓
# PostgreSQL / SQLite Schema 생성
#
# =========================================


# =========================================
# HUMAN ZONE
# =========================================

# 이 문서는 Builder의 첫 구현 문서다.
#
# Builder 역할
#
# SPEC 문서를 읽는다
# ↓
# 구조를 해석한다
# ↓
# DB Schema를 생성한다
#
# 왜 DB부터 시작하는가
#
# DB = 자리
#
# fragment
# relation
# pattern
# spec
#
# 이 모든 것이 저장되는 첫 번째 구조가 DB다.
#
# 그래서 Builder의 첫 Generator는
#
# DB Generator
#
# 이다.


# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  builder:

    name: the_things_builder_db

    version: 0.1

    target:

      - postgresql
      - sqlite

  pipeline:

    - load_spec
    - parse_spec
    - schema_model
    - generate_postgres
    - generate_sqlite

  abstract_types:

    id: uuid
    text: string
    number: float
    time: timestamp


# =========================================
# EXAMPLE SPEC
# =========================================

things_spec:

  db:

    name: seungeflow

    tables:

      fragment:

        id: id
        content: text
        created_at: time

      relation:

        id: id
        source: id
        target: id
        type: text


# =========================================
# MACHINE CODE
# =========================================

```python
import yaml

TYPE_MAP_POSTGRES = {
    "id": "UUID",
    "text": "TEXT",
    "number": "NUMERIC",
    "time": "TIMESTAMP"
}

TYPE_MAP_SQLITE = {
    "id": "TEXT",
    "text": "TEXT",
    "number": "REAL",
    "time": "TEXT"
}

def load_spec(path):

    with open(path, "r") as f:
        return yaml.safe_load(f)


def generate_sql(table_name, columns, type_map):

    lines = []

    for name, t in columns.items():

        sql_type = type_map.get(t, "TEXT")

        lines.append(f"{name} {sql_type}")

    cols = ",\n".join(lines)

    return f"CREATE TABLE {table_name} (\n{cols}\n);"


def build_db(spec):

    tables = spec["things_spec"]["db"]["tables"]

    for table, columns in tables.items():

        pg_sql = generate_sql(table, columns, TYPE_MAP_POSTGRES)
        sq_sql = generate_sql(table, columns, TYPE_MAP_SQLITE)

        print("PostgreSQL:")
        print(pg_sql)

        print("SQLite:")
        print(sq_sql)
```
