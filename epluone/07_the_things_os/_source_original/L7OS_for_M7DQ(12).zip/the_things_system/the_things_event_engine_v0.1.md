
# =========================================
# the_things_event_engine v0.1
# Pattern 0.46 — Event / Trigger Engine
#
# 목적
# Fabric Runtime 위에서 이벤트 기반 상호작용을 실행한다.
#
# COREMAP
# ↓
# Fabric Runtime
# ↓
# Event / Trigger
# ↓
# Propagation
#
# =========================================



# =========================================
# HUMAN ZONE
# =========================================

# Runtime Fabric이 만들어지면
# 노드와 링크는 존재한다.
#
# 하지만 시스템은 아직 수동 상태다.
#
# Event Engine은
# 시스템에 "움직임"을 만든다.
#
# 기본 개념
#
# event
# = 상태 변화
#
# trigger
# = 이벤트 발생 조건
#
# propagation
# = 이벤트 전파
#
#
# 예
#
# node A 상태 변경
# ↓
# trigger 발생
# ↓
# link 통해 전달
# ↓
# node B 반응
#
#
# 이것이 Fabric 내부 상호작용이다.
#
# 이 구조가 만들어지면
# 시스템은
#
# static graph
# ↓
# reactive network
#
# 으로 변한다.



# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  engine:

    name: event_trigger_engine

    version: 0.1

  event_model:

    event: state_change
    trigger: condition
    propagation: link_flow

  pipeline:

    - register_event
    - detect_trigger
    - propagate_event
    - update_state

  runtime_modes:

    - synchronous
    - async
    - queued



# =========================================
# MACHINE CODE
# =========================================

```python

class Event:

    def __init__(self, source, name, payload=None):

        self.source = source
        self.name = name
        self.payload = payload


class Trigger:

    def __init__(self, event_name, action):

        self.event_name = event_name
        self.action = action


class EventEngine:

    def __init__(self):

        self.triggers = {}

    def register_trigger(self, event_name, action):

        if event_name not in self.triggers:
            self.triggers[event_name] = []

        self.triggers[event_name].append(
            Trigger(event_name, action)
        )

    def emit(self, event):

        triggers = self.triggers.get(event.name, [])

        for trig in triggers:

            trig.action(event)


def propagate_event(runtime, event_engine, node):

    for link in node.links:

        target = runtime.nodes.get(link.target)

        if target:

            event = Event(
                source=node.name,
                name="link_propagation",
                payload={
                    "target": target.name,
                    "relation": link.relation
                }
            )

            event_engine.emit(event)
```
