# =========================================
# CELLULAR FABRIC ENGINE v0.2
# the_things_SYSTEM Core Engine
#
# 목적
# spacetime node (x,y,z,t) 기반 graph network + adaptive cell
# 구조를 사용하여 interaction / vector / density / rotation
# 이 발생하는 fabric field runtime 을 구현한다.
#
# engine = core
# generator = 발전기
#
# Structure Generator는 이 엔진 위에서
# node / link 구조를 생성하는 상위 계층이다.
#
# no delete only add
# =========================================


# =========================================
# HUMAN ZONE
# =========================================

# -----------------------------------------
# 기본 개념
# -----------------------------------------

# cell = spacetime node
#
# node 좌표
# (x, y, z, t)
#
# 즉
#
# node = 사건(event)
#
# 사건 사이 연결
#
# node ↔ node
#
# 이것이 link(edge)


# -----------------------------------------
# node 상태
# -----------------------------------------

# 각 node는 다음 상태를 가진다

# density     : 질량/정보 밀도
# energy      : 활동 에너지
# vector      : 이동 방향
# rotation    : 회전 성분
# state       : 상태


# -----------------------------------------
# link 상태
# -----------------------------------------

# link는 두 node 사이 상호작용이다

# weight
# direction
# interaction type


# -----------------------------------------
# interaction
# -----------------------------------------

# 모든 상호작용은 4가지로 단순화한다

# pull
# push
# rotate
# transfer


# -----------------------------------------
# spacetime progression
# -----------------------------------------

# 시간 t는 루프마다 증가한다

# node(x,y,z,t)
# →
# node(x,y,z,t+1)

# 즉

# 사건 흐름


# -----------------------------------------
# adaptive cell
# -----------------------------------------

# node는 다음 변화를 할 수 있다

# node split
# node merge
# link create
# link remove


# -----------------------------------------
# pattern emergence
# -----------------------------------------

# interaction 반복
# →
# flow
# →
# pattern
# →
# structure
# →
# fabric


# -----------------------------------------
# Structure Generator 연결
# -----------------------------------------

# Structure Generator는

# fragment
# relation
# pattern

# 을 분석하여

# graph topology를 생성한다


# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  engine: cellular_fabric_engine

  node_model:

    type: spacetime_node

    coordinates:
      - x
      - y
      - z
      - t

  node_properties:

    - density
    - energy
    - vector
    - rotation
    - state

  link_model:

    type: directed_edge

    properties:
      - weight
      - direction
      - interaction_type

  interaction_types:

    - pull
    - push
    - rotate
    - transfer

  adaptive_rules:

    - node_split
    - node_merge
    - link_create
    - link_remove

  spacetime_progression:

    timestep: engine_loop

  runtime_pipeline:

    - update_time
    - update_nodes
    - update_links
    - compute_vector_field
    - apply_interactions
    - detect_patterns
    - stabilize_structures
    - emit_fabric_state

  outputs:

    artifacts:

      - node_graph
      - vector_field
      - pattern_map
      - structure_graph
      - fabric_state