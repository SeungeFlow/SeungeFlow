# CR3BP Horseshoe Orbit Model v0.1

## Objective

Analyze the horseshoe orbit region in the Circular Restricted Three‑Body
Problem (CR3BP) as a transitional stability structure between unstable
motion and stable Lagrange regions.

This model evaluates how orbital motion circulates around L3, L4, and L5
before settling into more stable configurations.

------------------------------------------------------------------------

## Definition

A horseshoe orbit is a trajectory in the rotating frame of the CR3BP
where a small body appears to trace a horseshoe-shaped path around the
L3--L4--L5 region relative to the two primary bodies.

These trajectories periodically approach the L4 and L5 regions but
reverse direction before crossing the secondary body's orbit.

------------------------------------------------------------------------

## Physical Interpretation

The horseshoe orbit region acts as a transitional stability corridor.

Properties:

-   long-term bounded motion
-   periodic orbital reversal
-   energy exchange with the rotating frame
-   resonance-driven motion

This region demonstrates how chaotic trajectories can evolve into
semi‑stable orbital patterns.

------------------------------------------------------------------------

## Dynamical Behavior

Typical sequence:

energy gradient → orbital drift → resonance interaction → horseshoe
trajectory → stabilization near L4 or L5

The horseshoe region therefore acts as a transitional zone between
instability and stable equilibrium.

------------------------------------------------------------------------

## Relation to Spiral Convergence

In the spiral convergence model:

difference → pull → rotation → spiral → convergence → stability

Horseshoe motion corresponds to the transition between:

rotation → spiral → convergence

The path repeatedly circulates around potential stability points until
the trajectory energy settles into a stable attractor.

------------------------------------------------------------------------

## Observational Examples

Known horseshoe orbit systems include:

-   Saturn moons Janus and Epimetheus
-   Earth's co-orbital asteroid 3753 Cruithne
-   other Trojan-like co-orbital bodies

These systems demonstrate long-duration orbital exchange patterns.

------------------------------------------------------------------------

## Energy Landscape Interpretation

In phase space, horseshoe trajectories move along the boundary between
stability wells associated with L4 and L5.

The orbit oscillates across the potential ridge between wells without
falling permanently into either basin.

------------------------------------------------------------------------

## Hypothesis

Horseshoe regions may represent a universal transitional pattern in
rotating gravitational systems.

Similar transitional behavior may occur in:

-   accretion disk flow structures
-   spiral density wave formation
-   rotating fluid vortices

------------------------------------------------------------------------

## Position Inside NatureEOH Framework

Nature ↓ Human Observation ↓ AI Structural Modeling ↓ CR3BP Reference
System ↓ Horseshoe Orbit Transition Model ↓ Spiral Convergence
Validation
