# =========================================
# CELLULAR FABRIC ENGINE
# the_things_SYSTEM Core Engine
#
# 목적
# graph network 기반 adaptive cell 구조를 사용하여
# interaction / vector / density / rotation 이 발생하는
# fabric field runtime 을 구현한다.
#
# engine = core
# generator = 발전기
#
# 따라서 Structure Generator는
# 이 엔진 위에서 구조를 생성하는 상위 계층이다.
#
# no delete only add
# =========================================


# =========================================
# HUMAN ZONE
# =========================================

# Fabric Engine 개념
#
# 모든 시스템은 cell의 집합이다.
#
# cell은 고정된 격자가 아니라
# graph node로 존재한다.
#
# cell ↔ cell 연결은 link(edge)이다.


# -----------------------------------------
# 기본 구조
# -----------------------------------------

# cell = node
# link = edge

# graph 구조

# cell
#  |
# link
#  |
# cell


# -----------------------------------------
# cell 상태
# -----------------------------------------

# 각 cell은 다음 상태를 가진다

# density
# energy
# vector
# rotation
# state


# -----------------------------------------
# interaction
# -----------------------------------------

# cell 간 interaction

# pull
# push
# rotate
# transfer


# -----------------------------------------
# adaptive cell
# -----------------------------------------

# cell은 상황에 따라

# 분할
# 병합
# 연결 변경

# 을 수행한다.

# 즉

# adaptive topology


# -----------------------------------------
# fabric emergence
# -----------------------------------------

# link가 많아지고
# interaction이 반복되면

# pattern 발생

# pattern이 안정되면

# structure 발생

# structure 집합이

# fabric


# -----------------------------------------
# structure generator 연결
# -----------------------------------------

# Structure Generator는

# fragment
# relation
# pattern

# 을 분석하여

# fabric engine 위에

# node / link 구조를 생성한다.


# =========================================
# MACHINE ZONE
# =========================================

things_spec:

  engine: cellular_fabric_engine

  topology:

    model: graph_network
    adaptive_cells: true

  cell:

    properties:
      - density
      - energy
      - vector
      - rotation
      - state

  link:

    properties:
      - weight
      - direction
      - interaction_type

  interaction_types:

    - pull
    - push
    - rotate
    - transfer

  adaptive_rules:

    - cell_split
    - cell_merge
    - link_create
    - link_remove

  fabric_detection:

    pattern_threshold: dynamic
    structure_stability_loops: 10

  runtime:

    engine_loop:

      - update_cells
      - update_links
      - compute_vectors
      - apply_interactions
      - detect_patterns
      - emit_structure

  output:

    artifacts:

      - fabric_state
      - structure_graph
      - vector_field