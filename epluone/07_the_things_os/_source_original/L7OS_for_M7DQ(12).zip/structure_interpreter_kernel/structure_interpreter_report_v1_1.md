# Structure Interpreter Report v1.1

## Fusion Summary
- Count: 6
- Dominant Order: 정배열
- Dominant Z-State: transition
- Dominant Trajectory: spiral_convergence
- Dominant Graph Type: mixed_relation_graph
- Mean Priority Score: 6.4274
- Mean Anomaly Score: 1.3333
- Fusion Hint: 다중 데이터 융합 결과: order=정배열, zstate=transition, trajectory=spiral_convergence, graph=mixed_relation_graph, mean_priority=6.4274, mean_anomaly=1.3333.

## Sample 1
- Order: 정배열
- Z-State: transition
- Spiral: insufficient_data
- Priority: 2.5 (low)
- Anomaly: 0.0 (none)
- Graph Type: mixed_relation_graph
- Scientific Hint: 구조 상태=정배열, 안정성=transition, 동역학=insufficient_data, attractor_score=0.0000, memory_match=False.

### Top Ranked Hypotheses
- [2.5] 상승 방향의 구조 정렬 가능성
- [2.35] 현재 구조는 임계 전이 구간일 가능성
- [2.2] 기억된 패턴과 충분히 일치하지 않는 새로운 구조 가능성

### Top Ranked Hints
- [2.5] 계층 간 간격이 한 방향으로 정돈되고 있다
- [2.4] 작은 변화가 방향 전환으로 이어질 수 있다
- [2.3] 신규 구조 또는 미분류 패턴일 수 있다

## Sample 2
- Order: 정배열
- Z-State: transition
- Spiral: spiral_convergence
- Priority: 7.5615 (high)
- Anomaly: 0.0 (none)
- Graph Type: mixed_relation_graph
- Scientific Hint: 구조 상태=정배열, 안정성=transition, 동역학=spiral_convergence, attractor_score=0.5872, memory_match=True.

### Top Ranked Hypotheses
- [7.5615] 상승 방향의 구조 정렬 가능성
- [7.4115] 현재 구조는 임계 전이 구간일 가능성
- [7.2615] 과거에 관측된 구조 패턴이 재등장하고 있을 가능성

### Top Ranked Hints
- [7.5615] 계층 간 간격이 한 방향으로 정돈되고 있다
- [7.4615] 작은 변화가 방향 전환으로 이어질 수 있다
- [7.3615] 반복 구조를 기반으로 재귀적 검증이 가능하다

## Sample 3
- Order: 정배열
- Z-State: transition
- Spiral: spiral_convergence
- Priority: 7.6622 (high)
- Anomaly: 2.0 (medium)
- Graph Type: mixed_relation_graph
- Scientific Hint: 구조 상태=정배열, 안정성=transition, 동역학=spiral_convergence, attractor_score=0.6207, memory_match=True.

### Top Ranked Hypotheses
- [7.6622] 상승 방향의 구조 정렬 가능성
- [7.5122] 현재 구조는 임계 전이 구간일 가능성
- [7.3622] 과거에 관측된 구조 패턴이 재등장하고 있을 가능성

### Top Ranked Hints
- [7.6622] 계층 간 간격이 한 방향으로 정돈되고 있다
- [7.5622] 작은 변화가 방향 전환으로 이어질 수 있다
- [7.4622] 반복 구조를 기반으로 재귀적 검증이 가능하다

### Anomaly Notes
- magnitude outlier

## Sample 4
- Order: 정배열
- Z-State: transition
- Spiral: spiral_convergence
- Priority: 7.7454 (high)
- Anomaly: 1.0 (low)
- Graph Type: mixed_relation_graph
- Scientific Hint: 구조 상태=정배열, 안정성=transition, 동역학=spiral_convergence, attractor_score=0.6485, memory_match=True.

### Top Ranked Hypotheses
- [7.7454] 상승 방향의 구조 정렬 가능성
- [7.5954] 현재 구조는 임계 전이 구간일 가능성
- [7.4454] 과거에 관측된 구조 패턴이 재등장하고 있을 가능성

### Top Ranked Hints
- [7.7454] 계층 간 간격이 한 방향으로 정돈되고 있다
- [7.6454] 작은 변화가 방향 전환으로 이어질 수 있다
- [7.5454] 반복 구조를 기반으로 재귀적 검증이 가능하다

### Anomaly Notes
- magnitude deviation

## Sample 5
- Order: 정배열
- Z-State: transition
- Spiral: spiral_convergence
- Priority: 7.752 (high)
- Anomaly: 2.0 (medium)
- Graph Type: mixed_relation_graph
- Scientific Hint: 구조 상태=정배열, 안정성=transition, 동역학=spiral_convergence, attractor_score=0.6507, memory_match=True.

### Top Ranked Hypotheses
- [7.752] 상승 방향의 구조 정렬 가능성
- [7.602] 현재 구조는 임계 전이 구간일 가능성
- [7.452] 과거에 관측된 구조 패턴이 재등장하고 있을 가능성

### Top Ranked Hints
- [7.752] 계층 간 간격이 한 방향으로 정돈되고 있다
- [7.652] 작은 변화가 방향 전환으로 이어질 수 있다
- [7.552] 반복 구조를 기반으로 재귀적 검증이 가능하다

### Anomaly Notes
- magnitude outlier

## Sample 6
- Order: 혼합
- Z-State: transition
- Spiral: orbiting_basin
- Priority: 5.3432 (medium)
- Anomaly: 3.0 (medium)
- Graph Type: truss_transition_graph
- Scientific Hint: 구조 상태=혼합, 안정성=transition, 동역학=orbiting_basin, attractor_score=0.1311, memory_match=False.

### Top Ranked Hypotheses
- [5.3432] 혼합 배열 기반의 전이 구간 가능성
- [5.1932] 현재 구조는 임계 전이 구간일 가능성
- [5.0432] 기억된 패턴과 충분히 일치하지 않는 새로운 구조 가능성

### Top Ranked Hints
- [5.3432] 정렬보다 재배치가 우세한 상태다
- [5.2432] 작은 변화가 방향 전환으로 이어질 수 있다
- [5.1432] 신규 구조 또는 미분류 패턴일 수 있다

### Anomaly Notes
- magnitude outlier
- order regime change
