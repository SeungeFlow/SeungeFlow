"""
Structure Interpreter Kernel v0.1
ChartView Ratio Kernel + XAWF Mapper + Z Verifier + CSZ Runtime

This is the first runnable kernel skeleton for SeungeFlow-based
structure interpretation.

Authoring intent:
- C = ChartView decomposition
- S = SeungeFlow analysis / question generation bridge
- Z = Zsystem verification
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Any


@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str
    nearest_critical: str
    crossings: List[str]


@dataclass
class XAWFState:
    X: float
    A: float
    W: float
    F: float
    rhythm_signature: str


@dataclass
class ZState:
    score: float
    state: str
    reasons: List[str]


class RatioKernel:
    """
    1st Structure Kernel
    Detects interval ratios and structure state from layered values.
    Initial default layers:
    20, 60, 120, 240
    """

    def __init__(self, v20: float, v60: float, v120: float, v240: float) -> None:
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def _intervals(self) -> Dict[str, float]:
        return {
            "A_20_60": self.v20 - self.v60,
            "B_60_120": self.v60 - self.v120,
            "C_120_240": self.v120 - self.v240,
        }

    def _ordering(self) -> str:
        if self.v20 > self.v60 > self.v120 > self.v240:
            return "정배열"
        if self.v20 < self.v60 < self.v120 < self.v240:
            return "역배열"
        return "혼합배열"

    def _crossings(self) -> List[str]:
        crossings: List[str] = []
        if self.v20 == self.v60:
            crossings.append("20-60 교차")
        if self.v60 == self.v120:
            crossings.append("60-120 교차")
        if self.v120 == self.v240:
            crossings.append("120-240 교차")
        return crossings

    def compute(self) -> RatioState:
        intervals = self._intervals()
        nearest_critical = min(intervals, key=lambda k: abs(intervals[k]))
        return RatioState(
            intervals=intervals,
            order=self._ordering(),
            nearest_critical=nearest_critical,
            crossings=self._crossings(),
        )


class XAWFMapper:
    """
    Maps RatioState into XAWF cognition coordinates.

    X = current visible state
    A = transition signal
    W = deeper principle tendency
    F = usable function / average directional signal
    """

    def map(self, ratio_state: RatioState) -> XAWFState:
        x = ratio_state.intervals["A_20_60"]
        a = ratio_state.intervals["B_60_120"]
        w = ratio_state.intervals["C_120_240"]
        f = (x + a + w) / 3.0

        rhythm_signature = self._detect_rhythm(x, a, w)

        return XAWFState(
            X=x,
            A=a,
            W=w,
            F=f,
            rhythm_signature=rhythm_signature,
        )

    @staticmethod
    def _detect_rhythm(x: float, a: float, w: float) -> str:
        values = [x, a, w]
        signs = [1 if v > 0 else -1 if v < 0 else 0 for v in values]

        if signs[0] == signs[1] == signs[2]:
            return "aligned_rhythm"
        if signs[0] != signs[1] != signs[2]:
            return "alternating_rhythm"
        return "mixed_rhythm"


class ZVerifier:
    """
    Verifies structure stability.

    This is intentionally simple for v0.1.
    Later versions can add:
    - symmetry tests
    - topology tests
    - resonance tests
    - anomaly tests
    """

    def verify(self, xawf: XAWFState, ratio_state: RatioState) -> ZState:
        score = abs(xawf.X) + abs(xawf.A) + abs(xawf.W)
        reasons: List[str] = []

        if ratio_state.order == "혼합배열":
            reasons.append("배열 혼합 상태")
        else:
            reasons.append(f"{ratio_state.order} 감지")

        if ratio_state.crossings:
            reasons.append("교차 존재")
        else:
            reasons.append("직접 교차 없음")

        reasons.append(f"nearest_critical={ratio_state.nearest_critical}")
        reasons.append(f"rhythm={xawf.rhythm_signature}")

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return ZState(score=score, state=state, reasons=reasons)


class CSZRuntime:
    """
    C = ChartView decomposition
    S = SeungeFlow mapping
    Z = Zsystem verification
    """

    def __init__(self) -> None:
        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()

    def run(self, v20: float, v60: float, v120: float, v240: float) -> Dict[str, Any]:
        chart = RatioKernel(v20, v60, v120, v240)
        ratio_state = chart.compute()
        xawf_state = self.mapper.map(ratio_state)
        z_state = self.verifier.verify(xawf_state, ratio_state)

        return {
            "ratio": asdict(ratio_state),
            "xawf": asdict(xawf_state),
            "zsystem": asdict(z_state),
        }


def demo() -> Dict[str, Any]:
    runtime = CSZRuntime()
    return runtime.run(v20=84.7, v60=82.5, v120=78.2, v240=67.2)


if __name__ == "__main__":
    import json
    print(json.dumps(demo(), ensure_ascii=False, indent=2))
