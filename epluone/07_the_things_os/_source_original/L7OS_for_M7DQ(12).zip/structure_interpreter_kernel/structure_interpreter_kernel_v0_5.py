
"""
Structure Interpreter Kernel v0.5

New module:
Spiral Attractor Engine

Purpose:
Detect convergence / divergence tendencies across repeated structural states
and classify whether the system is moving toward a spiral attractor,
away from it, or orbiting around it.

Modules:
- RatioKernel
- XAWFMapper
- ZVerifier
- PatternMemory
- SpiralAttractorEngine
- StructureInterpreter
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any
import json
import math


# ============================
# Data Models
# ============================

@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str


# ============================
# Ratio Kernel
# ============================

class RatioKernel:

    def __init__(self, v20, v60, v120, v240):
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def compute(self):

        A = self.v20 - self.v60
        B = self.v60 - self.v120
        C = self.v120 - self.v240

        if self.v20 > self.v60 > self.v120 > self.v240:
            order = "정배열"
        elif self.v20 < self.v60 < self.v120 < self.v240:
            order = "역배열"
        else:
            order = "혼합"

        return RatioState(
            intervals={"A": A, "B": B, "C": C},
            order=order
        )


# ============================
# XAWF Mapper
# ============================

class XAWFMapper:

    def map(self, ratio):

        X = ratio.intervals["A"]
        A = ratio.intervals["B"]
        W = ratio.intervals["C"]
        F = (X + A + W) / 3.0

        magnitude = math.sqrt((X ** 2) + (A ** 2) + (W ** 2))

        return {
            "X": X,
            "A": A,
            "W": W,
            "F": F,
            "magnitude": magnitude
        }


# ============================
# Z System Verification
# ============================

class ZVerifier:

    def verify(self, xawf):

        score = abs(xawf["X"]) + abs(xawf["A"]) + abs(xawf["W"])

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return {
            "score": score,
            "state": state
        }


# ============================
# Pattern Memory Engine
# ============================

class PatternMemory:

    def __init__(self):
        self.memory: List[Dict[str, Any]] = []

    def add(self, state: Dict[str, Any]):
        self.memory.append(state)

    def compare(self, state: Dict[str, Any]):

        similarities = []

        for past in self.memory:
            score = 0

            if past["ratio"]["order"] == state["ratio"]["order"]:
                score += 1

            if past["zsystem"]["state"] == state["zsystem"]["state"]:
                score += 1

            similarities.append(score)

        if not similarities:
            return {"pattern_match": False, "score": 0}

        best = max(similarities)

        return {
            "pattern_match": best > 1,
            "score": best
        }


# ============================
# Spiral Attractor Engine
# ============================

class SpiralAttractorEngine:
    """
    Detects whether the recent sequence of XAWF magnitudes is:
    - converging toward an attractor
    - diverging away
    - orbiting / oscillating near a basin
    """

    def analyze(self, memory: List[Dict[str, Any]], current_state: Dict[str, Any]):

        magnitudes = [
            item["xawf"]["magnitude"]
            for item in memory[-5:]
            if "xawf" in item and "magnitude" in item["xawf"]
        ]

        magnitudes.append(current_state["xawf"]["magnitude"])

        if len(magnitudes) < 2:
            return {
                "trajectory": "insufficient_data",
                "delta_sequence": [],
                "attractor_score": 0.0
            }

        deltas = [
            magnitudes[i+1] - magnitudes[i]
            for i in range(len(magnitudes) - 1)
        ]

        negatives = sum(1 for d in deltas if d < 0)
        positives = sum(1 for d in deltas if d > 0)

        mean_abs_delta = sum(abs(d) for d in deltas) / len(deltas)

        if negatives == len(deltas):
            trajectory = "spiral_convergence"
        elif positives == len(deltas):
            trajectory = "spiral_divergence"
        elif negatives > 0 and positives > 0 and mean_abs_delta < 5:
            trajectory = "orbiting_basin"
        else:
            trajectory = "mixed_transition"

        attractor_score = 0.0
        if trajectory == "spiral_convergence":
            attractor_score = max(0.0, 1.0 / (1.0 + mean_abs_delta))
        elif trajectory == "orbiting_basin":
            attractor_score = max(0.0, 0.5 / (1.0 + mean_abs_delta))
        elif trajectory == "spiral_divergence":
            attractor_score = 0.0
        else:
            attractor_score = max(0.0, 0.2 / (1.0 + mean_abs_delta))

        return {
            "trajectory": trajectory,
            "delta_sequence": deltas,
            "attractor_score": attractor_score
        }


# ============================
# Structure Interpreter
# ============================

class StructureInterpreter:

    def __init__(self):
        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()
        self.memory = PatternMemory()
        self.spiral = SpiralAttractorEngine()

    def run(self, v20, v60, v120, v240):

        ratio_kernel = RatioKernel(v20, v60, v120, v240)
        ratio = ratio_kernel.compute()

        xawf = self.mapper.map(ratio)
        z = self.verifier.verify(xawf)

        state = {
            "ratio": asdict(ratio),
            "xawf": xawf,
            "zsystem": z
        }

        memory_check = self.memory.compare(state)
        spiral_state = self.spiral.analyze(self.memory.memory, state)

        self.memory.add(state)

        return {
            "state": state,
            "memory": memory_check,
            "spiral": spiral_state
        }


# ============================
# Demo
# ============================

if __name__ == "__main__":

    engine = StructureInterpreter()

    demo_data = [
        (84.7, 82.5, 78.2, 67.2),
        (84.1, 82.3, 78.5, 68.0),
        (83.9, 82.2, 78.8, 68.7),
        (83.6, 82.1, 79.0, 69.2),
        (83.3, 82.0, 79.3, 69.9),
    ]

    for row in demo_data:
        result = engine.run(*row)
        print(json.dumps(result, ensure_ascii=False, indent=2))
