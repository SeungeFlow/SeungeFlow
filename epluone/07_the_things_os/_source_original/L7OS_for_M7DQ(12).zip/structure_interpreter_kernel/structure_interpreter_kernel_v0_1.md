# Structure Interpreter Kernel v0.1

## Purpose

This file defines the first runnable kernel skeleton for the SeungeFlow-based Structure Interpreter.

Core loop:

```text
C = ChartView
S = SeungeFlow
Z = Zsystem
```

Execution:

```text
raw layered values
→ interval decomposition
→ XAWF mapping
→ stability verification
```

---

## Included Components

### 1. RatioKernel
Uses four default layers:

- 20
- 60
- 120
- 240

Computes:

- A_20_60
- B_60_120
- C_120_240

Detects:

- 정배열
- 역배열
- 혼합배열
- nearest critical interval
- direct crossings

---

### 2. XAWFMapper

Maps interval structure into:

- X = visible state
- A = transition
- W = principle tendency
- F = usable averaged signal

Also adds a simple rhythm signature:

- aligned_rhythm
- alternating_rhythm
- mixed_rhythm

---

### 3. ZVerifier

Evaluates:

- structure magnitude
- order state
- crossings
- nearest critical interval
- rhythm signature

Outputs:

- stable
- transition
- critical

---

### 4. CSZRuntime

Runs the full loop:

```text
ChartView → SeungeFlow → Zsystem
```

---

## Current Role

This is not the final Structure Interpreter core.

It is the first runnable **kernel shell** that connects:

- ChartView ratio structure
- XAWF cognition mapping
- Zsystem verification hook

---

## What Comes Next

Next kernel layers to add:

1. symmetry detector
2. topology detector
3. spiral / attractor detector
4. anomaly detector
5. multi-timeframe rhythm detector

---

## Position in the Project

```text
COREMAP
↓
CSZ Loop
↓
Structure Interpreter Kernel v0.1
↓
Future Scientific Hint Engine
```
