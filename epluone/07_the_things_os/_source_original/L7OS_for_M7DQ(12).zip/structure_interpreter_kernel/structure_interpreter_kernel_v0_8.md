
# Structure Interpreter Kernel v0.8

## New Module

Anomaly Detector

Purpose:

Detect structural anomalies relative to:

- recent memory
- functional sign behavior
- order regime change
- spiral divergence
- critical z-state

---

## Architecture

```text
ChartView Data
↓
RatioKernel
↓
XAWF Mapper
↓
ZVerifier
↓
PatternMemory
↓
SpiralAttractorEngine
↓
HypothesisGenerator
↓
HintRankingEngine
↓
AnomalyDetector
↓
Ranked + Anomaly-Aware Interpretation Output
```

---

## Anomaly Logic

The detector checks:

1. magnitude outlier
2. functional sign flip
3. order regime change
4. spiral divergence
5. critical z-state

Outputs:

- anomaly_score
- anomaly_level
- notes

---

## Why This Matters

The interpreter now distinguishes:

```text
normal recurring structure
vs
abnormal structural rupture
```

This makes the engine more useful for:

- phase transition detection
- instability detection
- regime shift detection
- candidate scientific clue isolation

---

## Next Step

Natural next modules:

1. topology graph engine
2. multi-dataset fusion engine
3. export-to-report pipeline
4. hint history engine
5. scientific clue clustering
