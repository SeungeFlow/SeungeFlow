
"""
Structure Interpreter Kernel v0.6

New module:
Hypothesis Generator

Purpose:
Generate interpretable hypotheses from structural state,
memory recurrence, and spiral attractor tendencies.

Modules:
- RatioKernel
- XAWFMapper
- ZVerifier
- PatternMemory
- SpiralAttractorEngine
- HypothesisGenerator
- StructureInterpreter
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any
import json
import math


# ============================
# Data Models
# ============================

@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str


# ============================
# Ratio Kernel
# ============================

class RatioKernel:

    def __init__(self, v20, v60, v120, v240):
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def compute(self):

        A = self.v20 - self.v60
        B = self.v60 - self.v120
        C = self.v120 - self.v240

        if self.v20 > self.v60 > self.v120 > self.v240:
            order = "정배열"
        elif self.v20 < self.v60 < self.v120 < self.v240:
            order = "역배열"
        else:
            order = "혼합"

        return RatioState(
            intervals={"A": A, "B": B, "C": C},
            order=order
        )


# ============================
# XAWF Mapper
# ============================

class XAWFMapper:

    def map(self, ratio):

        X = ratio.intervals["A"]
        A = ratio.intervals["B"]
        W = ratio.intervals["C"]
        F = (X + A + W) / 3.0
        magnitude = math.sqrt((X ** 2) + (A ** 2) + (W ** 2))

        return {
            "X": X,
            "A": A,
            "W": W,
            "F": F,
            "magnitude": magnitude
        }


# ============================
# Z System Verification
# ============================

class ZVerifier:

    def verify(self, xawf):

        score = abs(xawf["X"]) + abs(xawf["A"]) + abs(xawf["W"])

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return {
            "score": score,
            "state": state
        }


# ============================
# Pattern Memory
# ============================

class PatternMemory:

    def __init__(self):
        self.memory: List[Dict[str, Any]] = []

    def add(self, state: Dict[str, Any]):
        self.memory.append(state)

    def compare(self, state: Dict[str, Any]):

        similarities = []

        for past in self.memory:
            score = 0

            if past["ratio"]["order"] == state["ratio"]["order"]:
                score += 1

            if past["zsystem"]["state"] == state["zsystem"]["state"]:
                score += 1

            similarities.append(score)

        if not similarities:
            return {"pattern_match": False, "score": 0}

        best = max(similarities)

        return {
            "pattern_match": best > 1,
            "score": best
        }


# ============================
# Spiral Attractor Engine
# ============================

class SpiralAttractorEngine:

    def analyze(self, memory: List[Dict[str, Any]], current_state: Dict[str, Any]):

        magnitudes = [
            item["xawf"]["magnitude"]
            for item in memory[-5:]
            if "xawf" in item and "magnitude" in item["xawf"]
        ]

        magnitudes.append(current_state["xawf"]["magnitude"])

        if len(magnitudes) < 2:
            return {
                "trajectory": "insufficient_data",
                "delta_sequence": [],
                "attractor_score": 0.0
            }

        deltas = [
            magnitudes[i+1] - magnitudes[i]
            for i in range(len(magnitudes) - 1)
        ]

        negatives = sum(1 for d in deltas if d < 0)
        positives = sum(1 for d in deltas if d > 0)
        mean_abs_delta = sum(abs(d) for d in deltas) / len(deltas)

        if negatives == len(deltas):
            trajectory = "spiral_convergence"
        elif positives == len(deltas):
            trajectory = "spiral_divergence"
        elif negatives > 0 and positives > 0 and mean_abs_delta < 5:
            trajectory = "orbiting_basin"
        else:
            trajectory = "mixed_transition"

        if trajectory == "spiral_convergence":
            attractor_score = max(0.0, 1.0 / (1.0 + mean_abs_delta))
        elif trajectory == "orbiting_basin":
            attractor_score = max(0.0, 0.5 / (1.0 + mean_abs_delta))
        elif trajectory == "spiral_divergence":
            attractor_score = 0.0
        else:
            attractor_score = max(0.0, 0.2 / (1.0 + mean_abs_delta))

        return {
            "trajectory": trajectory,
            "delta_sequence": deltas,
            "attractor_score": attractor_score
        }


# ============================
# Hypothesis Generator
# ============================

class HypothesisGenerator:
    """
    Generates human-readable structural hypotheses from:
    - ratio order
    - z verification
    - memory recurrence
    - spiral attractor tendency
    """

    def generate(
        self,
        state: Dict[str, Any],
        memory_check: Dict[str, Any],
        spiral_state: Dict[str, Any],
    ) -> Dict[str, Any]:

        hypotheses: List[str] = []
        hints: List[str] = []

        order = state["ratio"]["order"]
        zstate = state["zsystem"]["state"]
        f_value = state["xawf"]["F"]
        trajectory = spiral_state["trajectory"]
        attractor_score = spiral_state["attractor_score"]

        if order == "정배열":
            hypotheses.append("상승 방향의 구조 정렬 가능성")
            hints.append("계층 간 간격이 한 방향으로 정돈되고 있다")
        elif order == "역배열":
            hypotheses.append("하강 방향의 구조 정렬 가능성")
            hints.append("계층 간 간격이 반대 방향으로 정돈되고 있다")
        else:
            hypotheses.append("혼합 배열 기반의 전이 구간 가능성")
            hints.append("정렬보다 재배치가 우세한 상태다")

        if zstate == "stable":
            hypotheses.append("현재 구조는 국소 안정권에 있을 가능성")
            hints.append("큰 교란 없이 유지되는 상태다")
        elif zstate == "transition":
            hypotheses.append("현재 구조는 임계 전이 구간일 가능성")
            hints.append("작은 변화가 방향 전환으로 이어질 수 있다")
        else:
            hypotheses.append("현재 구조는 고에너지 불안정 구간일 가능성")
            hints.append("구조 붕괴 또는 급격한 재배열 가능성을 본다")

        if memory_check["pattern_match"]:
            hypotheses.append("과거에 관측된 구조 패턴이 재등장하고 있을 가능성")
            hints.append("반복 구조를 기반으로 재귀적 검증이 가능하다")
        else:
            hypotheses.append("기억된 패턴과 충분히 일치하지 않는 새로운 구조 가능성")
            hints.append("신규 구조 또는 미분류 패턴일 수 있다")

        if trajectory == "spiral_convergence":
            hypotheses.append("구조가 spiral attractor basin으로 수렴 중일 가능성")
            hints.append("동역학이 점차 한 중심으로 모이고 있다")
        elif trajectory == "spiral_divergence":
            hypotheses.append("구조가 attractor basin에서 이탈 중일 가능성")
            hints.append("중심보다 분산 방향의 에너지가 우세하다")
        elif trajectory == "orbiting_basin":
            hypotheses.append("구조가 attractor 주변을 순환하며 안정권을 탐색 중일 가능성")
            hints.append("즉시 수렴하지 않고 공전형 탐색을 하는 상태다")
        else:
            hypotheses.append("동역학 구조가 복합 전이 상태에 있을 가능성")
            hints.append("수렴과 발산 요소가 동시에 존재한다")

        if abs(f_value) < 1:
            hints.append("F 값이 작아 즉시적 방향성보다 누적 구조가 중요하다")
        elif f_value > 0:
            hints.append("F 값이 양수이므로 상향 기능 벡터를 우선 검토한다")
        else:
            hints.append("F 값이 음수이므로 하향 기능 벡터를 우선 검토한다")

        scientific_hint = self._to_scientific_hint(
            order=order,
            zstate=zstate,
            trajectory=trajectory,
            attractor_score=attractor_score,
            memory_check=memory_check,
        )

        return {
            "hypotheses": hypotheses,
            "hints": hints,
            "scientific_hint": scientific_hint
        }

    @staticmethod
    def _to_scientific_hint(
        order: str,
        zstate: str,
        trajectory: str,
        attractor_score: float,
        memory_check: Dict[str, Any],
    ) -> str:
        return (
            f"구조 상태={order}, 안정성={zstate}, 동역학={trajectory}, "
            f"attractor_score={attractor_score:.4f}, "
            f"memory_match={memory_check['pattern_match']}."
        )


# ============================
# Structure Interpreter
# ============================

class StructureInterpreter:

    def __init__(self):
        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()
        self.memory = PatternMemory()
        self.spiral = SpiralAttractorEngine()
        self.hypothesis = HypothesisGenerator()

    def run(self, v20, v60, v120, v240):

        ratio_kernel = RatioKernel(v20, v60, v120, v240)
        ratio = ratio_kernel.compute()

        xawf = self.mapper.map(ratio)
        z = self.verifier.verify(xawf)

        state = {
            "ratio": asdict(ratio),
            "xawf": xawf,
            "zsystem": z
        }

        memory_check = self.memory.compare(state)
        spiral_state = self.spiral.analyze(self.memory.memory, state)
        hypothesis_state = self.hypothesis.generate(state, memory_check, spiral_state)

        self.memory.add(state)

        return {
            "state": state,
            "memory": memory_check,
            "spiral": spiral_state,
            "hypothesis": hypothesis_state
        }


# ============================
# Demo
# ============================

if __name__ == "__main__":

    engine = StructureInterpreter()

    demo_data = [
        (84.7, 82.5, 78.2, 67.2),
        (84.1, 82.3, 78.5, 68.0),
        (83.9, 82.2, 78.8, 68.7),
        (83.6, 82.1, 79.0, 69.2),
        (83.3, 82.0, 79.3, 69.9),
    ]

    for row in demo_data:
        result = engine.run(*row)
        print(json.dumps(result, ensure_ascii=False, indent=2))
