"""
Structure Interpreter Kernel v0.2
Adds:
- symmetry detector
- topology detector
- spiral / attractor detector
- multi-timeframe rhythm detector

Authoring intent:
C = ChartView decomposition
S = SeungeFlow analysis / question generation bridge
Z = Zsystem verification
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Dict, List, Any, Optional
import math


@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str
    nearest_critical: str
    crossings: List[str]


@dataclass
class XAWFState:
    X: float
    A: float
    W: float
    F: float
    rhythm_signature: str


@dataclass
class PatternState:
    symmetry_score: float
    topology_type: str
    spiral_score: float
    attractor_state: str
    mtf_rhythm: str
    notes: List[str]


@dataclass
class ZState:
    score: float
    state: str
    reasons: List[str]


class RatioKernel:
    """
    1st Structure Kernel
    Detects interval ratios and structure state from layered values.
    Default layers:
    20, 60, 120, 240
    """

    def __init__(self, v20: float, v60: float, v120: float, v240: float) -> None:
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def _intervals(self) -> Dict[str, float]:
        return {
            "A_20_60": self.v20 - self.v60,
            "B_60_120": self.v60 - self.v120,
            "C_120_240": self.v120 - self.v240,
        }

    def _ordering(self) -> str:
        if self.v20 > self.v60 > self.v120 > self.v240:
            return "정배열"
        if self.v20 < self.v60 < self.v120 < self.v240:
            return "역배열"
        return "혼합배열"

    def _crossings(self) -> List[str]:
        crossings: List[str] = []
        if self.v20 == self.v60:
            crossings.append("20-60 교차")
        if self.v60 == self.v120:
            crossings.append("60-120 교차")
        if self.v120 == self.v240:
            crossings.append("120-240 교차")
        return crossings

    def compute(self) -> RatioState:
        intervals = self._intervals()
        nearest_critical = min(intervals, key=lambda k: abs(intervals[k]))
        return RatioState(
            intervals=intervals,
            order=self._ordering(),
            nearest_critical=nearest_critical,
            crossings=self._crossings(),
        )


class XAWFMapper:
    """
    Maps RatioState into XAWF cognition coordinates.

    X = current visible state
    A = transition signal
    W = deeper principle tendency
    F = usable function / average directional signal
    """

    def map(self, ratio_state: RatioState) -> XAWFState:
        x = ratio_state.intervals["A_20_60"]
        a = ratio_state.intervals["B_60_120"]
        w = ratio_state.intervals["C_120_240"]
        f = (x + a + w) / 3.0

        rhythm_signature = self._detect_rhythm(x, a, w)

        return XAWFState(
            X=x,
            A=a,
            W=w,
            F=f,
            rhythm_signature=rhythm_signature,
        )

    @staticmethod
    def _detect_rhythm(x: float, a: float, w: float) -> str:
        values = [x, a, w]
        signs = [1 if v > 0 else -1 if v < 0 else 0 for v in values]

        if signs[0] == signs[1] == signs[2]:
            return "aligned_rhythm"
        if signs[0] != signs[1] != signs[2]:
            return "alternating_rhythm"
        return "mixed_rhythm"


class PatternDetector:
    """
    Adds pattern interpretation on top of XAWF and Ratio states.
    This is still heuristic, but it makes the kernel closer to
    a real structure interpreter.
    """

    def detect(
        self,
        ratio_state: RatioState,
        xawf_state: XAWFState,
        timeframe_series: Optional[Dict[str, float]] = None,
    ) -> PatternState:
        notes: List[str] = []

        symmetry_score = self._symmetry_score(
            ratio_state.intervals["A_20_60"],
            ratio_state.intervals["C_120_240"],
        )

        topology_type = self._topology_type(ratio_state, xawf_state)
        spiral_score = self._spiral_score(xawf_state)
        attractor_state = self._attractor_state(ratio_state, xawf_state, spiral_score)
        mtf_rhythm = self._multi_timeframe_rhythm(timeframe_series)

        notes.append(f"symmetry_score={symmetry_score:.4f}")
        notes.append(f"topology={topology_type}")
        notes.append(f"spiral_score={spiral_score:.4f}")
        notes.append(f"attractor_state={attractor_state}")
        notes.append(f"mtf_rhythm={mtf_rhythm}")

        return PatternState(
            symmetry_score=symmetry_score,
            topology_type=topology_type,
            spiral_score=spiral_score,
            attractor_state=attractor_state,
            mtf_rhythm=mtf_rhythm,
            notes=notes,
        )

    @staticmethod
    def _symmetry_score(left: float, right: float) -> float:
        denom = abs(left) + abs(right)
        if denom == 0:
            return 1.0
        return 1.0 - (abs(abs(left) - abs(right)) / denom)

    @staticmethod
    def _topology_type(ratio_state: RatioState, xawf_state: XAWFState) -> str:
        order = ratio_state.order
        rhythm = xawf_state.rhythm_signature

        if order in ("정배열", "역배열") and rhythm == "aligned_rhythm":
            return "linear_chain"
        if order == "혼합배열" and rhythm == "mixed_rhythm":
            return "truss_transition"
        if rhythm == "alternating_rhythm":
            return "oscillation_loop"
        return "mixed_network"

    @staticmethod
    def _spiral_score(xawf_state: XAWFState) -> float:
        values = [xawf_state.X, xawf_state.A, xawf_state.W]
        mags = [abs(v) for v in values]
        # Increasing or decreasing layered magnitudes imply directional spiral tendency.
        d1 = mags[1] - mags[0]
        d2 = mags[2] - mags[1]
        consistency = 1.0 if (d1 == 0 and d2 == 0) or (d1 >= 0 and d2 >= 0) or (d1 <= 0 and d2 <= 0) else 0.25
        spread = sum(mags) / (1.0 + max(mags))
        return consistency * spread

    @staticmethod
    def _attractor_state(ratio_state: RatioState, xawf_state: XAWFState, spiral_score: float) -> str:
        nearest = ratio_state.nearest_critical
        score = abs(xawf_state.F)

        if nearest == "A_20_60" and score < 3:
            return "near_local_attractor"
        if spiral_score > 1.2 and score < 20:
            return "spiral_convergence"
        if score >= 20:
            return "far_from_attractor"
        return "transitioning"

    @staticmethod
    def _multi_timeframe_rhythm(timeframe_series: Optional[Dict[str, float]]) -> str:
        if not timeframe_series:
            return "single_timeframe"
        vals = list(timeframe_series.values())
        signs = [1 if v > 0 else -1 if v < 0 else 0 for v in vals]
        if len(set(signs)) == 1:
            return "mtf_aligned"
        if len(set(signs)) == 2:
            return "mtf_mixed"
        return "mtf_complex"


class ZVerifier:
    """
    Verifies structure stability.

    v0.2 also takes detected patterns into account.
    """

    def verify(
        self,
        xawf: XAWFState,
        ratio_state: RatioState,
        pattern_state: PatternState,
    ) -> ZState:
        score = abs(xawf.X) + abs(xawf.A) + abs(xawf.W)
        reasons: List[str] = []

        if ratio_state.order == "혼합배열":
            reasons.append("배열 혼합 상태")
        else:
            reasons.append(f"{ratio_state.order} 감지")

        if ratio_state.crossings:
            reasons.append("교차 존재")
        else:
            reasons.append("직접 교차 없음")

        reasons.append(f"nearest_critical={ratio_state.nearest_critical}")
        reasons.append(f"rhythm={xawf.rhythm_signature}")
        reasons.append(f"topology={pattern_state.topology_type}")
        reasons.append(f"attractor={pattern_state.attractor_state}")

        # stability modulation
        if pattern_state.attractor_state == "near_local_attractor":
            score *= 0.8
        elif pattern_state.attractor_state == "far_from_attractor":
            score *= 1.25

        if pattern_state.mtf_rhythm == "mtf_aligned":
            score *= 0.9
            reasons.append("다중 시간축 정렬")
        elif pattern_state.mtf_rhythm == "mtf_complex":
            score *= 1.1
            reasons.append("다중 시간축 복합")

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return ZState(score=score, state=state, reasons=reasons)


class CSZRuntime:
    """
    C = ChartView decomposition
    S = SeungeFlow mapping
    Z = Zsystem verification
    """

    def __init__(self) -> None:
        self.mapper = XAWFMapper()
        self.detector = PatternDetector()
        self.verifier = ZVerifier()

    def run(
        self,
        v20: float,
        v60: float,
        v120: float,
        v240: float,
        timeframe_series: Optional[Dict[str, float]] = None,
    ) -> Dict[str, Any]:
        chart = RatioKernel(v20, v60, v120, v240)
        ratio_state = chart.compute()
        xawf_state = self.mapper.map(ratio_state)
        pattern_state = self.detector.detect(ratio_state, xawf_state, timeframe_series)
        z_state = self.verifier.verify(xawf_state, ratio_state, pattern_state)

        return {
            "ratio": asdict(ratio_state),
            "xawf": asdict(xawf_state),
            "pattern": asdict(pattern_state),
            "zsystem": asdict(z_state),
        }


def demo() -> Dict[str, Any]:
    runtime = CSZRuntime()
    return runtime.run(
        v20=84.7,
        v60=82.5,
        v120=78.2,
        v240=67.2,
        timeframe_series={
            "1h": 1.2,
            "1d": 1.8,
            "1w": 2.0,
            "1m": 2.5,
        },
    )


if __name__ == "__main__":
    import json
    print(json.dumps(demo(), ensure_ascii=False, indent=2))
