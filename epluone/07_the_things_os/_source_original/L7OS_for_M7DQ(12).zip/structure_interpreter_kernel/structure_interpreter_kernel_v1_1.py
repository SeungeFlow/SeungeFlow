
"""
Structure Interpreter Kernel v1.1

New module:
Export-to-Report Pipeline

Purpose:
Convert fused interpreter outputs into a readable Markdown report.

Modules:
- RatioKernel
- XAWFMapper
- ZVerifier
- PatternMemory
- SpiralAttractorEngine
- HypothesisGenerator
- HintRankingEngine
- AnomalyDetector
- TopologyGraphEngine
- MultiDatasetFusionEngine
- ReportExporter
- StructureInterpreter
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any
import json
import math
import statistics


@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str


class RatioKernel:
    def __init__(self, v20, v60, v120, v240):
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def compute(self):
        A = self.v20 - self.v60
        B = self.v60 - self.v120
        C = self.v120 - self.v240

        if self.v20 > self.v60 > self.v120 > self.v240:
            order = "정배열"
        elif self.v20 < self.v60 < self.v120 < self.v240:
            order = "역배열"
        else:
            order = "혼합"

        return RatioState(intervals={"A": A, "B": B, "C": C}, order=order)


class XAWFMapper:
    def map(self, ratio):
        X = ratio.intervals["A"]
        A = ratio.intervals["B"]
        W = ratio.intervals["C"]
        F = (X + A + W) / 3.0
        magnitude = math.sqrt((X ** 2) + (A ** 2) + (W ** 2))
        return {"X": X, "A": A, "W": W, "F": F, "magnitude": magnitude}


class ZVerifier:
    def verify(self, xawf):
        score = abs(xawf["X"]) + abs(xawf["A"]) + abs(xawf["W"])
        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"
        return {"score": score, "state": state}


class PatternMemory:
    def __init__(self):
        self.memory: List[Dict[str, Any]] = []

    def add(self, state: Dict[str, Any]):
        self.memory.append(state)

    def compare(self, state: Dict[str, Any]):
        similarities = []
        for past in self.memory:
            score = 0
            if past["ratio"]["order"] == state["ratio"]["order"]:
                score += 1
            if past["zsystem"]["state"] == state["zsystem"]["state"]:
                score += 1
            similarities.append(score)

        if not similarities:
            return {"pattern_match": False, "score": 0}

        best = max(similarities)
        return {"pattern_match": best > 1, "score": best}


class SpiralAttractorEngine:
    def analyze(self, memory: List[Dict[str, Any]], current_state: Dict[str, Any]):
        magnitudes = [
            item["xawf"]["magnitude"]
            for item in memory[-5:]
            if "xawf" in item and "magnitude" in item["xawf"]
        ]
        magnitudes.append(current_state["xawf"]["magnitude"])

        if len(magnitudes) < 2:
            return {"trajectory": "insufficient_data", "delta_sequence": [], "attractor_score": 0.0}

        deltas = [magnitudes[i+1] - magnitudes[i] for i in range(len(magnitudes) - 1)]
        negatives = sum(1 for d in deltas if d < 0)
        positives = sum(1 for d in deltas if d > 0)
        mean_abs_delta = sum(abs(d) for d in deltas) / len(deltas)

        if negatives == len(deltas):
            trajectory = "spiral_convergence"
        elif positives == len(deltas):
            trajectory = "spiral_divergence"
        elif negatives > 0 and positives > 0 and mean_abs_delta < 5:
            trajectory = "orbiting_basin"
        else:
            trajectory = "mixed_transition"

        if trajectory == "spiral_convergence":
            attractor_score = max(0.0, 1.0 / (1.0 + mean_abs_delta))
        elif trajectory == "orbiting_basin":
            attractor_score = max(0.0, 0.5 / (1.0 + mean_abs_delta))
        elif trajectory == "spiral_divergence":
            attractor_score = 0.0
        else:
            attractor_score = max(0.0, 0.2 / (1.0 + mean_abs_delta))

        return {
            "trajectory": trajectory,
            "delta_sequence": deltas,
            "attractor_score": attractor_score
        }


class HypothesisGenerator:
    def generate(self, state: Dict[str, Any], memory_check: Dict[str, Any], spiral_state: Dict[str, Any]) -> Dict[str, Any]:
        hypotheses: List[str] = []
        hints: List[str] = []

        order = state["ratio"]["order"]
        zstate = state["zsystem"]["state"]
        f_value = state["xawf"]["F"]
        trajectory = spiral_state["trajectory"]
        attractor_score = spiral_state["attractor_score"]

        if order == "정배열":
            hypotheses.append("상승 방향의 구조 정렬 가능성")
            hints.append("계층 간 간격이 한 방향으로 정돈되고 있다")
        elif order == "역배열":
            hypotheses.append("하강 방향의 구조 정렬 가능성")
            hints.append("계층 간 간격이 반대 방향으로 정돈되고 있다")
        else:
            hypotheses.append("혼합 배열 기반의 전이 구간 가능성")
            hints.append("정렬보다 재배치가 우세한 상태다")

        if zstate == "stable":
            hypotheses.append("현재 구조는 국소 안정권에 있을 가능성")
            hints.append("큰 교란 없이 유지되는 상태다")
        elif zstate == "transition":
            hypotheses.append("현재 구조는 임계 전이 구간일 가능성")
            hints.append("작은 변화가 방향 전환으로 이어질 수 있다")
        else:
            hypotheses.append("현재 구조는 고에너지 불안정 구간일 가능성")
            hints.append("구조 붕괴 또는 급격한 재배열 가능성을 본다")

        if memory_check["pattern_match"]:
            hypotheses.append("과거에 관측된 구조 패턴이 재등장하고 있을 가능성")
            hints.append("반복 구조를 기반으로 재귀적 검증이 가능하다")
        else:
            hypotheses.append("기억된 패턴과 충분히 일치하지 않는 새로운 구조 가능성")
            hints.append("신규 구조 또는 미분류 패턴일 수 있다")

        if trajectory == "spiral_convergence":
            hypotheses.append("구조가 spiral attractor basin으로 수렴 중일 가능성")
            hints.append("동역학이 점차 한 중심으로 모이고 있다")
        elif trajectory == "spiral_divergence":
            hypotheses.append("구조가 attractor basin에서 이탈 중일 가능성")
            hints.append("중심보다 분산 방향의 에너지가 우세하다")
        elif trajectory == "orbiting_basin":
            hypotheses.append("구조가 attractor 주변을 순환하며 안정권을 탐색 중일 가능성")
            hints.append("즉시 수렴하지 않고 공전형 탐색을 하는 상태다")
        else:
            hypotheses.append("동역학 구조가 복합 전이 상태에 있을 가능성")
            hints.append("수렴과 발산 요소가 동시에 존재한다")

        if abs(f_value) < 1:
            hints.append("F 값이 작아 즉시적 방향성보다 누적 구조가 중요하다")
        elif f_value > 0:
            hints.append("F 값이 양수이므로 상향 기능 벡터를 우선 검토한다")
        else:
            hints.append("F 값이 음수이므로 하향 기능 벡터를 우선 검토한다")

        scientific_hint = (
            f"구조 상태={order}, 안정성={zstate}, 동역학={trajectory}, "
            f"attractor_score={attractor_score:.4f}, memory_match={memory_check['pattern_match']}."
        )

        return {"hypotheses": hypotheses, "hints": hints, "scientific_hint": scientific_hint}


class HintRankingEngine:
    def rank(self, state: Dict[str, Any], memory_check: Dict[str, Any], spiral_state: Dict[str, Any], hypothesis_state: Dict[str, Any]) -> Dict[str, Any]:
        z_state = state["zsystem"]["state"]
        order = state["ratio"]["order"]
        trajectory = spiral_state["trajectory"]
        attractor_score = spiral_state["attractor_score"]
        memory_score = memory_check["score"]

        base_score = 0.0

        if z_state == "stable":
            base_score += 1.0
        elif z_state == "transition":
            base_score += 1.5
        else:
            base_score += 1.2

        if order == "혼합":
            base_score += 1.2
        else:
            base_score += 0.8

        if trajectory == "spiral_convergence":
            base_score += 2.0
        elif trajectory == "orbiting_basin":
            base_score += 1.5
        elif trajectory == "mixed_transition":
            base_score += 1.0
        else:
            base_score += 0.2

        base_score += float(memory_score) * 0.75
        base_score += float(attractor_score) * 3.0

        level = self._level(base_score)

        ranked_hypotheses = []
        for idx, h in enumerate(hypothesis_state["hypotheses"], start=1):
            ranked_hypotheses.append({"rank": idx, "score": round(base_score - ((idx - 1) * 0.15), 4), "text": h})

        ranked_hints = []
        for idx, h in enumerate(hypothesis_state["hints"], start=1):
            ranked_hints.append({"rank": idx, "score": round(base_score - ((idx - 1) * 0.1), 4), "text": h})

        return {
            "priority_score": round(base_score, 4),
            "priority_level": level,
            "ranked_hypotheses": ranked_hypotheses,
            "ranked_hints": ranked_hints
        }

    @staticmethod
    def _level(score: float) -> str:
        if score >= 5.5:
            return "high"
        if score >= 3.5:
            return "medium"
        return "low"


class AnomalyDetector:
    def detect(self, memory: List[Dict[str, Any]], state: Dict[str, Any], spiral_state: Dict[str, Any]) -> Dict[str, Any]:
        notes: List[str] = []
        anomaly_score = 0.0

        current_mag = state["xawf"]["magnitude"]
        current_f = state["xawf"]["F"]
        current_order = state["ratio"]["order"]

        recent = memory[-10:]
        recent_mags = [m["xawf"]["magnitude"] for m in recent if "xawf" in m]
        recent_fs = [m["xawf"]["F"] for m in recent if "xawf" in m]
        recent_orders = [m["ratio"]["order"] for m in recent if "ratio" in m]

        if recent_mags:
            mean_mag = statistics.mean(recent_mags)
            stdev_mag = statistics.pstdev(recent_mags) if len(recent_mags) > 1 else 0.0
            if stdev_mag > 0 and abs(current_mag - mean_mag) > 2.0 * stdev_mag:
                anomaly_score += 2.0
                notes.append("magnitude outlier")
            elif stdev_mag > 0 and abs(current_mag - mean_mag) > 1.0 * stdev_mag:
                anomaly_score += 1.0
                notes.append("magnitude deviation")

        if recent_fs:
            mean_f = statistics.mean(recent_fs)
            if (mean_f > 0 and current_f < 0) or (mean_f < 0 and current_f > 0):
                anomaly_score += 1.5
                notes.append("functional sign flip")

        if recent_orders:
            dominant_order = max(set(recent_orders), key=recent_orders.count)
            if current_order != dominant_order:
                anomaly_score += 1.0
                notes.append("order regime change")

        if spiral_state["trajectory"] == "spiral_divergence":
            anomaly_score += 1.5
            notes.append("spiral divergence detected")
        elif spiral_state["trajectory"] == "mixed_transition":
            anomaly_score += 0.5
            notes.append("mixed transition turbulence")

        if state["zsystem"]["state"] == "critical":
            anomaly_score += 1.5
            notes.append("critical z-state")

        if anomaly_score >= 4.0:
            anomaly_level = "high"
        elif anomaly_score >= 2.0:
            anomaly_level = "medium"
        elif anomaly_score > 0:
            anomaly_level = "low"
        else:
            anomaly_level = "none"

        return {"anomaly_score": round(anomaly_score, 4), "anomaly_level": anomaly_level, "notes": notes}


class TopologyGraphEngine:
    def build(self, raw_values: Dict[str, float], state: Dict[str, Any]) -> Dict[str, Any]:
        nodes = [
            {"id": "v20", "type": "time_layer", "value": raw_values["v20"]},
            {"id": "v60", "type": "time_layer", "value": raw_values["v60"]},
            {"id": "v120", "type": "time_layer", "value": raw_values["v120"]},
            {"id": "v240", "type": "time_layer", "value": raw_values["v240"]},
            {"id": "X", "type": "xawf", "value": state["xawf"]["X"]},
            {"id": "A", "type": "xawf", "value": state["xawf"]["A"]},
            {"id": "W", "type": "xawf", "value": state["xawf"]["W"]},
            {"id": "F", "type": "xawf", "value": state["xawf"]["F"]},
        ]

        edges = [
            self._edge("v20", "v60", "interval", state["ratio"]["intervals"]["A"]),
            self._edge("v60", "v120", "interval", state["ratio"]["intervals"]["B"]),
            self._edge("v120", "v240", "interval", state["ratio"]["intervals"]["C"]),
            self._edge("X", "A", "xawf_transition", state["xawf"]["A"] - state["xawf"]["X"]),
            self._edge("A", "W", "xawf_transition", state["xawf"]["W"] - state["xawf"]["A"]),
            self._edge("W", "F", "xawf_projection", state["xawf"]["F"] - state["xawf"]["W"]),
        ]

        graph_type = self._classify_graph(state)
        density = len(edges) / max(1, len(nodes))
        relation_signature = self._relation_signature(edges)

        return {
            "nodes": nodes,
            "edges": edges,
            "graph_type": graph_type,
            "density": round(density, 4),
            "relation_signature": relation_signature,
        }

    @staticmethod
    def _edge(src: str, dst: str, rel_type: str, weight: float) -> Dict[str, Any]:
        direction = "positive" if weight > 0 else "negative" if weight < 0 else "neutral"
        return {"src": src, "dst": dst, "type": rel_type, "weight": round(float(weight), 6), "direction": direction}

    @staticmethod
    def _classify_graph(state: Dict[str, Any]) -> str:
        order = state["ratio"]["order"]
        zstate = state["zsystem"]["state"]
        if order in ("정배열", "역배열") and zstate == "stable":
            return "ordered_chain"
        if order == "혼합" and zstate == "transition":
            return "truss_transition_graph"
        if zstate == "critical":
            return "rupture_graph"
        return "mixed_relation_graph"

    @staticmethod
    def _relation_signature(edges: List[Dict[str, Any]]) -> str:
        positives = sum(1 for e in edges if e["direction"] == "positive")
        negatives = sum(1 for e in edges if e["direction"] == "negative")
        neutrals = sum(1 for e in edges if e["direction"] == "neutral")
        return f"pos={positives}|neg={negatives}|neu={neutrals}"


class MultiDatasetFusionEngine:
    def fuse(self, outputs: List[Dict[str, Any]]) -> Dict[str, Any]:
        if not outputs:
            return {
                "count": 0,
                "dominant_order": None,
                "dominant_zstate": None,
                "dominant_trajectory": None,
                "mean_priority_score": 0.0,
                "mean_anomaly_score": 0.0,
                "graph_types": [],
                "fusion_hint": "no_data"
            }

        orders = [o["state"]["ratio"]["order"] for o in outputs]
        zstates = [o["state"]["zsystem"]["state"] for o in outputs]
        trajectories = [o["spiral"]["trajectory"] for o in outputs]
        priority_scores = [o["ranking"]["priority_score"] for o in outputs]
        anomaly_scores = [o["anomaly"]["anomaly_score"] for o in outputs]
        graph_types = [o["topology"]["graph_type"] for o in outputs]

        dominant_order = max(set(orders), key=orders.count)
        dominant_zstate = max(set(zstates), key=zstates.count)
        dominant_trajectory = max(set(trajectories), key=trajectories.count)
        dominant_graph = max(set(graph_types), key=graph_types.count)

        mean_priority = statistics.mean(priority_scores)
        mean_anomaly = statistics.mean(anomaly_scores)

        fusion_hint = (
            f"다중 데이터 융합 결과: order={dominant_order}, zstate={dominant_zstate}, "
            f"trajectory={dominant_trajectory}, graph={dominant_graph}, "
            f"mean_priority={mean_priority:.4f}, mean_anomaly={mean_anomaly:.4f}."
        )

        return {
            "count": len(outputs),
            "dominant_order": dominant_order,
            "dominant_zstate": dominant_zstate,
            "dominant_trajectory": dominant_trajectory,
            "dominant_graph_type": dominant_graph,
            "mean_priority_score": round(mean_priority, 4),
            "mean_anomaly_score": round(mean_anomaly, 4),
            "graph_types": graph_types,
            "fusion_hint": fusion_hint,
        }


class ReportExporter:
    """
    Export interpreter outputs and fused summary to Markdown.
    """

    def export_markdown(self, outputs: List[Dict[str, Any]], fused: Dict[str, Any]) -> str:
        lines: List[str] = []
        lines.append("# Structure Interpreter Report v1.1")
        lines.append("")
        lines.append("## Fusion Summary")
        lines.append(f"- Count: {fused['count']}")
        lines.append(f"- Dominant Order: {fused['dominant_order']}")
        lines.append(f"- Dominant Z-State: {fused['dominant_zstate']}")
        lines.append(f"- Dominant Trajectory: {fused['dominant_trajectory']}")
        lines.append(f"- Dominant Graph Type: {fused['dominant_graph_type']}")
        lines.append(f"- Mean Priority Score: {fused['mean_priority_score']}")
        lines.append(f"- Mean Anomaly Score: {fused['mean_anomaly_score']}")
        lines.append(f"- Fusion Hint: {fused['fusion_hint']}")
        lines.append("")

        for idx, out in enumerate(outputs, start=1):
            lines.append(f"## Sample {idx}")
            lines.append(f"- Order: {out['state']['ratio']['order']}")
            lines.append(f"- Z-State: {out['state']['zsystem']['state']}")
            lines.append(f"- Spiral: {out['spiral']['trajectory']}")
            lines.append(f"- Priority: {out['ranking']['priority_score']} ({out['ranking']['priority_level']})")
            lines.append(f"- Anomaly: {out['anomaly']['anomaly_score']} ({out['anomaly']['anomaly_level']})")
            lines.append(f"- Graph Type: {out['topology']['graph_type']}")
            lines.append(f"- Scientific Hint: {out['hypothesis']['scientific_hint']}")
            lines.append("")
            lines.append("### Top Ranked Hypotheses")
            for item in out["ranking"]["ranked_hypotheses"][:3]:
                lines.append(f"- [{item['score']}] {item['text']}")
            lines.append("")
            lines.append("### Top Ranked Hints")
            for item in out["ranking"]["ranked_hints"][:3]:
                lines.append(f"- [{item['score']}] {item['text']}")
            lines.append("")
            if out["anomaly"]["notes"]:
                lines.append("### Anomaly Notes")
                for note in out["anomaly"]["notes"]:
                    lines.append(f"- {note}")
                lines.append("")

        return "\n".join(lines)


class StructureInterpreter:
    def __init__(self):
        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()
        self.memory = PatternMemory()
        self.spiral = SpiralAttractorEngine()
        self.hypothesis = HypothesisGenerator()
        self.ranker = HintRankingEngine()
        self.anomaly = AnomalyDetector()
        self.topology = TopologyGraphEngine()

    def run(self, v20, v60, v120, v240):
        raw_values = {"v20": float(v20), "v60": float(v60), "v120": float(v120), "v240": float(v240)}

        ratio_kernel = RatioKernel(v20, v60, v120, v240)
        ratio = ratio_kernel.compute()

        xawf = self.mapper.map(ratio)
        z = self.verifier.verify(xawf)

        state = {
            "ratio": asdict(ratio),
            "xawf": xawf,
            "zsystem": z
        }

        memory_check = self.memory.compare(state)
        spiral_state = self.spiral.analyze(self.memory.memory, state)
        hypothesis_state = self.hypothesis.generate(state, memory_check, spiral_state)
        ranking_state = self.ranker.rank(state, memory_check, spiral_state, hypothesis_state)
        anomaly_state = self.anomaly.detect(self.memory.memory, state, spiral_state)
        topology_state = self.topology.build(raw_values, state)

        self.memory.add(state)

        return {
            "state": state,
            "memory": memory_check,
            "spiral": spiral_state,
            "hypothesis": hypothesis_state,
            "ranking": ranking_state,
            "anomaly": anomaly_state,
            "topology": topology_state,
        }


if __name__ == "__main__":
    engine = StructureInterpreter()
    fusion = MultiDatasetFusionEngine()
    exporter = ReportExporter()

    demo_data = [
        (84.7, 82.5, 78.2, 67.2),
        (84.1, 82.3, 78.5, 68.0),
        (83.9, 82.2, 78.8, 68.7),
        (83.6, 82.1, 79.0, 69.2),
        (83.3, 82.0, 79.3, 69.9),
        (79.0, 84.0, 81.0, 60.0),
    ]

    outputs = [engine.run(*row) for row in demo_data]
    fused = fusion.fuse(outputs)
    report = exporter.export_markdown(outputs, fused)

    print(report)
