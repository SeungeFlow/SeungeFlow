
"""
Structure Interpreter Kernel v0.4

New module:
Pattern Memory Engine

Purpose:
Allow the interpreter to remember previous structural states
and compare them with current states to detect repeating patterns.

Modules:

RatioKernel
XAWFMapper
ZVerifier
PatternMemory
StructureInterpreterRuntime
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any
import json


# ============================
# Data Models
# ============================

@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str


@dataclass
class KernelState:
    ratio: Dict[str, Any]
    xawf: Dict[str, Any]
    zsystem: Dict[str, Any]


# ============================
# Ratio Kernel
# ============================

class RatioKernel:

    def __init__(self, v20, v60, v120, v240):
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def compute(self):

        A = self.v20 - self.v60
        B = self.v60 - self.v120
        C = self.v120 - self.v240

        if self.v20 > self.v60 > self.v120 > self.v240:
            order = "정배열"
        elif self.v20 < self.v60 < self.v120 < self.v240:
            order = "역배열"
        else:
            order = "혼합"

        return RatioState(
            intervals={"A": A, "B": B, "C": C},
            order=order
        )


# ============================
# XAWF Mapper
# ============================

class XAWFMapper:

    def map(self, ratio):

        X = ratio.intervals["A"]
        A = ratio.intervals["B"]
        W = ratio.intervals["C"]

        F = (X + A + W) / 3

        return {
            "X": X,
            "A": A,
            "W": W,
            "F": F
        }


# ============================
# Z System Verification
# ============================

class ZVerifier:

    def verify(self, xawf):

        score = abs(xawf["X"]) + abs(xawf["A"]) + abs(xawf["W"])

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return {
            "score": score,
            "state": state
        }


# ============================
# Pattern Memory Engine
# ============================

class PatternMemory:

    """
    Stores previous structure states and detects similarity.
    """

    def __init__(self):

        self.memory: List[Dict[str, Any]] = []

    def add(self, state: Dict[str, Any]):
        self.memory.append(state)

    def compare(self, state: Dict[str, Any]):

        similarities = []

        for past in self.memory:

            score = 0

            if past["ratio"]["order"] == state["ratio"]["order"]:
                score += 1

            if past["zsystem"]["state"] == state["zsystem"]["state"]:
                score += 1

            similarities.append(score)

        if not similarities:
            return {"pattern_match": False, "score": 0}

        best = max(similarities)

        return {
            "pattern_match": best > 1,
            "score": best
        }


# ============================
# Structure Interpreter
# ============================

class StructureInterpreter:

    def __init__(self):

        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()
        self.memory = PatternMemory()

    def run(self, v20, v60, v120, v240):

        ratio_kernel = RatioKernel(v20, v60, v120, v240)

        ratio = ratio_kernel.compute()

        xawf = self.mapper.map(ratio)

        z = self.verifier.verify(xawf)

        state = {
            "ratio": asdict(ratio),
            "xawf": xawf,
            "zsystem": z
        }

        memory_check = self.memory.compare(state)

        self.memory.add(state)

        return {
            "state": state,
            "memory": memory_check
        }


# ============================
# Demo
# ============================

if __name__ == "__main__":

    engine = StructureInterpreter()

    demo_data = [
        (84.7,82.5,78.2,67.2),
        (83.1,82.0,79.0,70.1),
        (84.8,82.4,78.1,67.3)
    ]

    for row in demo_data:

        result = engine.run(*row)

        print(json.dumps(result, ensure_ascii=False, indent=2))
