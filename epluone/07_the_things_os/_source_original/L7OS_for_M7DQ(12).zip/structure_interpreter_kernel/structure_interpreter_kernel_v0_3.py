
"""
Structure Interpreter Kernel v0.3
Adds:

1. ChartView Dataset Adapter
2. CSV / JSON ingestion
3. Automatic kernel execution on dataset rows
4. Result export

This connects the real ChartView-style data with the interpreter kernel.
"""

from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, List, Any
import csv
import json


# ===============================
# Data structures
# ===============================

@dataclass
class RatioState:
    intervals: Dict[str, float]
    order: str


@dataclass
class KernelResult:
    ratio: Dict[str, Any]
    xawf: Dict[str, Any]
    zsystem: Dict[str, Any]


# ===============================
# Ratio Kernel
# ===============================

class RatioKernel:

    def __init__(self, v20: float, v60: float, v120: float, v240: float):
        self.v20 = float(v20)
        self.v60 = float(v60)
        self.v120 = float(v120)
        self.v240 = float(v240)

    def compute(self) -> RatioState:

        A = self.v20 - self.v60
        B = self.v60 - self.v120
        C = self.v120 - self.v240

        if self.v20 > self.v60 > self.v120 > self.v240:
            order = "정배열"
        elif self.v20 < self.v60 < self.v120 < self.v240:
            order = "역배열"
        else:
            order = "혼합"

        return RatioState(
            intervals={"A": A, "B": B, "C": C},
            order=order
        )


# ===============================
# XAWF Mapper
# ===============================

class XAWFMapper:

    def map(self, ratio: RatioState):

        X = ratio.intervals["A"]
        A = ratio.intervals["B"]
        W = ratio.intervals["C"]

        F = (X + A + W) / 3

        return {
            "X": X,
            "A": A,
            "W": W,
            "F": F
        }


# ===============================
# Z Verification
# ===============================

class ZVerifier:

    def verify(self, xawf):

        score = abs(xawf["X"]) + abs(xawf["A"]) + abs(xawf["W"])

        if score < 10:
            state = "stable"
        elif score < 50:
            state = "transition"
        else:
            state = "critical"

        return {
            "score": score,
            "state": state
        }


# ===============================
# Interpreter Runtime
# ===============================

class StructureInterpreter:

    def __init__(self):

        self.mapper = XAWFMapper()
        self.verifier = ZVerifier()

    def run(self, v20, v60, v120, v240) -> KernelResult:

        ratio_kernel = RatioKernel(v20, v60, v120, v240)

        ratio = ratio_kernel.compute()

        xawf = self.mapper.map(ratio)

        z = self.verifier.verify(xawf)

        return KernelResult(
            ratio=asdict(ratio),
            xawf=xawf,
            zsystem=z
        )


# ===============================
# ChartView Dataset Adapter
# ===============================

class ChartViewDatasetAdapter:

    """
    Reads ChartView-style datasets and feeds them into the interpreter kernel.
    Expected columns:

    v20
    v60
    v120
    v240
    """

    def __init__(self, file_path: str):

        self.file_path = file_path
        self.engine = StructureInterpreter()

    def run(self):

        results = []

        with open(self.file_path, "r", encoding="utf-8") as f:

            reader = csv.DictReader(f)

            for row in reader:

                v20 = float(row["v20"])
                v60 = float(row["v60"])
                v120 = float(row["v120"])
                v240 = float(row["v240"])

                result = self.engine.run(v20, v60, v120, v240)

                results.append(asdict(result))

        return results


# ===============================
# Demo Runner
# ===============================

if __name__ == "__main__":

    engine = StructureInterpreter()

    demo = engine.run(
        v20=84.7,
        v60=82.5,
        v120=78.2,
        v240=67.2
    )

    print(json.dumps(asdict(demo), ensure_ascii=False, indent=2))
