#!/bin/bash
set -e
cd /opt/m7dq/kernel

if [ -f seungeflow_master_runtime_all.py ]; then
  python3 seungeflow_master_runtime_all.py
else
  echo "runtime not found"
fi
