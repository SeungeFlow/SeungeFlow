
# SeungeFlow Final Distribution

Autonomous Research Infrastructure

## Components

Core Runtime
- seungeflow_master_runtime_all.py

Research Labs
- M7DQ millennium problem labs

Observatory
- live web dashboard

Operations
- cron or systemd runtime modes

## Install

bash INSTALL.sh

## Run research engine

cd /opt/m7dq/kernel
python3 seungeflow_master_runtime_all.py

## Run observatory

cd /opt/m7dq/kernel
python3 live_observatory_server.py

Open

http://localhost:7070

## Core Research Loop

Observe → Analyze → Ask → Plan → Discover → Review → Publish → Ask Again

## System Layout

/opt/m7dq

kernel/
logs/
reports/
systems/
inputs/
