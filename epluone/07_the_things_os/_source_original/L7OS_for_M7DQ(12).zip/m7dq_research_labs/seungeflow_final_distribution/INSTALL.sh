#!/bin/bash
set -e

BASE=/opt/m7dq

echo "Installing SeungeFlow Final Distribution"

mkdir -p $BASE/kernel
mkdir -p $BASE/logs
mkdir -p $BASE/reports
mkdir -p $BASE/systems
mkdir -p $BASE/inputs

echo "Directory layout created:"
echo "$BASE/{kernel,logs,reports,systems,inputs}"

echo ""
echo "Next steps:"
echo "1. Copy runtime files into $BASE/kernel"
echo "2. Place input datasets in $BASE/inputs"
echo "3. Place logs in $BASE/logs"
echo ""
echo "Run system:"
echo "cd $BASE/kernel"
echo "python3 seungeflow_master_runtime_all.py"
