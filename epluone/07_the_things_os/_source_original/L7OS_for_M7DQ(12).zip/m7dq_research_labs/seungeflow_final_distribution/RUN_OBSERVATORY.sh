#!/bin/bash
set -e
cd /opt/m7dq/kernel

python3 live_observatory_server.py
