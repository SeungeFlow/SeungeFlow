
import json
from pathlib import Path

BASE = Path("/opt/m7dq")
SYSTEMS = BASE / "systems"
REPORTS = BASE / "reports"

LABS = [
    "navier_stokes",
    "p_vs_np",
    "riemann",
    "yang_mills",
    "hodge",
    "birch_swinnerton_dyer",
    "poincare"
]

def build_structure():
    created = []
    for lab in LABS:
        lab_dir = SYSTEMS / lab
        (lab_dir / "logs").mkdir(parents=True, exist_ok=True)
        (lab_dir / "data").mkdir(parents=True, exist_ok=True)
        (lab_dir / "reports").mkdir(parents=True, exist_ok=True)

        meta = {
            "lab": lab,
            "status": "initialized",
            "description": "Millennium research lab environment"
        }

        with open(lab_dir / "lab_config.json","w") as f:
            json.dump(meta,f,indent=2)

        created.append(lab)

    REPORTS.mkdir(parents=True, exist_ok=True)
    with open(REPORTS / "m7dq_labs_created.json","w") as f:
        json.dump({"labs": created, "count": len(created)}, f, indent=2)

    print("M7DQ labs initialized:", created)

if __name__ == "__main__":
    build_structure()
