
# M7DQ Research Lab System

Creates automated research environments for the **7 Millennium Prize Problems**.

Labs created:

- navier_stokes
- p_vs_np
- riemann
- yang_mills
- hodge
- birch_swinnerton_dyer
- poincare

Directory layout:

/opt/m7dq/systems/

Each lab contains

logs/
data/
reports/
lab_config.json

Run research cycle

cd /opt/m7dq/kernel
python3 run_m7dq_cycle.py

Outputs

/opt/m7dq/reports/m7dq_labs_created.json
/opt/m7dq/reports/m7dq_experiment_signals.json
