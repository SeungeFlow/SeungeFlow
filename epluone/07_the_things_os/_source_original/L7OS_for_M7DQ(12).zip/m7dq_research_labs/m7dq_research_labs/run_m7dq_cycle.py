
import os

print("Running M7DQ research cycle")

steps = [
    "python3 m7dq_lab_builder.py",
    "python3 m7dq_experiment_runner.py"
]

for s in steps:
    print(">", s)
    os.system(s)

print("M7DQ cycle complete")
