
import json
from pathlib import Path
import random

BASE = Path("/opt/m7dq/systems")
REPORTS = Path("/opt/m7dq/reports")

results = []

for lab in BASE.iterdir():
    if not lab.is_dir():
        continue

    signal = round(random.random(), 4)

    results.append({
        "lab": lab.name,
        "experiment_signal": signal,
        "status": "running"
    })

REPORTS.mkdir(parents=True, exist_ok=True)

with open(REPORTS / "m7dq_experiment_signals.json","w") as f:
    json.dump(results,f,indent=2)

print("experiments simulated")
