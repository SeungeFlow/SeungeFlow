
import os

os.system("python3 pattern_memory_engine.py")
os.system("python3 pattern_comparison_engine.py")
os.system("python3 novelty_detector.py")
os.system("python3 pattern_memory_dashboard.py")
