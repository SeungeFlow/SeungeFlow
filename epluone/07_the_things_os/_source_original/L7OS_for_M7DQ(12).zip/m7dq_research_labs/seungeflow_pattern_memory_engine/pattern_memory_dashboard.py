
import json, os

STORE="/opt/m7dq/reports/pattern_memory_store.json"
REPORT="/opt/m7dq/reports/pattern_comparison_report.json"
OUT="/opt/m7dq/reports/pattern_memory_dashboard.md"

def main():
    snapshots=0
    if os.path.exists(STORE):
        snapshots=len(json.load(open(STORE)))
    novelty=0
    if os.path.exists(REPORT):
        novelty=json.load(open(REPORT)).get("novelty_score",0)
    md=f"""# Pattern Memory Dashboard

snapshot_count: {snapshots}
novelty_score: {novelty}
"""
    os.makedirs("/opt/m7dq/reports",exist_ok=True)
    open(OUT,"w").write(md)

if __name__=="__main__":
    main()
