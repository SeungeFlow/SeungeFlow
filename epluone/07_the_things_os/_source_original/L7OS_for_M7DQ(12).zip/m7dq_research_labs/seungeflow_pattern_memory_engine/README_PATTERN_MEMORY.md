
# SeungeFlow Pattern Memory Engine

modules:
pattern_memory_engine
pattern_comparison_engine
novelty_detector
pattern_memory_dashboard

cycle:
state -> compare -> novelty -> dashboard
