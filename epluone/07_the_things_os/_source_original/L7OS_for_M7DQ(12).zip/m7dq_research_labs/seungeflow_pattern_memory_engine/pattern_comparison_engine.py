
import json, os

STORE="/opt/m7dq/reports/pattern_memory_store.json"
REPORT="/opt/m7dq/reports/pattern_comparison_report.json"

def main():
    if not os.path.exists(STORE):
        return
    data=json.load(open(STORE))
    current=data[-1]
    report={
        "current_phase_state":current.get("phase_state"),
        "phase_seen_before":False,
        "known_hits":0,
        "novel_processes":[],
        "novelty_score":0.0
    }
    states=[d.get("phase_state") for d in data[:-1]]
    if current.get("phase_state") in states:
        report["phase_seen_before"]=True
        report["known_hits"]=states.count(current.get("phase_state"))
    else:
        report["novelty_score"]=0.8
    with open(REPORT,"w") as f:
        json.dump(report,f,indent=2)

if __name__=="__main__":
    main()
