
import json, os

REPORT="/opt/m7dq/reports/pattern_comparison_report.json"
OUT="/opt/m7dq/reports/novelty_alerts.json"

def main():
    if not os.path.exists(REPORT):
        return
    r=json.load(open(REPORT))
    score=r.get("novelty_score",0)
    level="low"
    if score>=0.6: level="high"
    elif score>=0.3: level="medium"
    with open(OUT,"w") as f:
        json.dump({"novelty_score":score,"alert_level":level},f,indent=2)

if __name__=="__main__":
    main()
