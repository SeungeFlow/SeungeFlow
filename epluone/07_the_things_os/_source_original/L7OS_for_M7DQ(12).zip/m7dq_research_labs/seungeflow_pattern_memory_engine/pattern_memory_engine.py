
import json, time, os

STORE="/opt/m7dq/reports/pattern_memory_store.json"
UPDATE="/opt/m7dq/reports/pattern_memory_update.json"

def collect_state():
    return {
        "top_processes":[],
        "phase_state":"unknown",
        "phase_score":0,
        "entropy":0,
        "lab_signals":[],
        "snapshot_timestamp":time.time()
    }

def main():
    state=collect_state()
    os.makedirs("/opt/m7dq/reports",exist_ok=True)
    with open(UPDATE,"w") as f:
        json.dump(state,f,indent=2)
    if os.path.exists(STORE):
        data=json.load(open(STORE))
    else:
        data=[]
    data.append(state)
    with open(STORE,"w") as f:
        json.dump(data,f,indent=2)

if __name__=="__main__":
    main()
