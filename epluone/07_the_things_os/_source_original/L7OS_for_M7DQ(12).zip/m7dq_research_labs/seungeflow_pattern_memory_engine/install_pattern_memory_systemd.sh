
#!/bin/bash
sudo cp pattern_memory.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable pattern_memory
sudo systemctl start pattern_memory
