
# M7DQ Research Observatory

Provides a lightweight dashboard for the 7 Millennium research labs.

## Run

cd /opt/m7dq/kernel
python3 run_observatory_cycle.py

## Outputs

/opt/m7dq/reports/m7dq_observatory_state.json
/opt/m7dq/reports/m7dq_dashboard.md

## Purpose

Monitor discovery signals across:

- navier_stokes
- p_vs_np
- riemann
- yang_mills
- hodge
- birch_swinnerton_dyer
- poincare
