
import json
from pathlib import Path

BASE = Path("/opt/m7dq")
REPORTS = BASE / "reports"
SYSTEMS = BASE / "systems"

OUTPUT = REPORTS / "m7dq_observatory_state.json"

labs = []
signals_file = REPORTS / "m7dq_experiment_signals.json"

signals = {}
if signals_file.exists():
    try:
        data = json.load(open(signals_file))
        signals = {d["lab"]: d["experiment_signal"] for d in data}
    except:
        signals = {}

for lab in SYSTEMS.iterdir():
    if lab.is_dir():
        labs.append({
            "lab": lab.name,
            "signal": signals.get(lab.name, None),
            "status": "active"
        })

report = {
    "lab_count": len(labs),
    "labs": labs
}

REPORTS.mkdir(parents=True, exist_ok=True)
with open(OUTPUT,"w") as f:
    json.dump(report,f,indent=2)

print("observatory state generated")
