
import json
from pathlib import Path

REPORTS = Path("/opt/m7dq/reports")
INPUT = REPORTS / "m7dq_observatory_state.json"
OUTPUT = REPORTS / "m7dq_dashboard.md"

lines = [
"# M7DQ Research Observatory",
"",
"## Lab Signals",
""
]

if INPUT.exists():
    data = json.load(open(INPUT))
    for lab in data.get("labs", []):
        signal = lab.get("signal")
        signal_str = "N/A" if signal is None else str(signal)
        lines.append(f"- {lab['lab']} : signal={signal_str}")

else:
    lines.append("No observatory data available")

lines += [
"",
"## Meaning",
"Signal values indicate experimental activity or discovery signals."
]

with open(OUTPUT,"w") as f:
    f.write("\n".join(lines))

print("dashboard generated")
