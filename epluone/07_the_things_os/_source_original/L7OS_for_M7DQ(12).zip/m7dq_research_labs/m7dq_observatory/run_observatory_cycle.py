
import os

print("Running M7DQ Observatory Cycle")

steps = [
"python3 m7dq_observatory_builder.py",
"python3 m7dq_dashboard_generator.py"
]

for s in steps:
    print(">", s)
    os.system(s)

print("Observatory cycle complete")
