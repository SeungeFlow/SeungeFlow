#!/usr/bin/env python3
import json
from pathlib import Path

REPORTS = Path("/opt/m7dq/reports")
STATE = REPORTS / "phase_transition_state.json"
ALERTS = REPORTS / "phase_alerts.json"
OUTPUT = REPORTS / "phase_transition_dashboard.md"

def load(path, default):
    if not path.exists():
        return default
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

state = load(STATE, {})
alerts = load(ALERTS, {"alerts": []})

lines = [
    "# SeungeFlow Phase Transition Dashboard",
    "",
    f"- phase_state: {state.get('phase_state', 'unknown')}",
    f"- phase_score: {state.get('phase_score', 0)}",
    "",
    "## Metrics"
]

for k, v in state.get("metrics", {}).items():
    lines.append(f"- {k}: {v}")

lines += [
    "",
    "## Alerts"
]

if alerts.get("alerts"):
    for a in alerts["alerts"]:
        lines.append(f"- [{a.get('level')}] {a.get('message')}")
else:
    lines.append("- No active phase alerts")

lines += [
    "",
    "## Meaning",
    "- stable: low transition pressure",
    "- unstable_active: signal and process motion rising",
    "- transition_rising: convergence toward a threshold",
    "- critical_transition: possible phase shift underway",
    ""
]

with open(OUTPUT, "w", encoding="utf-8") as f:
    f.write("\n".join(lines))

print("phase dashboard generated")
