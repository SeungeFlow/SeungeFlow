#!/usr/bin/env python3
import json
from pathlib import Path

REPORTS = Path("/opt/m7dq/reports")
INPUT = REPORTS / "phase_transition_state.json"
OUTPUT = REPORTS / "phase_alerts.json"

if not INPUT.exists():
    report = {
        "status": "missing",
        "message": "phase_transition_state.json not found",
        "alerts": []
    }
else:
    with open(INPUT, "r", encoding="utf-8") as f:
        state = json.load(f)

    phase_state = state.get("phase_state", "unknown")
    phase_score = state.get("phase_score", 0)
    alerts = []

    if phase_state == "critical_transition":
        alerts.append({
            "level": "high",
            "message": "Critical phase transition detected. Immediate review recommended."
        })
    elif phase_state == "transition_rising":
        alerts.append({
            "level": "medium",
            "message": "Phase transition rising. Monitor entropy, routing, and discovery activity."
        })
    elif phase_state == "unstable_active":
        alerts.append({
            "level": "low",
            "message": "System is active and unstable. Observe for pattern concentration."
        })

    report = {
        "status": "ok",
        "phase_state": phase_state,
        "phase_score": phase_score,
        "alert_count": len(alerts),
        "alerts": alerts
    }

with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("phase alerts generated")
