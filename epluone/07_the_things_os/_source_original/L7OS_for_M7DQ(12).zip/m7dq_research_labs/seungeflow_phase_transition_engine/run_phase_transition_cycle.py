#!/usr/bin/env python3
import os

print("Running SeungeFlow Phase Transition Cycle")

steps = [
    "python3 phase_transition_engine.py",
    "python3 phase_alert_manager.py",
    "python3 phase_dashboard_generator.py"
]

for s in steps:
    print(">", s)
    os.system(s)

print("Phase transition cycle complete")
