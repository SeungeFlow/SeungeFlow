#!/usr/bin/env python3
import json
from pathlib import Path

REPORTS = Path("/opt/m7dq/reports")
OUTPUT = REPORTS / "phase_transition_state.json"

def load_json(name, default):
    p = REPORTS / name
    if not p.exists():
        return default
    try:
        with open(p, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

log_analysis = load_json("master_log_analysis.json", {})
discovery_plan = load_json("discovery_plan.json", {"tasks": []})
observatory = load_json("m7dq_observatory_state.json", {"labs": []})
routing = load_json("universal_routing.json", {"routes": []})

entropy = float(log_analysis.get("entropy", 0) or 0)
total_events = int(log_analysis.get("total_events", 0) or 0)
unique_processes = int(log_analysis.get("unique_processes", 0) or 0)
route_count = int(routing.get("route_count", 0) or 0)
task_count = int(discovery_plan.get("planned_tasks", 0) or 0)

signals = []
for lab in observatory.get("labs", []):
    signal = lab.get("signal")
    if isinstance(signal, (int, float)):
        signals.append(float(signal))

avg_signal = sum(signals) / len(signals) if signals else 0.0
max_signal = max(signals) if signals else 0.0

phase_score = 0.0
phase_score += min(entropy / 6.0, 1.0) * 0.35
phase_score += min(total_events / 500.0, 1.0) * 0.20
phase_score += min(unique_processes / 40.0, 1.0) * 0.15
phase_score += min(route_count / 20.0, 1.0) * 0.10
phase_score += min(task_count / 20.0, 1.0) * 0.10
phase_score += min(avg_signal, 1.0) * 0.10

if phase_score >= 0.80:
    state = "critical_transition"
elif phase_score >= 0.60:
    state = "transition_rising"
elif phase_score >= 0.35:
    state = "unstable_active"
else:
    state = "stable"

report = {
    "phase_state": state,
    "phase_score": round(phase_score, 4),
    "metrics": {
        "entropy": entropy,
        "total_events": total_events,
        "unique_processes": unique_processes,
        "route_count": route_count,
        "planned_tasks": task_count,
        "avg_lab_signal": round(avg_signal, 4),
        "max_lab_signal": round(max_signal, 4)
    }
}

REPORTS.mkdir(parents=True, exist_ok=True)
with open(OUTPUT, "w", encoding="utf-8") as f:
    json.dump(report, f, indent=2)

print("phase transition state generated")
