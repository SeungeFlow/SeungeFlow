# SeungeFlow Phase Transition Engine

This module estimates whether the current system is approaching a phase transition.

## Inputs
Reads from `/opt/m7dq/reports/`:
- `master_log_analysis.json`
- `universal_routing.json`
- `discovery_plan.json`
- `m7dq_observatory_state.json`

## Outputs
- `phase_transition_state.json`
- `phase_alerts.json`
- `phase_transition_dashboard.md`

## Run
```bash
cd /opt/m7dq/kernel
python3 run_phase_transition_cycle.py
```

## Meaning
The engine combines:
- entropy
- event volume
- process diversity
- routing complexity
- discovery planning load
- lab signal intensity

to estimate transition pressure inside the SeungeFlow system.
