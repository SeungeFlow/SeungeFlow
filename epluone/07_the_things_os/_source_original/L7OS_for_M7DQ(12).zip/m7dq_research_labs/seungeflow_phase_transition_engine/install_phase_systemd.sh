#!/bin/bash
set -e

sudo cp phase_transition.service /etc/systemd/system/phase_transition.service
sudo systemctl daemon-reload
sudo systemctl enable phase_transition
sudo systemctl start phase_transition

echo "Phase Transition Engine service started"
systemctl status phase_transition --no-pager
