
#!/bin/bash
BASE=/opt/m7dq
mkdir -p $BASE/kernel $BASE/logs $BASE/reports $BASE/systems $BASE/inputs
echo "SeungeFlow directories created at /opt/m7dq"
