
#!/usr/bin/env python3
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

BASE = Path("/opt/m7dq")
REPORTS = BASE / "reports"
HOST = "0.0.0.0"
PORT = 7070

def load_json(name, default):
    p = REPORTS / name
    if not p.exists():
        return default
    try:
        with open(p,"r",encoding="utf-8") as f:
            return json.load(f)
    except:
        return default

def build_html():
    obs = load_json("m7dq_observatory_state.json", {"labs":[]})
    phase = load_json("phase_transition_state.json", {})
    alerts = load_json("phase_alerts.json", {"alerts":[]})
    log = load_json("master_log_analysis.json", {})

    lab_rows = []
    for lab in obs.get("labs",[]):
        signal = lab.get("signal")
        lab_rows.append(f"<tr><td>{lab['lab']}</td><td>{signal}</td></tr>")
    if not lab_rows:
        lab_rows.append("<tr><td colspan=2>No lab data</td></tr>")

    phase_state = phase.get("phase_state","unknown")
    phase_score = phase.get("phase_score",0)

    alert_items = []
    for a in alerts.get("alerts",[]):
        alert_items.append(f"<li>[{a.get('level')}] {a.get('message')}</li>")
    if not alert_items:
        alert_items.append("<li>No alerts</li>")

    entropy = log.get("entropy","N/A")

    return f"""
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="refresh" content="10">
<title>SeungeFlow Ultimate Observatory</title>
<style>
body {{font-family:Arial;background:#111;color:#eee;padding:30px}}
.card {{background:#1c1c1c;padding:20px;margin-bottom:20px;border-radius:10px}}
h1 {{color:#00ffcc}}
table {{width:100%;border-collapse:collapse}}
td,th {{border-bottom:1px solid #333;padding:8px}}
</style>
</head>
<body>

<h1>SeungeFlow Ultimate Observatory</h1>

<div class="card">
<h2>Phase Transition</h2>
<p><b>state:</b> {phase_state}</p>
<p><b>score:</b> {phase_score}</p>
<p><b>entropy:</b> {entropy}</p>
<ul>
{''.join(alert_items)}
</ul>
</div>

<div class="card">
<h2>M7DQ Lab Signals</h2>
<table>
<tr><th>Lab</th><th>Signal</th></tr>
{''.join(lab_rows)}
</table>
</div>

</body>
</html>
"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ["/","/index.html"]:
            html = build_html().encode()
            self.send_response(200)
            self.send_header("Content-Type","text/html")
            self.send_header("Content-Length",str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    print("SeungeFlow Ultimate Observatory running at http://localhost:7070")
    HTTPServer((HOST,PORT),Handler).serve_forever()
