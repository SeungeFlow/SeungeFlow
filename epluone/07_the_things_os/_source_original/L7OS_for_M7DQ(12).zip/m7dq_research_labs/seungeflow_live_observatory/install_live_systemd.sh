#!/bin/bash
set -e

sudo cp seungeflow_live_observatory.service /etc/systemd/system/seungeflow_live_observatory.service
sudo systemctl daemon-reload
sudo systemctl enable seungeflow_live_observatory
sudo systemctl start seungeflow_live_observatory

echo "Live Observatory service started"
systemctl status seungeflow_live_observatory --no-pager
