#!/usr/bin/env python3
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

BASE = Path("/opt/m7dq")
REPORTS = BASE / "reports"
HOST = "0.0.0.0"
PORT = 7070

def load_json(name, default):
    path = REPORTS / name
    if not path.exists():
        return default
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return default

def build_html():
    obs = load_json("m7dq_observatory_state.json", {"labs": []})
    log_analysis = load_json("master_log_analysis.json", {})
    routing = load_json("universal_routing.json", {"routes": []})
    questions = load_json("generated_questions.json", {"questions": []})
    discovery = load_json("discovery_plan.json", {"tasks": []})

    lab_rows = []
    for lab in obs.get("labs", []):
        signal = lab.get("signal")
        signal_str = "N/A" if signal is None else str(signal)
        lab_rows.append(f"<tr><td>{lab.get('lab')}</td><td>{signal_str}</td><td>{lab.get('status','')}</td></tr>")
    if not lab_rows:
        lab_rows.append("<tr><td colspan='3'>No lab data</td></tr>")

    route_rows = []
    for r in routing.get("routes", [])[:20]:
        route_rows.append(f"<tr><td>{r.get('file')}</td><td>{r.get('pipeline')}</td></tr>")
    if not route_rows:
        route_rows.append("<tr><td colspan='2'>No routing data</td></tr>")

    q_items = []
    for q in questions.get("questions", [])[:10]:
        q_items.append(f"<li>{q.get('question')}</li>")
    if not q_items:
        q_items.append("<li>No generated questions</li>")

    d_items = []
    for t in discovery.get("tasks", [])[:10]:
        d_items.append(f"<li>{t.get('task_id')} : {t.get('objective')}</li>")
    if not d_items:
        d_items.append("<li>No discovery tasks</li>")

    top_process_items = []
    for item in log_analysis.get("top_processes", [])[:10]:
        if isinstance(item, list) and len(item) >= 2:
            top_process_items.append(f"<li>{item[0]} : {item[1]}</li>")
    if not top_process_items:
        top_process_items.append("<li>No process analysis</li>")

    entropy = log_analysis.get("entropy", "N/A")
    total_events = log_analysis.get("total_events", 0)
    unique_processes = log_analysis.get("unique_processes", 0)

    return f"""
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>SeungeFlow Live Observatory</title>
<meta http-equiv="refresh" content="10">
<style>
body {{ font-family: Arial, sans-serif; margin: 24px; background: #f7f7f7; color: #111; }}
h1, h2 {{ margin-bottom: 8px; }}
.card {{ background: white; border-radius: 12px; padding: 16px; margin-bottom: 16px; box-shadow: 0 1px 6px rgba(0,0,0,0.08); }}
table {{ border-collapse: collapse; width: 100%; }}
th, td {{ border-bottom: 1px solid #ddd; padding: 8px; text-align: left; }}
.small {{ color: #555; font-size: 14px; }}
code {{ background: #eee; padding: 2px 6px; border-radius: 6px; }}
</style>
</head>
<body>
<div class="card">
  <h1>SeungeFlow Live Observatory</h1>
  <div class="small">Auto refresh every 10 seconds • http://localhost:7070</div>
</div>

<div class="card">
  <h2>M7DQ Lab Signals</h2>
  <table>
    <tr><th>Lab</th><th>Signal</th><th>Status</th></tr>
    {''.join(lab_rows)}
  </table>
</div>

<div class="card">
  <h2>System Log Summary</h2>
  <p><b>Entropy:</b> {entropy}</p>
  <p><b>Total Events:</b> {total_events}</p>
  <p><b>Unique Processes:</b> {unique_processes}</p>
  <h3>Top Processes</h3>
  <ul>{''.join(top_process_items)}</ul>
</div>

<div class="card">
  <h2>Universal Routing</h2>
  <table>
    <tr><th>File</th><th>Pipeline</th></tr>
    {''.join(route_rows)}
  </table>
</div>

<div class="card">
  <h2>Generated Questions</h2>
  <ul>{''.join(q_items)}</ul>
</div>

<div class="card">
  <h2>Discovery Plan</h2>
  <ul>{''.join(d_items)}</ul>
</div>

<div class="card">
  <h2>Operational Notes</h2>
  <p>Source directory: <code>/opt/m7dq/reports</code></p>
  <p>Refresh interval: <code>10 seconds</code></p>
</div>
</body>
</html>
"""

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path in ["/", "/index.html"]:
            html = build_html().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(html)))
            self.end_headers()
            self.wfile.write(html)
        elif self.path == "/health":
            body = b'{"status":"ok"}'
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_response(404)
            self.end_headers()

if __name__ == "__main__":
    server = HTTPServer((HOST, PORT), Handler)
    print(f"SeungeFlow Live Observatory running on http://localhost:{PORT}")
    server.serve_forever()
