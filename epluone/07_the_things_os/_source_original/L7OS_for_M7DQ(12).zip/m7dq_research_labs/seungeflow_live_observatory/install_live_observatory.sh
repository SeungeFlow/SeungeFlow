#!/bin/bash
set -e

BASE=/opt/m7dq
mkdir -p $BASE/kernel
mkdir -p $BASE/reports

echo "Copy live_observatory_server.py into $BASE/kernel"
echo "Run with:"
echo "  cd $BASE/kernel && python3 live_observatory_server.py"
echo "Open:"
echo "  http://localhost:7070"
