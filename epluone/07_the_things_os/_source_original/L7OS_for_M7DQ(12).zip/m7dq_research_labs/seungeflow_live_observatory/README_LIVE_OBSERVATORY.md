# SeungeFlow Live Observatory

Lightweight live web dashboard for:

- M7DQ lab signals
- system log entropy and process summary
- universal routing
- generated questions
- discovery plan

## Run directly

```bash
cd /opt/m7dq/kernel
python3 live_observatory_server.py
```

Open:

```text
http://localhost:7070
```

## Install as systemd service

```bash
sudo bash install_live_systemd.sh
```

## Health endpoint

```text
http://localhost:7070/health
```
