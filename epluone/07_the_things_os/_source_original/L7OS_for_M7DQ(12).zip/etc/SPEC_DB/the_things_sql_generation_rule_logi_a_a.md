# the_things_sql_generation_rule_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 의 PostgreSQL SQL 초안을 생성할 때 따라야 하는 기준과 제한을 정리한 sql generation rule 문서이다.  
이 문서는 logical table draft 와 logical column draft 를 실제 SQL 로 내릴 때  
문서보존, 계보보존, 원문보존, 구조분리 원칙이 무너지지 않도록 하기 위한 생성 규칙 문서이다.

---

## name
the_things_sql_generation_rule_logi_a_a

---

## purpose
This document defines the working rules
for generating PostgreSQL SQL drafts
for the_things_DB.

Its purpose is to clarify:

- how SQL should be generated from the logical drafts
- what principles must not be violated during SQL generation
- how document-preservation and graph/runtime structures should remain distinct
- how original text integrity, lineage, and ingest history must be respected
- how SQL generation should remain incremental and safe

This is not a final SQL schema.
It is a rule document for SQL generation.

---

## root_summary
SQL generation must not begin
as a freeform coding exercise.

It must begin
as a disciplined translation process
from the already established document logic.

The following must be preserved during SQL generation:

- baseline interpretation rules
- document-class distinction
- object separation
- lineage continuity
- original-text preservation
- ingest-history preservation
- separation between document layer and graph/runtime layer

Thus SQL is not the origin.
It is a downstream structural translation.

---

## core_definition

### original_definition_ko
정의 : the_things_DB 의 SQL 은 즉흥적으로 만드는 것이 아니라  
이미 정리된 baseline, class rule, ingest rule, schema seed, logical table/column draft 를
PostgreSQL 문법으로 번역하는 과정이어야 한다.  
이 과정에서 문서층과 구조그래프층을 섞어버리면 안 되며  
원문보존과 계보보존과 적재기록보존 원칙도 훼손되면 안 된다.  
즉 SQL generation 은 코딩이 아니라 구조번역 작업이다.

### translated_definition_en
The SQL of the_things_DB
must not be created as an improvised coding exercise.

It must be generated
as a translation process
from the already established baseline,
class rule,
ingest rule,
schema seed,
and logical table/column drafts
into PostgreSQL syntax.

During that process,
document-preservation structures
must not be collapsed into graph/runtime structures,
and the principles of original-text preservation,
lineage preservation,
and ingest-history preservation
must not be damaged.

Thus SQL generation is not mere coding.
It is structural translation.

---

## sql_generation_principles

### translation_not_invention_rule
SQL generation should translate
already defined logical structures.

It should not invent unrelated structures
without clear reason.

If a new SQL-side structure becomes necessary,
that necessity should first be explainable
at the logical-document level.

---

### document_graph_separation_rule
The SQL draft must preserve
the distinction between:

- document-preservation zone
- graph/runtime zone

These zones may later connect,
but must not be collapsed into one table set.

Document tables should not be forced
to imitate graph tables,
and graph tables should not be mistaken
for full document preservation.

---

### original_text_integrity_rule
SQL generation must support
exact preservation of original Korean text.

Thus the SQL design must not assume:
- translation replaces origin
- interpretation replaces source
- only one final text body exists

A layer-preserving structure must remain possible.

---

### lineage_preservation_rule
SQL generation must support
explicit document lineage.

This means SQL must not flatten:
- README chain
- working definition lineage
- future revision chains
into unrelated document rows without continuity structure.

---

### ingest_history_rule
SQL generation must preserve
the ingest event as meaningful history.

A document row alone is not enough.
There must be a place for:
- ingest stage
- ingest priority
- ingest source window
- ingest reason
- ingest timestamp

---

### no_delete_only_add_rule
SQL generation must favor schemas
that support additive continuity.

This means the design should prefer:
- new rows over destructive overwrite
- new layers over text replacement
- new lineage members over historical collapse
- new ingest records over hidden mutation

---

### present_incremental_rule
SQL generation must proceed incrementally
from the present actionable state.

It should not attempt to solve every future possibility
in the first DDL draft.

The first SQL draft should support:
- initial ingest
- baseline preservation
- public anchor lineage
- working definitions
- core ingest metadata

Further expansion may come later.

---

## sql_generation_scope

### current_sql_target_scope
The first SQL draft should focus primarily on:

- documents
- document_lineage
- document_layers
- ingest_records

These are the minimum structures
required to begin meaningful document preservation.

---

### secondary_sql_target_scope
The second SQL wave may expand to:

- document_object_links
- document_registry
- document_keywords

These improve clarity and retrieval
but are not required before the first structured intake begins.

---

### later_bridge_scope
Bridge structures such as:

- document_graph_links
- revision_links

should be treated as later expansion,
not first-draft necessities.

---

## table_generation_rules

### table_documents_rule
The `documents` table should be generated
as the main preservation table for document identity and metadata.

It must support:
- stable document identity
- class
- role
- related object
- source origin
- current status
- main content body
- content format
- original-text requirement
- timestamps
- notes

It should not attempt to contain
all lineage and all layer logic by itself.

---

### table_document_lineage_rule
The `document_lineage` table should be generated
to preserve continuity structure separately from the base document row.

It must support:
- lineage group
- linked document
- readable lineage position
- sortable order if needed
- previous / next continuity where useful

This prevents semantic flattening.

---

### table_document_layers_rule
The `document_layers` table should be generated
to preserve original, translation, interpretation, and summary layers separately.

It must support:
- document ownership
- layer type
- language code
- layer content
- preservation requirement
- timestamps

This table is essential for fwos baseline compliance.

---

### table_ingest_records_rule
The `ingest_records` table should be generated
to preserve structured intake history.

It must support:
- linked document
- ingest stage
- priority group if used
- source window if relevant
- ingest reason / note
- ingest timestamp

This prevents loss of intake context.

---

## column_generation_rules

### stable_identity_rule
Primary key identity columns must be stable and explicit.

IDs should not be replaced
by surface document names alone.

---

### explicit_meaning_rule
Columns should be named
to reflect meaning clearly.

Prefer:
- `document_name`
- `document_class`
- `primary_role`
- `source_origin`

Avoid ambiguous short names
unless there is strong reason.

---

### text_capacity_rule
Columns expected to hold document body or layer content
must use text-capable storage
rather than artificially narrow string limits.

This is especially important for:
- content_body
- layer_content
- notes
- ingest_note

---

### nullable_discipline_rule
Columns should not all be nullable by habit.

The first SQL draft should distinguish between:
- required continuity fields
- optional support fields

For example:
- `document_name` should not be null
- `document_class` should not be null
- `content_body` should not be null
- `notes` may be null

---

### timestamp_rule
Core preservation tables should carry timestamps.

At minimum:
- created_at should exist for all major core tables
- updated_at should exist where mutable metadata may later change

---

## constraint_generation_rules

### baseline_constraint_rule
Constraints should enforce structure
without over-constricting the first implementation.

Use constraints to protect:
- non-null identity
- non-null class
- non-null role
- valid layer type where reasonable

But do not over-design the first draft.

---

### enum_caution_rule
Strong enum-like categories may appear,
but the first draft should be cautious
about locking too many concepts into rigid DB enums.

Where possible,
early drafts may use:
- text + check constraint
instead of hard enum types,
unless stability is already high.

This allows controlled evolution.

---

### foreign_key_rule
Foreign keys should be used
for major continuity relations
where they clearly express ownership and linkage.

Examples:
- `document_lineage.document_id` → `documents.document_id`
- `document_layers.document_id` → `documents.document_id`
- `ingest_records.document_id` → `documents.document_id`

This preserves structural integrity.

---

## indexing_rules

### first_index_priority_rule
The first SQL draft should only add indexes
that clearly support:
- identity lookup
- lineage lookup
- ingest lookup

Examples:
- index on `documents.document_name`
- index on `document_lineage.lineage_group`
- index on `document_layers.document_id`
- index on `ingest_records.document_id`

---

### premature_index_avoidance_rule
Do not over-index the first SQL draft.

Too many indexes too early
can make the initial schema heavier
without enough present-stage benefit.

---

## naming_rules

### snake_case_rule
SQL table and column names should use consistent snake_case.

Examples:
- `document_lineage`
- `document_layers`
- `source_origin`
- `original_text_required`

---

### stable_name_rule
Once a core SQL table name is chosen,
renaming should be avoided without strong reason.

Continuity matters.

---

### meaning_alignment_rule
SQL names should remain aligned
with the logical document drafts.

The SQL layer should not introduce
needlessly different naming
that obscures the earlier design logic.

---

## migration_rules

### additive_migration_rule
Migration thinking should follow:

no delete, only add

Early migrations should prefer:
- adding new tables
- adding new columns
- adding new links
over destructive rework.

---

### first_wave_rule
The first migration wave
should create only the minimum core document-preservation tables.

Recommended first-wave tables:
- documents
- document_lineage
- document_layers
- ingest_records

---

### second_wave_rule
Second-wave migrations may add:
- document_object_links
- document_registry
- document_keywords

Only after first-wave preservation works.

---

### coexistence_rule
The new document-preservation tables
must be allowed to coexist
with the already existing graph/runtime tables.

The first SQL draft should not assume
the old graph schema must be removed.

---

## validation_rules

### logical_backreference_rule
Before accepting any SQL draft,
it should be checked backward against:

- fwos baseline
- document class rule
- ingest rule
- schema seed
- logical table draft
- logical column draft

If the SQL draft violates those,
it is not ready.

---

### sample_document_check_rule
A candidate SQL design should be testable
against sample documents such as:

- fwos baseline (unified)
- readme_anchor_logi_a_d
- the_things_builder_working_definition_logi_a_a

If those cannot be stored cleanly,
the SQL draft is insufficient.

---

### layer_check_rule
A candidate SQL design must be able to represent:
- original Korean layer
- English translation layer
without overwriting either.

If it cannot do that,
the SQL draft breaks the baseline.

---

## sql_output_expectation

### first_sql_draft_should_include
The first actual PostgreSQL draft should ideally include:

- CREATE TABLE documents
- CREATE TABLE document_lineage
- CREATE TABLE document_layers
- CREATE TABLE ingest_records
- primary keys
- foreign keys
- a small number of necessary indexes
- minimal check constraints where clearly useful

---

### first_sql_draft_should_not_yet_include
The first SQL draft does not need to include:

- every future bridge table
- every normalization table
- every retrieval feature
- every advanced validation mechanism
- every possible enum type

Those can arrive later.

---

## relation_to_logical_column_draft
The logical column draft identified
which columns should exist
and what they mean.

This SQL generation rule explains
how those columns should be translated carefully
into PostgreSQL-oriented design.

Thus:
- logical column draft = column meaning
- SQL generation rule = SQL translation discipline

---

## relation_to_next_step
The next step after this document
is to generate the first PostgreSQL schema draft.

That draft should follow this rule document,
not bypass it.

Thus this document acts as the final rule layer
before SQL generation begins.

---

## present_continuity_rule
This SQL generation rule follows
the present actionable state.

It does not attempt to define
the final eternal schema.

It defines how to generate
the first safe, disciplined SQL draft now.

---

## status
Working SQL generation rule.
Not final SQL DDL.
Not final migration script.
This document serves as the current operational rule
for generating PostgreSQL schema drafts
for the_things_DB.

---

end.