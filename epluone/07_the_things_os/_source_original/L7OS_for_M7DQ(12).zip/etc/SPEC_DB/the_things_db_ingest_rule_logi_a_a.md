# the_things_db_ingest_rule_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 에 문서를 적재할 때 필요한 기준과 순서를 정리한 ingest rule 문서이다.  
이 문서는 문서를 단순히 파일로 넣는 것이 아니라  
이름, class, object relation, lineage, 원문보존, 생성맥락을 함께 유지한 채  
DB 적재 방향을 고정하기 위한 기준 문서이다.

---

## name
the_things_db_ingest_rule_logi_a_a

---

## purpose
This document defines the working ingest rules
for loading documents into the_things_DB.

Its purpose is to clarify:

- what should be preserved when a document enters DB
- how document name, class, and object relation should be handled
- how lineage must be preserved
- how original text integrity must be protected
- how DB ingest differs from simple file storage

This is not yet a final SQL ingestion specification.
It is a working rule for DB-oriented document intake.

---

## root_summary
A document entering the_things_DB must not be treated
as a simple file drop.

Each document should enter DB
with preserved structural context.

At minimum, DB ingest must preserve:

- document identity
- document class
- related object
- origin context
- lineage continuity
- original text integrity
- present-stage status

Thus ingest is not mere upload.
It is structured intake.

---

## core_definition

### original_definition_ko
정의 : the_things_DB 에 문서를 넣는다는 것은
파일 하나를 집어넣는 것이 아니라
그 문서가 어떤 이름을 가지는지,
어떤 class 인지,
어느 객체와 연결되는지,
어떤 계보를 가지는지,
원문보존이 필요한지,
어떤 생성맥락에서 나왔는지를 함께 보존하는 것을 뜻한다.  
즉 ingest 는 단순 저장이 아니라 구조보존 적재이다.

### translated_definition_en
Loading a document into the_things_DB
does not mean merely dropping a file into storage.

It means preserving together:

- what the document is called
- what class it belongs to
- which object it is related to
- what lineage it belongs to
- whether original-text preservation is required
- from what generative context it emerged

Thus ingest is not simple storage.
It is structurally preserved intake.

---

## ingest_principles

### structure_preservation_rule
A document must be ingested with its structural meaning preserved.

This includes at least:
- name
- role
- class
- object relation
- lineage
- status

A content blob without context is insufficient.

---

### original_text_preservation_rule
If a document contains original Korean statements,
they must be preserved exactly as written.

Original Korean text must not be rewritten during ingest.

Translations, interpretations, and later summaries
must remain separate from the original text layer.

This follows the fwos baseline.

---

### lineage_preservation_rule
If a document belongs to a sequence,
that sequence must be preserved at ingest time.

Examples:
- README 0.1 → 0.4
- anchor chains
- revision chains
- working-definition continuities

Documents belonging to lineage must not be flattened
into unrelated isolated entries.

---

### class_awareness_rule
Every ingested document should carry a logical class.

Examples:
- raw_source_layer
- retrieval_pack_layer
- spec_layer
- graph_runtime_layer
- continuity_reference_layer
- coordination_layer
- public_anchor_layer

Even before full physical separation exists,
logical class separation must already exist.

---

### object_relation_rule
Each ingested document should record
which major object it most naturally relates to.

Possible major objects:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System

Some documents may be cross-object references,
but this should be explicit rather than assumed.

---

### no_delete_only_add_rule
DB ingest follows:

no delete, only add

Earlier ingested states remain preserved.
Later ingests should appear as:
- added versions
- added refinements
- added mappings
- added continuation entries

Not destructive replacement.

---

### present_continuity_rule
Ingest happens from the present actionable point.

A document is ingested
not because history must be worshiped,
but because current forward work requires
preserved usable continuity.

Thus ingest supports:
- current execution
- future retrieval
- continuity through accumulation

---

## minimum_ingest_fields

At minimum, an ingested document should preserve the following logical fields:

- document_name
- document_title_or_label
- document_class
- related_object
- primary_role
- source_origin
- lineage_group
- lineage_position
- original_text_required
- current_status
- content_body
- notes

These are logical ingest fields,
not yet final SQL column definitions.

---

## field_interpretation

### document_name
The stable working name of the document.

Example:
- the_things_db_working_definition_logi_a_a
- readme_anchor_logi_a_d

---

### document_title_or_label
A human-readable label or title.

This may match the name,
or may provide clearer surface description.

---

### document_class
The logical class of the document.

Examples:
- continuity_reference_layer
- coordination_layer
- public_anchor_layer

---

### related_object
The primary object relation.

Examples:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

---

### primary_role
The main role the document plays.

Examples:
- working definition
- object map
- anchor chain interpretation
- ingest rule
- registry
- public anchor

---

### source_origin
Where the document came from.

Examples:
- manually written by human
- generated through dialogue
- extracted from prior materials
- mapped from public README
- derived from existing schema notes

---

### lineage_group
The continuity group to which the document belongs.

Examples:
- readme_public_lineage
- the_things_working_definition_lineage
- fwos_baseline_reference

---

### lineage_position
The position within the lineage.

Examples:
- a
- b
- c
- d
- root
- standalone
- seed

---

### original_text_required
Whether exact original-text preservation is required.

Expected values may later become:
- yes
- no
- partial

---

### current_status
The present operational state of the document.

Examples:
- working definition
- mapped anchor
- reference baseline
- draft
- preserved input candidate

---

### content_body
The preserved main content body.

This must not be treated as sufficient alone,
but it remains essential.

---

### notes
Additional interpretive or operational notes.

Examples:
- cross-object relevance
- future ingest caution
- relation to README lineage
- relation to schema baseline

---

## ingest_classes_by_priority

### priority_group_1
Documents that should be ingested early as reference anchors:

- fwos baseline (unified)
- readme_anchor_chain_logi_a_a
- readme_anchor_logi_a_a
- readme_anchor_logi_a_b
- readme_anchor_logi_a_c
- readme_anchor_logi_a_d

Reason:
These form the current public/reference baseline.

---

### priority_group_2
Documents that should be ingested as operational internal definitions:

- the_things_db_working_definition_logi_a_a
- the_things_builder_working_definition_logi_a_a
- the_things_core_working_definition_logi_a_a
- the_things_system_working_definition_logi_a_a
- the_things_object_map_logi_a_a
- the_things_document_class_rule_logi_a_a
- the_things_registry_logi_a_a
- the_things_db_ingest_rule_logi_a_a

Reason:
These form the current internal operational skeleton.

---

### priority_group_3
Future source and generated documents:

- raw source notes
- retrieval packs
- spec outputs
- template-based outputs
- coordination notes
- future anchor documents

Reason:
These should be ingested after the basic baseline and rule system is established.

---

## ingest_order_model

### 1. identify the document
Determine:
- what the document is
- whether it is major or minor
- whether it is baseline, working definition, anchor, or output

---

### 2. assign class
Determine the logical document class.

---

### 3. assign object relation
Determine which major object it most naturally belongs to.

---

### 4. assign lineage
Determine:
- whether it belongs to a continuity chain
- which lineage group it belongs to
- what its position is in that chain

---

### 5. preserve original text layer
If original text is present,
preserve it exactly before any interpretation layer is added.

---

### 6. preserve main content
Store the document body.

---

### 7. attach notes and present status
Record:
- current status
- ingest notes
- special preservation concerns

---

## relation_to_current_postgresql_state
The currently observed seungeflow PostgreSQL schema
does not yet fully match this ingest rule.

Observed limitations include:
- no full raw document layer
- no visible lineage-aware document table
- no explicit original/translation separation layer
- no visible document_class-oriented preservation structure

Thus this ingest rule currently functions
as a higher logical guide
rather than a direct reflection of the current DB tables.

---

## ingest_examples

### example_1: README 0.4
document_name:
- readme_anchor_logi_a_d

document_class:
- public_anchor_layer

related_object:
- cross-object public reference
- Builder-threshold reference
- DB preservation candidate

primary_role:
- implementation transition anchor

source_origin:
- mapped from public README lineage

lineage_group:
- readme_public_lineage

lineage_position:
- d

original_text_required:
- yes

current_status:
- mapped public anchor

---

### example_2: the_things_builder_working_definition_logi_a_a
document_name:
- the_things_builder_working_definition_logi_a_a

document_class:
- continuity_reference_layer

related_object:
- the_things_Builder

primary_role:
- working definition

source_origin:
- generated through dialogue

lineage_group:
- the_things_working_definition_lineage

lineage_position:
- builder

original_text_required:
- yes where original Korean definition exists

current_status:
- working definition

---

### example_3: the_things_object_map_logi_a_a
document_name:
- the_things_object_map_logi_a_a

document_class:
- coordination_layer

related_object:
- the_things_System / cross-object reference

primary_role:
- object relation map

source_origin:
- generated through dialogue

lineage_group:
- the_things_coordination_lineage

lineage_position:
- object_map

original_text_required:
- yes where original Korean definition exists

current_status:
- working object map

---

## relation_to_registry
The registry records what documents currently exist
and how they are interpreted.

The ingest rule defines
how those registered documents should enter DB-oriented preservation.

Thus:
- registry = operational index
- ingest rule = intake rule

Both are needed.

---

## relation_to_future_schema
This ingest rule is expected to later inform:

- document table design
- metadata field design
- lineage table design
- class-aware retrieval design
- original-text preservation design
- Builder-to-DB return flow

Thus this document is a schema seed,
but not yet the schema itself.

---

## future_extension_rule
Later ingest logic may expand to include:

- template_type
- visibility_scope
- preservation_priority
- revision_parent
- source_window
- retrieval_tags
- coordination_flags

But the current minimum rule is enough to begin structured intake thinking.

---

## status
Working ingest rule.
Not final SQL ingest spec.
Not final schema implementation.
This document serves as the current operational ingest anchor
for the_things_DB.

---

end.