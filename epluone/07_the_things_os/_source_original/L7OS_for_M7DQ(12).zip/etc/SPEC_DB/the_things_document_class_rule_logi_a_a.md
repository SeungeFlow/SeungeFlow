# the_things_document_class_rule_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things 에서 다루는 문서들을 어떤 기준으로 구분하고 저장할지를 정리한 document class rule 문서이다.  
이 문서는 서로 다른 성격의 문서들이 한 곳에 섞이면서 발생하는 혼란을 줄이기 위해  
문서의 역할, 생성맥락, 사용방향에 따라 논리적 class 를 구분하기 위한 기준 문서이다.

---

## name
the_things_document_class_rule_logi_a_a

---

## purpose
This document defines the logical document classes
used in the_things project.

Its purpose is to clarify:

- how documents should be distinguished by role
- how source materials differ from generated outputs
- how retrieval bundles differ from specifications
- how graph/runtime structures differ from preserved documents
- how document classification should support DB preservation and Builder usage

This is not a final storage schema.
It is a working rule for document classification.

---

## root_summary
the_things project handles multiple kinds of documents.

These must not be treated as one undifferentiated mass.

At minimum, documents should be distinguished into:

- raw source materials
- retrieval-oriented bundles
- spec / design outputs
- graph-runtime structural records

This separation is necessary because each class differs in:

- origin
- purpose
- usage direction
- preservation meaning
- relation to DB / Builder / CORE / System

Thus document classification is not cosmetic.
It is structural.

---

## core_definition

### original_definition_ko
정의 : the_things 에서 다루는 문서들은 전부 같은 문서가 아니다.  
어떤 것은 원본재료이고, 어떤 것은 추출묶음이며, 어떤 것은 spec 이고, 어떤 것은 구조그래프층이다.  
따라서 문서를 저장할 때는 이름만이 아니라  
그 문서가 어떤 역할과 생성맥락을 가지는지에 따라 class 를 구분해야 한다.  
이 구분이 있어야 DB 와 Builder 와 CORE 와 System 이 서로 꼬이지 않는다.

### translated_definition_en
Not all documents handled in the_things are of the same kind.

Some are raw source materials,
some are extracted retrieval bundles,
some are specifications,
and some belong to the structural graph/runtime layer.

Therefore, when preserving documents,
classification must consider not only the file name
but also the role and generative context of the document.

This distinction is necessary
so that DB, Builder, CORE, and System do not become structurally tangled.

---

## classification_principles

### role_based_rule
A document class is determined primarily by its role,
not only by its file extension.

For example:
- a `.md` file may be raw source
- another `.md` file may be a spec
- another `.md` file may be a lineage interpretation

Thus extension alone is insufficient.

---

### generation_context_rule
A document class must reflect how the document came into existence.

Questions to ask:
- was it written directly as an original note?
- was it extracted from DB for a current task?
- was it generated through Builder-side dialogue?
- was it produced as a cross-object alignment note?

Generation context matters.

---

### usage_direction_rule
A document class must reflect how the document is intended to be used.

Examples:
- preserved as source memory
- uploaded as conversation input
- used as implementation guidance
- used as continuity reference
- used as system coordination material

---

### separation_first_rule
Different document classes must be logically separated first.

Even if they temporarily live in one broader storage system,
their class distinction must remain explicit.

---

### no_delete_only_add_rule
Document classes also follow:

no delete, only add

Earlier classed documents are preserved.
Later revisions or reinterpretations are added,
not destructively substituted.

---

## primary_document_classes

### 1. raw_source_layer
Definition:
Documents that originate as primary source materials.

Examples:
- phone memo text
- direct observations
- freeform markdown notes
- yaml / sql / py / json source files
- pseudocode fragments
- handwritten-to-digital transcription
- original Korean structural statements

Primary characteristics:
- close to origin
- may be rough or unfinished
- may contain direct author language
- must preserve original integrity where relevant

Main relation:
- primarily preserved by DB
- may later be extracted into other classes

---

### 2. retrieval_pack_layer
Definition:
Documents assembled or extracted
to serve as input material for a current task or new dialogue.

Examples:
- topic-specific md bundles
- selected anchor collections
- extracted context packs
- conversation upload preparation files

Primary characteristics:
- purpose-specific
- curated from existing materials
- transitional rather than permanent in the same way as raw notes
- supports current execution

Main relation:
- often pulled from DB
- often consumed by Builder
- may later be re-preserved

---

### 3. spec_layer
Definition:
Documents refined into structured outputs
for design, implementation, behavior definition, or development preparation.

Examples:
- spec documents
- design documents
- implementation explanation documents
- coding preparation documents
- template-shaped outputs
- architecture notes

Primary characteristics:
- more organized
- output-oriented
- shaped for building or implementation
- often created through Builder-side dialogue

Main relation:
- primarily produced by Builder
- may later be stored in DB
- may be checked against CORE
- may be coordinated in System if cross-object impact exists

---

### 4. graph_runtime_layer
Definition:
Documents or structures that belong to runtime graph interpretation
or structure-extracted system representation.

Examples:
- node
- relation
- event
- field
- pattern
- graph-derived structural logs

Primary characteristics:
- structure-centric
- system-representational
- closer to runtime or schema logic than prose-centered document form
- may coexist with preserved documents but should not be confused with them

Main relation:
- primarily linked to DB-side graph structure
- may support retrieval and interpretation
- is not identical to raw source or spec prose documents

---

## secondary_document_classes

### 5. continuity_reference_layer
Definition:
Documents used to stabilize central identity and continuity across change.

Examples:
- CORE working definitions
- naming continuity rules
- central anchor notes
- continuity comparison documents

Main relation:
- strongly related to CORE
- may be preserved in DB
- may be consulted during Builder or System revision

---

### 6. coordination_layer
Definition:
Documents created to align multiple objects or windows.

Examples:
- System working definitions
- schema alignment notes
- cross-object revision notes
- consistency mapping documents

Main relation:
- strongly related to System
- used when separation must be preserved while alignment is required

---

### 7. public_anchor_layer
Definition:
Documents that function as externally visible project anchors.

Examples:
- README lineage
- public-facing baseline statements
- externally visible transition declarations

Main relation:
- preserved as public reference lineage
- may be stored in DB with explicit anchor mapping
- important for external continuity and internal interpretation

---

## relation_to_the_things_objects

### relation_to_DB
DB must be able to preserve documents
without flattening all classes into one undifferentiated pool.

DB therefore needs class awareness,
even before full physical separation exists.

---

### relation_to_Builder
Builder consumes some classes and produces others.

Typical Builder relation:
- consumes raw source and retrieval packs
- produces spec documents
- references continuity documents when necessary

Builder must not confuse all materials as build outputs.

---

### relation_to_CORE
CORE is especially related to:
- continuity_reference_layer
- selected public_anchor_layer materials
- selected spec documents that affect central identity

CORE does not need to absorb every document.

---

### relation_to_System
System is especially related to:
- coordination_layer
- selected continuity_reference documents
- selected spec or schema documents with cross-object impact

System uses class distinction to coordinate safely.

---

## current_interpretation_of_project_materials

### README lineage
Current class:
- public_anchor_layer

Mapped examples:
- readme_anchor_logi_a_a
- readme_anchor_logi_a_b
- readme_anchor_logi_a_c
- readme_anchor_logi_a_d

---

### working definition documents
Current class:
- continuity_reference_layer
or
- coordination_layer
depending on the object and usage

Examples:
- the_things_db_working_definition_logi_a_a
- the_things_builder_working_definition_logi_a_a
- the_things_core_working_definition_logi_a_a
- the_things_system_working_definition_logi_a_a
- the_things_object_map_logi_a_a

---

### current seungeflow PostgreSQL graph schema
Current class:
- graph_runtime_layer

Observed examples:
- node
- relation
- event
- field
- pattern

---

## classification_questions
When a new document appears,
the following questions should be asked:

1. Is this an original source or a generated output?
2. Is this meant for preservation, retrieval, implementation, continuity, or coordination?
3. Is this a public anchor or an internal working document?
4. Is this primarily prose-centered or graph-runtime-centered?
5. Which object does this most naturally belong to: DB, Builder, CORE, or System?

These questions help prevent misclassification.

---

## future_storage_direction
Physical DB separation may come later,
but logical class separation must begin now.

This means:
- class labels should be preserved
- document origin should be remembered
- object relation should be noted
- future schema should reflect document-class distinction

Thus classification begins before full implementation.

---

## status
Working classification rule.
Not final schema.
Not final governance taxonomy.
This document serves as the current operational classification anchor
for document handling in the_things.

---

end.