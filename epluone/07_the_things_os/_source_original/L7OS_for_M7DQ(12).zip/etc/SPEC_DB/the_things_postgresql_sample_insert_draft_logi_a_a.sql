BEGIN;

-- =========================================================
-- the_things_postgresql_sample_insert_draft_logi_a_a.sql
-- Sample insert draft for first-wave document preservation
-- Assumes the following tables already exist:
--   documents
--   document_lineage
--   document_layers
--   ingest_records
-- =========================================================

-- ---------------------------------------------------------
-- 1. fwos baseline (unified)
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'fwos_baseline_unified',
    'fwos baseline (unified)',
    'continuity_reference_layer',
    'reference baseline',
    'cross-object reference',
    'written by human / provided in dialogue',
    'reference baseline',
    '# fwos baseline (unified)

Defines semantic document structure, keyword interpretation rules,
collaboration roles, external identification rules,
and original text preservation rules.

This baseline governs how fwos documents are created, interpreted, and stored.',
    'md',
    'yes',
    'Highest current baseline reference for document interpretation and preservation.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    lineage_order,
    lineage_note
)
SELECT
    'fwos_baseline_reference',
    d.document_id,
    'root',
    1,
    'Root baseline reference'
FROM documents d
WHERE d.document_name = 'fwos_baseline_unified';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Defines the operational baseline of fwos and governs semantic completeness, original text preservation, keyword generation rules, and external identifier rules.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'fwos_baseline_unified';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '1_baseline',
    'baseline-first structured ingest',
    'DB',
    'Inserted as the highest current interpretive baseline.'
FROM documents d
WHERE d.document_name = 'fwos_baseline_unified';

-- ---------------------------------------------------------
-- 2. readme_anchor_chain_logi_a_a
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'readme_anchor_chain_logi_a_a',
    'readme_anchor_chain_logi_a_a',
    'public_anchor_layer',
    'README public anchor lineage interpretation',
    'cross-object public reference',
    'generated through dialogue from README 0.1-0.4',
    'working lineage definition',
    '# readme_anchor_chain_logi_a_a

Interprets README 0.1 through README 0.4
as one continuous public anchor lineage.

Semantic progression:
foundational declaration
→ runtime direction
→ present-based continuity
→ implementation transition.',
    'md',
    'yes',
    'Meta-document defining the README public lineage.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    lineage_order,
    lineage_note
)
SELECT
    'readme_public_lineage_meta',
    d.document_id,
    'chain_definition',
    1,
    'Defines how README anchors must be interpreted as one chain'
FROM documents d
WHERE d.document_name = 'readme_anchor_chain_logi_a_a';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'README 0.1 to 0.4 form a public anchor lineage rather than isolated version files.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'readme_anchor_chain_logi_a_a';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '2_public_anchor_lineage',
    'anchor-chain preservation',
    'DB',
    'Inserted before individual README anchors to stabilize lineage interpretation.'
FROM documents d
WHERE d.document_name = 'readme_anchor_chain_logi_a_a';

-- ---------------------------------------------------------
-- 3. readme_anchor_logi_a_a
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'readme_anchor_logi_a_a',
    'README 0.1 mapped anchor',
    'public_anchor_layer',
    'foundational declaration anchor',
    'cross-object public reference',
    'mapped from README 0.1',
    'mapped public anchor',
    '# readme_anchor_logi_a_a

Mapped from README 0.1.

Role:
- foundational declaration anchor
- manifest seed
- first public structural self-declaration',
    'md',
    'yes',
    'First public seed anchor in README lineage.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    previous_document_id,
    next_document_id,
    lineage_order,
    lineage_note
)
SELECT
    'readme_public_lineage',
    d.document_id,
    'a',
    NULL,
    d_next.document_id,
    1,
    'README 0.1 mapped anchor'
FROM documents d
LEFT JOIN documents d_next
    ON d_next.document_name = 'readme_anchor_logi_a_b'
WHERE d.document_name = 'readme_anchor_logi_a_a';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Foundational declaration anchor mapped from README 0.1.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_a';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '2_public_anchor_lineage',
    'public anchor preservation',
    'external_public',
    'Mapped anchor for README 0.1.'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_a';

-- ---------------------------------------------------------
-- 4. readme_anchor_logi_a_b
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'readme_anchor_logi_a_b',
    'README 0.2 mapped anchor',
    'public_anchor_layer',
    'runtime direction anchor',
    'cross-object public reference',
    'mapped from README 0.2',
    'mapped public anchor',
    '# readme_anchor_logi_a_b

Mapped from README 0.2.

Role:
- runtime direction anchor
- operational movement declaration
- persistence-oriented system declaration',
    'md',
    'yes',
    'Second public anchor emphasizing runtime movement.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    previous_document_id,
    next_document_id,
    lineage_order,
    lineage_note
)
SELECT
    'readme_public_lineage',
    d.document_id,
    'b',
    d_prev.document_id,
    d_next.document_id,
    2,
    'README 0.2 mapped anchor'
FROM documents d
LEFT JOIN documents d_prev
    ON d_prev.document_name = 'readme_anchor_logi_a_a'
LEFT JOIN documents d_next
    ON d_next.document_name = 'readme_anchor_logi_a_c'
WHERE d.document_name = 'readme_anchor_logi_a_b';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Runtime direction anchor mapped from README 0.2.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_b';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '2_public_anchor_lineage',
    'public anchor preservation',
    'external_public',
    'Mapped anchor for README 0.2.'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_b';

-- ---------------------------------------------------------
-- 5. readme_anchor_logi_a_c
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'readme_anchor_logi_a_c',
    'README 0.3 mapped anchor',
    'public_anchor_layer',
    'present-continuity anchor',
    'cross-object public reference',
    'mapped from README 0.3',
    'mapped public anchor',
    '# readme_anchor_logi_a_c

Mapped from README 0.3.

Role:
- present-continuity anchor
- current execution reference anchor
- continuity-through-the-present declaration',
    'md',
    'yes',
    'Third public anchor preserving present-based continuity.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    previous_document_id,
    next_document_id,
    lineage_order,
    lineage_note
)
SELECT
    'readme_public_lineage',
    d.document_id,
    'c',
    d_prev.document_id,
    d_next.document_id,
    3,
    'README 0.3 mapped anchor'
FROM documents d
LEFT JOIN documents d_prev
    ON d_prev.document_name = 'readme_anchor_logi_a_b'
LEFT JOIN documents d_next
    ON d_next.document_name = 'readme_anchor_logi_a_d'
WHERE d.document_name = 'readme_anchor_logi_a_c';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Present-continuity anchor mapped from README 0.3. The present is treated as the active executable reference point.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_c';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '2_public_anchor_lineage',
    'public anchor preservation',
    'external_public',
    'Mapped anchor for README 0.3.'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_c';

-- ---------------------------------------------------------
-- 6. readme_anchor_logi_a_d
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'readme_anchor_logi_a_d',
    'README 0.4 mapped anchor',
    'public_anchor_layer',
    'implementation transition anchor',
    'cross-object public reference',
    'mapped from README 0.4',
    'mapped public anchor',
    '# readme_anchor_logi_a_d

Mapped from README 0.4.

Role:
- implementation transition anchor
- external implementation signal
- first public build-facing declaration',
    'md',
    'yes',
    'Fourth public anchor marking implementation-facing transition.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    previous_document_id,
    next_document_id,
    lineage_order,
    lineage_note
)
SELECT
    'readme_public_lineage',
    d.document_id,
    'd',
    d_prev.document_id,
    NULL,
    4,
    'README 0.4 mapped anchor'
FROM documents d
LEFT JOIN documents d_prev
    ON d_prev.document_name = 'readme_anchor_logi_a_c'
WHERE d.document_name = 'readme_anchor_logi_a_d';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Implementation transition anchor mapped from README 0.4.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_d';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '2_public_anchor_lineage',
    'public anchor preservation',
    'external_public',
    'Mapped anchor for README 0.4.'
FROM documents d
WHERE d.document_name = 'readme_anchor_logi_a_d';

-- ---------------------------------------------------------
-- 7. the_things_db_working_definition_logi_a_a
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'the_things_db_working_definition_logi_a_a',
    'the_things_db_working_definition_logi_a_a',
    'continuity_reference_layer',
    'working definition',
    'the_things_DB',
    'generated through dialogue',
    'working definition',
    '# the_things_db_working_definition_logi_a_a

Defines the_things_DB as the preservation and retrieval object.

Key points:
- preserve source materials
- preserve extracted references
- preserve spec outputs after dialogue refinement
- support retrieval base for future work',
    'md',
    'yes',
    'Working definition for the_things_DB.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    lineage_order,
    lineage_note
)
SELECT
    'the_things_working_definition_lineage',
    d.document_id,
    'db',
    1,
    'DB working definition'
FROM documents d
WHERE d.document_name = 'the_things_db_working_definition_logi_a_a';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Defines the_things_DB as the preservation and retrieval object.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'the_things_db_working_definition_logi_a_a';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '3_object_working_definitions',
    'internal object definition preservation',
    'DB',
    'Inserted as DB-side working definition.'
FROM documents d
WHERE d.document_name = 'the_things_db_working_definition_logi_a_a';

-- ---------------------------------------------------------
-- 8. the_things_builder_working_definition_logi_a_a
-- ---------------------------------------------------------
INSERT INTO documents (
    document_name,
    document_title,
    document_class,
    primary_role,
    related_object,
    source_origin,
    current_status,
    content_body,
    content_format,
    original_text_required,
    notes
) VALUES (
    'the_things_builder_working_definition_logi_a_a',
    'the_things_builder_working_definition_logi_a_a',
    'continuity_reference_layer',
    'working definition',
    'the_things_Builder',
    'generated through dialogue',
    'working definition',
    '# the_things_builder_working_definition_logi_a_a

Defines the_things_Builder as the human-led generation and assembly object.

Key points:
- structure generation
- template-based assembly
- spec production
- coding preparation materials generation',
    'md',
    'yes',
    'Working definition for the_things_Builder.'
);

INSERT INTO document_lineage (
    lineage_group,
    document_id,
    lineage_position,
    lineage_order,
    lineage_note
)
SELECT
    'the_things_working_definition_lineage',
    d.document_id,
    'builder',
    2,
    'Builder working definition'
FROM documents d
WHERE d.document_name = 'the_things_builder_working_definition_logi_a_a';

INSERT INTO document_layers (
    document_id,
    layer_type,
    language_code,
    layer_content,
    preservation_required,
    layer_order,
    source_note
)
SELECT
    d.document_id,
    'summary',
    'en',
    'Defines the_things_Builder as the human-led generation and assembly object.',
    TRUE,
    1,
    'sample summary layer'
FROM documents d
WHERE d.document_name = 'the_things_builder_working_definition_logi_a_a';

INSERT INTO ingest_records (
    document_id,
    ingest_stage,
    ingest_priority_group,
    ingest_reason,
    ingest_source_window,
    ingest_note
)
SELECT
    d.document_id,
    'initial_wave',
    '3_object_working_definitions',
    'internal object definition preservation',
    'Builder',
    'Inserted as Builder-side working definition.'
FROM documents d
WHERE d.document_name = 'the_things_builder_working_definition_logi_a_a';

COMMIT;