# the_things_logical_table_draft_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 의 문서보존 구조를 위해 필요한 논리 테이블들을 초안 형태로 정리한 문서이다.  
이 문서는 schema seed 에서 제안한 최소 구조를 실제 테이블 단위로 한 단계 더 구체화하여  
나중에 PostgreSQL SQL 설계로 내려가기 전의 중간 초안으로 사용된다.

---

## name
the_things_logical_table_draft_logi_a_a

---

## purpose
This document defines a logical table draft
for the_things_DB.

Its purpose is to clarify:

- which core logical tables should exist
- what each table is responsible for
- how document preservation differs from graph/runtime storage
- how lineage, layers, ingest history, and object relation may be represented
- how the schema seed may descend toward actual PostgreSQL design

This is not yet a final SQL DDL.
It is a logical table draft.

---

## root_summary
The current observed PostgreSQL schema in `seungeflow`
already contains a graph/runtime side:

- node
- relation
- event
- field
- pattern

However, the_things_DB also requires
a document-preservation side.

That side must support at minimum:

- document identity
- document class
- related object
- lineage continuity
- original / translation / interpretation separation
- ingest history
- registry-style review

Thus this draft proposes two major zones:

- document preservation zone
- graph/runtime zone

with possible future bridge structures between them.

---

## core_definition

### original_definition_ko
정의 : the_things_DB 의 논리 테이블은 크게 문서보존 테이블군과 구조그래프 테이블군으로 나누어 보아야 한다.  
문서보존 테이블군은 이름, class, 객체연결, 계보, 원문층, 본문, 적재기록을 감당해야 하고  
구조그래프 테이블군은 node, relation, event, field, pattern 을 감당한다.  
또한 필요할 경우 둘을 연결하는 bridge 테이블이 존재할 수 있다.  
즉 logical table draft 는 이 두 층을 분리 인식한 채 이후 SQL 구현으로 내려가기 위한 중간 설계이다.

### translated_definition_en
The logical tables of the_things_DB
should be understood in two major groups:

- document-preservation tables
- graph/runtime tables

The document-preservation tables must support:
name, class, object relation, lineage, original-text layer,
content body, and ingest history.

The graph/runtime tables support:
node, relation, event, field, and pattern.

If needed, bridge tables may later connect the two sides.

Thus this logical table draft is an intermediate design
that distinguishes the two layers
before descending into SQL implementation.

---

## table_design_principles

### separation_rule
Document-preservation tables
must not be collapsed into graph/runtime tables.

The two sides may connect later,
but they should remain conceptually distinct.

---

### minimal_viable_rule
The first draft should include
only the tables necessary to support structured document intake.

Over-design should be avoided at this stage.

---

### lineage_rule
Documents belonging to a continuity chain
must be supported by explicit lineage structure.

---

### layer_rule
Original text, translation, interpretation,
and derived summary layers
must remain separable.

---

### no_delete_only_add_rule
The logical design should support:
- version continuation
- added layers
- added lineage members
- preserved ingest history

without destructive replacement.

---

## zone_1_document_preservation_tables

### 1. documents
**role**  
Main document preservation table.

**responsibility**
- preserve stable document identity
- preserve primary metadata
- preserve main content reference
- preserve current state

**logical fields**
- document_id
- document_name
- document_title
- document_class
- primary_role
- related_object
- source_origin
- current_status
- content_body
- created_at
- updated_at
- notes

**interpretation**
This is the central entry table
for prose-centered or file-centered documents.

Examples that belong here:
- fwos baseline (unified)
- readme_anchor_logi_a_a
- the_things_db_working_definition_logi_a_a
- the_things_schema_seed_logi_a_a

---

### 2. document_lineage
**role**  
Continuity-chain preservation table.

**responsibility**
- group related documents
- preserve lineage order
- preserve parent/previous/next relation
- preserve version or sequence position

**logical fields**
- lineage_id
- lineage_group
- document_id
- lineage_position
- previous_document_id
- next_document_id
- lineage_note
- created_at

**interpretation**
This table preserves continuity chains such as:
- readme_public_lineage
- the_things_working_definition_lineage
- future revision chains

---

### 3. document_layers
**role**  
Text-layer preservation table.

**responsibility**
- preserve original text
- preserve translation
- preserve interpretation
- preserve summary or derived layers
without overwriting source

**logical fields**
- layer_id
- document_id
- layer_type
- language_code
- layer_content
- preservation_required
- created_at
- notes

**example layer_type values**
- original
- translation
- interpretation
- summary

**interpretation**
This table protects the fwos original-text rule.

---

### 4. document_object_links
**role**  
Explicit document-to-object relation table.

**responsibility**
- connect documents to major objects
- support one-to-many or many-to-many object relation if needed
- make cross-object references explicit

**logical fields**
- link_id
- document_id
- object_name
- relation_note
- created_at

**example object_name values**
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

**interpretation**
This table is useful when a document
relates to more than one object.

---

### 5. ingest_records
**role**  
Structured intake history table.

**responsibility**
- record when a document entered DB
- preserve ingest stage
- preserve ingest notes
- preserve source window or source route

**logical fields**
- ingest_id
- document_id
- ingest_stage
- ingest_reason
- ingest_source_window
- ingest_note
- ingested_at

**interpretation**
This table preserves intake history
rather than merely final state.

---

### 6. document_registry
**role**  
Operational registry table or materialized view candidate.

**responsibility**
- support current document overview
- support name/class/object/status review
- support quick operational inspection

**logical fields**
- registry_id
- document_id
- registry_role
- registry_class
- registry_status
- registry_note
- created_at

**interpretation**
This may later become:
- a physical table
or
- a view derived from `documents` and related metadata

---

## zone_2_supporting_normalization_tables

### 7. document_classes
**role**  
Class normalization support table.

**responsibility**
- standardize class names
- support validation and consistency

**logical fields**
- class_id
- class_name
- class_description
- created_at

**example class_name values**
- raw_source_layer
- retrieval_pack_layer
- spec_layer
- graph_runtime_layer
- continuity_reference_layer
- coordination_layer
- public_anchor_layer

**interpretation**
Optional at first.
Can be inlined into `documents` initially.

---

### 8. major_objects
**role**  
Major object normalization support table.

**responsibility**
- standardize major object identity
- support cleaner references

**logical fields**
- object_id
- object_name
- object_description
- created_at

**example object_name values**
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System

**interpretation**
Optional at first.
Can be inlined into `documents` or `document_object_links`.

---

### 9. document_keywords
**role**  
AI-derived keyword coordinate table.

**responsibility**
- preserve derived retrieval coordinates
- keep derived keywords separate from author text

**logical fields**
- keyword_id
- document_id
- keyword_text
- keyword_source
- created_at
- notes

**interpretation**
These are not author tags.
They belong to the derived structural layer.

---

## zone_3_graph_runtime_tables

### existing_graph_runtime_interpretation
The currently observed `seungeflow` schema already contains:

- node
- relation
- event
- field
- pattern
- field_node
- pattern_relation
- field_log

These should be treated as the graph/runtime zone,
not discarded.

---

### 10. node
**role**  
Basic structural entity.

**observed fields**
- id
- label
- type
- created_at

**interpretation**
Represents structural units or entities
in the runtime graph layer.

---

### 11. relation
**role**  
Connection edge between nodes.

**observed fields**
- source_node_id
- target_node_id
- relation_type
- weight
- created_at

**interpretation**
Preserves graph connections and relation semantics.

---

### 12. event
**role**  
Time-stamped node-centered activity record.

**observed fields**
- node_id
- event_type
- content
- created_at

**interpretation**
Represents runtime observations, questions,
changes, or decisions.

---

### 13. field
**role**  
Higher-level field/container structure.

**observed fields**
- id
- name
- stability_score
- created_at

**interpretation**
Represents structural field or state container logic.

---

### 14. pattern
**role**  
Pattern dictionary / abstraction table.

**observed fields**
- pattern_type
- description
- created_at

**interpretation**
Represents reusable structural patterns
applied to graph relations.

---

### 15. field_node
**role**  
Field-to-node relation table.

**interpretation**
Supports many-to-many assignment
between field and node.

---

### 16. pattern_relation
**role**  
Pattern-to-relation mapping table.

**interpretation**
Applies pattern abstraction
to graph relations.

---

### 17. field_log
**role**  
Field-state history table.

**interpretation**
Preserves stability-score change history
and supports continuity of state changes.

---

## zone_4_future_bridge_tables

### 18. document_graph_links
**role**  
Future bridge table between document layer
and graph/runtime layer.

**responsibility**
- connect documents to nodes
- connect documents to events
- connect documents to patterns
- allow trace from authored document to extracted graph structure

**logical fields**
- bridge_id
- document_id
- graph_entity_type
- graph_entity_id
- relation_note
- created_at

**example graph_entity_type values**
- node
- relation
- event
- field
- pattern

**interpretation**
Not required immediately,
but likely important later.

---

### 19. revision_links
**role**  
Future revision/parent tracking table.

**responsibility**
- connect newer documents to prior versions
- support revision trees beyond simple lineage order

**logical fields**
- revision_link_id
- parent_document_id
- child_document_id
- revision_note
- created_at

**interpretation**
May become useful when documents branch,
fork, or diverge.

---

## recommended_initial_table_set

### minimum_first_set
If implementation begins now,
the most important first logical tables are:

1. documents
2. document_lineage
3. document_layers
4. ingest_records

**reason**
These are sufficient to begin:
- preserving documents
- preserving lineage
- preserving original/translation separation
- preserving intake history

---

### minimum_second_set
After the first set,
the next recommended tables are:

5. document_object_links
6. document_registry
7. document_keywords

**reason**
These improve:
- object clarity
- registry visibility
- derived retrieval support

---

### existing_graph_runtime_handling
The existing graph/runtime tables
should remain as a parallel zone.

They do not need to be rebuilt immediately,
but they should be reinterpreted as:
- runtime structure side
rather than
- full document preservation side

---

## logical_relationship_draft

### document-side relationship
```text
documents
├─ document_lineage
├─ document_layers
├─ document_object_links
├─ ingest_records
└─ document_keywords
graph-side relationship
field ──< field_node >── node ──< relation >── node
  │                            │
  └────< field_log             └────< event

pattern ──< pattern_relation >── relation
future bridge relationship
documents ──< document_graph_links >── node / relation / event / field / pattern
sample_mapping_examples
example_1_readme_anchor_logi_a_d
documents

document_name = readme_anchor_logi_a_d

document_class = public_anchor_layer

primary_role = implementation transition anchor

related_object = cross-object public reference

document_lineage

lineage_group = readme_public_lineage

lineage_position = d

document_layers

original Korean anchor content preserved as original layer

English explanation preserved separately if needed

ingest_records

first structured ingest wave

example_2_the_things_builder_working_definition
documents

document_name = the_things_builder_working_definition_logi_a_a

document_class = continuity_reference_layer

primary_role = Builder working definition

related_object = the_things_Builder

document_lineage

lineage_group = the_things_working_definition_lineage

lineage_position = builder

document_layers

Korean definition in original layer

English explanation or extended body separated if needed

example_3_fwos_baseline_unified
documents

document_name = fwos baseline (unified)

document_class = continuity_reference_layer

primary_role = reference baseline

related_object = cross-object baseline reference

document_layers

preserve original text layer exactly where applicable

preserve English body without overwriting Korean statements

relation_to_schema_seed
The schema seed defined
the minimum logical zones and entities.

This logical table draft descends one step lower
by expressing those zones
as table-oriented draft structures.

Thus:

schema seed = logical zone proposal

logical table draft = table-oriented structural draft

relation_to_initial_ingest_manifest
The initial ingest manifest defines
which documents should enter first.

This logical table draft defines
what receiving structures
those documents are expected to enter.

Thus:

manifest = initial intake targets

logical table draft = initial receiving table draft

present_continuity_rule
This draft begins from the present actionable state.

It does not attempt to define the final total database.

Instead, it defines the minimum logical table landscape
needed to move from document theory
toward database implementation now.

current_limit_interpretation
At the current stage,
the existing PostgreSQL schema alone
cannot fully receive the current document ecology.

Therefore, this draft does not replace the existing graph schema.

It proposes an additional document-preservation side
that can coexist with the runtime graph side.

future_extension_direction
Later table evolution may include:

retrieval_bundle_groups

template_type tables

visibility_scope tables

coordination flags

source_window tracking

preservation_priority

builder_return_links

core_validation_links

system_sync_records

These belong to later implementation phases.

status
Working logical table draft.
Not final SQL DDL.
Not final migration script.
This document serves as the current table-oriented structural draft
for the_things_DB.

end.