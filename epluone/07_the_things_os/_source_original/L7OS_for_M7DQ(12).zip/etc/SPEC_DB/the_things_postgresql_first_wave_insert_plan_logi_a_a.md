# the_things_postgresql_first_wave_insert_plan_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 의 1차 PostgreSQL 적재를 실제로 수행하기 전에  
무엇을 어떤 순서로 어떤 기준으로 넣을지를 정리한 first wave insert plan 문서이다.  
이 문서는 SQL 실행문 자체가 아니라  
현재 문서구조를 유지한 채 초기 적재를 안전하게 진행하기 위한 작업계획 문서이다.

---

## name
the_things_postgresql_first_wave_insert_plan_logi_a_a

---

## purpose
This document defines the first-wave PostgreSQL insert plan
for the_things_DB.

Its purpose is to clarify:

- which documents belong to the first actual insert wave
- why those documents are inserted before later materials
- how each document should be interpreted during insertion
- how current document structure should remain unchanged
- how insert execution should proceed in a safe staged order

This is not the SQL itself.
It is the operational plan before SQL execution.

---

## root_summary
The first-wave insert should not begin
by loading every available file into DB.

It should begin from the current structured document set
that has already been created in this stage.

The current plan is:

1. preserve current document structure as-is
2. insert the present structured document set first
3. verify that the DB can preserve those documents correctly
4. only after that, re-ingest earlier uploaded materials in a later wave

Thus the first wave is not mass import.
It is structural stabilization.

---

## core_definition

### original_definition_ko
정의 : 1차 적재는 지금까지 현재 시점에서 정리된 문서들을 먼저 DB에 넣는 작업이다.  
이때 문서 구조를 다시 바꾸지 않고  
문서 정리 당시의 형식을 그대로 유지한 채  
이름, class, 객체연결, 계보, 본문, 정의문을 함께 적재한다.  
기존에 업로드했던 문서들은 이 1차 작업 이후에 다시 입력한다.  
즉 first wave insert plan 은 현재 구조를 먼저 고정하는 적재 계획이다.

### translated_definition_en
The first-wave insert is the process
of loading the documents organized in the present stage
into DB first.

During this process,
the document structure should not be changed again.

The format established during document preparation
must remain as it is,
while document name, class, object relation, lineage,
body, and definitions are inserted together.

Previously uploaded materials will be re-ingested later,
after this first wave.

Thus the first-wave insert plan
is an insert plan for stabilizing the current structure first.

---

## why_this_plan_exists

This plan exists because there are two different actions:

### action_1
Defining the structure of the DB

### action_2
Actually inserting documents into the DB

Those two actions must not be confused.

The schema and insert drafts already created
prepared the places where values can go.

This first-wave insert plan explains
how the first actual document wave should be inserted
into those prepared places.

---

## first_wave_principles

### current_documents_first_rule
The documents created and stabilized in the present stage
must be inserted first.

Reason:
They form the current structural baseline.

---

### do_not_restructure_again_rule
The already organized document format
must not be restructured again before first insert.

Reason:
Repeated redesign before insertion causes instability.

---

### english_body_with_korean_definition_rule
The document format already established should remain intact.

This means:
- English-centered body may remain
- Korean definition parts may remain where already intentionally written
- the document should be inserted in the form it already holds

Reason:
The current document format was already intentionally designed.

---

### first_wave_before_older_materials_rule
Previously uploaded or older materials
should not enter before the present structured set is stabilized.

Reason:
The current set acts as the first reference skeleton.

---

### verify_before_expand_rule
After first-wave insert,
the inserted result should be checked before broader re-ingest begins.

Reason:
Small verified structure is safer than uncontrolled mass import.

---

### no_delete_only_add_rule
First-wave insert follows:

no delete, only add

The first inserted state remains preserved.
Later materials are added in later waves.

---

## what_belongs_to_first_wave

The first wave should include the present structured document set.

### baseline reference
- fwos baseline (unified)

### public anchor lineage
- readme_anchor_chain_logi_a_a
- readme_anchor_logi_a_a
- readme_anchor_logi_a_b
- readme_anchor_logi_a_c
- readme_anchor_logi_a_d

### object working definitions
- the_things_db_working_definition_logi_a_a
- the_things_builder_working_definition_logi_a_a
- the_things_core_working_definition_logi_a_a
- the_things_system_working_definition_logi_a_a
- the_things_object_map_logi_a_a

### operational governance
- the_things_document_class_rule_logi_a_a
- the_things_registry_logi_a_a
- the_things_db_ingest_rule_logi_a_a
- the_things_initial_ingest_queue_logi_a_a
- the_things_schema_seed_logi_a_a
- the_things_initial_ingest_manifest_logi_a_a
- the_things_ingest_bundle_index_logi_a_a
- the_things_logical_table_draft_logi_a_a
- the_things_logical_column_draft_logi_a_a
- the_things_sql_generation_rule_logi_a_a

### sql draft references
- the_things_postgresql_schema_draft_logi_a_a.sql
- the_things_postgresql_sample_insert_draft_logi_a_a.sql

These SQL drafts may be preserved as documents too,
but they are also executable-reference materials.

---

## what_does_not_belong_to_first_wave_yet

The following should wait for a later wave:

- large older uploaded document sets
- broad memo archives from PC
- phone memo mass imports
- mixed historical code fragments
- unsorted raw source piles
- broader legacy materials

Reason:
The current structured set should stabilize first.

---

## first_wave_insert_order

### step_1
Create the first-wave document-preservation tables.

Target tables:
- documents
- document_lineage
- document_layers
- ingest_records

Meaning:
Create the receiving structure first.

---

### step_2
Insert the highest baseline reference.

Target:
- fwos baseline (unified)

Meaning:
The first inserted document should be the interpretive baseline.

---

### step_3
Insert the README public anchor chain.

Targets:
- readme_anchor_chain_logi_a_a
- readme_anchor_logi_a_a
- readme_anchor_logi_a_b
- readme_anchor_logi_a_c
- readme_anchor_logi_a_d

Meaning:
Preserve external continuity before internal expansion.

---

### step_4
Insert the major object working definitions.

Targets:
- the_things_db_working_definition_logi_a_a
- the_things_builder_working_definition_logi_a_a
- the_things_core_working_definition_logi_a_a
- the_things_system_working_definition_logi_a_a
- the_things_object_map_logi_a_a

Meaning:
Preserve the internal object skeleton.

---

### step_5
Insert operational governance documents.

Targets:
- the_things_document_class_rule_logi_a_a
- the_things_registry_logi_a_a
- the_things_db_ingest_rule_logi_a_a
- the_things_initial_ingest_queue_logi_a_a
- the_things_schema_seed_logi_a_a
- the_things_initial_ingest_manifest_logi_a_a
- the_things_ingest_bundle_index_logi_a_a
- the_things_logical_table_draft_logi_a_a
- the_things_logical_column_draft_logi_a_a
- the_things_sql_generation_rule_logi_a_a

Meaning:
Preserve the rule-and-structure governance layer.

---

### step_6
Insert SQL draft references.

Targets:
- the_things_postgresql_schema_draft_logi_a_a.sql
- the_things_postgresql_sample_insert_draft_logi_a_a.sql

Meaning:
Preserve the first executable structural drafts.

---

### step_7
Verify inserted results.

Check:
- documents row count
- lineage entries
- layers preserved correctly
- ingest records preserved correctly
- sample retrieval works

Meaning:
Verify the first wave before any second wave begins.

---

## insert_interpretation_rules

### rule_1_document_structure_stays_as_is
The already organized document structure stays as-is.

Do not redesign the document before insert.

---

### rule_2_definition_parts_must_remain
Korean definition parts that were intentionally preserved
must remain preserved in the inserted document form.

---

### rule_3_main_body_may_remain_english_centered
English-centered body structure may remain as currently written.

---

### rule_4_insert_is_not_rewriting
First-wave insert is not a rewriting stage.

It is a preservation stage.

---

### rule_5_lineage_must_be_explicit
If a document belongs to a chain,
its lineage must be stored explicitly.

---

### rule_6_layers_must_be_available
If original Korean definition and English body coexist,
the DB design must be able to preserve that without flattening it carelessly.

---

## first_wave_success_conditions

The first wave should be considered successful only if:

1. the core tables are created successfully
2. the baseline document is inserted successfully
3. README lineage documents are inserted successfully
4. working definitions are inserted successfully
5. governance documents are inserted successfully
6. ingest history is queryable
7. lineage is queryable
8. layers can be preserved without structure collapse

---

## second_wave_condition

The second wave should begin only after the first wave is checked.

The second wave may include:
- older uploaded documents
- older raw materials
- wider archives
- re-ingested legacy files

The second wave is not part of this document.
This document only defines the first wave.

---

## relation_to_schema_and_sql_drafts

### relation_to_schema_draft
The schema draft creates the receiving structure.

### relation_to_sample_insert_draft
The sample insert draft tests whether the structure works.

### relation_to_this_plan
This plan determines which real documents should be inserted first
once the structure is ready.

Thus:
- schema draft = receiving structure
- sample insert draft = trial insert
- first-wave insert plan = actual first insert strategy

---

## present_continuity_rule
This plan follows the present actionable state.

It does not attempt to solve every future archive problem at once.

It preserves the current structured document set first,
so that later expansion can proceed with less confusion.

---

## status
Working first-wave insert plan.
Not final migration execution log.
Not final second-wave plan.
This document serves as the current operational insert plan
for the first actual document-ingest wave
into the_things_DB.

---

end.