# the_things_object_map_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_System / the_things_DB / the_things_Builder / the_things_CORE 의
객체 구분과 상호관계를 한 장의 구조맵으로 정리한 object map 문서이다.  
이 문서는 각 객체를 서로 섞지 않고 독립적으로 인지하면서도
전체 시스템 안에서 어떤 위치와 역할을 가지는지를 명확히 하기 위한 기준 문서이다.

---

## name
the_things_object_map_logi_a_a

---

## purpose
This document provides a structural object map
for the_things project.

Its purpose is to clarify:

- which major objects currently exist
- how those objects differ from one another
- how they relate without collapsing into one mixed unit
- how work should be distributed across separated windows
- how coordination should occur when cross-object revision is required

This is not a final constitution.
It is a working object map for operational clarity.

---

## root_summary
the_things project should not be treated as one undifferentiated workspace.

Instead, it is composed of distinct independent objects:

- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System

These objects must be recognized as separate
so that work does not become structurally tangled.

The_things_System stands above the others
not as a merged replacement,
but as a coordination layer.

Thus the structure is:

- separation first
- controlled synchronization later

---

## core_definition

### original_definition_ko
정의 : the_things 는 하나의 작업창이 아니라
서로 다른 역할을 가진 독립 객체들의 집합으로 이해해야 한다.  
DB 는 저장과 추출을 담당하고,
Builder 는 생성과 조합을 담당하며,
CORE 는 중심정체성과 연속성을 담당하고,
System 은 이 객체들을 상위에서 조율한다.  
즉 the_things 는 혼합작업장이 아니라
분리된 객체들과 조율체계로 이루어진 시스템이다.

### translated_definition_en
the_things should not be understood as a single mixed workspace.

It should be understood as a set of independent objects with distinct roles.

DB handles preservation and retrieval.  
Builder handles generation and assembly.  
CORE handles central identity and continuity.  
System coordinates these objects from above.

Thus, the_things is not a merged workbench,
but a system composed of separated objects and a coordination layer.

---

## object_list

### 1. the_things_DB
Primary role:
- preserve source materials
- preserve extracted materials
- preserve refined outputs
- maintain retrieval direction
- support schema/storage logic

Core nature:
- preservation object
- retrieval object
- storage-side structure object

DB is where materials are kept, classified, and prepared for later reuse.

---

### 2. the_things_Builder
Primary role:
- generate structure
- combine templates
- assemble implementation-facing documents
- create spec and coding-preparation outputs

Core nature:
- generation object
- construction object
- implementation preparation object

Builder is where structure is actively formed and shaped for making.

---

### 3. the_things_CORE
Primary role:
- preserve central identity
- preserve continuity
- maintain stable internal reference
- reduce structural drift

Core nature:
- continuity object
- identity reference object
- central stability object

CORE is where the project remains itself through revision and expansion.

---

### 4. the_things_System
Primary role:
- coordinate across objects
- manage synchronization
- align schema and definitions when required
- preserve higher-level consistency

Core nature:
- coordination object
- synchronization object
- upper structural alignment object

System is where separated objects are compared and aligned when needed.

---

## object_relation_map

### structural relation
```text
the_things_System
├─ the_things_DB
├─ the_things_Builder
└─ the_things_CORE

This is a coordination relation, not a containment collapse.

System stands above as a coordination layer,
but DB, Builder, and CORE remain independent objects.

functional relation
DB       -> preserve / retrieve
Builder  -> generate / assemble
CORE     -> preserve continuity / identity
System   -> coordinate / synchronize

Each object has its own dominant direction.

separation_rules
object_independence_rule

Each object must be treated as independent.

This means:

DB should not become Builder

Builder should not become CORE

CORE should not become System

System should not absorb the others into one blurred workspace

Object distinction is necessary for clarity.

window_separation_rule

Each object should be worked on in its own window.

This supports:

cleaner thinking

clearer role boundaries

safer revision control

reduced conceptual overlap

Thus:

DB window handles DB

Builder window handles Builder

CORE window handles CORE

System window handles cross-object coordination

controlled_transfer_rule

Materials may move between objects,
but only through deliberate transfer.

Examples:

DB materials may be extracted into Builder

Builder outputs may be preserved back into DB

Builder or DB drift questions may be checked against CORE

cross-object inconsistencies may be brought into System

Transfer is allowed.
Confusion is not.

human_bridge_model

The human acts as the bridge across the separated objects.

The independent object windows do not automatically merge themselves.

Instead, Seung-i:

decides when extraction is needed

moves relevant schema or definitions between windows

preserves separation

triggers coordination only when necessary

Thus the human is the operational bridge of the_things system.

present_continuity_rule

All object work begins from the present actionable point.

Past, present, and future are understood as continuity,
but execution always begins now.

This means:

use the present as the active reference point

move forward from what is currently possible

refine later when needed

do not become trapped by older states

This rule applies across DB, Builder, CORE, and System.

no_delete_only_add_rule

All objects follow:

no delete, only add

Earlier states are preserved.
Later states are added as:

extensions

refinements

revisions

new branches of continuity

This preserves lineage while supporting growth.

document_flow_example
raw-to-system flow
raw source material
→ preserved in DB
→ extracted as reference bundle
→ used in Builder
→ refined into spec / design document
→ optionally checked against CORE
→ coordinated in System if cross-object revision is needed
→ preserved back into DB

This flow is not automatic.
It is guided by the human.

current_project_interpretation

At the current stage:

the_things_DB is being defined as a future document-preservation and retrieval base

the_things_Builder is the active construction-side object

the_things_CORE is the continuity and identity reference object

the_things_System is the upper coordination object

README v0.4 publicly signaled the beginning of implementation-facing movement,
while the working definitions created here establish internal object separation.

Thus public declaration and internal object clarification are now beginning to align.

relation_to_readme_lineage

The README lineage provides public-facing external anchors
for the project’s visible continuity.

The object map does not replace that lineage.

Instead, it explains how the internal object system
stands behind the public project trajectory.

In this sense:

README lineage shows external declaration flow

object map shows internal object structure

Both are needed.

future_extension_direction

This object map may later expand to include additional objects such as:

APP-related objects

template governance objects

archive/reference objects

protocol objects

interface objects

However, the current essential map remains:

DB

Builder

CORE

System

status

Working object map.
Not final constitution.
Not final governance graph.
This document serves as the current operational map
for the major objects of the_things.

end.


## 지금 이 문서의 의미
이제 네가 만든 축은 이렇게 보인다.

```text
the_things_System
├─ the_things_DB
├─ the_things_Builder
└─ the_things_CORE

그리고 흐름은 이렇게 잡힌다.

DB -> Builder -> DB
 \      |
  \     v
   -> CORE
        |
        v
      System

물론 이건 고정된 파이프가 아니라,
승이가 필요할 때 연결하는 조율 흐름이다.