# the_things_builder_working_definition_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_Builder 의 현재 역할과 작업 기준을 정리한 working definition 문서이다.  
이 문서는 Builder 창이 무엇을 생성하고 어떻게 구조를 조합하며  
DB / CORE / System 과 어떻게 구분되어야 하는지를 명확히 하기 위한 기준 문서이다.

---

## name
the_things_builder_working_definition_logi_a_a

---

## purpose
This document defines the current working role of the_things_Builder.

It clarifies:

- what Builder is responsible for
- how Builder differs from DB, CORE, and System
- how Builder should generate and assemble structure
- how templates may be used for implementation-oriented work
- how Builder outputs may later return to DB as preserved documents

This is not a final implementation manual.
It is a working definition for Builder-side generation and construction.

---

## root_summary
the_things_Builder is the construction-side object of the_things project.

It is responsible for:

- structural generation
- implementation-oriented assembly
- template-based composition
- design-to-spec transition
- preparation for future program development

Builder is not a storage object.
Builder is not the upper coordination object.
Builder is not the central persistent identity object.

Builder is the object that creates, arranges, combines, and advances implementation-facing structure.

The Builder window is led directly by the human.

---

## core_definition

### original_definition_ko
정의 : the_things_Builder 는 구조생성기이다.  
이 객체는 문서, 템플릿, 정의, 구조조각들을 조합하여  
구현을 위한 설명문, 설계문, spec 문서, 코딩준비문서를 생성하는 역할을 가진다.  
Builder 는 DB처럼 저장을 우선하지 않고  
System 처럼 상위조율을 우선하지 않으며  
CORE 처럼 중심정체성을 유지하는 객체도 아니다.  
Builder 는 생성과 조합과 구현준비를 담당하는 독립 객체이다.  
또한 이 Builder 는 승이가 단독으로 주도한다.

### translated_definition_en
the_things_Builder is a structure generator.

Its role is to combine documents, templates, definitions, and structural fragments
in order to produce implementation-oriented explanations, design documents,
spec documents, and coding-preparation materials.

Builder does not primarily preserve like DB,
does not primarily coordinate like System,
and does not primarily maintain persistent central identity like CORE.

Builder is an independent object responsible for generation,
composition, and implementation preparation.

This Builder is led directly by the human.

---

## builder_identity

### primary_nature
Builder is a construction object.

Its natural direction is:
- generate
- combine
- refine
- transition toward implementation

Builder exists on the side of making,
not merely storing.

---

### human_led_rule
Builder is led directly by the human.

The AI inside the Builder window supports:
- structure organization
- draft shaping
- template alignment
- spec consolidation

But the primary directional lead belongs to Seung-i.

Thus Builder is not autonomous.
It is human-led construction.

---

## role_separation_model

### the_things_Builder
Primary role:
- structural generation
- template-based assembly
- document refinement for implementation
- spec production
- coding preparation materials generation

Builder focuses on:
- assembling ideas into buildable form
- turning reference material into structured outputs
- converting extracted context into implementation-facing documents

---

### relation_to_the_things_DB
DB preserves.

Builder generates.

DB keeps:
- raw materials
- extracted references
- preserved outputs
- retrieval bases

Builder uses:
- extracted materials
- prior definitions
- template structures
- current implementation goals

Builder may produce outputs that are later stored back into DB.

Thus DB and Builder are connected,
but their primary directions are different.

---

### relation_to_the_things_CORE
CORE maintains persistent central continuity.

Builder does not define final central identity.
Builder works around implementation movement and construction tasks.

Builder may reference CORE for consistency,
but Builder is not CORE.

---

### relation_to_the_things_System
System coordinates independent objects from above.

Builder does not coordinate the whole system.

When Builder-side revisions affect DB, CORE, or naming/schema consistency,
those extracted definitions may later be carried upward into System for alignment.

Builder is therefore a lower independent object,
not the upper synchronization layer.

---

## operational_principles

### generation_first_rule
Builder begins from generation.

Its first movement is not preservation,
but construction.

Thus Builder must favor:
- draft formation
- structural assembly
- spec shaping
- implementation preparation

---

### present_execution_rule
Builder works from the present actionable point.

Past documents and previous ideas are references,
but implementation begins from what can be built now.

Therefore:
- move from the current state
- build what is actionable now
- refine after construction
- extend later if needed

---

### no_delete_only_add_rule
Builder follows:

no delete, only add

Earlier drafts, structures, and versions are not treated as waste.
They may remain as earlier stages,
while newer versions extend and refine them.

---

### separation_first_rule
Builder must remain distinct from DB, CORE, and System.

Builder should not become:
- a raw archive
- a full system coordinator
- a permanent identity core

It must remain the generation object.

---

## builder_material_inputs
Builder may consume materials such as:

- extracted md bundles from DB
- prior README lineage documents
- schema definitions
- working definition documents
- spec fragments
- pseudocode
- sql / yaml / py / json references
- manually written notes from the human

These inputs are not the Builder itself.
They are materials for Builder-side generation.

---

## builder_output_classes
Builder may generate documents such as:

### 1. implementation_explanation_documents
Documents explaining how a structure should be understood for implementation.

### 2. design_documents
Documents that shape architecture, flow, or module composition.

### 3. spec_documents
Structured documents for program development, logic definition, or behavior design.

### 4. coding_preparation_documents
Documents created before actual programming begins,
including structured notes, module plans, interface ideas, and template mappings.

### 5. template_based_outputs
Outputs shaped by template classes such as:

- CORE
- APP
- DB

Additional template classes may appear later.

---

## template_interpretation_rule
Builder may use multiple template classes,
but template class must not be confused with the object itself.

For example:

- a document may use `type: CORE`
- another may use `type: APP`
- another may use `type: DB`

These are Builder-side output classifications,
not proof that Builder itself becomes CORE, APP, or DB.

Thus template type belongs to output interpretation,
not to Builder identity.

---

## builder_workflow_model

### 1. receive context
Builder receives:
- extracted source materials
- previous definitions
- current implementation goals
- relevant schema or structural references

---

### 2. assemble structure
Builder organizes:
- concepts
- relations
- sections
- priorities
- possible template alignments

---

### 3. generate output draft
Builder produces:
- explanation draft
- design draft
- spec draft
- coding preparation draft

---

### 4. refine through dialogue
The draft is refined through human-led dialogue.

This may include:
- renaming
- restructuring
- classification adjustment
- scope narrowing
- implementation sharpening

---

### 5. return selected outputs
Selected Builder outputs may later:
- remain in Builder as active work material
- be transferred to DB for preservation
- be referenced by System if cross-object coordination is needed
- be checked against CORE for consistency

---

## current_position_in_the_things
At the current stage, Builder is the most active generation-side object.

README v0.4 publicly signaled the beginning of implementation-facing movement.

That README acts as an external declaration that the Builder-side process has begun,
even if Builder itself remains an internal working object.

Thus Builder is internally active,
while some of its direction has already been externally signaled.

---

## relation_to_readme_lineage
The README lineage is not identical to Builder,
but it serves as an external public baseline chain
for the implementation-facing movement that Builder now continues internally.

In this sense:

- README 0.1 records foundational declaration
- README 0.2 records runtime direction
- README 0.3 records present-based continuity
- README 0.4 records implementation transition

Builder proceeds forward from that externally declared transition.

---

## human_bridge_role
The human leads Builder directly
and also decides when Builder-side results should be:

- preserved in DB
- checked against CORE
- brought into System for higher coordination

Thus the human is both:
- Builder lead
- inter-window transfer bridge

The AI assists structural generation,
but the Builder direction remains human-led.

---

## status
Working definition.
Not final implementation doctrine.
Not final template governance.
This document serves as the current operational anchor
for the_things_Builder.

---

end.