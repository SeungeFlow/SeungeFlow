# the_things_db_working_definition_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 창의 현재 역할과 작업 기준을 정리한 working definition 문서이다.  
이 문서는 Builder, CORE, System 과의 구분을 명확히 하여  
DB 창이 무엇을 다루고 무엇을 다루지 않는지를 고정하기 위한 기준 문서이다.

---

## name
the_things_db_working_definition_logi_a_a

---

## purpose
This document defines the current working role of the_theings_DB.

It exists to clarify:
- what the DB window is responsible for
- how it differs from Builder and CORE
- how independent object separation should be maintained
- how future coordination with the higher System layer should occur

This is not a final database schema.
It is a working definition for operational separation and structural direction.

---

## root_summary
the_things project must not be handled as one mixed workspace.

The following objects must remain separated:

- the_things_DB
- the_things_Builder
- the_things_CORE

Each must be treated as an independent object with its own role, scope, and update cycle.

When changes affect multiple objects at once, coordination must occur through a higher-level system window.

That higher coordination layer is treated as:

- the_things_System

Thus the structure is not a single merged workspace,
but a separated multi-object system with controlled synchronization.

---

## core_definition

### original_definition_ko
정의 : DB창에서는 DB를 / 빌더창에서는 빌더를 / CORE에서는 CORE를 다룬다.  
서로를 처음부터 섞지 않고 독립된 객체로 인지해야 작업이 꼬이지 않는다.  
수정사항이 생길 경우에는 승이가 각 창의 schema 또는 정의를 추출하여  
상위 System 창에서 동시조율한다.  
즉 the_things_System 은 DB / Builder / CORE 를 상위에서 연결하는 조율 객체이다.

### translated_definition_en
The DB window handles DB only, the Builder window handles Builder only,
and the CORE window handles CORE only.

They must not be mixed from the beginning.
Each must be treated as an independent object in order to avoid structural confusion.

When revisions affect multiple windows,
Seung-i extracts the relevant schema or definitions from each object
and synchronizes them through the higher System window.

Thus, the_things_System functions as the upper coordination object
connecting DB, Builder, and CORE.

---

## role_separation_model

### the_things_DB
Primary role:
- preserve source materials
- preserve structured documents
- preserve extracted references
- preserve spec outputs after dialogue refinement
- provide retrieval base for future work

This window focuses on:
- storage logic
- document classification logic
- schema direction
- retrieval structure
- preservation rules

This window does not lead Builder implementation directly.

---

### the_things_Builder
Primary role:
- generation
- construction
- implementation-oriented document assembly
- template usage
- program-development preparation

This window is led directly by the human.

Builder is not the same as DB.
It consumes structured inputs and produces design or implementation outputs.

---

### the_things_CORE
Primary role:
- core structure definition
- central logic consolidation
- stable reference for implementation consistency

CORE is not identical to Builder or DB.
It acts as the internal central object for persistent structural identity.

---

### the_things_System
Primary role:
- upper coordination
- cross-window synchronization
- change management across DB / Builder / CORE
- system-level structural consistency

This object is activated when multiple independent objects must be aligned together.

the_things_System is not a replacement for DB, Builder, or CORE.
It is the coordinating layer above them.

---

## operational_principle

### separation_first_rule
Independent objects must be separated first.

Mixing DB, Builder, and CORE too early causes structural confusion.

Thus:
- separation first
- synchronization later

---

### present_continuity_rule
All execution begins from the current point.

Past, present, and future are understood as a continuous extension,
but implementation always begins at the present actionable point.

Therefore:
- move first
- implement first
- refine later
- add later

This rule supports forward motion without being trapped by previous states.

---

### no_delete_only_add_rule
The working direction follows the principle:

no delete, only add

Earlier states are preserved.
Later states are added through refinement, extension, or versioned continuation.

---

## document_classes_in_db
The DB is expected to eventually distinguish at least the following logical classes:

### 1. raw_source_layer
Examples:
- memo text
- markdown notes
- yaml
- sql
- py
- json
- pseudocode
- mobile note records
- observational originals

These are raw materials.

---

### 2. retrieval_pack_layer
Examples:
- extracted reference bundles
- current-topic material collections
- md files prepared as inputs for a new conversation

These are retrieval-oriented preparation materials.

---

### 3. spec_layer
Examples:
- refined design outputs
- structured specification documents
- template-based development documents

These are production-oriented documents.

---

### 4. graph_runtime_layer
Examples:
- node
- relation
- event
- field
- pattern

These are structure-extracted or system-runtime layers.

---

## current_db_interpretation
The currently observed seungeflow PostgreSQL database is not yet a full document-preservation DB.

Observed characteristics indicate:

- node / relation / event structure exists
- field / pattern schema exists but has little or no practical population
- raw document preservation layer is not yet established
- translation / interpretation separation layer is not yet established
- spec-oriented document distinction is not yet established

Therefore, the current DB is closer to an early structure-graph engine
than to a fully realized the_things_DB.

---

## relation_to_readme_lineage
README 0.1 to README 0.4 are treated as external public baseline lineage documents.

They are mapped as:

- readme_anchor_logi_a_a
- readme_anchor_logi_a_b
- readme_anchor_logi_a_c
- readme_anchor_logi_a_d

These README documents function as public-facing baseline anchors,
not merely versioned files.

They provide public reference points for how the project externally declared its continuity,
runtime direction, present-based action principle,
and implementation transition.

---

## human_bridge_role
The human acts as the synchronization bridge across independent windows.

The AI instance inside each window does not directly merge itself with the others.

Instead:
- Seung-i extracts the necessary schema or definitions
- transfers them across windows
- preserves separation
- enables controlled coordination

Thus the human is the bridge,
and system continuity is maintained through deliberate transfer rather than uncontrolled merge.

---

## status
Working definition.
Not final schema.
Not final system constitution.
This document serves as a current operational anchor for the_things_DB.

---

end.