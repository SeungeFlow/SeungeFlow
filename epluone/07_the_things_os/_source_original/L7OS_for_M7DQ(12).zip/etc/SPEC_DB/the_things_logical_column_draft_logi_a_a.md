# the_things_logical_column_draft_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 의 핵심 논리 테이블들에 대해 어떤 컬럼들이 왜 필요한지를 정리한 logical column draft 문서이다.  
이 문서는 logical table draft 에서 제안한 테이블들을 한 단계 더 세분화하여  
각 컬럼의 역할, 의미, 보존방향, nullable 여부에 대한 감각을 잡기 위한 중간 설계 문서이다.

---

## name
the_things_logical_column_draft_logi_a_a

---

## purpose
This document defines a logical column draft
for the core document-preservation tables
of the_things_DB.

Its purpose is to clarify:

- which columns are needed in each major logical table
- what responsibility each column carries
- how identity, class, lineage, layers, and ingest context should be preserved
- how this design can later descend into PostgreSQL column definitions

This is not yet final SQL DDL.
It is a column-oriented logical draft.

---

## root_summary
The logical table draft identified the main table groups needed for the_things_DB:

- documents
- document_lineage
- document_layers
- document_object_links
- ingest_records
- document_registry
- document_keywords

This document now refines those tables
by proposing column-level structure.

The goal is not to over-finalize,
but to make sure the DB can later preserve:

- document identity
- structural role
- object relation
- lineage continuity
- original text integrity
- ingest history
- retrieval coordinates

---

## core_definition

### original_definition_ko
정의 : logical column draft 는 테이블이 필요하다는 말에서 한 단계 더 내려가  
각 테이블 안에 어떤 컬럼이 어떤 의미로 들어가야 하는지를 정리한 문서이다.  
이 문서는 아직 최종 SQL 타입 선언문은 아니지만  
문서보존과 계보보존과 원문보존을 위해 어떤 컬럼이 핵심인지를 잡아주기 위한 중간초안이다.

### translated_definition_en
The logical column draft moves one step below
the statement that certain tables are needed.

It defines which columns should exist inside those tables
and what meaning each column should carry.

This is not yet a final SQL type declaration,
but an intermediate draft
for identifying the essential columns
needed for document preservation,
lineage preservation,
and original-text preservation.

---

## column_design_principles

### identity_first_rule
Each major row should have a stable identity column.

Identity must not depend only on surface document names.

Thus logical IDs are required.

---

### meaning_plus_context_rule
A preserved document should not be reduced
to content_body alone.

Context columns are essential:
- class
- role
- object relation
- lineage
- status
- source origin

---

### original_layer_protection_rule
Columns must support original-text preservation
without forcing translation or interpretation
to overwrite the source.

---

### add_not_replace_rule
Column design should support
added revisions, added layers, and added lineage entries
without destructive overwrite logic.

---

### nullable_awareness_rule
Some columns are essential,
while others are optional.

A useful draft should distinguish:
- must-have columns
- optional-support columns

---

## table_1_documents

### role
Main preservation table
for document identity and core metadata.

### recommended_columns

#### document_id
**meaning**  
Stable internal document identifier.

**importance**  
required

**nullable**  
no

**notes**  
Should be independent of file name.
May later become UUID or bigint.

---

#### document_name
**meaning**  
Stable working name of the document.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- the_things_db_working_definition_logi_a_a
- readme_anchor_logi_a_d

---

#### document_title
**meaning**  
Human-readable title or display label.

**importance**  
recommended

**nullable**  
yes

**notes**  
May be identical to document_name at first,
but allows cleaner presentation later.

---

#### document_class
**meaning**  
Logical document class.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- continuity_reference_layer
- coordination_layer
- public_anchor_layer

---

#### primary_role
**meaning**  
Main role played by the document.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- working definition
- reference baseline
- ingest rule
- object map
- public anchor

---

#### related_object
**meaning**  
Primary object relation.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

This may later be complemented by a separate link table.

---

#### source_origin
**meaning**  
How the document came into existence.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- written by human
- generated through dialogue
- mapped from README
- extracted from prior material

---

#### current_status
**meaning**  
Present operational state of the document.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- working definition
- mapped public anchor
- reference baseline
- draft

---

#### content_body
**meaning**  
Preserved main body content.

**importance**  
required

**nullable**  
no

**notes**  
This is not enough by itself,
but it remains essential.

---

#### content_format
**meaning**  
Primary surface format of the preserved body.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- md
- yaml
- sql
- py
- json
- txt

---

#### original_text_required
**meaning**  
Whether exact original-text preservation is required.

**importance**  
recommended

**nullable**  
no

**notes**  
Possible values later:
- yes
- no
- partial

---

#### created_at
**meaning**  
Initial creation timestamp of the preserved row.

**importance**  
required

**nullable**  
no

---

#### updated_at
**meaning**  
Last update timestamp for the preserved row.

**importance**  
recommended

**nullable**  
yes

---

#### notes
**meaning**  
Additional operational or interpretive notes.

**importance**  
optional

**nullable**  
yes

---

## table_2_document_lineage

### role
Preserve continuity chains and ordered position.

### recommended_columns

#### lineage_id
**meaning**  
Stable lineage row identifier.

**importance**  
required

**nullable**  
no

---

#### lineage_group
**meaning**  
Name of the continuity group.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- readme_public_lineage
- the_things_working_definition_lineage
- the_things_operational_rule_lineage

---

#### document_id
**meaning**  
Linked document identifier.

**importance**  
required

**nullable**  
no

---

#### lineage_position
**meaning**  
Position of the document inside the lineage.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- a
- b
- c
- d
- db
- builder
- core
- system
- root
- object_map

---

#### previous_document_id
**meaning**  
Previous document in chain if applicable.

**importance**  
optional

**nullable**  
yes

---

#### next_document_id
**meaning**  
Next document in chain if applicable.

**importance**  
optional

**nullable**  
yes

---

#### lineage_order
**meaning**  
Sortable numeric order if needed.

**importance**  
recommended

**nullable**  
yes

**notes**  
Useful because `a/b/c/d` is readable,
but numeric ordering is easier for sorting.

---

#### lineage_note
**meaning**  
Extra continuity note.

**importance**  
optional

**nullable**  
yes

---

#### created_at
**meaning**  
Timestamp of lineage entry creation.

**importance**  
required

**nullable**  
no

---

## table_3_document_layers

### role
Preserve original, translation, interpretation, and summary layers separately.

### recommended_columns

#### layer_id
**meaning**  
Stable layer row identifier.

**importance**  
required

**nullable**  
no

---

#### document_id
**meaning**  
Owning document identifier.

**importance**  
required

**nullable**  
no

---

#### layer_type
**meaning**  
Type of text layer.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- original
- translation
- interpretation
- summary

---

#### language_code
**meaning**  
Language of the layer content.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- ko
- en

---

#### layer_content
**meaning**  
Actual text content of the layer.

**importance**  
required

**nullable**  
no

---

#### preservation_required
**meaning**  
Whether this layer must be preserved exactly.

**importance**  
recommended

**nullable**  
no

**notes**  
Especially important for original Korean layers.

---

#### layer_order
**meaning**  
Ordering of multiple layers of same document.

**importance**  
optional

**nullable**  
yes

---

#### source_note
**meaning**  
Note about where this layer came from.

**importance**  
optional

**nullable**  
yes

**notes**  
Examples:
- direct original text
- generated translation
- later interpretation
- compressed summary

---

#### created_at
**meaning**  
Timestamp of layer creation.

**importance**  
required

**nullable**  
no

---

## table_4_document_object_links

### role
Preserve explicit many-to-many or multi-object relations.

### recommended_columns

#### link_id
**meaning**  
Stable link row identifier.

**importance**  
required

**nullable**  
no

---

#### document_id
**meaning**  
Linked document identifier.

**importance**  
required

**nullable**  
no

---

#### object_name
**meaning**  
Name of connected major object.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

---

#### link_role
**meaning**  
Type of relation between document and object.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- primary
- supporting
- reference
- threshold
- coordination

---

#### relation_note
**meaning**  
Additional explanation of the object relation.

**importance**  
optional

**nullable**  
yes

---

#### created_at
**meaning**  
Timestamp of object-link creation.

**importance**  
required

**nullable**  
no

---

## table_5_ingest_records

### role
Preserve structured intake history.

### recommended_columns

#### ingest_id
**meaning**  
Stable ingest-event identifier.

**importance**  
required

**nullable**  
no

---

#### document_id
**meaning**  
Document that was ingested.

**importance**  
required

**nullable**  
no

---

#### ingest_stage
**meaning**  
Stage or wave of ingest.

**importance**  
required

**nullable**  
no

**notes**  
Examples:
- initial_wave
- second_wave
- raw_source_wave
- spec_wave

---

#### ingest_priority_group
**meaning**  
Priority grouping used at ingest time.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- 1_baseline
- 2_public_anchor_lineage
- 3_object_working_definitions
- 4_operational_governance

---

#### ingest_reason
**meaning**  
Why this document was ingested.

**importance**  
recommended

**nullable**  
yes

---

#### ingest_source_window
**meaning**  
Which working window originated the ingest action.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- DB
- Builder
- CORE
- System
- external_public

---

#### ingest_note
**meaning**  
Additional intake notes.

**importance**  
optional

**nullable**  
yes

---

#### ingested_at
**meaning**  
Timestamp of ingest event.

**importance**  
required

**nullable**  
no

---

## table_6_document_registry

### role
Operational overview table or view.

### recommended_columns

#### registry_id
**meaning**  
Stable registry entry identifier.

**importance**  
required if physical table

**nullable**  
no

---

#### document_id
**meaning**  
Linked document identifier.

**importance**  
required

**nullable**  
no

---

#### registry_role
**meaning**  
Operational role summary.

**importance**  
required

**nullable**  
no

---

#### registry_class
**meaning**  
Operational class summary.

**importance**  
required

**nullable**  
no

---

#### registry_status
**meaning**  
Operational status summary.

**importance**  
required

**nullable**  
no

---

#### registry_note
**meaning**  
Short overview note.

**importance**  
optional

**nullable**  
yes

---

#### created_at
**meaning**  
Registry entry timestamp.

**importance**  
recommended

**nullable**  
yes

---

## table_7_document_keywords

### role
Preserve AI-derived retrieval coordinates.

### recommended_columns

#### keyword_id
**meaning**  
Stable keyword-row identifier.

**importance**  
required

**nullable**  
no

---

#### document_id
**meaning**  
Owning document identifier.

**importance**  
required

**nullable**  
no

---

#### keyword_text
**meaning**  
Derived keyword text.

**importance**  
required

**nullable**  
no

---

#### keyword_source
**meaning**  
Origin of keyword derivation.

**importance**  
recommended

**nullable**  
yes

**notes**  
Examples:
- AI derived
- structural extraction
- later retrieval refinement

---

#### keyword_rank
**meaning**  
Relative priority or compact ordering of keyword.

**importance**  
optional

**nullable**  
yes

---

#### notes
**meaning**  
Additional note about keyword usage.

**importance**  
optional

**nullable**  
yes

---

#### created_at
**meaning**  
Timestamp of keyword entry.

**importance**  
required

**nullable**  
no

---

## optional_normalization_tables

### document_classes
Recommended columns:
- class_id
- class_name
- class_description
- created_at

Use:
Support class normalization if direct string storage becomes messy.

---

### major_objects
Recommended columns:
- object_id
- object_name
- object_description
- created_at

Use:
Support object normalization if direct string storage becomes messy.

---

## bridge_table_columns

### table_document_graph_links

#### bridge_id
Stable link identifier.

#### document_id
Linked document.

#### graph_entity_type
One of:
- node
- relation
- event
- field
- pattern

#### graph_entity_id
Identifier of linked graph entity.

#### relation_note
Explanation of why the document is linked to the graph entity.

#### created_at
Timestamp of bridge creation.

---

## recommended_column_priority

### priority_1_must_exist_early
These columns are most important in the first actual implementation:

#### in documents
- document_id
- document_name
- document_class
- primary_role
- related_object
- source_origin
- current_status
- content_body
- created_at

#### in document_lineage
- lineage_id
- lineage_group
- document_id
- lineage_position
- created_at

#### in document_layers
- layer_id
- document_id
- layer_type
- layer_content
- preservation_required
- created_at

#### in ingest_records
- ingest_id
- document_id
- ingest_stage
- ingested_at

---

### priority_2_should_follow_soon
Columns that improve clarity early:

#### in documents
- document_title
- content_format
- original_text_required
- notes
- updated_at

#### in document_lineage
- previous_document_id
- next_document_id
- lineage_order
- lineage_note

#### in document_layers
- language_code
- source_note
- layer_order

#### in ingest_records
- ingest_priority_group
- ingest_reason
- ingest_source_window
- ingest_note

---

### priority_3_can_wait
Columns that are useful later:

- keyword_rank
- registry_note
- class normalization fields
- object normalization fields
- advanced bridge note fields

---

## example_column_mapping

### example_1_readme_anchor_logi_a_d

#### documents
- document_name = readme_anchor_logi_a_d
- document_class = public_anchor_layer
- primary_role = implementation transition anchor
- related_object = cross-object public reference
- source_origin = mapped from public README
- current_status = mapped public anchor

#### document_lineage
- lineage_group = readme_public_lineage
- lineage_position = d
- lineage_order = 4

#### document_layers
- original / ko layer preserved exactly
- translation / en layer separated if needed

#### ingest_records
- ingest_stage = initial_wave
- ingest_priority_group = 2_public_anchor_lineage

---

### example_2_the_things_builder_working_definition_logi_a_a

#### documents
- document_name = the_things_builder_working_definition_logi_a_a
- document_class = continuity_reference_layer
- primary_role = Builder working definition
- related_object = the_things_Builder
- source_origin = generated through dialogue
- current_status = working definition

#### document_lineage
- lineage_group = the_things_working_definition_lineage
- lineage_position = builder

#### document_layers
- original Korean definition as original layer
- English explanation separated where needed

---

## relation_to_logical_table_draft
The logical table draft identified
which tables should exist.

This document refines that draft
by specifying which columns those tables should carry
and what those columns mean.

Thus:
- logical table draft = table landscape
- logical column draft = column landscape

---

## relation_to_future_sql
This document should later guide:
- column naming
- type selection
- nullability decisions
- constraint design
- index planning

It is still one step above direct SQL.

---

## present_continuity_rule
This draft reflects the present actionable state.

It does not try to finalize every future column now.

It identifies the columns
needed to begin implementation
without losing continuity later.

---

## status
Working logical column draft.
Not final SQL column specification.
Not final migration script.
This document serves as the current column-oriented structural draft
for the_things_DB.

---

end.