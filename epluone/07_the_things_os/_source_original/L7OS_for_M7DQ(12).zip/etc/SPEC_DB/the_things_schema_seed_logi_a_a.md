# the_things_schema_seed_logi_a_a.md

## meta_summary_ko
정의 : 이 문서는 the_things_DB 가 앞으로 가져야 할 최소 논리 스키마 구조를 seed 형태로 정리한 문서이다.  
이 문서는 현재의 working definition, document class rule, ingest rule, registry, README anchor chain 을 바탕으로  
문서보존, 계보보존, class 구분, 객체연결, 원문보존을 감당하기 위한 최소 구조 씨앗을 제안한다.

---

## name
the_things_schema_seed_logi_a_a

---

## purpose
This document defines a schema seed
for the_things_DB.

Its purpose is to clarify:

- what minimum logical structures the DB should eventually support
- how documents differ from graph/runtime structures
- how class, lineage, and object relation should be preserved
- how original text integrity should be handled
- how current working documents may later map into a DB-oriented schema

This is not a final SQL schema.
It is a seed-level structural proposal.

---

## root_summary
The current observed PostgreSQL structure in `seungeflow`
is centered on:

- node
- relation
- event
- field
- pattern

This graph/runtime structure is useful,
but it is not yet sufficient
for full document-preservation work in the_things_DB.

The_things_DB is expected to preserve:

- raw source materials
- retrieval packs
- spec outputs
- continuity reference documents
- coordination documents
- public anchor lineages

Therefore, a broader schema direction is needed.

This schema seed proposes
a minimum logical structure
that can preserve document identity,
document class,
object relation,
lineage,
original text,
and content body.

---

## core_definition

### original_definition_ko
정의 : the_things_DB 의 스키마는 단순히 테이블 몇 개를 만드는 것이 아니라  
문서의 이름, 역할, class, 객체연결, 계보, 원문보존, 본문내용을 함께 감당할 수 있어야 한다.  
또한 기존의 graph/runtime 구조와 문서보존 구조는 서로 다른 층으로 인지해야 한다.  
즉 schema seed 는 문서층과 구조층을 분리 인식하면서  
나중에 서로 연결될 수 있도록 최소 논리 구조를 제안하는 것이다.

### translated_definition_en
The schema of the_things_DB
must support more than a few isolated tables.

It must be able to preserve together:

- document name
- document role
- document class
- object relation
- lineage
- original-text preservation
- content body

It must also distinguish
between document-preservation structures
and graph/runtime structures.

Thus the schema seed proposes
a minimum logical structure
that recognizes document-layer and structure-layer as distinct,
while still allowing later linkage between them.

---

## schema_principles

### document_layer_and_graph_layer_rule
The DB must distinguish between:

- document layer
- graph/runtime layer

These are related,
but not identical.

Document layer preserves authored or generated materials.
Graph/runtime layer preserves extracted or runtime-oriented structure.

They should not be collapsed into one undifferentiated store.

---

### class_aware_preservation_rule
Documents must be preserved with class awareness.

At minimum, the DB must support class distinction for:
- raw_source_layer
- retrieval_pack_layer
- spec_layer
- graph_runtime_layer
- continuity_reference_layer
- coordination_layer
- public_anchor_layer

---

### lineage_aware_preservation_rule
If a document belongs to a continuity chain,
the DB must preserve that chain.

Examples:
- README public lineage
- working definition lineage
- future revision lineages
- anchor sequences

Lineage must not be lost during ingest.

---

### original_text_integrity_rule
Original Korean text must be preserved exactly.

If translated or interpreted layers exist,
they must not overwrite the original layer.

The DB must be able to preserve:
- original layer
- translation layer
- interpretation layer
as distinguishable layers where needed.

---

### object_relation_rule
Each preserved document must be able to indicate
which major object it most naturally relates to.

Examples:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

---

### no_delete_only_add_rule
Schema direction follows:

no delete, only add

The structure should support preservation of earlier states,
new revisions,
new lineage members,
and added interpretation layers
without destructive replacement.

---

## minimum_logical_entities

### 1. documents
Purpose:
The main preservation entity for prose-centered or file-centered documents.

Expected responsibility:
- preserve document identity
- preserve class
- preserve object relation
- preserve status
- preserve content body
- preserve source origin

Possible logical fields:
- document_id
- document_name
- document_title_or_label
- document_class
- related_object
- primary_role
- source_origin
- current_status
- content_body
- created_at
- updated_at
- notes

This is the core document preservation entity.

---

### 2. document_lineage
Purpose:
Preserve continuity chains between documents.

Expected responsibility:
- group related documents into a lineage
- preserve order or position
- support anchor chains, revision chains, and definition sequences

Possible logical fields:
- lineage_id
- lineage_group
- document_id
- lineage_position
- previous_document_id
- next_document_id
- lineage_note

Examples:
- readme_public_lineage
- the_things_working_definition_lineage

---

### 3. document_layers
Purpose:
Preserve distinct text layers when needed.

Expected responsibility:
- preserve original text
- preserve translation
- preserve interpretation
- preserve summary or derived layers without overwriting origin

Possible logical fields:
- layer_id
- document_id
- layer_type
- language_code
- layer_content
- preservation_required
- created_at

Possible layer_type values:
- original
- translation
- interpretation
- summary

This entity protects original text integrity.

---

### 4. document_object_links
Purpose:
Preserve explicit relation between documents and major objects.

Expected responsibility:
- connect documents to DB / Builder / CORE / System
- allow cross-object references
- avoid implicit assumptions

Possible logical fields:
- link_id
- document_id
- object_name
- relation_note

Examples of object_name:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System
- cross-object reference

---

### 5. document_registry_view_or_table
Purpose:
Preserve or derive registry-style overview information.

Expected responsibility:
- support name / role / class / object / status overview
- help operational indexing
- help present-stage review

Possible logical fields:
- registry_id
- document_id
- registry_role
- registry_class
- registry_status
- registry_note

This may later be implemented as a table or a derived view.

---

### 6. ingest_records
Purpose:
Preserve ingest history and intake context.

Expected responsibility:
- record when and why a document entered DB
- preserve ingest sequence
- preserve intake notes
- preserve initial queue relation if relevant

Possible logical fields:
- ingest_id
- document_id
- ingest_stage
- ingest_reason
- ingest_source_window
- ingest_note
- ingested_at

This supports structured intake history.

---

## optional_supporting_entities

### 7. document_classes
Purpose:
Support class normalization if needed later.

Possible fields:
- class_id
- class_name
- class_description

This may be optional at first
if class is stored directly in documents.

---

### 8. major_objects
Purpose:
Support object normalization if needed later.

Possible fields:
- object_id
- object_name
- object_description

Possible values:
- the_things_DB
- the_things_Builder
- the_things_CORE
- the_things_System

This may be optional at first
if object relation is stored directly in documents.

---

### 9. document_tags_or_keywords
Purpose:
Preserve AI-derived retrieval coordinates.

Important note:
These are not author tags.
They belong to derived structural interpretation.

Possible fields:
- keyword_id
- document_id
- keyword_text
- keyword_source
- created_at

This should remain separate from original author text.

---

## relation_to_existing_graph_runtime_schema

### existing_observed_tables
Current observed `seungeflow` schema includes:

- node
- relation
- event
- field
- pattern
- field_node
- pattern_relation
- field_log

These form a graph/runtime layer.

---

### interpretation
This layer should not be discarded.

Instead, it should be treated as:

- structure-extracted layer
- runtime graph layer
- event-relation interpretation layer

This means the future DB may have:

- document preservation side
- graph/runtime side

These may later connect,
but should not be confused.

---

### possible future bridge
In the future,
a bridge may exist between documents and graph structures.

Examples:
- a document may generate nodes
- a document may generate events
- a document may be linked to patterns
- an anchor may correspond to graph relations

Possible bridge entity:
- document_graph_links

Possible logical fields:
- bridge_id
- document_id
- graph_entity_type
- graph_entity_id
- relation_note

This is not required immediately,
but may later become important.

---

## minimum_schema_zones

### zone_1_document_preservation
Focus:
- document identity
- document class
- object relation
- content body
- source origin
- status

Core logical entity:
- documents

---

### zone_2_lineage_and_layer_preservation
Focus:
- lineage continuity
- version order
- anchor chains
- original/translation/interpretation separation

Core logical entities:
- document_lineage
- document_layers

---

### zone_3_operational_intake_and_registry
Focus:
- ingest history
- present-stage registry view
- intake notes
- queue relation

Core logical entities:
- ingest_records
- document_registry_view_or_table

---

### zone_4_graph_runtime_structure
Focus:
- node
- relation
- event
- field
- pattern

Core logical entities:
- existing graph/runtime schema
- optional future bridges

---

## first_schema_seed_recommendation

### recommended_initial_focus
If implementation begins gradually,
the first document-side schema seed should prioritize:

1. documents
2. document_lineage
3. document_layers
4. ingest_records

Reason:
These four are enough to begin preserving:
- document identity
- lineage
- original text layers
- ingest history

This is sufficient for early structured intake
before more normalization is added.

---

### recommended_second_focus
Later expansion may add:

5. document_object_links
6. document_registry_view_or_table
7. document_tags_or_keywords
8. document_graph_links

Reason:
These are important,
but not necessary before initial document preservation begins.

---

## example_interpretations

### example_1: readme_anchor_logi_a_d
Possible interpretation:
- goes into `documents`
- belongs to lineage group `readme_public_lineage`
- position `d`
- original Korean preserved in `document_layers`
- related to Builder-threshold meaning and DB public reference

---

### example_2: the_things_builder_working_definition_logi_a_a
Possible interpretation:
- goes into `documents`
- class = continuity_reference_layer
- related object = the_things_Builder
- original Korean definition preserved as original layer
- English explanatory body may exist in content body or translation layer

---

### example_3: fwos baseline (unified)
Possible interpretation:
- goes into `documents`
- class = continuity_reference_layer
- lineage group = fwos_baseline_reference
- role = reference baseline
- original text and English explanation layers preserved appropriately

---

## relation_to_ingest_rule
The ingest rule explains
how a document should conceptually enter DB.

The schema seed explains
what kind of logical structure must exist
to receive that document properly.

Thus:
- ingest rule = intake logic
- schema seed = receiving structure seed

Both are necessary.

---

## relation_to_registry
The registry shows
which major documents currently exist
and how they are interpreted.

The schema seed suggests
how those documents may later be represented
inside the DB in a structured way.

Thus:
- registry = current document map
- schema seed = future structural container map

---

## present_continuity_rule
This schema seed begins from the present actionable state.

It does not attempt to design the final total database immediately.

Instead, it identifies
the minimum logical structures
needed to move forward now
without losing continuity later.

---

## current_limit_interpretation
At the current stage,
the existing PostgreSQL schema is closer to
a graph/runtime engine
than a full document-preservation system.

This schema seed therefore does not reject the current DB.

Instead, it explains what additional document-preservation zones
must be introduced
so that the_things_DB can support
both preserved documents and structure extraction.

---

## future_extension_direction
Later schema evolution may include:

- revision-parent tracking
- template_type support
- visibility_scope
- preservation_priority
- source_window tracking
- retrieval bundle grouping
- spec-to-code linkage
- Builder-return lineage
- CORE-reference validation flags
- System-coordination markers

These belong to later extension phases.

---

## status
Working schema seed.
Not final SQL schema.
Not final migration script.
This document serves as the current logical schema seed
for the_things_DB.

---

end.