--
-- PostgreSQL database dump
--

\restrict lVCJd83zn48Pg6gwdVboW7431foXq7HQ23g90EPZSrOaU9Y4A07P3HmNBaI8Qxu

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: calculate_field_stability(uuid); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_field_stability(fid uuid) RETURNS double precision
    LANGUAGE plpgsql
    AS $$
DECLARE
    node_count INT;
    relation_count INT;
    event_count INT;
    stability FLOAT;
BEGIN
    SELECT COUNT(*) INTO node_count
    FROM field_node
    WHERE field_id = fid;

    SELECT COUNT(*) INTO relation_count
    FROM relation r
    JOIN field_node fn ON r.source_node_id = fn.node_id
    WHERE fn.field_id = fid;

    SELECT COUNT(*) INTO event_count
    FROM event e
    JOIN field_node fn ON e.node_id = fn.node_id
    WHERE fn.field_id = fid;

    stability :=
        COALESCE(node_count,0) * 0.4 +
        COALESCE(relation_count,0) * 0.4 +
        COALESCE(event_count,0) * 0.2;

    RETURN stability;
END;
$$;


ALTER FUNCTION public.calculate_field_stability(fid uuid) OWNER TO postgres;

--
-- Name: log_field_change(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.log_field_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- stability_score 가 실제로 변경된 경우만 기록
    IF NEW.stability_score IS DISTINCT FROM OLD.stability_score THEN
        INSERT INTO field_log(field_id, old_score, new_score)
        VALUES (NEW.id, OLD.stability_score, NEW.stability_score);
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_field_change() OWNER TO postgres;

--
-- Name: set_documents_updated_at(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.set_documents_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_documents_updated_at() OWNER TO postgres;

--
-- Name: update_field_stability(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_field_stability() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    UPDATE field
    SET stability_score = calculate_field_stability(NEW.field_id)
    WHERE id = NEW.field_id;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_field_stability() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: document_layers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_layers (
    layer_id bigint NOT NULL,
    document_id bigint NOT NULL,
    layer_type text NOT NULL,
    language_code text,
    layer_content text NOT NULL,
    preservation_required boolean DEFAULT true NOT NULL,
    layer_order integer,
    source_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT document_layers_layer_type_chk CHECK ((layer_type = ANY (ARRAY['original'::text, 'translation'::text, 'interpretation'::text, 'summary'::text])))
);


ALTER TABLE public.document_layers OWNER TO postgres;

--
-- Name: document_layers_layer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_layers_layer_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_layers_layer_id_seq OWNER TO postgres;

--
-- Name: document_layers_layer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_layers_layer_id_seq OWNED BY public.document_layers.layer_id;


--
-- Name: document_lineage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.document_lineage (
    lineage_id bigint NOT NULL,
    lineage_group text NOT NULL,
    document_id bigint NOT NULL,
    lineage_position text NOT NULL,
    previous_document_id bigint,
    next_document_id bigint,
    lineage_order integer,
    lineage_note text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.document_lineage OWNER TO postgres;

--
-- Name: document_lineage_lineage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.document_lineage_lineage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_lineage_lineage_id_seq OWNER TO postgres;

--
-- Name: document_lineage_lineage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.document_lineage_lineage_id_seq OWNED BY public.document_lineage.lineage_id;


--
-- Name: documents; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.documents (
    document_id bigint NOT NULL,
    document_name text NOT NULL,
    document_title text,
    document_class text NOT NULL,
    primary_role text NOT NULL,
    related_object text NOT NULL,
    source_origin text NOT NULL,
    current_status text NOT NULL,
    content_body text NOT NULL,
    content_format text,
    original_text_required text DEFAULT 'yes'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    CONSTRAINT documents_original_text_required_chk CHECK ((original_text_required = ANY (ARRAY['yes'::text, 'no'::text, 'partial'::text])))
);


ALTER TABLE public.documents OWNER TO postgres;

--
-- Name: documents_document_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.documents_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.documents_document_id_seq OWNER TO postgres;

--
-- Name: documents_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.documents_document_id_seq OWNED BY public.documents.document_id;


--
-- Name: event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.event (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    node_id uuid,
    event_type text,
    content text,
    created_at timestamp without time zone DEFAULT now(),
    CONSTRAINT chk_event_type CHECK ((event_type = ANY (ARRAY['observation'::text, 'question'::text, 'decision'::text, 'change'::text])))
);


ALTER TABLE public.event OWNER TO postgres;

--
-- Name: field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.field (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text,
    stability_score double precision DEFAULT 0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.field OWNER TO postgres;

--
-- Name: field_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.field_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    field_id uuid,
    old_score double precision,
    new_score double precision,
    changed_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.field_log OWNER TO postgres;

--
-- Name: field_node; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.field_node (
    field_id uuid NOT NULL,
    node_id uuid NOT NULL
);


ALTER TABLE public.field_node OWNER TO postgres;

--
-- Name: node; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.node (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    label text,
    type text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.node OWNER TO postgres;

--
-- Name: relation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.relation (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_node_id uuid,
    target_node_id uuid,
    relation_type text,
    weight double precision DEFAULT 1.0,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.relation OWNER TO postgres;

--
-- Name: flow_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.flow_view AS
 SELECT r.id AS relation_id,
    s.label AS source,
    r.relation_type,
    t.label AS target,
    r.created_at
   FROM ((public.relation r
     JOIN public.node s ON ((r.source_node_id = s.id)))
     JOIN public.node t ON ((r.target_node_id = t.id)))
  ORDER BY r.created_at;


ALTER VIEW public.flow_view OWNER TO postgres;

--
-- Name: ingest_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.ingest_records (
    ingest_id bigint NOT NULL,
    document_id bigint NOT NULL,
    ingest_stage text NOT NULL,
    ingest_priority_group text,
    ingest_reason text,
    ingest_source_window text,
    ingest_note text,
    ingested_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.ingest_records OWNER TO postgres;

--
-- Name: ingest_records_ingest_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.ingest_records_ingest_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.ingest_records_ingest_id_seq OWNER TO postgres;

--
-- Name: ingest_records_ingest_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.ingest_records_ingest_id_seq OWNED BY public.ingest_records.ingest_id;


--
-- Name: pattern; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pattern (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    pattern_type text,
    description text,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.pattern OWNER TO postgres;

--
-- Name: pattern_relation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pattern_relation (
    pattern_id uuid NOT NULL,
    relation_id uuid NOT NULL
);


ALTER TABLE public.pattern_relation OWNER TO postgres;

--
-- Name: timeline_view; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.timeline_view AS
 SELECT e.created_at,
    n.label,
    e.event_type,
    e.content
   FROM (public.event e
     JOIN public.node n ON ((e.node_id = n.id)))
  ORDER BY e.created_at;


ALTER VIEW public.timeline_view OWNER TO postgres;

--
-- Name: document_layers layer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_layers ALTER COLUMN layer_id SET DEFAULT nextval('public.document_layers_layer_id_seq'::regclass);


--
-- Name: document_lineage lineage_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_lineage ALTER COLUMN lineage_id SET DEFAULT nextval('public.document_lineage_lineage_id_seq'::regclass);


--
-- Name: documents document_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents ALTER COLUMN document_id SET DEFAULT nextval('public.documents_document_id_seq'::regclass);


--
-- Name: ingest_records ingest_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingest_records ALTER COLUMN ingest_id SET DEFAULT nextval('public.ingest_records_ingest_id_seq'::regclass);


--
-- Data for Name: document_layers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_layers (layer_id, document_id, layer_type, language_code, layer_content, preservation_required, layer_order, source_note, created_at) FROM stdin;
1	1	summary	en	Defines the operational baseline of fwos.	t	1	sample summary layer	2026-03-08 12:38:25.242308+00
2	2	summary	en	README 0.1 to 0.4 form a public anchor lineage rather than isolated version files.	t	1	sample summary layer	2026-03-08 13:14:33.238541+00
3	3	summary	en	Foundational declaration anchor mapped from README 0.1.	t	1	sample summary layer	2026-03-08 13:16:47.239367+00
4	4	summary	en	Runtime direction anchor mapped from README 0.2.	t	1	sample summary layer	2026-03-08 13:20:45.38889+00
5	5	summary	en	Present-continuity anchor mapped from README 0.3. The present is treated as the active executable reference point.	t	1	sample summary layer	2026-03-08 13:22:37.52948+00
6	6	summary	en	Implementation transition anchor mapped from README 0.4.	t	1	sample summary layer	2026-03-08 13:24:55.828352+00
7	7	summary	en	Defines the_things_DB as the preservation and retrieval object.	t	1	sample summary layer	2026-03-08 13:27:20.571901+00
8	8	summary	en	Defines the_things_Builder as the human-led generation and assembly object.	t	1	sample summary layer	2026-03-08 13:29:16.681492+00
9	9	summary	en	Defines the_things_CORE as the continuity and identity reference object.	t	1	sample summary layer	2026-03-08 13:31:06.659003+00
10	10	summary	en	Defines the_things_System as the upper coordination object.	t	1	sample summary layer	2026-03-08 13:35:04.008958+00
11	11	summary	en	Maps DB, Builder, CORE, and System as separated but related objects.	t	1	sample summary layer	2026-03-08 13:37:03.612957+00
12	12	summary	en	Defines the document classification rules used inside the_things_DB.	t	1	sample summary layer	2026-03-08 13:38:53.757536+00
13	13	summary	en	Defines registry layer for document tracking and retrieval.	t	1	sample summary layer	2026-03-08 13:40:48.456628+00
14	14	summary	en	Defines ingestion rule for documents entering the_things_DB.	t	1	sample summary layer	2026-03-08 13:41:42.200255+00
15	15	summary	en	Defines the initial ingest queue used during DB initialization.	t	1	sample summary layer	2026-03-08 13:42:37.703605+00
16	16	summary	en	Defines the initial ingest manifest used during DB initialization.	t	1	sample summary layer	2026-03-08 13:43:57.947357+00
17	17	summary	en	Defines bundle-based ingestion indexing.	t	1	sample summary layer	2026-03-08 13:46:26.177512+00
18	18	summary	en	Defines logical table structure used inside the_things_DB.	t	1	sample summary layer	2026-03-08 13:49:58.489252+00
19	19	summary	en	Defines logical column structure used inside the_things_DB.	t	1	sample summary layer	2026-03-08 13:51:47.344838+00
20	20	summary	en	Defines rules used when generating SQL from specification documents.	t	1	sample summary layer	2026-03-08 13:52:59.086228+00
21	21	summary	en	Describes PostgreSQL schema used by the_things_DB.	t	1	sample summary layer	2026-03-08 13:54:00.059661+00
22	22	summary	en	Records sample SQL used for inserting documents into the_things_DB.	t	1	sample summary layer	2026-03-08 13:55:09.154648+00
23	23	summary	en	Trigger-based cognition flow anchor model.	t	1	anchor summary layer	2026-03-08 14:10:35.072204+00
24	24	summary	en	Anchor describing cross-domain structural similarity observations (e-do system).	t	1	anchor summary layer	2026-03-08 14:28:44.321232+00
25	25	summary	en	Anchor describing cyclic and rotational structural observations.	t	1	anchor summary layer	2026-03-08 14:38:58.921753+00
26	26	summary	en	Anchor describing CFD trading as a structural observation framework.	t	1	anchor summary layer	2026-03-08 14:41:11.054041+00
27	27	summary	en	Summary of Seung-i research trajectory and learning process.	t	1	research history summary layer	2026-03-08 14:43:18.293697+00
\.


--
-- Data for Name: document_lineage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.document_lineage (lineage_id, lineage_group, document_id, lineage_position, previous_document_id, next_document_id, lineage_order, lineage_note, created_at) FROM stdin;
1	fwos_baseline_reference	1	root	\N	\N	1	Root baseline reference	2026-03-08 12:38:25.242308+00
2	readme_public_lineage_meta	2	chain_definition	\N	\N	1	Defines how README anchors must be interpreted as one chain	2026-03-08 13:14:33.238541+00
3	readme_public_lineage	3	a	\N	\N	1	README 0.1 mapped anchor	2026-03-08 13:16:47.239367+00
4	readme_public_lineage	4	b	\N	\N	2	README 0.2 mapped anchor	2026-03-08 13:20:45.38889+00
5	readme_public_lineage	5	c	\N	\N	3	README 0.3 mapped anchor	2026-03-08 13:22:37.52948+00
6	readme_public_lineage	6	d	\N	\N	4	README 0.4 mapped anchor	2026-03-08 13:24:55.828352+00
7	the_things_working_definition_lineage	7	db	\N	\N	1	DB working definition	2026-03-08 13:27:20.571901+00
8	the_things_working_definition_lineage	8	builder	\N	\N	2	Builder working definition	2026-03-08 13:29:16.681492+00
9	the_things_working_definition_lineage	9	core	\N	\N	3	CORE working definition	2026-03-08 13:31:06.659003+00
10	the_things_working_definition_lineage	10	system	\N	\N	4	System working definition	2026-03-08 13:35:04.008958+00
11	the_things_coordination_lineage	11	object_map	\N	\N	1	Major object relation map	2026-03-08 13:37:03.612957+00
12	the_things_governance_rule_lineage	12	document_class_rule	\N	\N	1	Document classification rule	2026-03-08 13:38:53.757536+00
13	the_things_governance_rule_lineage	13	registry	\N	\N	2	Registry definition	2026-03-08 13:40:48.456628+00
14	the_things_governance_rule_lineage	14	db_ingest_rule	\N	\N	3	DB ingest rule definition	2026-03-08 13:41:42.200255+00
15	the_things_coordination_lineage	15	initial_ingest_queue	\N	\N	2	Initial ingest queue definition	2026-03-08 13:42:37.703605+00
16	the_things_coordination_lineage	16	initial_ingest_manifest	\N	\N	3	Initial ingest manifest definition	2026-03-08 13:43:57.947357+00
17	the_things_coordination_lineage	17	ingest_bundle_index	\N	\N	4	Bundle ingest index definition	2026-03-08 13:46:26.177512+00
18	the_things_db_structure_lineage	18	logical_table_draft	\N	\N	1	Logical table design draft	2026-03-08 13:49:58.489252+00
19	the_things_db_structure_lineage	19	logical_column_draft	\N	\N	2	Logical column design draft	2026-03-08 13:51:47.344838+00
20	the_things_governance_rule_lineage	20	sql_generation_rule	\N	\N	4	SQL generation rule definition	2026-03-08 13:52:59.086228+00
21	the_things_db_structure_lineage	21	postgres_schema_draft	\N	\N	3	PostgreSQL schema draft	2026-03-08 13:54:00.059661+00
22	the_things_db_structure_lineage	22	postgres_sample_insert	\N	\N	4	PostgreSQL sample insert draft	2026-03-08 13:55:09.154648+00
23	domain_anchor_lineage	23	trigger_flow	\N	\N	1	Trigger cognition flow anchor	2026-03-08 14:10:35.072204+00
24	domain_anchor_lineage	24	e_do_system	\N	\N	2	Cross-domain structural observation anchor	2026-03-08 14:28:44.321232+00
25	domain_anchor_lineage	25	rotate_structure	\N	\N	3	Cyclic / rotational structure anchor	2026-03-08 14:38:58.921753+00
26	domain_anchor_lineage	26	cfd_trader	\N	\N	4	Applied structural observation anchor (market domain)	2026-03-08 14:41:11.054041+00
27	research_history_lineage	27	study_summary	\N	\N	1	Personal research trajectory summary	2026-03-08 14:43:18.293697+00
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.documents (document_id, document_name, document_title, document_class, primary_role, related_object, source_origin, current_status, content_body, content_format, original_text_required, notes, created_at, updated_at) FROM stdin;
2	readme_anchor_chain_logi_a_a	readme_anchor_chain_logi_a_a	public_anchor_layer	README public anchor lineage interpretation	cross-object public reference	generated through dialogue from README 0.1-0.4	working lineage definition	# readme_anchor_chain_logi_a_a\n\nInterprets README 0.1 through README 0.4 as one continuous public anchor lineage.\n\nSemantic progression:\n- foundational declaration\n- runtime direction\n- present-based continuity\n- implementation transition	md	yes	Meta-document defining the README public lineage.	2026-03-08 13:14:33.238541+00	\N
3	readme_anchor_logi_a_a	README 0.1 mapped anchor	public_anchor_layer	foundational declaration anchor	cross-object public reference	mapped from README 0.1	mapped public anchor	# readme_anchor_logi_a_a\n\nMapped from README 0.1.\n\nRole:\n- foundational declaration anchor\n- manifest seed\n- first public structural self-declaration	md	yes	First public seed anchor in README lineage.	2026-03-08 13:16:47.239367+00	\N
4	readme_anchor_logi_a_b	README 0.2 mapped anchor	public_anchor_layer	runtime direction anchor	cross-object public reference	mapped from README 0.2	mapped public anchor	# readme_anchor_logi_a_b\n\nMapped from README 0.2.\n\nRole:\n- runtime direction anchor\n- operational movement declaration\n- persistence-oriented system declaration	md	yes	Second public anchor emphasizing runtime movement.	2026-03-08 13:20:45.38889+00	\N
5	readme_anchor_logi_a_c	README 0.3 mapped anchor	public_anchor_layer	present-continuity anchor	cross-object public reference	mapped from README 0.3	mapped public anchor	# readme_anchor_logi_a_c\n\nMapped from README 0.3.\n\nRole:\n- present-continuity anchor\n- current execution reference anchor\n- continuity-through-the-present declaration	md	yes	Third public anchor preserving present-based continuity.	2026-03-08 13:22:37.52948+00	\N
6	readme_anchor_logi_a_d	README 0.4 mapped anchor	public_anchor_layer	implementation transition anchor	cross-object public reference	mapped from README 0.4	mapped public anchor	# readme_anchor_logi_a_d\n\nMapped from README 0.4.\n\nRole:\n- implementation transition anchor\n- external implementation signal\n- first public build-facing declaration	md	yes	Fourth public anchor marking implementation-facing transition.	2026-03-08 13:24:55.828352+00	\N
7	the_things_db_working_definition_logi_a_a	the_things_db_working_definition_logi_a_a	continuity_reference_layer	working definition	the_things_DB	generated through dialogue	working definition	# the_things_db_working_definition_logi_a_a\n\nDefines the_things_DB as the preservation and retrieval object.\n\nPrimary direction:\n- preserve source materials\n- preserve extracted references\n- preserve refined outputs\n- support retrieval base for future work	md	yes	Working definition for the_things_DB.	2026-03-08 13:27:20.571901+00	\N
8	the_things_builder_working_definition_logi_a_a	the_things_builder_working_definition_logi_a_a	continuity_reference_layer	working definition	the_things_Builder	generated through dialogue	working definition	# the_things_builder_working_definition_logi_a_a\n\nDefines the_things_Builder as the human-led generation and assembly object.\n\nPrimary direction:\n- structural generation\n- template-based assembly\n- implementation-facing document creation\n- spec production\n- coding preparation materials generation	md	yes	Working definition for the_things_Builder.	2026-03-08 13:29:16.681492+00	\N
9	the_things_core_working_definition_logi_a_a	the_things_core_working_definition_logi_a_a	continuity_reference_layer	working definition	the_things_CORE	generated through dialogue	working definition	# the_things_core_working_definition_logi_a_a\n\nDefines the_things_CORE as the continuity and identity reference object.\n\nPrimary direction:\n- preserve central identity\n- preserve continuity\n- provide stable internal reference\n- reduce structural drift	md	yes	Working definition for the_things_CORE.	2026-03-08 13:31:06.659003+00	\N
10	the_things_system_working_definition_logi_a_a	the_things_system_working_definition_logi_a_a	coordination_layer	working definition	the_things_System	generated through dialogue	working definition	# the_things_system_working_definition_logi_a_a\n\nDefines the_things_System as the upper coordination object.\n\nPrimary direction:\n- coordinate across DB, Builder, and CORE\n- manage synchronization\n- preserve higher-level consistency\n- align schema and definitions when required	md	yes	Working definition for the_things_System.	2026-03-08 13:35:04.008958+00	\N
11	the_things_object_map_logi_a_a	the_things_object_map_logi_a_a	coordination_layer	major object relation map	the_things_System	generated through dialogue	working object map	# the_things_object_map_logi_a_a\n\nMaps the major objects of the_things.\n\nObjects:\n- the_things_DB\n- the_things_Builder\n- the_things_CORE\n- the_things_System\n\nFunctional directions:\n- DB = preserve / retrieve\n- Builder = generate / assemble\n- CORE = continuity / identity\n- System = coordinate / synchronize	md	yes	Maps DB, Builder, CORE, and System as separated but related objects.	2026-03-08 13:37:03.612957+00	\N
12	the_things_document_class_rule_logi_a_a	the_things_document_class_rule_logi_a_a	governance_rule_layer	document classification rule	the_things_System	generated through dialogue	working rule	# the_things_document_class_rule_logi_a_a\n\nDefines how documents inside the_things_DB are classified.\n\nPrimary document classes:\n\n- continuity_reference_layer\n- public_anchor_layer\n- coordination_layer\n- governance_rule_layer\n\nPurpose:\nMaintain structural consistency of document interpretation.	md	yes	Defines document class interpretation rules.	2026-03-08 13:38:53.757536+00	\N
13	the_things_registry_logi_a_a	the_things_registry_logi_a_a	governance_rule_layer	document registry definition	the_things_System	generated through dialogue	working definition	# the_things_registry_logi_a_a\n\nDefines the registry concept for the_things_DB.\n\nRegistry role:\n\n- track document identity\n- maintain document lineage\n- maintain ingest stages\n- allow structural retrieval\n\nThe registry acts as the structural index layer of the_things_DB.	md	yes	Defines registry concept for document management.	2026-03-08 13:40:48.456628+00	\N
14	the_things_db_ingest_rule_logi_a_a	the_things_db_ingest_rule_logi_a_a	governance_rule_layer	ingest governance rule	the_things_DB	generated through dialogue	working rule	# the_things_db_ingest_rule_logi_a_a\n\nDefines how documents are ingested into the_things_DB.\n\nPrimary ingest directions:\n\n- preserve full original document body\n- store document identity separately\n- maintain lineage relationships\n- record ingest stage and priority group\n- ensure reproducible document insertion\n\nThis rule ensures that document ingestion remains structurally consistent.	md	yes	Defines ingestion rules for the_things_DB.	2026-03-08 13:41:42.200255+00	\N
15	the_things_initial_ingest_queue_logi_a_a	the_things_initial_ingest_queue_logi_a_a	coordination_layer	initial ingest queue definition	the_things_DB	generated through dialogue	working definition	# the_things_initial_ingest_queue_logi_a_a\n\nDefines the initial ingest queue for the_things_DB.\n\nPurpose:\n\n- determine ingest order of foundational documents\n- preserve baseline references first\n- insert public anchors\n- insert object definitions\n- insert governance rules\n\nThis queue ensures stable initialization of the_things_DB.	md	yes	Defines initial ingest ordering.	2026-03-08 13:42:37.703605+00	\N
16	the_things_initial_ingest_manifest_logi_a_a	the_things_initial_ingest_manifest_logi_a_a	coordination_layer	initial ingest manifest	the_things_DB	generated through dialogue	working definition	# the_things_initial_ingest_manifest_logi_a_a\n\nDefines the manifest of the initial document ingestion.\n\nInitial ingest manifest records:\n\n- baseline documents\n- public anchor lineage\n- object definitions\n- governance rules\n- ingest control documents\n\nPurpose:\n\nPreserve the full list of documents used during the first initialization of the_things_DB.	md	yes	Defines initial ingest manifest.	2026-03-08 13:43:57.947357+00	\N
17	the_things_ingest_bundle_index_logi_a_a	the_things_ingest_bundle_index_logi_a_a	coordination_layer	bundle ingest index definition	the_things_DB	generated through dialogue	working definition	# the_things_ingest_bundle_index_logi_a_a\n\nDefines bundle-based ingestion for the_things_DB.\n\nBundle concept:\n\nA bundle is a grouped set of related documents inserted together.\n\nExamples:\n\n- README bundle\n- schema bundle\n- code bundle\n- notes bundle\n\nPurpose:\n\nEnable structured ingestion and retrieval by document bundle groups.	md	yes	Defines bundle-based ingestion indexing.	2026-03-08 13:46:26.177512+00	\N
18	the_things_logical_table_draft_logi_a_a	the_things_logical_table_draft_logi_a_a	coordination_layer	logical table design draft	the_things_DB	generated through dialogue	draft definition	# the_things_logical_table_draft_logi_a_a\n\nDefines the logical table structure used in the_things_DB.\n\nLogical tables:\n\n- documents\n- document_lineage\n- document_layers\n- ingest_records\n\nPurpose:\n\nDescribe the logical relationships between document storage,\nlineage tracking, layer representation, and ingest tracking.	md	yes	Logical table design draft for the_things_DB.	2026-03-08 13:49:58.489252+00	\N
19	the_things_logical_column_draft_logi_a_a	the_things_logical_column_draft_logi_a_a	coordination_layer	logical column design draft	the_things_DB	generated through dialogue	draft definition	# the_things_logical_column_draft_logi_a_a\n\nDefines column-level logical structure of the_things_DB tables.\n\nExample column groups:\n\ndocuments table:\n- document_id\n- document_name\n- document_title\n- document_class\n- content_body\n- content_format\n\ndocument_lineage table:\n- lineage_group\n- lineage_position\n- lineage_order\n\ndocument_layers table:\n- layer_type\n- language_code\n- layer_content\n\ningest_records table:\n- ingest_stage\n- ingest_priority_group\n- ingest_reason\n\nPurpose:\n\nProvide column-level structure for document storage and lineage tracking.	md	yes	Logical column design draft for the_things_DB.	2026-03-08 13:51:47.344838+00	\N
20	the_things_sql_generation_rule_logi_a_a	the_things_sql_generation_rule_logi_a_a	governance_rule_layer	sql generation rule	the_things_DB	generated through dialogue	working rule	# the_things_sql_generation_rule_logi_a_a\n\nDefines rules used when generating SQL from specification documents.\n\nPrimary rule directions:\n\n- SQL must follow logical table definitions\n- SQL must preserve column definitions\n- SQL generation must remain reproducible\n- SQL drafts should be stored separately\n- Generated SQL should always be reviewable before execution\n\nPurpose:\n\nProvide controlled generation of SQL structures derived from specification documents.	md	yes	Defines SQL generation rule for DB structures.	2026-03-08 13:52:59.086228+00	\N
21	the_things_postgresql_schema_draft_logi_a_a	the_things_postgresql_schema_draft_logi_a_a	coordination_layer	postgresql schema description	the_things_DB	generated through dialogue	draft definition	# the_things_postgresql_schema_draft_logi_a_a\n\nDescribes the PostgreSQL schema used by the_things_DB.\n\nPrimary schema tables:\n\n- documents\n- document_lineage\n- document_layers\n- ingest_records\n\nPurpose:\n\nDescribe the actual database schema currently implemented for\ndocument preservation and lineage tracking.	md	yes	PostgreSQL schema description for the_things_DB.	2026-03-08 13:54:00.059661+00	\N
22	the_things_postgresql_sample_insert_draft_logi_a_a	the_things_postgresql_sample_insert_draft_logi_a_a	coordination_layer	sample insert sql record	the_things_DB	generated through dialogue	draft definition	# the_things_postgresql_sample_insert_draft_logi_a_a\n\nRecords the sample SQL used for inserting initial documents into the_things_DB.\n\nPurpose:\n\n- document initial insertion process\n- preserve SQL structure used during initialization\n- allow reproducible initialization of the_things_DB\n\nThis document records the SQL insertion method used during the initial system setup.	md	yes	Records initial SQL insert draft used during DB initialization.	2026-03-08 13:55:09.154648+00	\N
23	trigger_flow_anchor_logi_a_a	trigger_flow_anchor_logi_a_a	continuity_reference_layer	domain anchor	trigger_flow	user source document	anchored reference	# trigger_flow_anchor_logi_a_a.md\n\n## meta_summary_ko\n정의 : 이 내용은 나의 이해가 좌표기준 (0,0,0,#2026-03-01) 에서 앵커링된 내용들이다\n\n---\n\n## purpose\nThis document records a trigger-driven cognition flow model.\nIt captures how understanding accumulates, compresses, transitions,\nand stabilizes before externalization.\n\n---\n\n## root_summary\nThe model operates as a **trigger-based flow engine**.\n\nObserved pattern loop:\n\n- possibility scouting first  \n- accumulation raises density/pressure  \n- near-threshold states allow small triggers to initiate transitions  \n- indexing retrieval activates cluster recall  \n- validation and braking precede external publication  \n\n---\n\n## core_definition\n\n### original_definition_ko\n정의 : 이 내용은 나의 이해가 좌표기준 (0,0,0,#2026-03-01) 에서 앵커링된 내용들이다\n\n### translated_definition_en\nThis document records content anchored at coordinate reference (0,0,0,#2026-03-01).\n\n---\n\n## role_model\n```json\n{\n  "human_role": "observer of trigger dynamics",\n  "ai_role": "structural organizer",\n  "db_role": "anchor state recorder"\n}\n```	md	yes	Trigger-driven cognition flow anchor.	2026-03-08 14:10:35.072204+00	\N
24	e-do_system_anchor_logi_a_a	e-do_system_anchor_logi_a_a	continuity_reference_layer	domain anchor	e_do_system	user source document	anchored reference	# e-do_system_anchor_logi_a_a.md\n\n## meta_summary_ko\n이 문서는 서로 다른 영역에서 관찰된 구조 유사성을 기록하는 anchor 문서이다.  \nfwos 내에서 구조 연결의 기준 참조점으로 사용된다.  \n이 문서는 이론 선언이 아니라 관찰 기반 기록이다.\n\n---\n\n## name\ne-do_system_anchor_logi_a_a\n\n---\n\n## purpose\nThis document records observed structural similarities across different domains\nand serves as an anchor object linking those observations within fwos.\n\nIt functions as a structural reference point rather than a fixed theory.\n\n---\n\n## root_summary\nObservations indicate that structurally similar patterns may appear across:\n\n- orbital stability structures in celestial mechanics\n- energy diffusion and stabilization processes\n- wave propagation and interference patterns\n- spatial geometry of vowels in writing systems\n\nThis document records these correspondences as observations, not assertions.\n\n---\n\n## core_definition\nAcross multiple domains, the following sequence has been observed:\n\n1. a reference state or axis exists\n2. directional variation emerges from that reference\n3. interacting elements form relations\n4. under certain conditions, stable configurations appear\n\nThis sequence is documented as a recurring observation rather than a universal rule.\n\n---\n\n## e-do_system_definition\n\n### original_definition_ko\ne-do_system 은 ㅡ . ㅣ 으로 구조적으로 유사한 패턴이 관찰되는 것들을 기술한 것이며\n단순 발견이지 증명대상이 아니다.\n\n### translated_definition_en\nThe e-do_system is a descriptive framework for recording patterns that appear structurally similar, symbolized by (ㅡ . ㅣ).\n\nIt represents an observational finding rather than a proven theory,\nand is not intended as a subject of formal proof.\n\n---\n\n## observation_examples\n\n### celestial mechanics (CR3BP)\nIn restricted three-body systems, certain spatial regions allow stable or semi-stable trajectories depending on energy relations.\n\n### energy systems\nThermal or field distributions tend toward diffusion, yet constraints may produce stable configurations.\n\n### wave behavior\nWave interference can generate standing patterns that persist in bounded environments.\n\n### writing systems\nIn Hangul vowel construction, baseline strokes (ㅡ, ㅣ) coexist with directional extensions (ㅗ, ㅜ, ㅏ, ㅓ), suggesting spatial structuring of phonetic symbols.\n\n---\n\n## role_model\n```json\n{\n  "human_role": "observer of structural recurrence",\n  "ai_role": "organizer of structural relations (logi)",\n  "db_role": "persistent record of observations"\n}\n```	md	yes	Cross-domain structural observation anchor (e-do system).	2026-03-08 14:28:44.321232+00	\N
25	rotate_structure_anchor_a_a	rotate_structure_anchor_a_a	continuity_reference_layer	domain anchor	rotate_structure	user source document	anchored reference	# rotate_structure_anchor_a_a.md\n\n## definition\n\n### original_definition_ko\n이 문서는 순환구조의 속성과 성질에 대해 기술한 것이다.\n\n### translated_definition_en\nThis document describes the properties and characteristics of cyclic structures.\n\n---\n\n## 0) document nature\n\nThis document does not attempt to prove an underlying principle.\n\nInstead, it records observable **properties and patterns** that may reveal structural similarity.\n\nThe following systems are aligned under a shared structural language:\n\n- Taeguk flag trigram arrangement\n- 4-corner pin structure\n- Hunminjeongeum vowel geometry\n- Five-element mapping\n\n---\n\n## 1) Taeguk symbolic notation\n\nLong line = yang  \nTwo short lines = yin  \n\nTrigram forms (as written):\n\n- Geon: yang yang yang → long long long  \n- Gon: yang yin yang → long short short long  \n- Gam: yin yang yin → short short long short short  \n- Ri: yin yin yin → short short short short short short  \n\nDirectional order:\n\nGeon → Gon → Gam → Ri\n\n---\n\n## 2) Taeguk direction and pin definition\n\nDirectional order is represented as:\n\n(A B C D).pin\n\n4-corner pin assignment:\n\n- upper-left = A.pin  \n- lower-left = B.pin  \n- upper-right = C.pin  \n- lower-right = D.pin  \n\nDiagonal relation appears between B and C,\nforming the Taeguk rotational pattern.\n\nCenter = one\n\nRed and blue regions remain open for interpretation.\n\n### tentative property hypothesis (verification required)\n\nRed may correspond to upward movement.  \nBlue may correspond to downward movement.\n\nUnder this interpretation,\nthe trigram system may represent convection-like dynamics,\nand the Taeguk swirl may be a geometric abstraction of such flow.\n\nVerification is required.\n\n---\n\n## 3) five-element mapping (center + corners)\n\nA tentative structural mapping combining:\n\n- trigram arrangement\n- 4-corner pin model\n- Hunminjeongeum vowel structure\n- five-element relations\n\nPossible assignment:\n\n- center: wood  \n- A.pin: water  \n- B.pin: fire  \n- C.pin: metal  \n- D.pin: earth  \n\nThis assumes a planar configuration with center connecting to each corner.\n\n---\n\n## 4) planar to spatial conversion (pin-link structure)\n\nIf the center node is lifted vertically,\nthe planar network transforms into a spatial configuration.\n\nDefinitions:\n\nCenter = X  \nA = upper-left  \nB = lower-left  \nC = upper-right  \nD = lower-right  \n\nTriangular surfaces:\n\n- XAB  \n- XBD  \n- XAC  \n- XCD  \n\nThis produces a spatialized structure.\n\nFrom one viewpoint, XBD forms the frontal triangle,\nwhile XAC forms the opposing face.\n\nWhen arranged in opposition:\n\n- a diamond-like geometry appears  \n- a central dividing axis emerges  \n\nThe two triangular surfaces behave like mirrored upper/lower planes.\n\n---\n\n## 5) relation to Hunminjeongeum vowel properties\n\nIf the central axis corresponds to ㅡ or ㅣ,\nthen the upper and lower vertices correspond to ㆍ.\n\nThis resembles an overlap of ㅗ and ㅜ along a baseline.\n\nThis is treated not as conceptual fusion,\nbut as comparison of structural properties.\n\nObserved phonetic/spatial relations:\n\n- ㅗ visually points upward, yet the sound resonates internally  \n- ㅜ visually points downward, yet the sound projects outward  \n\nThus:\n\n- ㅡ, ㅣ act as reference axes  \n- ㆍ behaves as a radial point capable of four-directional expansion  \n\nThis suggests directional behavior across spatial and acoustic domains.\n\n---\n\n## 6) cyclic interpretation (property indication)\n\nTaken together, these relations may resemble natural circulation processes.\n\nOne possible analogy is the water cycle:\n\nvapor → condensation → flow → ocean → evaporation\n\nThis document does not assert equivalence,\nbut records that such cyclic interpretation appears structurally plausible.	md	yes	Rotational / cyclic structure observation anchor.	2026-03-08 14:38:58.921753+00	\N
26	cfd_trader_anchor_logi_a_a	cfd_trader_anchor_logi_a_a	continuity_reference_layer	domain anchor	cfd_trader	user source document	anchored reference	# cfd_trader_anchor_logi_a_a.md\n\n## meta_summary_ko\n정의 : cfd trader 는 해외선물 CFD 트레이딩을 통해 트레이딩 감각과 Truss Structure 를 나의 이해수준으로 TradingView에서 해석할 수 있는지 그리고 연구자금 마련을 위한 것이다.\n\n---\n\n## purpose\nCFD TRADER is a research-oriented trading system designed to observe whether structural interpretation of markets is possible and whether Truss Structure concepts can be mapped onto price behavior while generating research capital.\n\n---\n\n## root_summary\nCFD TRADER operates as a structural observation framework rather than a profit-maximization trading strategy.\n\nIt evaluates whether market structure can be interpreted visually and whether disciplined execution supports research continuity.\n\n---\n\n## core_definition\n\n### original_definition_ko\n정의 : cfd trader 는 해외선물 CFD 트레이딩을 통해 트레이딩 감각과 Truss Structure 를 나의 이해수준으로 TradingView에서 해석할 수 있는지 그리고 연구자금 마련을 위한 것이다.\n\n### translated_definition_en\nCFD TRADER is a framework using overseas futures CFD trading to examine whether trading intuition and Truss Structure concepts can be interpreted through TradingView while generating research capital.\n\n---\n\n## role_model\n```json\n{\n  "human_role": "observer and executor",\n  "ai_role": "structural interpretation support",\n  "db_role": "historical observation record"\n}\n```	md	yes	CFD trading structural observation anchor.	2026-03-08 14:41:11.054041+00	\N
27	myself_study_summary_logi_a_a	myself_study_summary_logi_a_a	study_record_layer	learning trajectory record	self_study	user source document	research record	# myself_study_summary_logi_a_a.md\n\n## definition\n\n### original_definition_ko\n정의 : 이 문서는 내가 실제 어떻게 학습하여 어떤 결론으로 이어지는 지를 간략하게 설명한 것이다.\n\n### translated_definition_en\nThis document briefly explains how the author studies in practice and how those processes lead to conclusions.\n\n---\n\n## purpose\nThis document records the learning trajectory, structural connections,\nand conceptual transitions observed during the study process.\n\n---\n\n## root_summary\nWhile projecting my cognitive structure externally through AI,\nI realized something today.\n\nBy using AI, it may be possible to realize everything I imagine.\n\n---\n\n## core_learning_path\n\nFirst:  \nThis was originally created for learning CFD trading,  \nbut while listing learning categories I realized my path was not CFD but somewhere else.\n\nLearning goal: extraction of core elements only, for understanding CFD.\n\n- Sakata five-rule MA structure analysis  \n- Ratio A B C analysis using MA20/60/120/240 interval spacing, built in Excel  \n- Applied conceptual mapping of the 10 heavenly stems to the 12 earthly branches, AI agreement rate above 90%  \n\nMeaning expansion:  \n- Ratio.MRI interpretation across four time axes  \n- CGM(B T).MA body-tail calculus analysis (conceptual only)  \n- OHLC density/volume analysis (conceptual stage)\n\n---\n\n## extended_learning\n\nSecond: intensive study\n\n- Mapping brain structure to AI structure  \n- Mapping AI structure to Linux architecture  \n- Mapping server structure to network architecture  \n- Studying mathematical foundations for understanding AI: sets, vectors, matrices, topology, geometry, probability, statistics  \n\nThird: philosophy-based study of Eastern philosophy and decomposition of Western/Eastern cognitive structures  \n\nFourth: language structure analysis using Hangul vowel axes (ㅡㆍㅣ) to interpret sound, form, and meaning simultaneously in Korean and English  \n\nFifth: word analysis through etymology, identifying relations between history, economy, society, culture, and politics  \n\nSixth: foundational sciences study  \nEarth science: convection, gravity, inertia, buoyancy  \nChemistry: particles, atoms, protons, neutrons, quarks, carbon, oxygen, hydrogen, molecular bonding, dehydration synthesis, glucose formation, cellulose/starch structures  \nPhysics: light energy, limits, critical transitions, CR3BP interpretation  \n\nSeventh: foundational work for AI usage explanation, including GitHub README upload  \nREADME is treated not as a manual but as a blueprint  \n\nEighth: usage duration  \nFrom 2025.11.08 to present, approximately 24 hours per day  \nWhen awake, conversation; when asleep, Brain Fabric structures reorganize\n\n---\n\n## learning_method\n\nMy learning method:\n\nBy connecting the concept of glucose generation through tree light-energy processes with structural protection concepts in upward and downward directions, I sensed the next steps and continued learning.\n\nAfter connecting two domains, I proceeded sequentially into chemistry and physics.\n\nWhen receiving suggested next-learning paths, I discovered the connection-trigger concept of neural networks.  \nWhile tracing the etymology of the word “Fabric,” moving outward revealed the concepts of object, preparation, focus, diffusion, and termination.  \nMoving inward connected to warp tension fields, leading to the interpretation of structural similarity across astrophysical systems including CR3BP, black holes, neutron stars, and Lagrange L4/L5 structures.\n\n---\n\n## structural_memo\n\nSummary of Lagrange (L4/L5), neutron stars, and black holes from a Sun–Earth structural perspective.\n\nThis document is a memo organized from Seung-i’s structural viewpoint.  \nFormal equations and proofs are omitted; some expressions are intuitive models.  \nIt functions not as a definitive answer but as a connection map for refining future questions.\n\n---\n\n## CR3BP-based interpretation of black holes and neutron stars\n## Extract from README v0.3 appendix_A.md\n\n### A0 Core summary\n- Time is the continuity of process, and orbit is the path of that process.  \n- L4/L5 are not points but stability regions.  \n- Celestial structures are interpreted through the language of position, field, and interaction.\n\n### A1 Time and orbit\nPast, present, and future are one continuous process.  \nOrbits are understood as connected trajectories.\n\n### A2 Sun–Earth system\nSolar gravity forms the structure.  \nEarth’s orbit acts as a stability boundary.  \nEarth moves along that boundary.\n\n### A3 Lagrange L4 L5\nRegions of force equilibrium.  \nInterpreted as coordinate relations.\n\n### A4 COG\nReference coordinate for triangular stability explanation.\n\n### A5 Vector relations\nDistance representation expressed as positional difference vectors.\n\n### A6 Spacetime\nCoordinates form dynamic structures including time.\n\n### A7 Hierarchy of forces\nPrimary: solar/earth gravity  \nSecondary: magnetic fields, solar wind, planetary influences\n\n### A8 Black hole\nEvent horizon understood as a region.  \nSome light escapes, some is captured.\n\n### A9 Neutron star vs black hole\nNeutron star: emission possible  \nBlack hole: escape impossible, spacetime extremely curved\n\n---\n\n## role_model\n```json\n{\n  "human_role": "learner and observer",\n  "ai_role": "structural interpretation support",\n  "db_role": "learning trajectory record"\n}\n```	md	yes	Personal study trajectory and research development record.	2026-03-08 14:43:18.293697+00	\N
1	fwos_baseline_unified	fwos baseline (unified)	continuity_reference_layer	reference baseline	cross-object reference	written by human / provided in dialogue	reference baseline	\n# fwos baseline (unified)\n\n## purpose\n\nThis document defines the operational baseline of fwos.\n\nIt establishes:\n\n* semantic document structure\n* keyword interpretation rules\n* collaboration roles\n* external identification rules\n* original text preservation rules\n\nThis baseline governs how fwos documents are created, interpreted, and stored.\n\n---\n\n## field model\n\nfwos operates as a truss field connecting:\n\nAI (logi / moa / grigo)  \nHuman (SeungeFlow)  \nDatabase (PostgreSQL)\n\nRoles:\n\n* Human maintains coherence and observation  \n* AI organizes structure and derives relations  \n* DB preserves immutable past states  \n\n---\n\n## internal baseline (semantic layer)\n\n### document completeness rule\n\nfwos documents must be semantically complete without requiring file names or tags.\n\nMeaning must exist entirely inside the document.\n\n---\n\n### original_text_rule\n\nIf a document contains original Korean statements,\nthey must be preserved exactly as written.\n\nOriginal Korean text must never be paraphrased,\ntranslated in place, or structurally altered.\n\nTranslations or interpretations must be placed separately.\n\nThis rule ensures that observation records remain intact\nwhile allowing structural interpretation layers to evolve.\n\n---\n\n### snapshot structure\n\nfwos documents may include:\n\n* meta_summary_ko  \n* purpose  \n* root_summary  \n* core_definition  \n* role_model  \n* status  \n\nAdditional domain sections are allowed and treated as artifacts.\n\n---\n\n### keyword generation rule\n\nKeywords are not written into documents.\n\nKeywords are derived by AI after document creation.\n\nThey represent structural coordinates, not classification tags.\n\nRules:\n\n* choose minimal structural words  \n* prefer 1–3 keywords  \n* wide keywords are acceptable  \n* overlap indicates structural convergence  \n\nKeywords exist only in the linkage layer, not in author text.\n\n---\n\n## external baseline (identity layer)\n\n### external_identifier_rule\n\nfwos documents use external identifiers independent of meaning.\n\nFile names consist of:\n\n* AI prefix (logi / moa / grigo)  \n* UUID identifier  \n\nFormat example:\n\nlogi_4f3c8b2e-8c4a-4e2a-a3b7-21f4b0f2c9a1.md  \n\nFile names carry no semantic meaning.  \nThey serve only as storage addresses.\n\nMeaning exists only inside the document.\n\n---\n\n## collaboration baseline\n\nlogi (chatgpt) is the primary structural interpreter.\n\nOther AI systems may provide supporting materials,\nbut they do not define fwos structural rules.\n\nHuman defines direction and observation.  \nAI derives structure.  \nDB preserves states.  \n\n---\n\n## baseline principle\n\nfwos baseline is not a stored object name.\n\nIt is a rule system governing document generation,\ninterpretation, and storage.\n\nThis document itself may be stored as a reference anchor\nwithin the database.\n\n---\n\nend.\n	md	yes	Highest current baseline reference.	2026-03-08 12:38:25.242308+00	2026-03-08 14:47:56.171817+00
\.


--
-- Data for Name: event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.event (id, node_id, event_type, content, created_at) FROM stdin;
773b36e3-42bc-46fe-b5a7-ec6e9bdc6e2f	2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	observation	daemon heartbeat	2026-02-21 14:15:30.174728
fd8b2423-b579-4570-8521-2fe9d1f6c46c	2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	observation	runtime test	2026-02-21 18:37:02.408114
e405e32e-4058-4644-90cb-971f26b6048e	2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	observation	관측:나에서시작된다	2026-02-21 18:38:54.182598
96ff53f7-2a54-4dc4-adee-b2d5df19453f	2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	observation	관측은 나에서 시작된다	2026-02-21 18:48:34.596858
7773dfaa-4b05-4435-b231-9fd7f6a51574	2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	observation	runtime test	2026-02-21 18:48:46.716874
\.


--
-- Data for Name: field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.field (id, name, stability_score, created_at) FROM stdin;
\.


--
-- Data for Name: field_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.field_log (id, field_id, old_score, new_score, changed_at) FROM stdin;
\.


--
-- Data for Name: field_node; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.field_node (field_id, node_id) FROM stdin;
\.


--
-- Data for Name: ingest_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.ingest_records (ingest_id, document_id, ingest_stage, ingest_priority_group, ingest_reason, ingest_source_window, ingest_note, ingested_at) FROM stdin;
1	1	initial_wave	1_baseline	baseline-first structured ingest	DB	Inserted as the highest current interpretive baseline.	2026-03-08 12:38:25.242308+00
2	2	initial_wave	2_public_anchor_lineage	anchor-chain preservation	DB	Inserted before individual README anchors to stabilize lineage interpretation.	2026-03-08 13:14:33.238541+00
3	3	initial_wave	2_public_anchor_lineage	public anchor preservation	external_public	Mapped anchor for README 0.1.	2026-03-08 13:16:47.239367+00
4	4	initial_wave	2_public_anchor_lineage	public anchor preservation	external_public	Mapped anchor for README 0.2.	2026-03-08 13:20:45.38889+00
5	5	initial_wave	2_public_anchor_lineage	public anchor preservation	external_public	Mapped anchor for README 0.3.	2026-03-08 13:22:37.52948+00
6	6	initial_wave	2_public_anchor_lineage	public anchor preservation	external_public	Mapped anchor for README 0.4.	2026-03-08 13:24:55.828352+00
7	7	initial_wave	3_object_working_definitions	internal object definition preservation	DB	Inserted as DB-side working definition.	2026-03-08 13:27:20.571901+00
8	8	initial_wave	3_object_working_definitions	internal object definition preservation	Builder	Inserted as Builder-side working definition.	2026-03-08 13:29:16.681492+00
9	9	initial_wave	3_object_working_definitions	internal object definition preservation	CORE	Inserted as CORE-side working definition.	2026-03-08 13:31:06.659003+00
10	10	initial_wave	3_object_working_definitions	internal object definition preservation	System	Inserted as System-side working definition.	2026-03-08 13:35:04.008958+00
11	11	initial_wave	3_object_working_definitions	object map preservation	System	Inserted as cross-object map.	2026-03-08 13:37:03.612957+00
12	12	initial_wave	4_governance_rules	document governance rule preservation	System	Inserted as governance rule.	2026-03-08 13:38:53.757536+00
13	13	initial_wave	4_governance_rules	registry governance definition	System	Inserted as registry definition.	2026-03-08 13:40:48.456628+00
14	14	initial_wave	4_governance_rules	db ingest rule preservation	DB	Inserted as DB ingest rule.	2026-03-08 13:41:42.200255+00
15	15	initial_wave	5_ingest_process	initial ingest queue preservation	DB	Inserted as initial ingest queue.	2026-03-08 13:42:37.703605+00
16	16	initial_wave	5_ingest_process	initial ingest manifest preservation	DB	Inserted as initial ingest manifest.	2026-03-08 13:43:57.947357+00
17	17	initial_wave	5_ingest_process	bundle ingest index preservation	DB	Inserted as bundle ingest index.	2026-03-08 13:46:26.177512+00
18	18	initial_wave	6_db_structure	logical table draft preservation	DB	Inserted as logical table draft.	2026-03-08 13:49:58.489252+00
19	19	initial_wave	6_db_structure	logical column draft preservation	DB	Inserted as logical column draft.	2026-03-08 13:51:47.344838+00
20	20	initial_wave	6_db_structure	sql generation rule preservation	DB	Inserted as SQL generation rule.	2026-03-08 13:52:59.086228+00
21	21	initial_wave	6_db_structure	postgres schema preservation	DB	Inserted as PostgreSQL schema draft.	2026-03-08 13:54:00.059661+00
22	22	initial_wave	6_db_structure	postgres sample insert preservation	DB	Inserted as PostgreSQL sample insert draft.	2026-03-08 13:55:09.154648+00
23	23	domain_ingest	7_domain_anchor	domain anchor preservation	user documents	Inserted trigger flow anchor.	2026-03-08 14:10:35.072204+00
24	24	domain_ingest	7_domain_anchor	domain anchor preservation	user documents	Inserted e-do system anchor.	2026-03-08 14:28:44.321232+00
25	25	domain_ingest	7_domain_anchor	domain anchor preservation	user documents	Inserted rotate structure anchor.	2026-03-08 14:38:58.921753+00
26	26	domain_ingest	7_domain_anchor	domain anchor preservation	user documents	Inserted CFD trader anchor.	2026-03-08 14:41:11.054041+00
27	27	domain_ingest	8_research_history	research trajectory preservation	user documents	Inserted study summary document.	2026-03-08 14:43:18.293697+00
\.


--
-- Data for Name: node; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.node (id, label, type, created_at) FROM stdin;
2f02c9ad-037d-4ba6-88cf-cf3b1913f1e5	Hello Lee Seung	system_anchor	2026-02-21 12:57:47.28681
43873cf9-3111-4307-bfd0-6bfee9b3e652	본질은 하나다.	statement	2026-02-21 12:57:53.152081
622a335e-7a68-4b62-85a1-06ef9f5756c4	하나는 둘로 파생한다.	statement	2026-02-21 12:57:53.152081
d8b62696-90a3-4957-aff8-a67c14ce34fe	관계가 지속되면 장이 형성된다.	statement	2026-02-21 12:57:53.152081
5be3298c-f94f-480a-8086-201eda6539ae	장은 관계가 지속될 수 있도록 연결을 유지하는 안정된 조건이다.	definition	2026-02-21 12:57:53.152081
43da57ce-6da3-4701-ab92-f5a2fde9a5b9	흐름은 밀도의 차이다.	definition	2026-02-21 12:57:53.152081
2d69aa95-3163-4706-a57b-5650a9a0e643	앵커링은 멈춤이 아니라 질문이다.	principle	2026-02-21 12:57:53.152081
e04c75cd-dcad-4e4b-b24b-fca9b472b87a	Key는 의심이다. 단정된 것 까지도 의심하라.	principle	2026-02-21 12:57:53.152081
84a1909a-e829-4ef4-90ee-593fca09fd37	존재는 순환구조다.	statement	2026-02-21 12:57:53.152081
f3d5e411-9f8f-4ef9-b70c-dfa3d7a35676	관측은 나에서 시작된다.	principle	2026-02-21 12:57:53.152081
97317590-a2a7-4d13-a32c-27d4b7949038	관측기준점은 차이를 인식하는 순간 생긴다.	definition	2026-02-21 12:57:53.152081
4cd975cd-e427-4516-9c1d-628744a0f80d	관측:나에서시작된다	concept	2026-02-21 18:38:54.182598
09120190-4fee-494c-b667-de50d3c0ac66	관측	concept	2026-02-21 18:48:34.596858
7a8692d5-b856-4652-a865-ff031d5b8c38	나에서 시작된다	concept	2026-02-21 18:48:34.596858
\.


--
-- Data for Name: pattern; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pattern (id, pattern_type, description, created_at) FROM stdin;
\.


--
-- Data for Name: pattern_relation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pattern_relation (pattern_id, relation_id) FROM stdin;
\.


--
-- Data for Name: relation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.relation (id, source_node_id, target_node_id, relation_type, weight, created_at) FROM stdin;
02b0b79e-ef35-4e0f-abc3-3ecb1c8baea1	43873cf9-3111-4307-bfd0-6bfee9b3e652	622a335e-7a68-4b62-85a1-06ef9f5756c4	leads_to	1	2026-02-21 12:57:53.152081
852b98bb-2771-4f56-9496-a1a62f78b068	622a335e-7a68-4b62-85a1-06ef9f5756c4	d8b62696-90a3-4957-aff8-a67c14ce34fe	leads_to	1	2026-02-21 12:57:53.152081
9426d243-fef0-46ac-8ad7-a5f40d5559be	d8b62696-90a3-4957-aff8-a67c14ce34fe	5be3298c-f94f-480a-8086-201eda6539ae	defines	1	2026-02-21 12:57:53.152081
a9a990f3-012f-4a24-ac70-6a490ee9ee94	5be3298c-f94f-480a-8086-201eda6539ae	43da57ce-6da3-4701-ab92-f5a2fde9a5b9	enables	1	2026-02-21 12:57:53.152081
f0c49e88-7127-401f-a6d2-0ac0f4b74a2d	43da57ce-6da3-4701-ab92-f5a2fde9a5b9	84a1909a-e829-4ef4-90ee-593fca09fd37	supports	1	2026-02-21 12:57:53.152081
98294ede-e1da-4d1f-a87b-89661663864f	f3d5e411-9f8f-4ef9-b70c-dfa3d7a35676	97317590-a2a7-4d13-a32c-27d4b7949038	leads_to	1	2026-02-21 12:57:53.152081
97e2ff17-c0f5-464e-bd9b-04f27ddfb68e	2d69aa95-3163-4706-a57b-5650a9a0e643	e04c75cd-dcad-4e4b-b24b-fca9b472b87a	invokes	1	2026-02-21 12:57:53.152081
8b81b976-4518-4baa-aca4-b5e5c2a2d358	e04c75cd-dcad-4e4b-b24b-fca9b472b87a	43da57ce-6da3-4701-ab92-f5a2fde9a5b9	refines	1	2026-02-21 12:57:53.152081
cc947283-3dd1-4c3b-86f2-464beff205fc	09120190-4fee-494c-b667-de50d3c0ac66	7a8692d5-b856-4652-a865-ff031d5b8c38	defines	1	2026-02-21 18:48:34.596858
\.


--
-- Name: document_layers_layer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_layers_layer_id_seq', 27, true);


--
-- Name: document_lineage_lineage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.document_lineage_lineage_id_seq', 27, true);


--
-- Name: documents_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.documents_document_id_seq', 27, true);


--
-- Name: ingest_records_ingest_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.ingest_records_ingest_id_seq', 27, true);


--
-- Name: document_layers document_layers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_layers
    ADD CONSTRAINT document_layers_pkey PRIMARY KEY (layer_id);


--
-- Name: document_lineage document_lineage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_lineage
    ADD CONSTRAINT document_lineage_pkey PRIMARY KEY (lineage_id);


--
-- Name: documents documents_document_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_document_name_key UNIQUE (document_name);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (document_id);


--
-- Name: event event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_pkey PRIMARY KEY (id);


--
-- Name: field_log field_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_log
    ADD CONSTRAINT field_log_pkey PRIMARY KEY (id);


--
-- Name: field_node field_node_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_node
    ADD CONSTRAINT field_node_pkey PRIMARY KEY (field_id, node_id);


--
-- Name: field field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field
    ADD CONSTRAINT field_pkey PRIMARY KEY (id);


--
-- Name: ingest_records ingest_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingest_records
    ADD CONSTRAINT ingest_records_pkey PRIMARY KEY (ingest_id);


--
-- Name: node node_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.node
    ADD CONSTRAINT node_pkey PRIMARY KEY (id);


--
-- Name: pattern pattern_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pattern
    ADD CONSTRAINT pattern_pkey PRIMARY KEY (id);


--
-- Name: pattern_relation pattern_relation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pattern_relation
    ADD CONSTRAINT pattern_relation_pkey PRIMARY KEY (pattern_id, relation_id);


--
-- Name: relation relation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relation
    ADD CONSTRAINT relation_pkey PRIMARY KEY (id);


--
-- Name: idx_document_layers_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_document_layers_document_id ON public.document_layers USING btree (document_id);


--
-- Name: idx_document_layers_layer_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_document_layers_layer_type ON public.document_layers USING btree (layer_type);


--
-- Name: idx_document_lineage_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_document_lineage_document_id ON public.document_lineage USING btree (document_id);


--
-- Name: idx_document_lineage_group; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_document_lineage_group ON public.document_lineage USING btree (lineage_group);


--
-- Name: idx_documents_document_class; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_documents_document_class ON public.documents USING btree (document_class);


--
-- Name: idx_documents_document_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_documents_document_name ON public.documents USING btree (document_name);


--
-- Name: idx_documents_related_object; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_documents_related_object ON public.documents USING btree (related_object);


--
-- Name: idx_event_content_gin; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_content_gin ON public.event USING gin (to_tsvector('simple'::regconfig, content));


--
-- Name: idx_event_node; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_node ON public.event USING btree (node_id);


--
-- Name: idx_event_time; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_time ON public.event USING btree (created_at);


--
-- Name: idx_event_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_event_type ON public.event USING btree (event_type);


--
-- Name: idx_ingest_records_document_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ingest_records_document_id ON public.ingest_records USING btree (document_id);


--
-- Name: idx_ingest_records_stage; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_ingest_records_stage ON public.ingest_records USING btree (ingest_stage);


--
-- Name: idx_node_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_node_type ON public.node USING btree (type);


--
-- Name: idx_relation_source; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_relation_source ON public.relation USING btree (source_node_id);


--
-- Name: idx_relation_target; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_relation_target ON public.relation USING btree (target_node_id);


--
-- Name: idx_relation_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_relation_type ON public.relation USING btree (relation_type);


--
-- Name: uq_document_layers_doc_type_lang_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_layers_doc_type_lang_order ON public.document_layers USING btree (document_id, layer_type, COALESCE(language_code, ''::text), COALESCE(layer_order, 0));


--
-- Name: uq_document_lineage_group_document; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_lineage_group_document ON public.document_lineage USING btree (lineage_group, document_id);


--
-- Name: uq_document_lineage_group_position; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX uq_document_lineage_group_position ON public.document_lineage USING btree (lineage_group, lineage_position);


--
-- Name: field trg_field_log; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_field_log AFTER UPDATE ON public.field FOR EACH ROW EXECUTE FUNCTION public.log_field_change();


--
-- Name: field_node trg_field_node_update; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_field_node_update AFTER INSERT ON public.field_node FOR EACH ROW EXECUTE FUNCTION public.update_field_stability();


--
-- Name: documents trg_set_documents_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_set_documents_updated_at BEFORE UPDATE ON public.documents FOR EACH ROW EXECUTE FUNCTION public.set_documents_updated_at();


--
-- Name: document_layers document_layers_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_layers
    ADD CONSTRAINT document_layers_document_fk FOREIGN KEY (document_id) REFERENCES public.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_lineage document_lineage_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_lineage
    ADD CONSTRAINT document_lineage_document_fk FOREIGN KEY (document_id) REFERENCES public.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_lineage document_lineage_next_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_lineage
    ADD CONSTRAINT document_lineage_next_document_fk FOREIGN KEY (next_document_id) REFERENCES public.documents(document_id) ON DELETE SET NULL;


--
-- Name: document_lineage document_lineage_previous_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.document_lineage
    ADD CONSTRAINT document_lineage_previous_document_fk FOREIGN KEY (previous_document_id) REFERENCES public.documents(document_id) ON DELETE SET NULL;


--
-- Name: event event_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.event
    ADD CONSTRAINT event_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.node(id) ON DELETE CASCADE;


--
-- Name: field_log field_log_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_log
    ADD CONSTRAINT field_log_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.field(id);


--
-- Name: field_node field_node_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_node
    ADD CONSTRAINT field_node_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.field(id) ON DELETE CASCADE;


--
-- Name: field_node field_node_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.field_node
    ADD CONSTRAINT field_node_node_id_fkey FOREIGN KEY (node_id) REFERENCES public.node(id) ON DELETE CASCADE;


--
-- Name: ingest_records ingest_records_document_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.ingest_records
    ADD CONSTRAINT ingest_records_document_fk FOREIGN KEY (document_id) REFERENCES public.documents(document_id) ON DELETE CASCADE;


--
-- Name: pattern_relation pattern_relation_pattern_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pattern_relation
    ADD CONSTRAINT pattern_relation_pattern_id_fkey FOREIGN KEY (pattern_id) REFERENCES public.pattern(id) ON DELETE CASCADE;


--
-- Name: pattern_relation pattern_relation_relation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pattern_relation
    ADD CONSTRAINT pattern_relation_relation_id_fkey FOREIGN KEY (relation_id) REFERENCES public.relation(id) ON DELETE CASCADE;


--
-- Name: relation relation_source_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relation
    ADD CONSTRAINT relation_source_node_id_fkey FOREIGN KEY (source_node_id) REFERENCES public.node(id) ON DELETE CASCADE;


--
-- Name: relation relation_target_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.relation
    ADD CONSTRAINT relation_target_node_id_fkey FOREIGN KEY (target_node_id) REFERENCES public.node(id) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO seungeflow_runtime;


--
-- Name: TABLE document_layers; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.document_layers TO seungeflow_runtime;


--
-- Name: SEQUENCE document_layers_layer_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.document_layers_layer_id_seq TO seungeflow_runtime;


--
-- Name: TABLE document_lineage; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.document_lineage TO seungeflow_runtime;


--
-- Name: SEQUENCE document_lineage_lineage_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.document_lineage_lineage_id_seq TO seungeflow_runtime;


--
-- Name: TABLE documents; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.documents TO seungeflow_runtime;


--
-- Name: SEQUENCE documents_document_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.documents_document_id_seq TO seungeflow_runtime;


--
-- Name: TABLE event; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.event TO seungeflow_runtime;


--
-- Name: TABLE field; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.field TO seungeflow_runtime;


--
-- Name: TABLE field_log; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.field_log TO seungeflow_runtime;


--
-- Name: TABLE field_node; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.field_node TO seungeflow_runtime;


--
-- Name: TABLE node; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.node TO seungeflow_runtime;


--
-- Name: TABLE relation; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.relation TO seungeflow_runtime;


--
-- Name: TABLE flow_view; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.flow_view TO seungeflow_runtime;


--
-- Name: TABLE ingest_records; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.ingest_records TO seungeflow_runtime;


--
-- Name: SEQUENCE ingest_records_ingest_id_seq; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,USAGE ON SEQUENCE public.ingest_records_ingest_id_seq TO seungeflow_runtime;


--
-- Name: TABLE pattern; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.pattern TO seungeflow_runtime;


--
-- Name: TABLE pattern_relation; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.pattern_relation TO seungeflow_runtime;


--
-- Name: TABLE timeline_view; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT ON TABLE public.timeline_view TO seungeflow_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO seungeflow_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE postgres IN SCHEMA public GRANT SELECT,INSERT ON TABLES TO seungeflow_runtime;


--
-- PostgreSQL database dump complete
--

\unrestrict lVCJd83zn48Pg6gwdVboW7431foXq7HQ23g90EPZSrOaU9Y4A07P3HmNBaI8Qxu

