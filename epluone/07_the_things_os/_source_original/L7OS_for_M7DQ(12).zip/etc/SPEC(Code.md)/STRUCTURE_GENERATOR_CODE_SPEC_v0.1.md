# STRUCTURE_GENERATOR_CODE_SPEC v0.1

Author: Rogi  
Context: SeungeFlow / the_things_SYSTEM / COREMAP  
Status: Initial code-spec before `core_restore_system` 33-zip integration

---

## 0. Intent

This document defines the executable code specification for the **Structure Generator**.

The Structure Generator is the engine that transforms:

- conversation
- notes
- markdown documents
- code fragments
- structured packets

into:

- fragments
- relations
- patterns
- structure candidates
- buildable specifications

It is the bridge between:

```text
human cognition
→ recorded material
→ structural extraction
→ spec generation
→ builder/runtime/framework creation
```

---

## 1. Position in the total system

```text
SeungeFlow / Human Observation
        ↓
COREMAP IO Packet / uploaded files / raw docs
        ↓
Structure Generator
        ↓
A. COREMAP storage objects
B. things_spec / spec.json
C. structure reports / validation logs
        ↓
core_restore_system + builder + runtime
        ↓
Framework OS
```

---

## 2. Core principles

### 2.1 No delete, only add
- No hard delete
- Supersession is expressed as lineage / revision / rebinding
- Every extraction result is append-only

### 2.2 Structure is discovered, not invented
- The generator must not arbitrarily impose meaning
- It extracts repeated relations and stable patterns from given material

### 2.3 Original text preservation
- Original Korean definitions are stored verbatim
- Interpretation layers are stored separately

### 2.4 Relation-first semantics
- Meaning, identity, and knowledge are stabilized through relations and responses
- Raw source is preserved; structural interpretation is layered on top

### 2.5 Deterministic core, extensible heuristics
- Parsing and normalization should be deterministic where possible
- Pattern detection may be heuristic, but every heuristic output must include confidence and evidence

---

## 3. Input domain

### 3.1 Accepted source types

```text
chat transcript
markdown
sql
yaml
json
python
pseudo code
coremap packet
layer7 statements
runtime logs
```

### 3.2 Input modes

#### Mode A. RAW_DOCUMENT
- Entire uploaded document
- Stored as a source object
- Generator extracts segments/fragments from it

#### Mode B. COREMAP_IO_PACKET
- Structured packet input
- Parsed by packet parser first

#### Mode C. L7_STATEMENTS
- Deterministic Layer7 statements
- Parsed to AST then mapped to internal objects

#### Mode D. MIXED_BUNDLE
- Chat + documents + metadata + file manifest
- Typical working mode for SeungeFlow

---

## 4. Output domain

The generator must produce one or more of the following outputs.

### 4.1 Structural storage outputs

```text
fragment records
relation records
pattern records
structure candidates
validation logs
revision lineage
```

### 4.2 Human-readable outputs

```text
structure_summary.md
anchor_document.md
extraction_report.md
mismatch_report.md
```

### 4.3 Machine-readable outputs

```text
things_spec.yaml
spec.json
relation_map.json
pattern_map.json
lineage_map.json
```

### 4.4 Builder-facing outputs

```text
core spec
app spec
db spec
runtime spec
restore spec
framework spec
```

---

## 5. Internal architecture

```text
structure_generator/
├─ ingest/
│  ├─ source_loader.py
│  ├─ packet_loader.py
│  └─ bundle_loader.py
├─ parse/
│  ├─ text_segmenter.py
│  ├─ coremap_io_parser.py
│  ├─ layer7_parser.py
│  └─ code_block_parser.py
├─ normalize/
│  ├─ normalizer.py
│  ├─ alias_resolver.py
│  └─ language_layer_splitter.py
├─ extract/
│  ├─ fragment_extractor.py
│  ├─ relation_extractor.py
│  ├─ pattern_detector.py
│  ├─ structure_extractor.py
│  └─ anchor_classifier.py
├─ validate/
│  ├─ invariant_validator.py
│  ├─ conflict_detector.py
│  └─ confidence_evaluator.py
├─ emit/
│  ├─ coremap_emitter.py
│  ├─ things_spec_emitter.py
│  ├─ spec_json_emitter.py
│  ├─ report_emitter.py
│  └─ lineage_emitter.py
├─ orchestrator/
│  └─ pipeline.py
└─ models/
   ├─ source.py
   ├─ fragment.py
   ├─ relation.py
   ├─ pattern.py
   ├─ structure.py
   ├─ spec.py
   └─ validation.py
```

---

## 6. Canonical pipeline

```text
ingest
→ parse
→ normalize
→ fragment extraction
→ relation extraction
→ pattern detection
→ structure extraction
→ invariant validation
→ spec emission
→ lineage/revision recording
→ report generation
```

### 6.1 Step detail

#### Step 1. ingest
- Read file(s), packet(s), or transcript
- Assign source_id
- Record raw content hash
- Preserve exact original text

#### Step 2. parse
- Split into sections / code blocks / declarations / prose segments
- Detect packet headers, L7 statements, explicit schema blocks, YAML/JSON blocks

#### Step 3. normalize
- Normalize casing/enums/aliases
- Separate original text from interpretation text
- Mark boundaries between human zone and machine zone

#### Step 4. fragment extraction
- Produce minimal meaningful units
- Each fragment gets:
  - fragment_id
  - source_ref
  - content
  - span / line range
  - language
  - kind

#### Step 5. relation extraction
- Detect explicit and inferred relations such as:
  - defines
  - extends
  - depends_on
  - transforms_to
  - feeds
  - validates
  - restores
  - supersedes
  - maps_to

#### Step 6. pattern detection
- Detect repeated structures
- Example patterns:
  - pin → link → flow → pattern → structure → fabric
  - fragment → relation → pattern → structure → system
  - pull → rotation → push
  - conversation → fragment → spec → builder

#### Step 7. structure extraction
- Convert stable pattern clusters into structure candidates
- Candidate types:
  - anchor
  - schema
  - engine
  - runtime
  - builder
  - restore
  - framework

#### Step 8. invariant validation
- Validate against:
  - no delete only add
  - original text preservation
  - relation-first semantics
  - revision/lineage consistency
  - packet / DSL syntax validity

#### Step 9. spec emission
- Emit one or more specs:
  - COREMAP object/relation payload
  - things_spec
  - spec.json
  - restore integration hints

#### Step 10. lineage recording
- Connect extraction result to source lineage
- Create parent→child revision references

#### Step 11. report generation
- Human-readable explanation
- Machine validation logs
- Conflict / ambiguity list

---

## 7. Core data models

### 7.1 SourceRecord

```python
from dataclasses import dataclass
from typing import Optional, Literal

@dataclass
class SourceRecord:
    source_id: str
    source_type: Literal["chat", "markdown", "sql", "yaml", "json", "python", "packet", "bundle"]
    title: Optional[str]
    content: str
    content_hash: str
    created_at: str
    language: Optional[str]
```

### 7.2 FragmentRecord

```python
from dataclasses import dataclass
from typing import Optional, Literal

@dataclass
class FragmentRecord:
    fragment_id: str
    source_id: str
    start_line: Optional[int]
    end_line: Optional[int]
    content: str
    original_text: Optional[str]
    interpretation_text: Optional[str]
    kind: Literal[
        "concept", "definition", "rule", "question", "answer", "schema",
        "code", "pipeline", "pattern", "structure", "runtime", "builder",
        "restore", "framework", "unknown"
    ]
    confidence: float
```

### 7.3 RelationRecord

```python
from dataclasses import dataclass
from typing import Optional

@dataclass
class RelationRecord:
    relation_id: str
    from_fragment_id: str
    to_fragment_id: str
    relation_type: str
    evidence: Optional[str]
    confidence: float
```

### 7.4 PatternRecord

```python
from dataclasses import dataclass
from typing import List

@dataclass
class PatternRecord:
    pattern_id: str
    pattern_code: str
    sequence: List[str]
    member_fragment_ids: List[str]
    invariant_text: str
    confidence: float
```

### 7.5 StructureCandidate

```python
from dataclasses import dataclass
from typing import List, Literal

@dataclass
class StructureCandidate:
    structure_id: str
    structure_type: Literal[
        "anchor", "schema", "engine", "runtime", "builder", "restore", "framework"
    ]
    name: str
    source_fragment_ids: List[str]
    pattern_ids: List[str]
    summary: str
    confidence: float
```

### 7.6 ValidationRecord

```python
from dataclasses import dataclass
from typing import Literal, List

@dataclass
class ValidationRecord:
    validation_id: str
    target_id: str
    result: Literal["PASS", "PARTIAL", "FAIL"]
    action: Literal["LOCK", "CONTINUE", "REBIND", "REDEFINE"]
    invariant_checks: List[str]
    notes: List[str]
```

---

## 8. Fragment extraction rules

A segment becomes a fragment when at least one condition holds:

- defines a term
- declares a rule
- describes a transformation
- describes a relation
- contains executable logic
- contains machine-readable schema
- contains a boundary/invariant statement
- contains a repeated structural sequence

### 8.1 Fragment categories

```text
concept
definition
rule
question
answer
schema
code
pipeline
pattern
structure
runtime
builder
restore
framework
```

### 8.2 Fragment extraction pseudocode

```python
def extract_fragments(segments: list[str]) -> list[FragmentRecord]:
    out = []
    for seg in segments:
        if is_noise(seg):
            continue
        kind = classify_segment(seg)
        out.append(build_fragment(seg, kind))
    return out
```

---

## 9. Relation extraction rules

### 9.1 Explicit relation markers

```text
is
means
defines
extends
depends on
maps to
feeds
restores
generates
outputs
```

### 9.2 Structural relation templates

```text
A → B
A ↔ B
A + B = C
A consists of B,C,D
A begins from B
A produces B
A stores B
A validates B
A restores B
```

### 9.3 Relation extraction pseudocode

```python
def extract_relations(fragments: list[FragmentRecord]) -> list[RelationRecord]:
    relations = []
    for f in fragments:
        targets = detect_targets(f, fragments)
        for t, rel_type, evidence, conf in targets:
            relations.append(RelationRecord(
                relation_id=new_id("REL"),
                from_fragment_id=f.fragment_id,
                to_fragment_id=t.fragment_id,
                relation_type=rel_type,
                evidence=evidence,
                confidence=conf,
            ))
    return relations
```

---

## 10. Pattern detection rules

### 10.1 Canonical patterns to detect first

#### P1. Structural hierarchy

```text
pin → link → flow → pattern → structure → fabric
```

#### P2. Generator hierarchy

```text
fragment → relation → pattern → structure → system
```

#### P3. Runtime loop

```text
observation → fragment → structure → system → new observation
```

#### P4. Dynamics loop

```text
pull → rotation → push
```

#### P5. Implementation bridge

```text
question → structure → implementation
```

### 10.2 Pattern scoring

Suggested score formula:

```text
score = (explicit_mentions * 0.4)
      + (cross-document repetition * 0.3)
      + (relation density * 0.2)
      + (lineage recurrence * 0.1)
```

If score ≥ threshold_pattern:
- emit PatternRecord

---

## 11. Structure extraction rules

A structure candidate is emitted when:

- one or more stable patterns exist
- relation density exceeds threshold
- semantic purpose is clear enough to classify
- evidence spans one or more source fragments

### 11.1 Candidate classifiers

#### anchor
- reference point
- definition node
- context bootstrap node

#### schema
- logical/physical DB or data format definition

#### engine
- executable subsystem definition

#### runtime
- session/step/event loop subsystem

#### builder
- spec → software subsystem

#### restore
- snapshot / restore / core recovery subsystem

#### framework
- integrated top-level system structure

### 11.2 Extraction pseudocode

```python
def extract_structures(patterns, relations, fragments):
    clusters = cluster_by_pattern_and_relation(patterns, relations)
    candidates = []
    for cluster in clusters:
        stype = classify_structure_type(cluster, fragments)
        candidates.append(build_structure_candidate(cluster, stype))
    return candidates
```

---

## 12. Emission formats

### 12.1 COREMAP emission

```json
{
  "project": "the_things_system",
  "fragments": [],
  "relations": [],
  "patterns": [],
  "structures": [],
  "validation": []
}
```

### 12.2 things_spec emission

```yaml
things_spec:
  system:
    name: structure_generator
    version: 0.1
  input:
    accepted:
      - chat
      - markdown
      - sql
      - yaml
      - json
      - python
      - packet
      - bundle
  pipeline:
    - ingest
    - parse
    - normalize
    - extract_fragments
    - extract_relations
    - detect_patterns
    - extract_structures
    - validate
    - emit_specs
  outputs:
    - coremap_payload
    - things_spec
    - spec_json
    - validation_report
```

### 12.3 spec.json emission

```json
{
  "spec_version": "0.1",
  "system_name": "structure_generator",
  "modules": [
    {"name": "ingest", "type": "core"},
    {"name": "parse", "type": "core"},
    {"name": "extract", "type": "core"},
    {"name": "validate", "type": "core"},
    {"name": "emit", "type": "core"}
  ],
  "runtime": {
    "mode": "service",
    "append_only": true
  }
}
```

---

## 13. Invariant validator

### 13.1 Required invariant checks

```text
INV-001 no_delete_only_add
INV-002 original_text_preserved
INV-003 relation_first_semantics
INV-004 revision_lineage_append_only
INV-005 packet_syntax_valid
INV-006 layer7_syntax_valid
INV-007 evidence_attached_to_pattern
INV-008 evidence_attached_to_structure
```

### 13.2 Validator pseudocode

```python
def validate_bundle(bundle) -> list[ValidationRecord]:
    results = []
    checks = run_all_invariants(bundle)
    result, action = aggregate_checks(checks)
    results.append(ValidationRecord(
        validation_id=new_id("VAL"),
        target_id=bundle.target_id,
        result=result,
        action=action,
        invariant_checks=[c.code for c in checks],
        notes=[c.note for c in checks],
    ))
    return results
```

---

## 14. CLI / service interface

### 14.1 CLI

```bash
python -m structure_generator run \
  --mode bundle \
  --input ./input_bundle \
  --out ./out_bundle
```

### 14.2 Service API sketch

```http
POST /structure-generator/run
Content-Type: application/json

{
  "mode": "file_bundle",
  "project": "the_things_system",
  "sources": ["README.md", "notes.md", "packet.txt"]
}
```

Response:

```json
{
  "run_id": "sg-0001",
  "status": "PARTIAL",
  "outputs": {
    "things_spec": "./out/structure_generator.things.yaml",
    "spec_json": "./out/structure_generator.spec.json",
    "report": "./out/extraction_report.md"
  }
}
```

---

## 15. Integration with COREMAP

### 15.1 Storage contract

The Structure Generator should be able to emit directly into COREMAP-compatible storage concepts:

- object
- relation
- relation_response
- boundary_rule
- revision
- validation_log
- artifact

### 15.2 Mapping example

```text
FragmentRecord     → object(object_type='fragment')
RelationRecord     → relation
PatternRecord      → object(object_type='pattern') + relation links
StructureCandidate → object(object_type='structure_candidate')
ValidationRecord   → validation_log
Output files       → artifact
```

### 15.3 Runtime bridge

Conversation packets recorded by SeungsFlow Runtime become source input for the Structure Generator.

```text
runtime_session/runtime_step
→ packet payloads
→ fragment extraction
→ structure extraction
→ spec emission
```

---

## 16. Integration target for core_restore_system

This section is intentionally defined as a placeholder integration contract before the 33 zip packages are ingested.

### 16.1 Expected restore integration zones

```text
snapshot model
restore flow
system protection
rollback / rebind
bootstrap initialization
state reconstruction
runtime recovery
```

### 16.2 Required future adapter

```text
extract restore concepts from zip sources
→ classify restore fragments
→ detect restore patterns
→ emit restore_spec
→ connect restore_spec to framework OS
```

### 16.3 Future output

```yaml
restore_spec:
  snapshot:
    enabled: true
  restore:
    modes:
      - cold_restore
      - warm_restore
      - lineage_restore
  safety:
    no_delete_only_add: true
```

---

## 17. Suggested first implementation order

### Phase A. Minimal
- source loader
- text segmenter
- fragment extractor
- simple relation extractor
- report emitter

### Phase B. COREMAP integration
- packet parser
- Layer7 parser
- validation emitter
- COREMAP payload emitter

### Phase C. Spec generator
- things_spec emitter
- spec.json emitter
- structure candidate classifier

### Phase D. Restore integration
- core_restore_system zip ingestion
- restore pattern extraction
- restore_spec emission

### Phase E. Framework OS integration
- connect builder
- connect runtime
- connect restore
- generate final framework spec

---

## 18. Minimal executable skeleton

```python
class StructureGenerator:
    def __init__(self, config):
        self.config = config

    def run(self, sources):
        loaded = self.ingest(sources)
        parsed = self.parse(loaded)
        normalized = self.normalize(parsed)
        fragments = self.extract_fragments(normalized)
        relations = self.extract_relations(fragments)
        patterns = self.detect_patterns(fragments, relations)
        structures = self.extract_structures(fragments, relations, patterns)
        validations = self.validate(fragments, relations, patterns, structures)
        outputs = self.emit(fragments, relations, patterns, structures, validations)
        return outputs
```

---

## 19. Final statement

The Structure Generator is the source engine that converts accumulated human material into structural form.

It must:

- preserve original source
- extract fragments and relations
- detect repeatable patterns
- emit stable structure candidates
- generate machine-readable specs
- prepare the bridge toward builder, runtime, restore, and framework OS

This document is the initial code specification for that engine.

