#!/usr/bin/env python3
"""
SeungeFlow Master Runtime All-in-One
Practical integrated runner for the SeungeFlow stack.

This file does not replace every earlier module in full detail.
Instead, it provides one operational shell that can:
1. prepare directories
2. scan inputs and logs
3. build lightweight reports
4. generate questions and discovery plans
5. compile a master summary

Recommended layout:
  /opt/m7dq/
    inputs/
    logs/
    reports/
"""

from __future__ import annotations

import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path


BASE = Path("/opt/m7dq")
INPUTS = BASE / "inputs"
LOGS = BASE / "logs"
REPORTS = BASE / "reports"
SYSTEMS = BASE / "systems"

PROCESS_PATTERN = re.compile(r"(\\w+)\\[\\d+\\]")


def ensure_dirs() -> None:
    for p in [BASE, INPUTS, LOGS, REPORTS, SYSTEMS]:
        p.mkdir(parents=True, exist_ok=True)


def write_json(path: Path, data: dict | list) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def scan_inputs() -> dict:
    records = []
    for f in sorted(INPUTS.glob("*")):
        if f.is_file():
            records.append({"file": f.name, "size_bytes": f.stat().st_size})
    report = {"input_count": len(records), "inputs": records}
    write_json(REPORTS / "universal_input_summary.json", report)
    return report


def classify_domains(input_summary: dict) -> dict:
    classified = []
    for r in input_summary.get("inputs", []):
        name = r["file"].lower()
        if "trade" in name or "market" in name:
            domain = "trading"
        elif "brain" in name or "neuro" in name:
            domain = "brain"
        elif "paper" in name or "research" in name or name.endswith(".pdf"):
            domain = "science"
        elif "log" in name:
            domain = "system"
        else:
            domain = "unknown"
        classified.append({"file": r["file"], "domain": domain})
    report = {"count": len(classified), "classified": classified}
    write_json(REPORTS / "domain_classification.json", report)
    return report


def route_pipelines(classification: dict) -> dict:
    routes = []
    for item in classification.get("classified", []):
        d = item["domain"]
        if d == "system":
            pipe = "system_analysis"
        elif d == "trading":
            pipe = "trading_analysis"
        elif d == "brain":
            pipe = "cognitive_analysis"
        elif d == "science":
            pipe = "research_analysis"
        else:
            pipe = "generic_analysis"
        routes.append({"file": item["file"], "pipeline": pipe})
    report = {"route_count": len(routes), "routes": routes}
    write_json(REPORTS / "universal_routing.json", report)
    return report


def analyze_raw_log() -> dict:
    log_file = LOGS / "raw.log"
    if not log_file.exists():
        report = {"status": "missing", "message": "raw.log not found"}
        write_json(REPORTS / "master_log_analysis.json", report)
        return report

    processes = []
    edges = defaultdict(int)

    with open(log_file, "r", encoding="utf-8", errors="ignore") as f:
        prev = None
        for line in f:
            m = PROCESS_PATTERN.search(line)
            if not m:
                continue
            p = m.group(1)
            processes.append(p)
            if prev is not None:
                edges[(prev, p)] += 1
            prev = p

    freq = Counter(processes)
    total = sum(freq.values())
    entropy = -sum((c / total) * math.log2(c / total) for c in freq.values()) if total else 0.0

    graph = [
        {"from": a, "to": b, "weight": w}
        for (a, b), w in sorted(edges.items(), key=lambda x: x[1], reverse=True)
    ]

    report = {
        "status": "ok",
        "total_events": total,
        "unique_processes": len(freq),
        "entropy": entropy,
        "top_processes": freq.most_common(20),
        "top_edges": graph[:50],
    }
    write_json(REPORTS / "master_log_analysis.json", report)
    write_json(REPORTS / "process_graph.json", graph)
    return report


def generate_questions(routing: dict) -> dict:
    questions = []
    for r in routing.get("routes", []):
        pipe = r["pipeline"]
        file = r["file"]
        if pipe == "system_analysis":
            q = f"What structural anomaly patterns exist in {file}?"
        elif pipe == "trading_analysis":
            q = f"What repeating market behaviors appear in {file}?"
        elif pipe == "cognitive_analysis":
            q = f"What cognitive signal patterns emerge from {file}?"
        elif pipe == "research_analysis":
            q = f"What hypotheses can be derived from {file}?"
        else:
            q = f"What hidden patterns might exist in {file}?"
        questions.append({"source": file, "question": q})
    report = {"question_count": len(questions), "questions": questions}
    write_json(REPORTS / "generated_questions.json", report)
    return report


def build_problem_space(questions: dict) -> dict:
    priorities = []
    for i, q in enumerate(questions.get("questions", []), start=1):
        priorities.append({
            "priority_rank": i,
            "question": q["question"],
            "curiosity_score": round(1.0 / i, 4)
        })
    write_json(REPORTS / "curiosity_priorities.json", {"priority_count": len(priorities), "priorities": priorities})

    problem_space = []
    for p in priorities:
        problem_space.append({"problem": p["question"], "exploration_status": "unexplored"})
    report = {"problem_count": len(problem_space), "problem_space": problem_space}
    write_json(REPORTS / "problem_space_map.json", report)
    return report


def build_discovery_plan(problem_space: dict) -> dict:
    tasks = []
    for i, p in enumerate(problem_space.get("problem_space", [])[:20], start=1):
        tasks.append({
            "task_id": f"DISC-{i:03d}",
            "objective": p["problem"],
            "status": "planned"
        })
    report = {"planned_tasks": len(tasks), "tasks": tasks}
    write_json(REPORTS / "discovery_plan.json", report)
    return report


def compile_master_report(
    input_summary: dict,
    classification: dict,
    routing: dict,
    log_analysis: dict,
    questions: dict,
    problem_space: dict,
    discovery_plan: dict,
) -> Path:
    out = REPORTS / "SEUNGEFLOW_MASTER_REPORT.md"
    lines = [
        "# SeungeFlow Master Report",
        "",
        "## Identity",
        "- System: SeungeFlow Master Runtime All-in-One",
        "- Mode: Practical integrated operational shell",
        "",
        "## Inputs",
        f"- input_count: {input_summary.get('input_count', 0)}",
        f"- classified_count: {classification.get('count', 0)}",
        f"- route_count: {routing.get('route_count', 0)}",
        "",
        "## Log Analysis",
        f"- status: {log_analysis.get('status', 'unknown')}",
        f"- total_events: {log_analysis.get('total_events', 0)}",
        f"- unique_processes: {log_analysis.get('unique_processes', 0)}",
        f"- entropy: {log_analysis.get('entropy', 0)}",
        "",
        "## Question Layer",
        f"- question_count: {questions.get('question_count', 0)}",
        f"- problem_count: {problem_space.get('problem_count', 0)}",
        f"- planned_tasks: {discovery_plan.get('planned_tasks', 0)}",
        "",
        "## Top Questions",
    ]
    for q in questions.get("questions", [])[:10]:
        lines.append(f"- {q['question']}")
    lines += [
        "",
        "## Top Processes",
    ]
    for p, c in log_analysis.get("top_processes", [])[:10]:
        lines.append(f"- {p}: {c}")
    lines += [
        "",
        "## Meaning",
        "- Observe → Analyze → Ask → Plan",
        ""
    ]
    out.write_text("\\n".join(lines), encoding="utf-8")
    return out


def main() -> None:
    ensure_dirs()
    input_summary = scan_inputs()
    classification = classify_domains(input_summary)
    routing = route_pipelines(classification)
    log_analysis = analyze_raw_log()
    questions = generate_questions(routing)
    problem_space = build_problem_space(questions)
    discovery_plan = build_discovery_plan(problem_space)
    master_report = compile_master_report(
        input_summary, classification, routing, log_analysis, questions, problem_space, discovery_plan
    )

    runtime_status = {
        "runtime": "SeungeFlow Master Runtime All-in-One",
        "status": "complete",
        "generated_reports": [
            "universal_input_summary.json",
            "domain_classification.json",
            "universal_routing.json",
            "master_log_analysis.json",
            "process_graph.json",
            "generated_questions.json",
            "curiosity_priorities.json",
            "problem_space_map.json",
            "discovery_plan.json",
            master_report.name,
        ],
    }
    write_json(REPORTS / "runtime_status_all_in_one.json", runtime_status)
    print("SeungeFlow all-in-one runtime complete")


if __name__ == "__main__":
    main()
