# SeungeFlow All-in-One Runtime

This package provides a single-file practical runtime.

## Files
- seungeflow_master_runtime_all.py
- install_all_in_one.sh
- README_ALL_IN_ONE.md

## What it does
- prepares `/opt/m7dq`
- scans `/opt/m7dq/inputs`
- classifies input domains
- routes pipelines
- analyzes `/opt/m7dq/logs/raw.log`
- generates questions
- builds problem space and discovery plan
- compiles `SEUNGEFLOW_MASTER_REPORT.md`

## Run
```bash
bash install_all_in_one.sh
cp seungeflow_master_runtime_all.py /opt/m7dq/kernel/
cd /opt/m7dq/kernel
python3 seungeflow_master_runtime_all.py
```

## Outputs
- `/opt/m7dq/reports/universal_input_summary.json`
- `/opt/m7dq/reports/domain_classification.json`
- `/opt/m7dq/reports/universal_routing.json`
- `/opt/m7dq/reports/master_log_analysis.json`
- `/opt/m7dq/reports/process_graph.json`
- `/opt/m7dq/reports/generated_questions.json`
- `/opt/m7dq/reports/curiosity_priorities.json`
- `/opt/m7dq/reports/problem_space_map.json`
- `/opt/m7dq/reports/discovery_plan.json`
- `/opt/m7dq/reports/SEUNGEFLOW_MASTER_REPORT.md`
