#!/bin/bash
set -e

BASE=/opt/m7dq

echo "Installing SeungeFlow All-in-One Runtime"
mkdir -p $BASE/kernel
mkdir -p $BASE/logs
mkdir -p $BASE/reports
mkdir -p $BASE/systems
mkdir -p $BASE/inputs

echo "Copy seungeflow_master_runtime_all.py into $BASE/kernel"
echo "Then run:"
echo "  cd $BASE/kernel && python3 seungeflow_master_runtime_all.py"
