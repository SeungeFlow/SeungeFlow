#!/bin/bash
set -e

BASE=/opt/m7dq
KERNEL=$BASE/kernel

echo "Installing SeungeFlow cron job"

mkdir -p $BASE

CRONLINE="*/5 * * * * cd $KERNEL && python3 seungeflow_master_runtime_all.py >> $BASE/reports/cron_runtime.log 2>&1"

( crontab -l 2>/dev/null | grep -v seungeflow_master_runtime_all.py ; echo "$CRONLINE" ) | crontab -

echo "Cron installed: every 5 minutes"
