#!/bin/bash
set -e

cd /opt/m7dq/kernel
python3 seungeflow_master_runtime_all.py
