
# SeungeFlow Operations Pack

This pack provides **two runtime modes**.

## Mode A — Cron Loop

Runs every 5 minutes.

Install:

```bash
bash install_cron.sh
```

Check:

```bash
crontab -l
```

Log:

```
/opt/m7dq/reports/cron_runtime.log
```

---

## Mode B — systemd Service

Continuous daemon mode.

Install:

```bash
sudo bash install_systemd.sh
```

Control:

```bash
systemctl start seungeflow
systemctl stop seungeflow
systemctl restart seungeflow
systemctl status seungeflow
```

Logs:

```bash
journalctl -u seungeflow
```

---

## Quick Run

```bash
bash run_once.sh
```

---

## Recommended Setup

Development:
```
cron
```

Production:
```
systemd
```
