#!/bin/bash
set -e

echo "Installing SeungeFlow systemd service"

sudo cp seungeflow.service /etc/systemd/system/seungeflow.service

sudo systemctl daemon-reload
sudo systemctl enable seungeflow
sudo systemctl start seungeflow

echo "Service started"
systemctl status seungeflow --no-pager
