#!/bin/bash
set -e

BASE=/opt/m7dq

echo "Installing SeungeFlow Master Bundle"

mkdir -p $BASE/kernel
mkdir -p $BASE/logs
mkdir -p $BASE/reports
mkdir -p $BASE/systems
mkdir -p $BASE/inputs

echo "Directory structure ready:"
echo "$BASE/{kernel,logs,reports,systems,inputs}"

echo "Copy all *.py files into $BASE/kernel"
echo "Copy source logs into $BASE/logs"
echo "Copy universal input files into $BASE/inputs"

chmod +x $BASE/kernel/*.py 2>/dev/null || true

echo "Install complete"
