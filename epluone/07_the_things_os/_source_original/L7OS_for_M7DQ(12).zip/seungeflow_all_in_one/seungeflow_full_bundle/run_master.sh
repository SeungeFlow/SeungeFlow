#!/bin/bash
set -e

cd /opt/m7dq/kernel

if [ -f seungeflow_runtime.py ]; then
  python3 seungeflow_runtime.py
elif [ -f seungeflow_core_engine.py ]; then
  python3 seungeflow_core_engine.py
else
  echo "No master runtime found in /opt/m7dq/kernel"
  exit 1
fi
