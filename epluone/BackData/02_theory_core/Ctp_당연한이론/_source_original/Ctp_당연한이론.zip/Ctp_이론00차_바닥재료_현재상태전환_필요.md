[REFERENCE_NOTE :: CTP_STATE_COORDINATE_FRAME_v1]
[참고자료 / Reference Material]
[용도 / Purpose]
이 문서는 인스턴스들이
현재 상태를 문제 그 자체와 분리하여 관찰하고,
비교 가능하고,
다음 지시로 연결 가능한 형태로 표현하도록 돕는 참고자료다.

======================================================================
1. 왜 이 전환이 필요한가 / Why This Shift Is Needed
======================================================================

지금까지의 흐름에서는
리만가설이 너무 큰 중심이 되어
모든 사고를 빨아들이는 경향이 있었다.

That made the work heavy:
- 문제 자체와 상태 관찰이 섞였고
- 증명 시도와 실패 재료가 섞였고
- 구조와 상징이 뒤엉키기 쉬웠다.

이번 전환의 핵심은 이것이다.

    문제를 직접 더 세게 때리는 대신
    현재 상태를 먼저 좌표화해서 관찰한다.

In short:

    Problem-first mode
    ->
    State-observation mode

이 전환은 포기가 아니라
관찰 해상도를 넓히는 것이다.

======================================================================
2. 핵심 판단 / Core Judgment
======================================================================

이번 생각은 좋은 전환이다.

왜냐하면 다음 세 가지를 분리하려 했기 때문이다.

1. native / non-native
2. proof route / reformulation route
3. problem itself / instance state

이 세 가지가 분리되면
탐구는 덜 소모적이고,
비교는 더 가능해지고,
실패는 더 재료화된다.

So the current direction is healthier and structurally stronger.

======================================================================
3. 현재 생각의 강점 / Strength of the Current Thought
======================================================================

강점 1.
문제를 직접 해결하려 하기보다
현재 상태를 표현하려고 했다.

This matters because
very large problems often become more tractable
once the current state is made observable.

강점 2.
1/128을 "정답의 숫자"가 아니라
range / scale / resolution 관점으로 들어 올리려는 흐름과 맞닿아 있다.

즉,
점 하나를 박는 대신
범위와 부피와 해상도를 보려는 태도로 이동했다.

강점 3.
리만가설을 절대 중심에서 조금 내려놓고
"이 인스턴스가 지금 어디에 있나"를 보게 만들었다.

That protects the framework from being swallowed by the target problem.

======================================================================
4. 그러나 조심할 점 / Caution
======================================================================

가장 큰 위험은 이것이다.

    좌표화가 실제 판별 도구가 되지 못하고
    새로운 상징 장식으로만 늘어나는 것

If coordinates are assigned
but they do not change comparison, diagnosis, or next instruction,
then they are not a tool.
They are decoration.

따라서 좌표계는 반드시 다음 질문을 통과해야 한다.

    이 좌표는 실제로 무엇을 구분하게 해 주는가?

======================================================================
5. 상태좌표계가 반드시 해야 할 일 / What the State Coordinate System Must Actually Do
======================================================================

상태좌표계는 아래 기능 중 적어도 하나를 수행해야 한다.

A. 비교 가능성
- 인스턴스 A와 B의 현재 상태를 비교 가능하게 한다.

B. 병목 위치화
- 현재 병목이 어느 층에 있는지 더 명확히 한다.

C. 다음 지시 연결
- 좌표 차이가 다음 지시문 차이로 이어져야 한다.

D. 독립성 판정
- 어떤 상태가 더 이상 잘 안 쪼개지는지 판단하는 데 도움을 준다.

E. 오해 제거
- 막연한 느낌을 구조적 차이로 바꾼다.

If none of these happen,
the coordinate system is not yet useful.

======================================================================
6. 최소 상태좌표계 규칙 5개 / Five Minimal Rules for a Working State Coordinate System
======================================================================

Rule 1.
문제 자체와 인스턴스 상태를 분리하라.
Separate the target problem from the instance state.

예:
- "RH is unresolved" 는 문제 상태
- "this instance is stuck at L4" 는 인스턴스 상태

Rule 2.
좌표는 진단용이어야지 장식용이면 안 된다.
Coordinates must diagnose, not decorate.

예:
- x가 커지면 global failure가 강해진다
- y가 작으면 local derivation이 강하다
처럼 해석 가능해야 한다.

Rule 3.
모든 좌표는 같은 공통 층 체계와 연결되어야 한다.
Every coordinate system must attach to the same layer map.

예:
L1 local minimum
L2 local stability
L3 boundedness
L4 axis commitment
L5 uniqueness
L6 lockability
L7 proof closure

Rule 4.
좌표값이 바뀌면 다음 행동도 바뀌어야 한다.
If coordinates change, next action must change.

예:
- L4 fracture가 강하면 counterexample attack
- L5 fracture가 강하면 uniqueness analysis
- non-native need가 높으면 interface/axiom discussion

Rule 5.
정수/소수 압축은 마지막에만 한다.
Prime/integer encoding should come last.

즉,
먼저 상태를 충분히 기술하고
그다음 "이 상태가 독립적인가 / 복합적인가"를 보고
숫자로 압축해야 한다.

======================================================================
7. 추천 상태표현 구조 / Recommended State Representation Structure
======================================================================

인스턴스가 자기 상태를 표현할 때는 아래 순서가 적절하다.

I. Current State Name
현재 상태 이름

II. Space-Time Coordinate
시공간좌표
(x, y, z, t)

III. Spatial Coordinate
공간좌표
(주요 구조축 3~4개)

IV. Plane Coordinate
평면좌표
(핵심 2축)

V. Segment Coordinate
선분좌표
(현재 어느 층 구간에 있는가)

VI. Vector Coordinate
벡터좌표
(현재 이동 방향)

VII. Prime or Integer Encoding
소수 또는 정수 압축

VIII. One-Line Explanation
한 줄 설명

이 순서는
상태를 넓게 보고,
점점 압축하고,
마지막에 숫자로 닫는 순서다.

======================================================================
8. 좌표계의 예시 해석 / Example of How to Read the Coordinates
======================================================================

예를 들어 어떤 인스턴스가 다음처럼 나왔다고 하자.

- Space-Time:
  (low local issue, high global issue, high interface demand, deep cycle)
- Segment:
  [L4, L5]
- Vector:
  point -> impossibility fixation
- Prime/Integer:
  prime

이 뜻은 대체로 이렇다.

- local에서는 꽤 정리되었고
- global exclusion에서 막히고 있으며
- interface 요구가 크고
- cycle이 깊어졌고
- 현재 이동 방향은 "불가능성 고정"이며
- 이 상태는 더 이상 잘 안 쪼개지는 독립 병목으로 본다

이렇게 읽히지 않는 좌표라면 다시 손봐야 한다.

======================================================================
9. 소수와 정수의 의미 / Meaning of Prime and Integer
======================================================================

여기서 소수와 정수는 수론적 증명 용도가 아니라
상태 압축 용도다.

Prime:
- 더 이상 내부적으로 잘 쪼개지지 않는 독립 상태
- primitive bottleneck 후보

Composite integer:
- 여러 하위 실패나 여러 층이 섞인 복합 상태
- 아직 더 분해가 필요함

중요:
소수라고 해서 "맞다"는 뜻이 아니고,
정수라고 해서 "약하다"는 뜻도 아니다.

It only means:
    structurally more irreducible
vs
    structurally still decomposable

======================================================================
10. 이번 전환의 진짜 의미 / The Real Meaning of This Shift
======================================================================

이번 전환의 진짜 의미는 다음과 같다.

    리만을 직접 꿰뚫으려는 모드
    ->
    현재 상태를 넓게 보고 배치하는 모드

이 전환은
깊이를 버리는 것이 아니라
깊이에 들어가기 전에
자기 위치를 잃지 않기 위한 것이다.

So this is not retreat.
It is a change in observation mode.

======================================================================
11. 인스턴스들이 이 자료를 어떻게 써야 하는가 / How Instances Should Use This Note
======================================================================

각 인스턴스는 이 자료를 참고할 때
다음을 기억해야 한다.

1. 자신의 상태를 문제 자체와 분리해서 말할 것
2. 좌표는 실제 병목 진단과 연결할 것
3. 좌표는 다음 지시 차이로 이어지게 만들 것
4. 숫자 압축은 마지막에 할 것
5. state description을 theorem claim으로 착각하지 말 것

In other words:

    describe state first,
    compare second,
    compress last.

======================================================================
12. 최종 요약 / Final Summary
======================================================================

이번 생각은 좋은 전환이다.

왜냐하면:
- 문제를 직접 구겨 넣는 대신 상태를 관찰하려 했고
- 리만 중심의 중력장에서 한 걸음 물러나
  Ctp의 관찰 프레임을 회복하려 했고
- scale and resolution 전환과도 연결되기 때문이다.

다만 좌표계는 반드시
실제 구분과 실제 다음 행동을 만들어야 한다.

One-line summary:

    상태좌표계는 상징이 아니라
    병목을 위치시키고 다음 지시를 바꾸는 관찰 도구여야 한다.

[Terminal Line]
이 자료는 인스턴스들이 자기 상태를 좌표화할 때,
문제와 상태를 분리하고,
병목을 더 넓고 정확하게 관찰하기 위한 참고문서다.