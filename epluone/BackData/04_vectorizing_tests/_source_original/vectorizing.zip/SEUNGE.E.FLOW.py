import numpy as np
import matplotlib.pyplot as plt
import streamlit as st

# ==========================================
# SEUNGE.E.FLOW ENGINE: EVENT HORIZON RENDERER
# GOAL: Visualize C=tp / Dynamic Equilibrium
# ==========================================

def render_seunge_flow():
    st.set_page_config(page_title="Seunge.e.flow Event Horizon", layout="wide")
    st.title("Seunge.e.flow: The Core Singularity (n=1000)")
    
    # 사이드바 컨트롤: t(시간)와 p(구조 필드 강도) 조절
    st.sidebar.header("Engine Parameters")
    t_val = st.sidebar.slider("Cumulative Time (t)", 1, 1000, 400)
    p_strength = st.sidebar.slider("Hazard Field Strength (p)", 0.1, 5.0, 1.0)
    
    # 1. 수평(금강경)과 수직(반야심경)의 벡터 데이터 생성
    # Grid 설정
    x = np.linspace(-5, 5, 40)
    y = np.linspace(-5, 5, 40)
    X, Y = np.meshgrid(x, y)
    
    # 2. C = tp 수식 기반의 동역학장 계산
    # r은 원점으로부터의 거리 (Singularity 탐지)
    r = np.sqrt(X**2 + Y**2) + 0.1 # 분모 0 방지
    
    # ∇Φ (Seunge-Flow Gradient): 중심인력
    u_gravity = -X / (r**3) * p_strength 
    v_gravity = -Y / (r**3) * p_strength
    
    # R_ω (High-Velocity Rotation): 사건의 지평선 회전 연산
    # 초고속 회전력을 구현하기 위한 각속도 커널
    omega = (t_val / 100) / (r**2)
    u_rot = -Y * omega
    v_rot = X * omega
    
    # 3. 최종 벡터 합 (Dynamic Equilibrium)
    # 끌어당기나 끌어당기지 않는 듯한 평형 상태 구현
    U = u_gravity + u_rot
    V = v_gravity + v_rot
    
    # 4. 시각화 (Matplotlib -> Streamlit)
    fig, ax = plt.subplots(figsize=(10, 10), facecolor='black')
    
    # 유선(Streamline) 표시: 잔잔하지만 빠른 회전의 시각화
    color_map = plt.cm.inferno
    strm = ax.streamplot(X, Y, U, V, color=r, linewidth=1, cmap=color_map, 
                         density=2, arrowstyle='->', arrowsize=0.5)
    
    # Event Horizon(사건의 지평선) 경계 표시
    horizon_radius = np.sqrt(p_strength * (t_val/500))
    circle = plt.Circle((0, 0), horizon_radius, color='white', fill=False, 
                        linestyle='--', linewidth=2, alpha=0.5)
    ax.add_artist(circle)
    
    # 시각적 보정
    ax.set_facecolor('black')
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    ax.set_aspect('equal')
    plt.axis('off')
    
    # UI 배치
    col1, col2 = st.columns([3, 1])
    with col1:
        st.pyplot(fig)
    
    with col2:
        st.markdown(f"""
        ### [Structure Report]
        - **State:** Closed Continuity ($C$)
        - **Horizon Radius:** `{horizon_radius:.4f}`
        - **Angular Momentum:** `High (Topological Lock)`
        
        **수식적 해석:**
        중심부로 갈수록 에너지가 무한히 수렴하지만, 
        회전 연산자($\mathbf{{\hat{{R}}}}_{\omega}$)와의 
        상쇄 간섭을 통해 지평선 표면은 
        **잔잔한 평형상태($\mathbf{{0}}$)**를 유지합니다.
        """)

if __name__ == "__main__":
    render_seunge_flow()