SeungeFlow Black Hole Accretion Disk Structured Bundle

Folder guide
- 01_ctp_core: core Ctp_v2 consolidation and closure documents
- 02_spec: black hole accretion disk implementation spec
- 03_simulation_v1: first structural simulation
- 04_viewer: HTML canvas viewer
- 05_simulation_v2: simulation with added physical-link variables

This bundle is organized for preservation and later GitHub upload.
