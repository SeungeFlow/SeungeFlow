# BlackHole_AccretionDisk_Spec.md

## 상태
Ctp_v2 기반 블랙홀 강착원반 구현 시작
이론 추가 확장 중지
구조 구현 우선

---

## 목표

블랙홀 강착원반을
기존 천체물리 계산식 중심이 아니라

Twist → I → flow → self_return → disk stability

구조로 구현한다.

---

## Core Mapping

O → ∂ → I → flow → flow_self_return → C

---

## 블랙홀 강착원반 매핑

### O
블랙홀 중심축  
사건지평선 기준  
회전축 기준점  

### ∂
반경별 밀도 차이  
반경별 속도 차이  
반경별 온도 차이  
내부/외부 회전 차이  

### I
압착 통로  
ISCO 근방  
강착 전이층  
낙하 직전 임계 띠  

### flow
회전 흐름  
나선 유입  
전단 누적  
내부 낙하 흐름  

### flow_self_return
원반 내부 재순환  
안정 궤도층  
반복 회전 구조  

### C
안정된 강착원반  
붕괴되지 않는 disk shell  
중심축 기준 회전 구조 고착  

---

## 핵심 법칙

### Law 1
Twist는 제거 대상이 아니다  
Twist는 회전 유지 엔진이다  

### Law 2
I는 단순 경계가 아니다  
I는 압착 통로다  

### Law 3
flow는 직선 낙하가 아니다  
회전 + 압착 + 누적이다  

### Law 4
원반 안정성은
flow_self_return 가능한 회전층의 존재 여부로 본다  

---

## 구현 대상 요소

### Layer 1
중심 블랙홀

### Layer 2
기본 강착원반 링

### Layer 3
나선 유입 흐름

### Layer 4
임계 통로 I

### Layer 5
내부 붕괴 구간

---

## 입력 변수

radius r  
density ρ(r)  
velocity v(r)  
twist τ(r)  
temperature T(r)  

선택:
angular momentum L(r)  
shear S(r)  
pressure P(r)  

---

## 출력 목표

1. 중심 블랙홀
2. 바깥 안정 원반
3. 안쪽 압착 통로
4. 나선 유입 흐름
5. 중심 낙하 구멍
6. 안정/불안정 구간 시각화

---

## 최소 구현 로직

### Step 1
중심점 O 생성

### Step 2
반경별 차이 ∂ 생성

### Step 3
임계 반경대에서 I 생성

### Step 4
Twist 부여

### Step 5
회전 흐름 생성

### Step 6
안쪽은 낙하
바깥은 안정 회전
중간은 압착 전이층 형성

### Step 7
flow_self_return 가능한 구간 표시

---

## 시각화 기준

### 바깥쪽
안정된 회전 링

### 중간층
밀도 높은 압착 구간

### 안쪽
붕괴 직전 급가속 구간

### 중심
암흑 축 / 흡수점

### 전체 형상
disk + torus-like compression + spiral inflow

---

## 구현 파일 계획

### 1
BlackHole_AccretionDisk_Spec.md

### 2
blackhole_disk_simulation.py

### 3
blackhole_disk_view.html

---

## 구현 우선순위

### Phase 1
2D 시뮬레이션

### Phase 2
Canvas 기반 시각화

### Phase 3
3D 확장 가능 여부 판단

---

## 판단 기준

좋은 구현은
정확한 수식보다
다음 구조가 눈에 보여야 한다

- Twist 유지
- I 형성
- flow 누적
- self_return 층 존재
- 안정 원반과 붕괴층 구분

---

## One Line

블랙홀 강착원반은
중력 계산 결과가 아니라
Twist와 I와 flow가 만든 구조체로 구현한다
