# blackhole_disk_simulation_v2.py
# Ctp_v2 기반 블랙홀 강착원반 v2
# 구조 시각화 + 물리 연결(각운동량, 전단, 소산, 낙하속도)
#
# 목적:
# - 정밀 GR/MHD 계산이 아니라
# - Twist / I / flow / self_return 구조에
#   물리적으로 읽을 수 있는 보조량을 붙이는 것

import math
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt


@dataclass
class DiskParamsV2:
    r_min: float = 0.10
    r_max: float = 1.00
    n_rings: int = 240
    n_points: int = 360

    # I(압착 통로) 중심과 폭
    i_center: float = 0.34
    i_width: float = 0.125

    # Twist 구조
    twist_base: float = 0.18
    twist_peak: float = 0.42

    # 흐름/시각화
    inward_pull: float = 0.24
    spiral_gain: float = 3.6

    # self-return 안정 회전층
    self_return_band: Tuple[float, float] = (0.54, 0.86)

    # 낙하 강화 반경
    isco_like_radius: float = 0.28

    # 시각화용 밝기 비중
    weight_density: float = 0.30
    weight_velocity: float = 0.15
    weight_twist: float = 0.10
    weight_temperature: float = 0.10
    weight_dissipation: float = 0.20
    weight_infall: float = 0.15


def gaussian(x: float, mu: float, sigma: float) -> float:
    if sigma <= 0:
        return 0.0
    z = (x - mu) / sigma
    return math.exp(-0.5 * z * z)


def clamp(v: float, low: float, high: float) -> float:
    return max(low, min(high, v))


def density_profile(r: float, params: DiskParamsV2) -> float:
    outer_decay = 1.0 - 0.70 * r
    i_bump = 0.55 * gaussian(r, params.i_center, params.i_width * 0.42)
    inner_loss = 0.85 * gaussian(r, params.r_min + 0.05, 0.06)
    rho = outer_decay + i_bump - inner_loss
    return clamp(rho, 0.02, 1.0)


def velocity_profile(r: float, params: DiskParamsV2) -> float:
    # 안쪽으로 갈수록 빨라지는 단순 회전 속도
    base = 0.58 / math.sqrt(max(r, 0.04))
    i_accel = 0.30 * gaussian(r, params.i_center, params.i_width * 0.36)
    return base + i_accel


def twist_profile(r: float, params: DiskParamsV2) -> float:
    return params.twist_base + params.twist_peak * gaussian(r, params.i_center, params.i_width * 0.34)


def temperature_profile(r: float, params: DiskParamsV2) -> float:
    core_heat = 1.15 / max(r, 0.08)
    i_heat = 0.95 * gaussian(r, params.i_center, params.i_width * 0.32)
    return core_heat + i_heat


def angular_momentum_profile(r: float, params: DiskParamsV2) -> float:
    # 단순화: L = r * v
    v = velocity_profile(r, params)
    return r * v


def infall_speed_profile(r: float, params: DiskParamsV2) -> float:
    # ISCO-like 반경 안쪽에서 급격한 낙하 증가
    if r >= params.isco_like_radius:
        return 0.02 * gaussian(r, params.i_center, params.i_width * 0.45)
    depth = (params.isco_like_radius - r) / max(params.isco_like_radius - params.r_min, 1e-6)
    return 0.08 + 0.72 * depth**1.6


def radial_derivative(values: List[float], radii: List[float], idx: int) -> float:
    if idx == 0:
        dv = values[1] - values[0]
        dr = radii[1] - radii[0]
        return dv / dr
    if idx == len(values) - 1:
        dv = values[-1] - values[-2]
        dr = radii[-1] - radii[-2]
        return dv / dr
    dv = values[idx + 1] - values[idx - 1]
    dr = radii[idx + 1] - radii[idx - 1]
    return dv / dr


def classify_region(r: float, params: DiskParamsV2) -> str:
    if r < params.r_min + 0.08:
        return "inner_collapse"
    if abs(r - params.i_center) <= params.i_width * 0.5:
        return "conduit_I"
    if params.self_return_band[0] <= r <= params.self_return_band[1]:
        return "self_return_band"
    return "outer_disk"


def build_profiles(params: DiskParamsV2) -> Dict[str, List[float]]:
    radii = [
        params.r_min + (params.r_max - params.r_min) * i / (params.n_rings - 1)
        for i in range(params.n_rings)
    ]
    density = [density_profile(r, params) for r in radii]
    velocity = [velocity_profile(r, params) for r in radii]
    twist = [twist_profile(r, params) for r in radii]
    temperature = [temperature_profile(r, params) for r in radii]
    angular_momentum = [angular_momentum_profile(r, params) for r in radii]
    infall = [infall_speed_profile(r, params) for r in radii]

    shear = [abs(radial_derivative(velocity, radii, i)) for i in range(len(radii))]
    dissipation = [shear[i] * twist[i] for i in range(len(radii))]

    # 정규화
    def normalize(arr: List[float]) -> List[float]:
        mn, mx = min(arr), max(arr)
        if abs(mx - mn) < 1e-12:
            return [0.0 for _ in arr]
        return [(x - mn) / (mx - mn) for x in arr]

    return {
        "radii": radii,
        "density": density,
        "velocity": velocity,
        "twist": twist,
        "temperature": temperature,
        "angular_momentum": angular_momentum,
        "infall": infall,
        "shear": shear,
        "dissipation": dissipation,
        "density_n": normalize(density),
        "velocity_n": normalize(velocity),
        "twist_n": normalize(twist),
        "temperature_n": normalize(temperature),
        "angular_momentum_n": normalize(angular_momentum),
        "infall_n": normalize(infall),
        "shear_n": normalize(shear),
        "dissipation_n": normalize(dissipation),
    }


def generate_disk_points(params: DiskParamsV2, profiles: Dict[str, List[float]]):
    xs: List[float] = []
    ys: List[float] = []
    intensity: List[float] = []
    regions: List[str] = []

    radii = profiles["radii"]

    for i, r in enumerate(radii):
        rho_n = profiles["density_n"][i]
        vel_n = profiles["velocity_n"][i]
        tw_n = profiles["twist_n"][i]
        temp_n = profiles["temperature_n"][i]
        dis_n = profiles["dissipation_n"][i]
        inf_n = profiles["infall_n"][i]
        region = classify_region(r, params)

        tw_raw = profiles["twist"][i]
        vel_raw = profiles["velocity"][i]

        for j in range(params.n_points):
            theta = 2.0 * math.pi * j / params.n_points

            spiral_phase = params.spiral_gain * (1.0 - r) * (1.0 + tw_raw)
            local_warp = 0.12 * tw_raw * math.sin(3.0 * theta + 5.0 * r)

            conduit_pull = params.inward_pull * gaussian(r, params.i_center, params.i_width * 0.30)
            collapse_pull = 0.16 * gaussian(r, params.r_min + 0.03, 0.045)
            infall_pull = 0.10 * inf_n

            r_eff = r * (1.0 - conduit_pull - collapse_pull - infall_pull) + local_warp * 0.03

            # 낙하층 안쪽은 더 비대칭적으로 말리게 함
            angle = theta + spiral_phase + 0.03 * vel_raw + 0.12 * inf_n * math.sin(theta)

            x = r_eff * math.cos(angle)
            y = r_eff * math.sin(angle)

            lum = (
                params.weight_density * rho_n
                + params.weight_velocity * vel_n
                + params.weight_twist * tw_n
                + params.weight_temperature * temp_n
                + params.weight_dissipation * dis_n
                + params.weight_infall * inf_n
            )
            lum = clamp(lum, 0.0, 1.0)

            xs.append(x)
            ys.append(y)
            intensity.append(lum)
            regions.append(region)

    return xs, ys, intensity, regions


def summarize_profiles(params: DiskParamsV2, profiles: Dict[str, List[float]]) -> Dict[str, Dict[str, float]]:
    sample_r = [
        params.r_min,
        params.isco_like_radius,
        params.i_center - params.i_width * 0.45,
        params.i_center,
        params.i_center + params.i_width * 0.45,
        0.72,
        params.r_max,
    ]

    radii = profiles["radii"]

    def nearest_index(target: float) -> int:
        return min(range(len(radii)), key=lambda i: abs(radii[i] - target))

    out: Dict[str, Dict[str, float]] = {}
    for r in sample_r:
        i = nearest_index(r)
        out[f"r={radii[i]:.3f}"] = {
            "density": round(profiles["density"][i], 4),
            "velocity": round(profiles["velocity"][i], 4),
            "twist": round(profiles["twist"][i], 4),
            "temperature": round(profiles["temperature"][i], 4),
            "angular_momentum": round(profiles["angular_momentum"][i], 4),
            "shear": round(profiles["shear"][i], 4),
            "dissipation": round(profiles["dissipation"][i], 4),
            "infall": round(profiles["infall"][i], 4),
        }
    return out


def plot_disk_and_profiles(params: DiskParamsV2, profiles: Dict[str, List[float]], output_png: str) -> None:
    xs, ys, lum, _ = generate_disk_points(params, profiles)

    fig = plt.figure(figsize=(12, 10))

    # Panel 1: Disk structure
    ax1 = fig.add_subplot(2, 2, 1)
    ax1.scatter(xs, ys, c=lum, s=1.5, alpha=0.65)
    ax1.set_aspect("equal")
    ax1.set_title("Accretion Disk v2 (Twist / I / flow)")
    ax1.set_xlabel("x")
    ax1.set_ylabel("y")

    center = plt.Circle((0, 0), params.r_min * 0.78, fill=False, linewidth=2)
    conduit = plt.Circle((0, 0), params.i_center, fill=False, linewidth=1.2, linestyle="--")
    stable = plt.Circle((0, 0), sum(params.self_return_band) / 2.0, fill=False, linewidth=1.0, linestyle=":")
    ax1.add_patch(center)
    ax1.add_patch(conduit)
    ax1.add_patch(stable)

    lim = params.r_max * 1.1
    ax1.set_xlim(-lim, lim)
    ax1.set_ylim(-lim, lim)
    ax1.text(0.02, 0.02, "O", transform=ax1.transAxes)
    ax1.text(0.73, 0.92, "I", transform=ax1.transAxes)
    ax1.text(0.55, 0.10, "self_return", transform=ax1.transAxes)

    # Panel 2: main profiles
    r = profiles["radii"]
    ax2 = fig.add_subplot(2, 2, 2)
    ax2.plot(r, profiles["density_n"], label="density")
    ax2.plot(r, profiles["velocity_n"], label="velocity")
    ax2.plot(r, profiles["twist_n"], label="twist")
    ax2.plot(r, profiles["temperature_n"], label="temperature")
    ax2.axvline(params.i_center, linestyle="--")
    ax2.axvline(params.isco_like_radius, linestyle=":")
    ax2.set_title("Primary Profiles (normalized)")
    ax2.set_xlabel("radius")
    ax2.set_ylabel("normalized value")
    ax2.legend(fontsize=8)

    # Panel 3: physical links
    ax3 = fig.add_subplot(2, 2, 3)
    ax3.plot(r, profiles["angular_momentum_n"], label="angular momentum")
    ax3.plot(r, profiles["shear_n"], label="shear")
    ax3.plot(r, profiles["dissipation_n"], label="dissipation")
    ax3.plot(r, profiles["infall_n"], label="infall")
    ax3.axvline(params.i_center, linestyle="--")
    ax3.axvline(params.isco_like_radius, linestyle=":")
    ax3.set_title("Physical Link Profiles (normalized)")
    ax3.set_xlabel("radius")
    ax3.set_ylabel("normalized value")
    ax3.legend(fontsize=8)

    # Panel 4: interpretation
    ax4 = fig.add_subplot(2, 2, 4)
    ax4.axis("off")
    text = (
        "Ctp_v2 mapping\n"
        "O = black hole axis\n"
        "∂ = radial gradient\n"
        "I = compression conduit\n"
        "flow = rotation + spiral inflow + shear\n"
        "flow_self_return = stable rotating shell\n"
        "C = stabilized disk structure\n\n"
        "Added in v2:\n"
        "- angular momentum\n"
        "- shear\n"
        "- dissipation\n"
        "- infall speed\n"
    )
    ax4.text(0.02, 0.98, text, va="top")

    plt.tight_layout()
    plt.savefig(output_png, dpi=180)
    plt.close(fig)


def write_summary(params: DiskParamsV2, profiles: Dict[str, List[float]], output_txt: str) -> None:
    summary = summarize_profiles(params, profiles)
    with open(output_txt, "w", encoding="utf-8") as f:
        f.write("Black Hole Accretion Disk v2 Structural Summary\n")
        f.write("==============================================\n\n")
        f.write("Added physical link variables:\n")
        f.write("- angular momentum L(r)\n")
        f.write("- shear |dv/dr|\n")
        f.write("- dissipation = shear * twist\n")
        f.write("- infall speed (inside ISCO-like radius)\n\n")
        f.write("Interpretation:\n")
        f.write("Outer disk  : relatively stable rotation\n")
        f.write("Conduit I   : compression / shear / dissipation rise\n")
        f.write("Inner zone  : angular momentum drop + infall increase\n\n")
        f.write("Sample profiles:\n")
        for key, values in summary.items():
            f.write(f"{key}: {values}\n")


def main() -> None:
    params = DiskParamsV2()
    profiles = build_profiles(params)

    py_path = "/mnt/data/blackhole_disk_simulation_v2.py"
    png_path = "/mnt/data/blackhole_disk_simulation_v2.png"
    txt_path = "/mnt/data/blackhole_disk_simulation_v2_summary.txt"

    plot_disk_and_profiles(params, profiles, png_path)
    write_summary(params, profiles, txt_path)

    print(py_path)
    print(png_path)
    print(txt_path)


if __name__ == "__main__":
    main()
