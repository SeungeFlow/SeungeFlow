# blackhole_disk_simulation.py
# Ctp_v2 기반 블랙홀 강착원반 최소 구조 시뮬레이션
# 목적:
# - 정밀 천체물리 계산이 아니라
# - Twist / I / flow / self_return 구조를 눈에 보이게 만드는 최소 엔진

import math
from dataclasses import dataclass
from typing import Dict, List, Tuple

import matplotlib.pyplot as plt


@dataclass
class DiskParams:
    """강착원반 구조 파라미터."""
    r_min: float = 0.12          # 중심 블랙홀 이벤트 영역 근방
    r_max: float = 1.0           # 원반 외곽
    n_rings: int = 220           # 반경 샘플 수
    n_points: int = 360          # 각 링당 점 수
    i_center: float = 0.34       # I(압착 통로) 중심 반경
    i_width: float = 1.0 / 8.0   # 시각화용 I 폭(구조적 해상도 표현)
    twist_base: float = 0.18     # 기본 twist
    twist_peak: float = 0.42     # I 근방 twist 증폭
    inward_pull: float = 0.22    # 내부 낙하 경향
    spiral_gain: float = 3.2     # 나선 말림 정도
    self_return_band: Tuple[float, float] = (0.55, 0.88)  # 안정 회전층


def gaussian(x: float, mu: float, sigma: float) -> float:
    if sigma <= 0:
        return 0.0
    z = (x - mu) / sigma
    return math.exp(-0.5 * z * z)


def clamp(v: float, low: float, high: float) -> float:
    return max(low, min(high, v))


def density_profile(r: float, params: DiskParams) -> float:
    """
    바깥쪽은 완만, I 근방은 압착으로 밀도 상승, 중심 근방은 다시 붕괴.
    """
    outer_decay = 1.0 - 0.72 * r
    i_bump = 0.55 * gaussian(r, params.i_center, params.i_width * 0.42)
    inner_loss = 0.80 * gaussian(r, params.r_min + 0.05, 0.07)
    rho = outer_decay + i_bump - inner_loss
    return clamp(rho, 0.02, 1.0)


def velocity_profile(r: float, params: DiskParams) -> float:
    """
    안쪽으로 갈수록 속도 증가, I 근방에서 전이 가속.
    """
    base = 0.55 / math.sqrt(max(r, 0.04))
    i_accel = 0.28 * gaussian(r, params.i_center, params.i_width * 0.38)
    return base + i_accel


def twist_profile(r: float, params: DiskParams) -> float:
    """
    Twist는 제거 대상이 아니라 구조 유지 엔진.
    I 근방에서 최대.
    """
    return params.twist_base + params.twist_peak * gaussian(r, params.i_center, params.i_width * 0.34)


def temperature_profile(r: float, params: DiskParams) -> float:
    """
    중심으로 갈수록 가열되며 I 근방에서 마찰/전단 상승.
    """
    core_heat = 1.15 / max(r, 0.08)
    i_heat = 0.85 * gaussian(r, params.i_center, params.i_width * 0.35)
    return core_heat + i_heat


def classify_region(r: float, params: DiskParams) -> str:
    """
    구조 해석용 구간 분류
    """
    if r < params.r_min + 0.08:
        return "inner_collapse"
    if abs(r - params.i_center) <= params.i_width * 0.5:
        return "conduit_I"
    if params.self_return_band[0] <= r <= params.self_return_band[1]:
        return "self_return_band"
    return "outer_disk"


def generate_disk_points(params: DiskParams) -> Tuple[List[float], List[float], List[float], List[str]]:
    """
    2D 평면에 강착원반 구조를 생성한다.
    x, y, density, region 리스트 반환.
    """
    xs: List[float] = []
    ys: List[float] = []
    ds: List[float] = []
    regions: List[str] = []

    radii = [
        params.r_min + (params.r_max - params.r_min) * i / (params.n_rings - 1)
        for i in range(params.n_rings)
    ]

    for r in radii:
        rho = density_profile(r, params)
        vel = velocity_profile(r, params)
        twist = twist_profile(r, params)
        temp = temperature_profile(r, params)
        region = classify_region(r, params)

        for j in range(params.n_points):
            theta = 2.0 * math.pi * j / params.n_points

            # 핵심: 반경에 따라 나선형 위상 오프셋을 준다.
            # 단순 원이 아니라 "회전 + 압착 + 누적" 구조가 보이게 한다.
            spiral_phase = params.spiral_gain * (1.0 - r) * (1.0 + twist)
            local_warp = 0.10 * twist * math.sin(3.0 * theta + 5.0 * r)

            # I 근방에서 압착(반경 감소), 바깥은 비교적 안정.
            conduit_pull = params.inward_pull * gaussian(r, params.i_center, params.i_width * 0.32)
            collapse_pull = 0.12 * gaussian(r, params.r_min + 0.03, 0.05)

            r_eff = r * (1.0 - conduit_pull - collapse_pull) + local_warp * 0.03

            x = r_eff * math.cos(theta + spiral_phase + 0.02 * vel)
            y = r_eff * math.sin(theta + spiral_phase + 0.02 * vel)

            # 시각화용 intensity
            intensity = clamp(0.45 * rho + 0.18 * vel + 0.07 * twist + 0.03 * temp, 0.0, 1.0)

            xs.append(x)
            ys.append(y)
            ds.append(intensity)
            regions.append(region)

    return xs, ys, ds, regions


def summarize_structure(params: DiskParams) -> Dict[str, Dict[str, float]]:
    """
    구조 해석 텍스트 출력용 요약.
    """
    sample_r = [params.r_min, params.i_center - params.i_width * 0.45, params.i_center,
                params.i_center + params.i_width * 0.45, 0.72, params.r_max]

    table: Dict[str, Dict[str, float]] = {}
    for r in sample_r:
        table[f"r={r:.3f}"] = {
            "density": round(density_profile(r, params), 4),
            "velocity": round(velocity_profile(r, params), 4),
            "twist": round(twist_profile(r, params), 4),
            "temperature": round(temperature_profile(r, params), 4),
        }
    return table


def plot_disk(params: DiskParams, output_png: str) -> None:
    xs, ys, ds, regions = generate_disk_points(params)

    fig, ax = plt.subplots(figsize=(8, 8))
    ax.scatter(xs, ys, c=ds, s=2, alpha=0.65)
    ax.set_aspect("equal")
    ax.set_title("Black Hole Accretion Disk (Ctp_v2 structural view)")
    ax.set_xlabel("x")
    ax.set_ylabel("y")

    # 중심 블랙홀 이벤트 영역
    center = plt.Circle((0, 0), params.r_min * 0.78, fill=False, linewidth=2)
    ax.add_patch(center)

    # I 통로 가이드 원
    conduit = plt.Circle((0, 0), params.i_center, fill=False, linewidth=1.2, linestyle="--")
    ax.add_patch(conduit)

    # self_return band 가이드
    stable = plt.Circle((0, 0), sum(params.self_return_band) / 2.0, fill=False, linewidth=1.0, linestyle=":")
    ax.add_patch(stable)

    ax.text(0.02, 0.02, "O", transform=ax.transAxes)
    ax.text(0.70, 0.92, "I", transform=ax.transAxes)
    ax.text(0.60, 0.10, "self_return band", transform=ax.transAxes)

    lim = params.r_max * 1.1
    ax.set_xlim(-lim, lim)
    ax.set_ylim(-lim, lim)
    plt.tight_layout()
    plt.savefig(output_png, dpi=180)
    plt.close(fig)


def main() -> None:
    params = DiskParams()
    output_png = "/mnt/data/blackhole_disk_simulation.png"
    plot_disk(params, output_png)

    summary = summarize_structure(params)

    output_txt = "/mnt/data/blackhole_disk_simulation_summary.txt"
    with open(output_txt, "w", encoding="utf-8") as f:
        f.write("Black Hole Accretion Disk Structural Summary\n")
        f.write("===========================================\n\n")
        f.write("Core mapping:\n")
        f.write("O = black hole axis\n")
        f.write("∂ = radial density/velocity/temperature difference\n")
        f.write("I = accretion conduit near critical band\n")
        f.write("flow = rotation + inward spiral + shear accumulation\n")
        f.write("flow_self_return = stable rotating band\n")
        f.write("C = stabilized accretion disk shell\n\n")
        f.write("Sample profiles:\n")
        for key, values in summary.items():
            f.write(f"{key}: {values}\n")

    print("/mnt/data/blackhole_disk_simulation.py")
    print(output_png)
    print(output_txt)


if __name__ == "__main__":
    main()
