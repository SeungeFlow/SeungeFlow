# Ctp_v2_Attractor_0017

## 상태
Field → Attractor 전환 단계

---

## 구조

Field → Interference → Pattern Selection → Attractor

---

## 정의

Attractor = 반복되어 사라지지 않는 안정 구조

---

## 생성 과정

Layer 간 간섭 → Field 형성  
Field 내부 상호작용 → 패턴 생성  
패턴 중 일부만 유지 → Attractor 형성

---

## 조건

- 반복 유지 가능
- 구조 붕괴 없음
- flow_self_return 지속
- topology 유지

---

## 특징

- 안정성
- 반복성
- 자기 유지
- 외부 영향에 대한 저항

---

## 관계

Field ⊃ Attractor  
Attractor ⊂ 안정 패턴 집합

---

## 의미

모든 패턴이 살아남지 않고  
일부만 지속적으로 유지된다

---

## 확장

Flow → Layer → Field → Attractor

---

## One Line

장이 형성되면 그 안에서 살아남는 구조가 결정된다
