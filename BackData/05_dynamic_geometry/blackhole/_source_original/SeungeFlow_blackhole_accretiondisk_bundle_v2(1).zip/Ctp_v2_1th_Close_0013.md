# Ctp_v2_1th_Close_0013

## 상태
ㅇ 발생 조건 확정

---

## Core Pattern

ㆍ → ㅡ → ㅎ → ㅣ → ㅇ

---

## Trigger

flow_self_return = true
boundary_match = true
topology_match = 1
curvature_alignment = maximum

---

## Supporting Conditions (Non-decisive)

pressure ≥ threshold
density ≥ threshold

---

## Decision Rule

curvature_alignment = maximum
→ ㅇ 발생

---

## Sequence

ㆍㅡㅎㅣ → (조건 충족) → ㆍㅡㅎㅣㅇ

---

## Principle

압력/밀도 = 충분조건 후보
곡률정렬 = 결정조건

---

## Meaning

닫힘은 축적이 아니라
정확한 정렬에서 발생

---

## One Line

ㅇ은 밀려서 생기는 것이 아니라
맞아서 생긴다
