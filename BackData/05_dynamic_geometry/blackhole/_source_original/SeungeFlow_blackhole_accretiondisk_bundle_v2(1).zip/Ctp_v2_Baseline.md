# Ctp_v2_Baseline

## Core Structure

O → ∂ → I → flow → flow_self_return → C

---

## Core Definitions

O = 관측 기준 (이동 가능)
∂ = 차이 (전이 시작 조건)
t = 전이 (연속 흐름)
I = 통로 / 임계사이영역 / 판별층
flow = 전이 누적 / 순환
flow_self_return = 자기 회귀 조건
C = 되돌아온 상태 (고착)

---

## Core Relations

∂ ≠ 0 → t ≠ 0
t ≠ 0 → I ≠ ∅
flow_self_return ∧ boundary_match → C

---

## Layers

t = 원인층
flow = 진행층
I = 통과층
gap = 결과층
C = 구조층

---

## Key Distinction

gap ≠ t
gap = shadow(t)

---

## Resolution

1/128 = I 내부 해상도
±1/128 = 임계 영역
±1/256 = 중심 정렬 영역

---

## Closure

closure ≠ 선언
closure = 판정

true:
Δt → 0 ∧ A_drift → 0 ∧ topology_match = 1

---

## Axis / Space

axis = 기준
I = axis 주변 통로
space = 연결된 간격의 누적

---

## Principle

구조는 값이 아니라 관계다
좌표는 위치가 아니라 흐름이다
닫힘은 끝이 아니라 되돌아옴이다

---

## One Line

gap은 흔적이고 t는 실제다
